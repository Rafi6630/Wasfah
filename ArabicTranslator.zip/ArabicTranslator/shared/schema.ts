import { pgTable, text, serial, integer, boolean, json, timestamp, date, uniqueIndex, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User table schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  username: text("username").default(""),
  bio: text("bio"),
  location: text("location"),
  language: text("language").default("en"),
  theme: text("theme").default("royal"),
  avatar_url: text("avatar_url"),
  dietary_preferences: json("dietary_preferences").$type<string[]>().default([]),
  allergens: json("allergens").$type<string[]>().default([]),
  cuisine_preferences: json("cuisine_preferences").$type<string[]>().default([]),
  skill_level: text("skill_level").default("beginner"),
  pantry_ingredients: json("pantry_ingredients").$type<string[]>().default([]),
  favorites: json("favorites").$type<string[]>().default([]),
  subscription_tier: text("subscription_tier").default("free"),
  subscription_billing_period: text("subscription_billing_period").default("monthly"),
  subscription_start_date: timestamp("subscription_start_date"),
  subscription_end_date: timestamp("subscription_end_date"),
  stripe_customer_id: text("stripe_customer_id"),
  stripe_subscription_id: text("stripe_subscription_id"),
  payment_methods: json("payment_methods").$type<{
    id: string;
    type: string;
    last_four: string;
    expiry_date: string;
    is_default: boolean;
  }[]>().default([]),
  health_goals: json("health_goals").$type<{ 
    calories_per_day?: number;
    protein_per_day?: number;
    fat_per_day?: number;
    carbs_per_day?: number;
  }>(),
  badges: json("badges").$type<string[]>().default([]),
  nutrition_stats: json("nutrition_stats").$type<{
    total_calories_consumed: number;
    total_protein_consumed: number;
    total_fat_consumed: number;
    total_carbs_consumed: number;
    balanced_meals_count: number;
    high_protein_meals_count: number;
    low_fat_meals_count: number;
    low_calorie_meals_count: number;
    vegetarian_meals_count: number;
    healthy_meals_streak: number;
  }>().default({
    total_calories_consumed: 0,
    total_protein_consumed: 0,
    total_fat_consumed: 0,
    total_carbs_consumed: 0,
    balanced_meals_count: 0,
    high_protein_meals_count: 0,
    low_fat_meals_count: 0,
    low_calorie_meals_count: 0,
    vegetarian_meals_count: 0,
    healthy_meals_streak: 0
  }),
  achievements: json("achievements").$type<{
    id: string;
    name: string;
    description: string;
    icon: string;
    earned_at: string;
    progress: number;
    completed: boolean;
  }[]>().default([]),
  role: text("role").default("USER"),
  status: text("status").default("ACTIVE"),
  last_login_at: timestamp("last_login_at"),
  created_at: timestamp("created_at").defaultNow()
});

// Recipe table schema
export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  external_id: text("external_id").notNull().unique(),
  name: text("name").notNull(),
  name_ar: text("name_ar").notNull(),
  image_url: text("image_url"),
  images: json("images").$type<string[]>().default([]),
  video_url: text("video_url"),
  cook_time: integer("cook_time"),
  difficulty: text("difficulty"),
  difficulty_ar: text("difficulty_ar"),
  servings: text("servings"),
  calories: integer("calories"),
  ingredients: json("ingredients").$type<RecipeIngredient[]>(),
  instructions: json("instructions").$type<RecipeInstruction[]>(),
  description: text("description"),
  description_ar: text("description_ar"),
  nutrition_facts: json("nutrition_facts").$type<NutritionFacts>(),
  cuisine: text("cuisine"),
  cuisine_ar: text("cuisine_ar"),
  category: text("category"),
  category_ar: text("category_ar"),
  subcategory: text("subcategory"),
  subcategory_ar: text("subcategory_ar"),
  dietary_types: json("dietary_types").$type<string[]>().default([]),
  is_premium: boolean("is_premium").default(false),
  rating: integer("rating"),
  views_count: integer("views_count").default(0),
  likes_count: integer("likes_count").default(0),
  created_by: integer("created_by").references(() => users.id),
  is_user_generated: boolean("is_user_generated").default(false),
  is_approved: boolean("is_approved").default(true),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

// User Cooking History
export const cooking_history = pgTable("cooking_history", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  recipe_id: text("recipe_id").notNull(),
  cooked_at: timestamp("cooked_at").defaultNow(),
  rating: integer("rating"),
  notes: text("notes")
});

// User Recipe Likes
export const recipe_likes = pgTable("recipe_likes", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  recipe_id: integer("recipe_id").notNull().references(() => recipes.id),
  created_at: timestamp("created_at").defaultNow()
}, (table) => {
  return {
    unq: uniqueIndex("user_recipe_unique_idx").on(table.user_id, table.recipe_id)
  };
});

// Shopping List
export const shopping_lists = pgTable("shopping_lists", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull().default("My Shopping List"),
  items: json("items").$type<ShoppingListItem[]>().default([]),
  is_active: boolean("is_active").default(true),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

// Meal Plans
export const meal_plans = pgTable("meal_plans", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull().default("My Meal Plan"),
  start_date: date("start_date"),
  end_date: date("end_date"),
  is_active: boolean("is_active").default(true),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

// Meal Plan Items
export const meal_plan_items = pgTable("meal_plan_items", {
  id: serial("id").primaryKey(),
  meal_plan_id: integer("meal_plan_id").notNull().references(() => meal_plans.id),
  recipe_id: integer("recipe_id").references(() => recipes.id),
  day_number: integer("day_number").notNull(),
  meal_type: text("meal_type").notNull(), // breakfast, lunch, dinner, snack
  custom_name: text("custom_name"),
  custom_note: text("custom_note"),
  servings: integer("servings").default(1),
  created_at: timestamp("created_at").defaultNow()
});

// Categories Table (For organizing recipes)
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  name_ar: text("name_ar").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon"),
  parent_id: integer("parent_id"),
  description: text("description"),
  description_ar: text("description_ar"),
  is_active: boolean("is_active").default(true),
  created_at: timestamp("created_at").defaultNow()
});

// Achievement Badges
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  name_ar: text("name_ar").notNull(),
  description: text("description").notNull(),
  description_ar: text("description_ar").notNull(),
  icon: text("icon").notNull(),
  category: text("category").notNull(), // nutrition, cooking, exploration
  type: text("type").notNull(), // milestone, streak, collection, special
  threshold: integer("threshold").notNull(), // Value needed to earn the badge
  premium: boolean("premium").default(false), // Is this a premium-only badge
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
});

// User Achievement Records
export const user_achievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  badge_id: integer("badge_id").notNull().references(() => badges.id),
  progress: integer("progress").default(0),
  completed: boolean("completed").default(false),
  earned_at: timestamp("earned_at"),
  created_at: timestamp("created_at").defaultNow(),
  updated_at: timestamp("updated_at").defaultNow()
}, (table) => {
  return {
    unq: uniqueIndex("user_badge_unique_idx").on(table.user_id, table.badge_id)
  };
});

// Define relations
export const usersRelations = relations(users, ({ many }) => ({
  recipes: many(recipes),
  cookingHistory: many(cooking_history),
  recipeLikes: many(recipe_likes),
  shoppingLists: many(shopping_lists),
  mealPlans: many(meal_plans),
  achievements: many(user_achievements)
}));

export const recipesRelations = relations(recipes, ({ one, many }) => ({
  creator: one(users, {
    fields: [recipes.created_by],
    references: [users.id]
  }),
  likes: many(recipe_likes),
  mealPlanItems: many(meal_plan_items)
}));

export const mealPlansRelations = relations(meal_plans, ({ one, many }) => ({
  user: one(users, {
    fields: [meal_plans.user_id],
    references: [users.id]
  }),
  items: many(meal_plan_items)
}));

export const mealPlanItemsRelations = relations(meal_plan_items, ({ one }) => ({
  mealPlan: one(meal_plans, {
    fields: [meal_plan_items.meal_plan_id],
    references: [meal_plans.id]
  }),
  recipe: one(recipes, {
    fields: [meal_plan_items.recipe_id],
    references: [recipes.id]
  })
}));

export const badgesRelations = relations(badges, ({ many }) => ({
  userAchievements: many(user_achievements)
}));

export const userAchievementsRelations = relations(user_achievements, ({ one }) => ({
  user: one(users, {
    fields: [user_achievements.user_id],
    references: [users.id]
  }),
  badge: one(badges, {
    fields: [user_achievements.badge_id],
    references: [badges.id]
  })
}));

// Data types for JSON columns
export interface RecipeIngredient {
  name: string;
  nameAr: string;
  quantity: string;
  unit?: string;
  isOptional?: boolean;
}

export interface RecipeInstruction {
  step: number;
  text: string;
  textAr: string;
  image?: string;
  timer?: number;
}

export interface NutritionFacts {
  calories: number;
  fat: string;
  carbs: string;
  protein: string;
  sodium: string;
  fiber: string;
  sugar?: string;
  cholesterol?: string;
}

export interface ShoppingListItem {
  id: string;
  name: string;
  category?: string;
  quantity?: string;
  unit?: string;
  isChecked: boolean;
  recipeId?: number;
  addedAt: string;
}

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
  name: true,
  username: true,
  language: true,
  avatar_url: true,
  dietary_preferences: true,
  cuisine_preferences: true,
  skill_level: true,
  pantry_ingredients: true,
  favorites: true,
  subscription_tier: true,
  role: true,
  status: true
});

export const insertRecipeSchema = createInsertSchema(recipes);
export const insertCookingHistorySchema = createInsertSchema(cooking_history);
export const insertShoppingListSchema = createInsertSchema(shopping_lists);
export const insertMealPlanSchema = createInsertSchema(meal_plans);
export const insertMealPlanItemSchema = createInsertSchema(meal_plan_items);
export const insertCategorySchema = createInsertSchema(categories);
export const insertRecipeLikeSchema = createInsertSchema(recipe_likes);
export const insertBadgeSchema = createInsertSchema(badges);
export const insertUserAchievementSchema = createInsertSchema(user_achievements);

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type InsertCookingHistory = z.infer<typeof insertCookingHistorySchema>;
export type InsertShoppingList = z.infer<typeof insertShoppingListSchema>;
export type InsertMealPlan = z.infer<typeof insertMealPlanSchema>;
export type InsertMealPlanItem = z.infer<typeof insertMealPlanItemSchema>;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type InsertRecipeLike = z.infer<typeof insertRecipeLikeSchema>;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type InsertUserAchievement = z.infer<typeof insertUserAchievementSchema>;

export type User = typeof users.$inferSelect;
export type Recipe = typeof recipes.$inferSelect;
export type CookingHistory = typeof cooking_history.$inferSelect;
export type ShoppingList = typeof shopping_lists.$inferSelect;
export type MealPlan = typeof meal_plans.$inferSelect;
export type MealPlanItem = typeof meal_plan_items.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type RecipeLike = typeof recipe_likes.$inferSelect;
export type Badge = typeof badges.$inferSelect;
export type UserAchievement = typeof user_achievements.$inferSelect;