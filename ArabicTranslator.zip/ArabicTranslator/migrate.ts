import { drizzle } from 'drizzle-orm/neon-serverless';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import * as schema from "./shared/schema";
import { Pool, neonConfig } from '@neondatabase/serverless';
import ws from "ws";

neonConfig.webSocketConstructor = ws;

// Check for DATABASE_URL
if (!process.env.DATABASE_URL) {
  console.error("Error: DATABASE_URL is not set");
  process.exit(1);
}

async function main() {
  console.log("Starting database migration...");
  
  try {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    const db = drizzle({ client: pool, schema });
    
    console.log("Creating tables...");
    
    // Create tables if they don't exist
    await pool.query(`
      -- Create users table if not exists
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        name TEXT,
        email TEXT,
        language TEXT DEFAULT 'en',
        avatar_url TEXT,
        dietary_preferences JSONB DEFAULT '[]',
        cuisine_preferences JSONB DEFAULT '[]',
        skill_level TEXT DEFAULT 'beginner',
        pantry_ingredients JSONB DEFAULT '[]',
        favorites JSONB DEFAULT '[]',
        health_goals JSONB DEFAULT '[]',
        allergens JSONB DEFAULT '[]',
        is_premium BOOLEAN DEFAULT false,
        subscription_status TEXT DEFAULT 'free',
        subscription_expires TIMESTAMP,
        created_at TIMESTAMP DEFAULT NOW()
      );

      -- Create recipes table if not exists
      CREATE TABLE IF NOT EXISTS recipes (
        id SERIAL PRIMARY KEY,
        external_id TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        name_ar TEXT NOT NULL,
        image_url TEXT,
        images JSONB DEFAULT '[]',
        video_url TEXT,
        cook_time INTEGER,
        difficulty TEXT,
        difficulty_ar TEXT,
        servings TEXT,
        calories INTEGER,
        ingredients JSONB,
        instructions JSONB,
        description TEXT,
        description_ar TEXT,
        nutrition_facts JSONB,
        cuisine TEXT,
        cuisine_ar TEXT,
        category TEXT,
        category_ar TEXT,
        subcategory TEXT,
        subcategory_ar TEXT,
        dietary_types JSONB DEFAULT '[]',
        is_premium BOOLEAN DEFAULT false,
        rating INTEGER,
        views_count INTEGER DEFAULT 0,
        likes_count INTEGER DEFAULT 0,
        created_by INTEGER REFERENCES users(id),
        is_user_generated BOOLEAN DEFAULT false,
        is_approved BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      -- Create cooking_history table if not exists
      CREATE TABLE IF NOT EXISTS cooking_history (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        recipe_id TEXT NOT NULL,
        cooked_at TIMESTAMP DEFAULT NOW(),
        rating INTEGER,
        notes TEXT
      );

      -- Create recipe_likes table if not exists
      CREATE TABLE IF NOT EXISTS recipe_likes (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        recipe_id INTEGER NOT NULL REFERENCES recipes(id),
        created_at TIMESTAMP DEFAULT NOW(),
        CONSTRAINT user_recipe_unique_idx UNIQUE (user_id, recipe_id)
      );

      -- Create shopping_lists table if not exists
      CREATE TABLE IF NOT EXISTS shopping_lists (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        name TEXT NOT NULL DEFAULT 'My Shopping List',
        items JSONB DEFAULT '[]',
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      -- Create meal_plans table if not exists
      CREATE TABLE IF NOT EXISTS meal_plans (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        name TEXT NOT NULL DEFAULT 'My Meal Plan',
        start_date DATE,
        end_date DATE,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      -- Create meal_plan_items table if not exists
      CREATE TABLE IF NOT EXISTS meal_plan_items (
        id SERIAL PRIMARY KEY,
        meal_plan_id INTEGER NOT NULL REFERENCES meal_plans(id),
        recipe_id INTEGER REFERENCES recipes(id),
        day_number INTEGER NOT NULL,
        meal_type TEXT NOT NULL,
        custom_name TEXT,
        custom_note TEXT,
        servings INTEGER DEFAULT 1,
        created_at TIMESTAMP DEFAULT NOW()
      );

      -- Create categories table if not exists
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        name_ar TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        icon TEXT,
        parent_id INTEGER REFERENCES categories(id),
        description TEXT,
        description_ar TEXT,
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    console.log("Migration completed successfully!");
    
  } catch (error) {
    console.error("Migration failed:", error);
    process.exit(1);
  }

  process.exit(0);
}

main();