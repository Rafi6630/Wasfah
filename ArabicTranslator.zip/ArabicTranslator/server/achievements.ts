import { storage } from './storage';
import { 
  User, Badge, UserAchievement, 
  InsertBadge, InsertUserAchievement 
} from '@shared/schema';

// Badge categories
export const BADGE_CATEGORIES = {
  NUTRITION: 'nutrition',
  COOKING: 'cooking',
  EXPLORATION: 'exploration',
  SPECIAL: 'special'
};

// Badge types
export const BADGE_TYPES = {
  MILESTONE: 'milestone',
  STREAK: 'streak',
  COLLECTION: 'collection',
  SPECIAL: 'special'
};

// Predefined badges
export const PREDEFINED_BADGES: InsertBadge[] = [
  // Nutrition Badges
  {
    code: 'balanced_diet_novice',
    name: 'Balanced Diet Novice',
    name_ar: 'مبتدئ في النظام الغذائي المتوازن',
    description: 'Cook 5 balanced meals',
    description_ar: 'طهي 5 وجبات متوازنة',
    icon: 'balanced-diet-1',
    category: BADGE_CATEGORIES.NUTRITION,
    type: BADGE_TYPES.MILESTONE,
    threshold: 5,
    premium: false
  },
  {
    code: 'balanced_diet_enthusiast',
    name: 'Balanced Diet Enthusiast',
    name_ar: 'متحمس للنظام الغذائي المتوازن',
    description: 'Cook 25 balanced meals',
    description_ar: 'طهي 25 وجبة متوازنة',
    icon: 'balanced-diet-2',
    category: BADGE_CATEGORIES.NUTRITION,
    type: BADGE_TYPES.MILESTONE,
    threshold: 25,
    premium: false
  },
  {
    code: 'balanced_diet_master',
    name: 'Balanced Diet Master',
    name_ar: 'خبير في النظام الغذائي المتوازن',
    description: 'Cook 50 balanced meals',
    description_ar: 'طهي 50 وجبة متوازنة',
    icon: 'balanced-diet-3',
    category: BADGE_CATEGORIES.NUTRITION,
    type: BADGE_TYPES.MILESTONE,
    threshold: 50,
    premium: false
  },
  {
    code: 'protein_powerhouse_novice',
    name: 'Protein Powerhouse Novice',
    name_ar: 'مبتدئ في وجبات البروتين',
    description: 'Cook 5 high-protein meals',
    description_ar: 'طهي 5 وجبات عالية البروتين',
    icon: 'protein-1',
    category: BADGE_CATEGORIES.NUTRITION,
    type: BADGE_TYPES.MILESTONE,
    threshold: 5,
    premium: false
  },
  {
    code: 'protein_powerhouse_enthusiast',
    name: 'Protein Powerhouse Enthusiast',
    name_ar: 'متحمس لوجبات البروتين',
    description: 'Cook 25 high-protein meals',
    description_ar: 'طهي 25 وجبة عالية البروتين',
    icon: 'protein-2',
    category: BADGE_CATEGORIES.NUTRITION,
    type: BADGE_TYPES.MILESTONE,
    threshold: 25,
    premium: false
  },
  {
    code: 'protein_powerhouse_master',
    name: 'Protein Powerhouse Master',
    name_ar: 'خبير في وجبات البروتين',
    description: 'Cook 50 high-protein meals',
    description_ar: 'طهي 50 وجبة عالية البروتين',
    icon: 'protein-3',
    category: BADGE_CATEGORIES.NUTRITION,
    type: BADGE_TYPES.MILESTONE,
    threshold: 50,
    premium: true
  },
  
  // Cooking streak badges
  {
    code: 'healthy_streak_beginner',
    name: 'Healthy Streak Beginner',
    name_ar: 'مبتدئ في سلسلة الطهي الصحي',
    description: 'Maintain a 3-day healthy cooking streak',
    description_ar: 'الحفاظ على سلسلة طهي صحي لمدة 3 أيام',
    icon: 'streak-1',
    category: BADGE_CATEGORIES.COOKING,
    type: BADGE_TYPES.STREAK,
    threshold: 3,
    premium: false
  },
  {
    code: 'healthy_streak_intermediate',
    name: 'Healthy Streak Intermediate',
    name_ar: 'متوسط في سلسلة الطهي الصحي',
    description: 'Maintain a 7-day healthy cooking streak',
    description_ar: 'الحفاظ على سلسلة طهي صحي لمدة 7 أيام',
    icon: 'streak-2',
    category: BADGE_CATEGORIES.COOKING,
    type: BADGE_TYPES.STREAK,
    threshold: 7,
    premium: false
  },
  {
    code: 'healthy_streak_advanced',
    name: 'Healthy Streak Advanced',
    name_ar: 'متقدم في سلسلة الطهي الصحي',
    description: 'Maintain a 14-day healthy cooking streak',
    description_ar: 'الحفاظ على سلسلة طهي صحي لمدة 14 يومًا',
    icon: 'streak-3',
    category: BADGE_CATEGORIES.COOKING,
    type: BADGE_TYPES.STREAK,
    threshold: 14,
    premium: false
  },
  {
    code: 'healthy_streak_master',
    name: 'Healthy Streak Master',
    name_ar: 'خبير في سلسلة الطهي الصحي',
    description: 'Maintain a 30-day healthy cooking streak',
    description_ar: 'الحفاظ على سلسلة طهي صحي لمدة 30 يومًا',
    icon: 'streak-4',
    category: BADGE_CATEGORIES.COOKING,
    type: BADGE_TYPES.STREAK,
    threshold: 30,
    premium: true
  },
  
  // Exploration badges
  {
    code: 'global_explorer_novice',
    name: 'Global Explorer Novice',
    name_ar: 'مستكشف عالمي مبتدئ',
    description: 'Cook recipes from 3 different cuisines',
    description_ar: 'طهي وصفات من 3 مطابخ مختلفة',
    icon: 'global-1',
    category: BADGE_CATEGORIES.EXPLORATION,
    type: BADGE_TYPES.COLLECTION,
    threshold: 3,
    premium: false
  },
  {
    code: 'global_explorer_enthusiast',
    name: 'Global Explorer Enthusiast',
    name_ar: 'مستكشف عالمي متحمس',
    description: 'Cook recipes from 7 different cuisines',
    description_ar: 'طهي وصفات من 7 مطابخ مختلفة',
    icon: 'global-2',
    category: BADGE_CATEGORIES.EXPLORATION,
    type: BADGE_TYPES.COLLECTION,
    threshold: 7,
    premium: false
  },
  {
    code: 'global_explorer_master',
    name: 'Global Explorer Master',
    name_ar: 'مستكشف عالمي خبير',
    description: 'Cook recipes from 12 different cuisines',
    description_ar: 'طهي وصفات من 12 مطبخ مختلف',
    icon: 'global-3',
    category: BADGE_CATEGORIES.EXPLORATION,
    type: BADGE_TYPES.COLLECTION,
    threshold: 12,
    premium: true
  }
];

/**
 * Initialize badges in the database
 */
export async function initializeBadges() {
  try {
    const existingBadges = await storage.getAllBadges();
    if (existingBadges.length === 0) {
      for (const badge of PREDEFINED_BADGES) {
        await storage.createBadge(badge);
      }
      console.log('Badges initialized successfully');
    }
  } catch (error) {
    console.error('Error initializing badges:', error);
  }
}

/**
 * Update user's nutrition stats and check for badges
 */
export async function updateNutritionStats(userId: number, recipe: any) {
  try {
    const user = await storage.getUser(userId);
    if (!user) return;

    // Get existing nutrition stats or initialize
    const stats = user.nutrition_stats || {
      total_calories_consumed: 0,
      total_protein_consumed: 0,
      total_fat_consumed: 0,
      total_carbs_consumed: 0,
      balanced_meals_count: 0,
      high_protein_meals_count: 0,
      low_fat_meals_count: 0,
      low_calorie_meals_count: 0,
      vegetarian_meals_count: 0,
      healthy_meals_streak: 0
    };
    
    // Update nutrition stats based on recipe
    if (recipe.nutrition_facts) {
      stats.total_calories_consumed += recipe.nutrition_facts.calories || 0;
      
      // Parse protein value (assuming it's in format like "20g")
      let proteinValue = 0;
      if (recipe.nutrition_facts.protein) {
        const proteinMatch = recipe.nutrition_facts.protein.match(/(\d+)/);
        if (proteinMatch) {
          proteinValue = parseInt(proteinMatch[1]);
          stats.total_protein_consumed += proteinValue;
        }
      }
      
      // Parse fat value
      let fatValue = 0;
      if (recipe.nutrition_facts.fat) {
        const fatMatch = recipe.nutrition_facts.fat.match(/(\d+)/);
        if (fatMatch) {
          fatValue = parseInt(fatMatch[1]);
          stats.total_fat_consumed += fatValue;
        }
      }
      
      // Parse carbs value
      let carbsValue = 0;
      if (recipe.nutrition_facts.carbs) {
        const carbsMatch = recipe.nutrition_facts.carbs.match(/(\d+)/);
        if (carbsMatch) {
          carbsValue = parseInt(carbsMatch[1]);
          stats.total_carbs_consumed += carbsValue;
        }
      }
      
      // Check if this is a balanced meal (good protein, moderate fat, moderate carbs)
      const caloriesPerServing = recipe.nutrition_facts.calories / (recipe.servings ? parseInt(recipe.servings) : 1);
      if (proteinValue >= 15 && fatValue < 20 && caloriesPerServing < 600) {
        stats.balanced_meals_count += 1;
      }
      
      // Check if this is a high-protein meal
      if (proteinValue >= 25) {
        stats.high_protein_meals_count += 1;
      }
      
      // Check if this is a low-fat meal
      if (fatValue < 10) {
        stats.low_fat_meals_count += 1;
      }
      
      // Check if this is a low-calorie meal
      if (caloriesPerServing < 400) {
        stats.low_calorie_meals_count += 1;
      }
      
      // Check if this is a vegetarian meal
      if (recipe.dietary_types && recipe.dietary_types.includes('vegetarian')) {
        stats.vegetarian_meals_count += 1;
      }
      
      // Update healthy meals streak
      if (proteinValue >= 15 && fatValue < 20 && caloriesPerServing < 600) {
        stats.healthy_meals_streak += 1;
      } else {
        stats.healthy_meals_streak = 0;
      }
    }
    
    // Update user's nutrition stats
    await storage.updateUser(userId, { nutrition_stats: stats });
    
    // Check for badges
    await checkForNutritionBadges(userId, stats);
    await checkForStreakBadges(userId, stats);
    
    return stats;
  } catch (error) {
    console.error('Error updating nutrition stats:', error);
    throw error;
  }
}

/**
 * Check and award nutrition badges
 */
async function checkForNutritionBadges(userId: number, stats: any) {
  try {
    // Check balanced diet badges
    await checkBadgeProgress(userId, 'balanced_diet_novice', stats.balanced_meals_count);
    await checkBadgeProgress(userId, 'balanced_diet_enthusiast', stats.balanced_meals_count);
    await checkBadgeProgress(userId, 'balanced_diet_master', stats.balanced_meals_count);
    
    // Check protein powerhouse badges
    await checkBadgeProgress(userId, 'protein_powerhouse_novice', stats.high_protein_meals_count);
    await checkBadgeProgress(userId, 'protein_powerhouse_enthusiast', stats.high_protein_meals_count);
    await checkBadgeProgress(userId, 'protein_powerhouse_master', stats.high_protein_meals_count);
  } catch (error) {
    console.error('Error checking nutrition badges:', error);
  }
}

/**
 * Check and award streak badges
 */
async function checkForStreakBadges(userId: number, stats: any) {
  try {
    // Check streak badges
    await checkBadgeProgress(userId, 'healthy_streak_beginner', stats.healthy_meals_streak);
    await checkBadgeProgress(userId, 'healthy_streak_intermediate', stats.healthy_meals_streak);
    await checkBadgeProgress(userId, 'healthy_streak_advanced', stats.healthy_meals_streak);
    await checkBadgeProgress(userId, 'healthy_streak_master', stats.healthy_meals_streak);
  } catch (error) {
    console.error('Error checking streak badges:', error);
  }
}

/**
 * Check user's progress toward a badge
 */
async function checkBadgeProgress(userId: number, badgeCode: string, currentValue: number) {
  try {
    const badge = await storage.getBadgeByCode(badgeCode);
    if (!badge) return;
    
    // Check if user already has this badge
    const userAchievement = await storage.getUserAchievement(userId, badge.id);
    
    if (userAchievement) {
      // Update progress if not already completed
      if (!userAchievement.completed) {
        const progress = Math.min(currentValue, badge.threshold);
        const completed = progress >= badge.threshold;
        
        await storage.updateUserAchievement(
          userAchievement.id, 
          { 
            progress,
            completed,
            earned_at: completed ? new Date() : null
          }
        );
        
        // If newly completed, update user's badges array
        if (completed && !userAchievement.completed) {
          const user = await storage.getUser(userId);
          if (user) {
            const currentBadges = user.badges || [];
            await storage.updateUser(userId, {
              badges: [...currentBadges, badge.code]
            });
          }
        }
      }
    } else {
      // Create new user achievement entry
      const progress = Math.min(currentValue, badge.threshold);
      const completed = progress >= badge.threshold;
      
      await storage.createUserAchievement({
        user_id: userId,
        badge_id: badge.id,
        progress,
        completed,
        earned_at: completed ? new Date() : null
      });
      
      // If completed on creation, update user's badges array
      if (completed) {
        const user = await storage.getUser(userId);
        if (user) {
          const currentBadges = user.badges || [];
          await storage.updateUser(userId, {
            badges: [...currentBadges, badge.code]
          });
        }
      }
    }
  } catch (error) {
    console.error(`Error checking badge progress for ${badgeCode}:`, error);
  }
}

/**
 * Get user's achievements with badge details
 */
export async function getUserAchievements(userId: number) {
  try {
    const achievements = await storage.getUserAchievementsWithBadges(userId);
    return achievements;
  } catch (error) {
    console.error('Error getting user achievements:', error);
    throw error;
  }
}

/**
 * Get all available badges
 */
export async function getAllBadges() {
  try {
    return await storage.getAllBadges();
  } catch (error) {
    console.error('Error getting all badges:', error);
    throw error;
  }
}