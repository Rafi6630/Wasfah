import { Express } from "express";
import { storage } from "../storage";
import { Recipe, RecipeIngredient, RecipeInstruction } from "@shared/schema";
import { generateRecipeRecommendations, getRecipeById, RecommendationParams } from "../openai";

export function setupRecipesApi(app: Express) {
  // Get recipe recommendations based on user preferences and pantry ingredients
  app.post("/api/recipes/recommend", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const params: RecommendationParams = {
        ingredients: req.body.ingredients || req.user.pantry_ingredients || [],
        dietaryPreferences: req.body.dietaryPreferences || req.user.dietary_preferences || [],
        cuisinePreferences: req.body.cuisinePreferences || req.user.cuisine_preferences || [],
        skillLevel: req.body.skillLevel || req.user.skill_level
      };

      // Get recommendations from OpenAI
      const recommendations = await generateRecipeRecommendations(params);
      
      // Save to history or do other processing if needed
      
      return res.json(recommendations);
    } catch (error) {
      console.error("Error in recipe recommendations:", error);
      return res.status(500).json({ message: "Failed to get recipe recommendations" });
    }
  });

  // Get popular recipes with optional seasonal and festive filtering
  // Note: This must be defined BEFORE the /api/recipes/:id route to avoid conflicts
  app.get("/api/recipes/popular", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Extract seasonal parameters from query
      const season = typeof req.query.season === 'string' ? req.query.season : undefined;
      const festiveEvent = typeof req.query.festiveEvent === 'string' ? req.query.festiveEvent : undefined;
      
      console.log(`Fetching recipes with season: ${season}, festiveEvent: ${festiveEvent}`);
      
      // This would normally fetch from a database of popular recipes filtered by season/event
      // For demo purposes, we'll use our mock recipes and add seasonal tags
      const popularRecipes = await generateRecipeRecommendations({
        ingredients: [],
        dietaryPreferences: req.user.dietary_preferences || [],
        cuisinePreferences: req.user.cuisine_preferences || [],
        season, 
        festiveEvent
      });
      
      // In a real implementation, we would filter recipes based on seasonal tags
      // For demo, we'll just return all recipes with added context
      return res.json(popularRecipes.map(recipe => ({
        ...recipe,
        seasonal: season ? true : undefined,
        festive: festiveEvent ? true : undefined
      })));
    } catch (error) {
      console.error("Error fetching popular recipes:", error);
      return res.status(500).json({ message: "Failed to fetch popular recipes" });
    }
  });

  // Get favorite recipes
  // Note: This must be defined BEFORE the /api/recipes/:id route to avoid conflicts
  app.get("/api/recipes/favorites", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const favorites = req.user.favorites || [];
      
      // Fetch all favorite recipes
      const recipes = await Promise.all(
        favorites.map(id => getRecipeById(id))
      );
      
      return res.json(recipes.filter(Boolean)); // Filter out any null results
    } catch (error) {
      console.error("Error fetching favorites:", error);
      return res.status(500).json({ message: "Failed to fetch favorite recipes" });
    }
  });

  // Get recipe details by ID
  // This must be defined AFTER any other routes that start with /api/recipes/
  app.get("/api/recipes/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const recipeId = req.params.id;
      const recipe = await getRecipeById(recipeId);
      
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      // Check if this is in user's favorites
      const isFavorite = (req.user.favorites || []).includes(recipeId);
      
      return res.json({
        ...recipe,
        isFavorite
      });
    } catch (error) {
      console.error("Error fetching recipe:", error);
      return res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });

  // Toggle favorite recipe
  app.post("/api/recipes/:id/favorite", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const recipeId = req.params.id;
      const isFavorite = req.body.favorite;

      const currentFavorites = req.user.favorites || [];
      let favorites = [...currentFavorites];

      if (isFavorite && !favorites.includes(recipeId)) {
        favorites.push(recipeId);
      } else if (!isFavorite && favorites.includes(recipeId)) {
        favorites = favorites.filter(id => id !== recipeId);
      }

      // Update user favorites
      const updatedUser = await storage.updateUser(req.user.id, { favorites });
      
      return res.json({ isFavorite: favorites.includes(recipeId) });
    } catch (error) {
      console.error("Error updating favorites:", error);
      return res.status(500).json({ message: "Failed to update favorites" });
    }
  });

  // Save cooking history
  app.post("/api/recipes/:id/cooked", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const recipeId = req.params.id;
      
      // Save to cooking history
      await storage.saveCookingHistory(req.user.id, recipeId);
      
      return res.json({ success: true });
    } catch (error) {
      console.error("Error saving cooking history:", error);
      return res.status(500).json({ message: "Failed to save cooking history" });
    }
  });

  // Get cooking history
  app.get("/api/cooking-history", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Get user's cooking history
      const history = await storage.getUserCookingHistory(req.user.id);
      
      // Fetch recipe details for each entry
      const historyWithDetails = await Promise.all(
        history.map(async (entry: any) => {
          const recipe = await getRecipeById(entry.recipe_id);
          return {
            ...entry,
            recipe
          };
        })
      );
      
      return res.json(historyWithDetails.filter((entry: any) => entry.recipe)); // Filter out any null recipe results
    } catch (error) {
      console.error("Error fetching cooking history:", error);
      return res.status(500).json({ message: "Failed to fetch cooking history" });
    }
  });
}
