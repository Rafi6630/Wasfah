import { Request, Response, Express } from "express";
import { storage } from "../storage";

// Admin middleware to check admin rights
function isAdmin(req: Request, res: Response, next: Function) {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  if (req.user.role !== "ADMIN" && req.user.role !== "admin") {
    return res.status(403).json({ message: "Admin access required" });
  }
  
  next();
}

export function setupAdminApi(app: Express) {
  // Middleware for all admin routes
  app.use("/api/admin/*", isAdmin);
  
  // Get admin dashboard stats
  app.get("/api/admin/stats", async (req, res) => {
    try {
      // In a real implementation, these would come from database queries
      const stats = {
        totalUsers: 0,
        newUsers: 0,
        totalRecipes: 0,
        newRecipes: 0,
        activeSubscriptions: 0,
        premiumConversionRate: 0,
        averageRating: 0,
        totalCategories: 0
      };
      
      // Get user stats
      const users = await storage.getAllUsers();
      stats.totalUsers = users.length;
      
      // Count new users (registered in the last 7 days)
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      stats.newUsers = users.filter(user => 
        user.created_at && new Date(user.created_at) > oneWeekAgo
      ).length;
      
      // Get recipe stats
      const recipes = await storage.getAllRecipes();
      stats.totalRecipes = recipes.length;
      
      // Count new recipes (added in the last 7 days)
      stats.newRecipes = recipes.filter(recipe => 
        recipe.created_at && new Date(recipe.created_at) > oneWeekAgo
      ).length;
      
      // Count premium subscriptions
      stats.activeSubscriptions = users.filter(user => 
        user.subscription_tier === "premium" || user.subscription_tier === "PREMIUM"
      ).length;
      
      // Calculate premium conversion rate
      stats.premiumConversionRate = users.length > 0 
        ? (stats.activeSubscriptions / users.length) * 100 
        : 0;
      
      // Calculate average recipe rating
      const ratingsSum = recipes.reduce((sum, recipe) => sum + (recipe.rating || 0), 0);
      stats.averageRating = recipes.length > 0 ? ratingsSum / recipes.length : 0;
      
      // Get category count
      const categories = await storage.getAllCategories();
      stats.totalCategories = categories.length;
      
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Error fetching admin stats" });
    }
  });
  
  // Get all users
  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Apply filters if provided
      let filteredUsers = [...users];
      
      const search = req.query.search as string;
      const status = req.query.status as string;
      const subscription = req.query.subscription as string;
      
      if (search) {
        filteredUsers = filteredUsers.filter(user => 
          user.email.toLowerCase().includes(search.toLowerCase()) || 
          (user.name && user.name.toLowerCase().includes(search.toLowerCase())) ||
          (user.username && user.username.toLowerCase().includes(search.toLowerCase()))
        );
      }
      
      if (status) {
        filteredUsers = filteredUsers.filter(user => 
          user.status && user.status.toUpperCase() === status.toUpperCase()
        );
      }
      
      if (subscription) {
        filteredUsers = filteredUsers.filter(user => {
          if (subscription.toUpperCase() === "PREMIUM") {
            return user.subscription_tier === "premium" || user.subscription_tier === "PREMIUM";
          } else {
            return user.subscription_tier === "free" || user.subscription_tier === "FREE" || !user.subscription_tier;
          }
        });
      }
      
      // Format response to match expected UI format
      const formattedUsers = filteredUsers.map(user => ({
        id: user.id,
        email: user.email,
        username: user.username || user.name || user.email.split('@')[0],
        role: user.role || "USER",
        status: user.status || "ACTIVE",
        subscriptionStatus: (user.subscription_tier === "premium" || user.subscription_tier === "PREMIUM") 
          ? "PREMIUM" 
          : "FREE",
        createdAt: user.created_at || new Date().toISOString(),
        lastLoginAt: user.last_login_at || user.created_at || new Date().toISOString()
      }));
      
      res.json(formattedUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Error fetching users" });
    }
  });
  
  // Get a specific user
  app.get("/api/admin/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error(`Error fetching user ${req.params.id}:`, error);
      res.status(500).json({ message: "Error fetching user" });
    }
  });
  
  // Create a new user
  app.post("/api/admin/users", async (req, res) => {
    try {
      const { email, password, role } = req.body;
      const name = req.body.name || req.body.username || email.split('@')[0];
      
      if (!email || !password) {
        return res.status(400).json({ message: "Email and password are required" });
      }
      
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      const newUser = await storage.createUser({
        email,
        name,
        password,
        role: role || "USER"
      });
      
      res.status(201).json(newUser);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Error creating user" });
    }
  });
  
  // Update a user
  app.patch("/api/admin/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const userData = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updatedUser = await storage.updateUser(userId, userData);
      res.json(updatedUser);
    } catch (error) {
      console.error(`Error updating user ${req.params.id}:`, error);
      res.status(500).json({ message: "Error updating user" });
    }
  });
  
  // Delete a user
  app.delete("/api/admin/users/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      await storage.deleteUser(userId);
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error(`Error deleting user ${req.params.id}:`, error);
      res.status(500).json({ message: "Error deleting user" });
    }
  });
  
  // Recipes endpoints
  
  // Get all recipes
  app.get("/api/admin/recipes", async (req, res) => {
    try {
      const recipes = await storage.getAllRecipes();
      
      // Apply filters if provided
      let filteredRecipes = [...recipes];
      
      const search = req.query.search as string;
      const status = req.query.status as string;
      const category = req.query.category as string;
      const cuisine = req.query.cuisine as string;
      const sort = req.query.sort as string || "name";
      const direction = req.query.direction as string || "asc";
      
      if (search) {
        filteredRecipes = filteredRecipes.filter(recipe => 
          recipe.name.toLowerCase().includes(search.toLowerCase()) || 
          (recipe.description && recipe.description.toLowerCase().includes(search.toLowerCase()))
        );
      }
      
      if (status) {
        filteredRecipes = filteredRecipes.filter(recipe => {
          // Use is_approved as a proxy for status
          if (status.toUpperCase() === "ACTIVE") {
            return recipe.is_approved === true;
          } else if (status.toUpperCase() === "INACTIVE") {
            return recipe.is_approved === false;
          }
          return true;
        });
      }
      
      if (category) {
        filteredRecipes = filteredRecipes.filter(recipe => 
          recipe.category && recipe.category.toLowerCase() === category.toLowerCase()
        );
      }
      
      if (cuisine) {
        filteredRecipes = filteredRecipes.filter(recipe => 
          recipe.cuisine && recipe.cuisine.toLowerCase() === cuisine.toLowerCase()
        );
      }
      
      // Sort recipes
      filteredRecipes.sort((a, b) => {
        // Handle common sort fields explicitly
        if (sort === "name") {
          const aValue = a.name || "";
          const bValue = b.name || "";
          return direction === "asc" 
            ? aValue.localeCompare(bValue) 
            : bValue.localeCompare(aValue);
        } else if (sort === "views_count") {
          const aValue = a.views_count || 0;
          const bValue = b.views_count || 0;
          return direction === "asc" ? aValue - bValue : bValue - aValue;
        } else if (sort === "likes_count") {
          const aValue = a.likes_count || 0;
          const bValue = b.likes_count || 0;
          return direction === "asc" ? aValue - bValue : bValue - aValue;
        } else if (sort === "created_at") {
          const aValue = a.created_at ? new Date(a.created_at).getTime() : 0;
          const bValue = b.created_at ? new Date(b.created_at).getTime() : 0;
          return direction === "asc" ? aValue - bValue : bValue - aValue;
        } else if (sort === "updated_at") {
          const aValue = a.updated_at ? new Date(a.updated_at).getTime() : 0;
          const bValue = b.updated_at ? new Date(b.updated_at).getTime() : 0;
          return direction === "asc" ? aValue - bValue : bValue - aValue;
        }
        
        // Default sort by name
        return direction === "asc" 
          ? (a.name || "").localeCompare(b.name || "") 
          : (b.name || "").localeCompare(a.name || "");
      });
      
      res.json(filteredRecipes);
    } catch (error) {
      console.error("Error fetching recipes:", error);
      res.status(500).json({ message: "Error fetching recipes" });
    }
  });
  
  // Get categories
  app.get("/api/admin/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Error fetching categories" });
    }
  });
  
  // Get cuisines
  app.get("/api/admin/cuisines", async (req, res) => {
    try {
      const cuisines = await storage.getAllCuisines();
      res.json(cuisines);
    } catch (error) {
      console.error("Error fetching cuisines:", error);
      res.status(500).json({ message: "Error fetching cuisines" });
    }
  });
  
  // Get all settings
  app.get("/api/admin/settings", (req, res) => {
    try {
      // Don't expose actual API keys, just the fact that they exist
      const sanitizedSettings = JSON.parse(JSON.stringify(adminSettings));
      
      // If API keys exist, replace them with placeholders
      if (sanitizedSettings.api.openaiApiKey) {
        sanitizedSettings.api.openaiApiKey = "•••••••••••••••••••••••••••••••";
      }
      if (sanitizedSettings.api.stripePublicKey) {
        sanitizedSettings.api.stripePublicKey = "pk_•••••••••••••••••••••••••";
      }
      if (sanitizedSettings.api.stripeSecretKey) {
        sanitizedSettings.api.stripeSecretKey = "sk_•••••••••••••••••••••••••";
      }
      if (sanitizedSettings.api.stripeWebhookSecret) {
        sanitizedSettings.api.stripeWebhookSecret = "whsec_••••••••••••••••••";
      }
      
      res.json(sanitizedSettings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ message: "Error fetching settings" });
    }
  });
  
  // Update general settings
  app.post("/api/admin/settings/general", (req, res) => {
    try {
      // In a real app, you'd validate the request body using a schema
      adminSettings.general = { ...adminSettings.general, ...req.body };
      res.json({ success: true, settings: adminSettings.general });
    } catch (error) {
      console.error("Error updating general settings:", error);
      res.status(500).json({ message: "Error updating general settings" });
    }
  });
  
  // Update email settings
  app.post("/api/admin/settings/email", (req, res) => {
    try {
      adminSettings.email = { ...adminSettings.email, ...req.body };
      res.json({ success: true, settings: adminSettings.email });
    } catch (error) {
      console.error("Error updating email settings:", error);
      res.status(500).json({ message: "Error updating email settings" });
    }
  });
  
  // Update API settings
  app.post("/api/admin/settings/api", (req, res) => {
    try {
      adminSettings.api = { ...adminSettings.api, ...req.body };
      
      // In a real app, you'd verify the API keys work before saving them
      
      // Return success but don't send the actual keys back
      const sanitizedApiSettings = { ...adminSettings.api };
      if (sanitizedApiSettings.openaiApiKey) {
        sanitizedApiSettings.openaiApiKey = "•••••••••••••••••••••••••••••••";
      }
      if (sanitizedApiSettings.stripePublicKey) {
        sanitizedApiSettings.stripePublicKey = "pk_•••••••••••••••••••••••••";
      }
      if (sanitizedApiSettings.stripeSecretKey) {
        sanitizedApiSettings.stripeSecretKey = "sk_•••••••••••••••••••••••••";
      }
      if (sanitizedApiSettings.stripeWebhookSecret) {
        sanitizedApiSettings.stripeWebhookSecret = "whsec_••••••••••••••••••";
      }
      
      res.json({ success: true, settings: sanitizedApiSettings });
    } catch (error) {
      console.error("Error updating API settings:", error);
      res.status(500).json({ message: "Error updating API settings" });
    }
  });
  
  // Update recipe settings
  app.post("/api/admin/settings/recipe", (req, res) => {
    try {
      adminSettings.recipe = { ...adminSettings.recipe, ...req.body };
      res.json({ success: true, settings: adminSettings.recipe });
    } catch (error) {
      console.error("Error updating recipe settings:", error);
      res.status(500).json({ message: "Error updating recipe settings" });
    }
  });
  
  // Update moderation settings
  app.post("/api/admin/settings/moderation", (req, res) => {
    try {
      adminSettings.moderation = { ...adminSettings.moderation, ...req.body };
      res.json({ success: true, settings: adminSettings.moderation });
    } catch (error) {
      console.error("Error updating moderation settings:", error);
      res.status(500).json({ message: "Error updating moderation settings" });
    }
  });
  
  // Recipe approval system
  
  // Get pending recipes for approval
  app.get("/api/admin/recipes/pending", async (req, res) => {
    try {
      const recipes = await storage.getAllRecipes();
      
      // Filter recipes that are pending approval (is_approved = false)
      const pendingRecipes = recipes.filter(recipe => 
        recipe.is_approved === false && recipe.is_user_generated === true
      );
      
      res.json(pendingRecipes);
    } catch (error) {
      console.error("Error fetching pending recipes:", error);
      res.status(500).json({ message: "Error fetching pending recipes" });
    }
  });
  
  // Approve or reject a recipe
  app.post("/api/admin/recipes/:id/approval", async (req, res) => {
    try {
      const recipeId = req.params.id;
      const { action, rejectionReason } = req.body;
      
      if (!action || (action !== "approve" && action !== "reject")) {
        return res.status(400).json({ message: "Invalid action. Must be 'approve' or 'reject'" });
      }
      
      const recipe = await storage.getRecipeByExternalId(recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      // Update recipe approval status
      const isApproved = action === "approve";
      const updatedRecipe = await storage.updateRecipe(recipe.id, { 
        is_approved: isApproved,
        rejection_reason: isApproved ? null : (rejectionReason || "Not specified")
      });
      
      // In a real app, we'd send notifications to the recipe creator
      
      res.json({
        message: `Recipe ${isApproved ? 'approved' : 'rejected'} successfully`,
        recipe: updatedRecipe
      });
    } catch (error) {
      console.error(`Error processing approval for recipe ${req.params.id}:`, error);
      res.status(500).json({ message: "Error processing recipe approval" });
    }
  });
  
  // Update recipe status
  app.patch("/api/admin/recipes/:id/status", async (req, res) => {
    try {
      const recipeId = req.params.id;
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      const recipe = await storage.getRecipeByExternalId(recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      const updatedRecipe = await storage.updateRecipe(recipe.id, { status });
      res.json(updatedRecipe);
    } catch (error) {
      console.error(`Error updating recipe status ${req.params.id}:`, error);
      res.status(500).json({ message: "Error updating recipe status" });
    }
  });
  
  // Update recipe premium status
  app.patch("/api/admin/recipes/:id/premium", async (req, res) => {
    try {
      const recipeId = req.params.id;
      const { isPremium } = req.body;
      
      if (isPremium === undefined) {
        return res.status(400).json({ message: "isPremium is required" });
      }
      
      const recipe = await storage.getRecipeByExternalId(recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      const updatedRecipe = await storage.updateRecipe(recipe.id, { is_premium: isPremium });
      res.json(updatedRecipe);
    } catch (error) {
      console.error(`Error updating recipe premium status ${req.params.id}:`, error);
      res.status(500).json({ message: "Error updating recipe premium status" });
    }
  });
  
  // Delete a recipe
  app.delete("/api/admin/recipes/:id", async (req, res) => {
    try {
      const recipeId = req.params.id;
      
      const recipe = await storage.getRecipeByExternalId(recipeId);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      
      await storage.deleteRecipe(recipe.id);
      res.json({ message: "Recipe deleted successfully" });
    } catch (error) {
      console.error(`Error deleting recipe ${req.params.id}:`, error);
      res.status(500).json({ message: "Error deleting recipe" });
    }
  });

  // Get analytics data
  app.get("/api/admin/analytics", async (req, res) => {
    try {
      const timeRange = req.query.timeRange as string || "month";
      
      // In a production environment, this would fetch real analytics data from the database
      // For now, we'll generate representative analytics data
      
      // Define date ranges based on requested time range
      const now = new Date();
      let startDate: Date;
      
      switch (timeRange) {
        case "week":
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 7);
          break;
        case "quarter":
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 90);
          break;
        case "year":
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 365);
          break;
        case "month":
        default:
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 30);
          break;
      }
      
      // Get all users and recipes for analytics
      const users = await storage.getAllUsers();
      const recipes = await storage.getAllRecipes();
      const categories = await storage.getAllCategories();
      const cuisines = await storage.getAllCuisines();
      
      // Generate analytics data structure
      const analyticsData = {
        // User metrics
        userGrowth: generateUserGrowthData(users, startDate, now, timeRange),
        userEngagement: generateUserEngagementData(users, startDate, now, timeRange),
        userRetention: generateRetentionData(),
        
        // Content metrics
        recipeEngagement: generateRecipeEngagementData(recipes),
        topCategories: generateTopCategoriesData(recipes, categories),
        topCuisines: generateTopCuisinesData(recipes, cuisines),
        
        // Feature usage
        featureUsage: generateFeatureUsageData(),
        
        // Business metrics
        conversionRate: generateConversionRateData(users, startDate, now, timeRange),
        revenue: generateRevenueData(users, startDate, now, timeRange),
        churnRate: generateChurnRateData(startDate, now, timeRange)
      };
      
      res.json(analyticsData);
    } catch (error) {
      console.error("Error generating analytics data:", error);
      res.status(500).json({ message: "Error generating analytics data" });
    }
  });
}

// Helper functions for analytics data generation

function generateUserGrowthData(users: any[], startDate: Date, endDate: Date, timeRange: string) {
  const datePoints = getDatePointsBetween(startDate, endDate, timeRange);
  
  return datePoints.map((date, index) => {
    // Simulate an upward growth trend with some randomness
    const baseNumber = 1000 + (index * 100);
    const newUsers = 10 + Math.floor(Math.random() * 20);
    const premiumPercentage = 0.2 + (index * 0.01);
    
    return {
      date: formatDateForTimeRange(date, timeRange),
      total: baseNumber,
      new: newUsers,
      premium: Math.floor(baseNumber * premiumPercentage)
    };
  });
}

function generateUserEngagementData(users: any[], startDate: Date, endDate: Date, timeRange: string) {
  const datePoints = getDatePointsBetween(startDate, endDate, timeRange);
  
  return datePoints.map(() => {
    return {
      date: formatDateForTimeRange(new Date(startDate), timeRange),
      activeUsers: 200 + Math.floor(Math.random() * 300),
      sessionsPerUser: 2 + (Math.random() * 3),
      avgSessionDuration: 5 + (Math.random() * 15)
    };
  });
}

function generateRetentionData() {
  // Simulate cohort retention data
  return [
    {
      cohort: "Jan 1-7",
      week0: 100,
      week1: 75 + Math.floor(Math.random() * 10),
      week2: 60 + Math.floor(Math.random() * 8),
      week3: 55 + Math.floor(Math.random() * 6),
      week4: 52 + Math.floor(Math.random() * 5)
    },
    {
      cohort: "Jan 8-14",
      week0: 100,
      week1: 78 + Math.floor(Math.random() * 10),
      week2: 62 + Math.floor(Math.random() * 8),
      week3: 58 + Math.floor(Math.random() * 6),
      week4: 54 + Math.floor(Math.random() * 5)
    },
    {
      cohort: "Jan 15-21",
      week0: 100,
      week1: 80 + Math.floor(Math.random() * 10),
      week2: 70 + Math.floor(Math.random() * 8),
      week3: 65 + Math.floor(Math.random() * 6),
      week4: 60 + Math.floor(Math.random() * 5)
    },
    {
      cohort: "Jan 22-28",
      week0: 100,
      week1: 82 + Math.floor(Math.random() * 10),
      week2: 72 + Math.floor(Math.random() * 8),
      week3: 67 + Math.floor(Math.random() * 6),
      week4: 63 + Math.floor(Math.random() * 5)
    },
    {
      cohort: "Feb 1-7",
      week0: 100,
      week1: 85 + Math.floor(Math.random() * 10),
      week2: 75 + Math.floor(Math.random() * 8),
      week3: 70 + Math.floor(Math.random() * 6),
      week4: 68 + Math.floor(Math.random() * 5)
    }
  ];
}

function generateRecipeEngagementData(recipes: any[]) {
  // Use actual recipe data if available, otherwise simulate
  const recipeData = recipes.slice(0, 8).map(recipe => {
    return {
      recipeId: recipe.external_id || recipe.id,
      recipeName: recipe.name,
      views: recipe.views_count || Math.floor(500 + Math.random() * 1000),
      likes: recipe.likes_count || Math.floor(100 + Math.random() * 300),
      cooks: Math.floor(50 + Math.random() * 150),
      avgRating: recipe.rating || (3.5 + Math.random() * 1.5)
    };
  });
  
  // If we don't have enough real recipes, add some simulated ones
  if (recipeData.length < 8) {
    const defaultRecipes = [
      { id: "1", name: "Shawarma" },
      { id: "2", name: "Falafel Wrap" },
      { id: "3", name: "Biryani" },
      { id: "4", name: "Chicken Tikka" },
      { id: "5", name: "Hummus" },
      { id: "6", name: "Tabbouleh" },
      { id: "7", name: "Mansaf" },
      { id: "8", name: "Kunafa" }
    ];
    
    for (let i = recipeData.length; i < 8; i++) {
      const defaultRecipe = defaultRecipes[i];
      recipeData.push({
        recipeId: defaultRecipe.id,
        recipeName: defaultRecipe.name,
        views: Math.floor(500 + Math.random() * 1000),
        likes: Math.floor(100 + Math.random() * 300),
        cooks: Math.floor(50 + Math.random() * 150),
        avgRating: (3.5 + Math.random() * 1.5)
      });
    }
  }
  
  return recipeData;
}

function generateTopCategoriesData(recipes: any[], categories: any[]) {
  // Count recipes per category
  const categoryCounts: Record<string, number> = {};
  
  recipes.forEach(recipe => {
    if (recipe.category) {
      categoryCounts[recipe.category] = (categoryCounts[recipe.category] || 0) + 1;
    }
  });
  
  // Format and sort categories by count
  const topCategories = Object.entries(categoryCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);
  
  // If we don't have enough real categories, add some default ones
  if (topCategories.length < 6) {
    const defaultCategories = [
      { name: "Main Dishes", count: 450 },
      { name: "Desserts", count: 320 },
      { name: "Appetizers", count: 280 },
      { name: "Soups", count: 180 },
      { name: "Salads", count: 220 },
      { name: "Beverages", count: 150 }
    ];
    
    for (let i = topCategories.length; i < 6; i++) {
      topCategories.push(defaultCategories[i]);
    }
  }
  
  return topCategories;
}

function generateTopCuisinesData(recipes: any[], cuisines: any[]) {
  // Count recipes per cuisine
  const cuisineCounts: Record<string, number> = {};
  
  recipes.forEach(recipe => {
    if (recipe.cuisine) {
      cuisineCounts[recipe.cuisine] = (cuisineCounts[recipe.cuisine] || 0) + 1;
    }
  });
  
  // Format and sort cuisines by count
  const topCuisines = Object.entries(cuisineCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);
  
  // If we don't have enough real cuisines, add some default ones
  if (topCuisines.length < 6) {
    const defaultCuisines = [
      { name: "Middle Eastern", count: 380 },
      { name: "Indian", count: 310 },
      { name: "Italian", count: 260 },
      { name: "Mexican", count: 210 },
      { name: "Thai", count: 180 },
      { name: "French", count: 150 }
    ];
    
    for (let i = topCuisines.length; i < 6; i++) {
      topCuisines.push(defaultCuisines[i]);
    }
  }
  
  return topCuisines;
}

function generateFeatureUsageData() {
  // Simulate feature usage data
  return [
    { feature: "Recipe Search", usageCount: 15000, percentUsers: 92 },
    { feature: "Meal Planning", usageCount: 8500, percentUsers: 65 },
    { feature: "Shopping List", usageCount: 7200, percentUsers: 58 },
    { feature: "Dietary Preferences", usageCount: 6300, percentUsers: 52 },
    { feature: "Smart Pantry", usageCount: 5800, percentUsers: 48 },
    { feature: "Recipe Sharing", usageCount: 4500, percentUsers: 38 }
  ];
}

function generateConversionRateData(users: any[], startDate: Date, endDate: Date, timeRange: string) {
  const datePoints = getDatePointsBetween(startDate, endDate, timeRange);
  
  // Calculate base conversion rate from actual user data if available
  const totalUsers = users.length;
  const premiumUsers = users.filter(user => 
    user.subscription_tier === "premium" || user.subscription_tier === "PREMIUM"
  ).length;
  const baseConversionRate = totalUsers > 0 ? (premiumUsers / totalUsers) * 100 : 15;
  
  return datePoints.map((date) => {
    // Add some randomness to conversion rate
    const variationPercent = Math.random() * 20 - 10; // -10% to +10%
    const conversionRate = baseConversionRate * (1 + variationPercent / 100);
    
    const trials = Math.floor(20 + Math.random() * 10);
    const conversions = Math.floor(trials * (conversionRate / 100));
    
    return {
      date: formatDateForTimeRange(date, timeRange),
      rate: conversionRate,
      trials: trials,
      conversions: conversions
    };
  });
}

function generateRevenueData(users: any[], startDate: Date, endDate: Date, timeRange: string) {
  const datePoints = getDatePointsBetween(startDate, endDate, timeRange);
  
  // Calculate base monthly subscription revenue from actual user data if available
  const premiumUsers = users.filter(user => 
    user.subscription_tier === "premium" || user.subscription_tier === "PREMIUM"
  ).length;
  const monthlyPrice = 5.99;
  const baseRevenuePerDay = (premiumUsers * monthlyPrice) / 30;
  
  return datePoints.map((date, index) => {
    // Add growth trend and some randomness to revenue
    const growthFactor = 1 + (index * 0.005); // Small growth over time
    const variationPercent = Math.random() * 30 - 15; // -15% to +15% variation
    
    const subscriptions = Math.floor(premiumUsers * growthFactor * (1 + variationPercent / 100) / 30);
    const amount = subscriptions * monthlyPrice;
    
    return {
      date: formatDateForTimeRange(date, timeRange),
      amount: amount,
      subscriptions: subscriptions
    };
  });
}

function generateChurnRateData(startDate: Date, endDate: Date, timeRange: string) {
  const datePoints = getDatePointsBetween(startDate, endDate, timeRange);
  
  // Simulate churn rate with a base rate of 3%
  const baseChurnRate = 3;
  
  return datePoints.map((date) => {
    // Add some randomness to churn rate
    const variationPercent = Math.random() * 50 - 25; // -25% to +25%
    const churnRate = baseChurnRate * (1 + variationPercent / 100);
    
    const cancelations = Math.floor(Math.random() * 3); // 0-2 cancelations per day
    
    return {
      date: formatDateForTimeRange(date, timeRange),
      rate: churnRate,
      cancelations: cancelations
    };
  });
}

// Utility functions for analytics data generation

function getDatePointsBetween(startDate: Date, endDate: Date, timeRange: string) {
  const datePoints: Date[] = [];
  const currentDate = new Date(startDate);
  
  // Determine increment based on time range
  let increment = 1; // Default to 1 day
  if (timeRange === "quarter" || timeRange === "year") {
    increment = 3; // For longer periods, use larger increments to reduce data points
  }
  
  while (currentDate <= endDate) {
    datePoints.push(new Date(currentDate));
    currentDate.setDate(currentDate.getDate() + increment);
  }
  
  return datePoints;
}

function formatDateForTimeRange(date: Date, timeRange: string) {
  const month = date.toLocaleString('default', { month: 'short' });
  const day = date.getDate();
  
  return `${month} ${day}`;
}

// Admin settings

// In-memory settings store (in a real app, these would be in the database)
const adminSettings = {
  general: {
    siteName: "Recipes Gourmet AI",
    siteDescription: "AI-powered recipe recommendations with culinary elegance",
    logo: "/logo.png",
    featuredRecipesCount: 8,
    defaultLanguage: "en",
    enablePublicRecipes: true,
    enableRecipeSubmissions: true,
    requireApproval: true,
  },
  email: {
    emailFromName: "Recipes Gourmet AI",
    emailFromAddress: "notifications@recipesgourmet.ai",
    emailSignature: "The Recipes Gourmet AI Team",
    welcomeEmailEnabled: true,
    notificationEmailsEnabled: true,
    digestEmailsEnabled: false,
    digestFrequency: "weekly",
  },
  api: {
    openaiApiKey: "",
    stripePublicKey: "",
    stripeSecretKey: "",
    stripeWebhookSecret: "",
  },
  recipe: {
    autoTagging: true,
    enableAIDescriptions: true,
    maximumUserSubmissionsPerDay: 5,
    enableComments: true,
    requireLoginToView: false,
    defaultPrivacy: "public",
  },
  moderation: {
    autoModerateComments: true,
    autoModerateRecipes: true,
    profanityFilter: true,
    adminNotificationOnSubmission: true,
    maximumPendingQueue: 100,
    rejectionReasons: [
      "Incomplete recipe",
      "Inappropriate content",
      "Low quality",
      "Duplicate content",
      "Copyright concerns",
    ],
  },
};