import OpenAI from "openai";
import { enhanceDietaryPrompt, computeDietaryMatchScore } from "./dietary-match";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "sk-demo-key"});

export interface RecipeIngredient {
  name: string;
  nameAr: string;
  quantity: string;
}

export interface RecipeInstruction {
  step: number;
  text: string;
  textAr: string;
}

export interface Recipe {
  id: string;
  name: string;
  nameAr: string;
  matchPercentage?: number;
  dietaryMatchScore?: number;
  dietaryMatchExplanations?: string[];
  cookTime: number;
  imageUrl: string;
  difficulty: string;
  difficultyAr: string;
  servings: string;
  calories: number;
  ingredients: RecipeIngredient[];
  instructions: RecipeInstruction[];
  description: string;
  descriptionAr: string;
  nutritionFacts: {
    calories: number;
    fat: string;
    carbs: string;
    protein: string;
    sodium: string;
    fiber: string;
  };
  cuisine: string;
  cuisineAr: string;
  category: string;
  categoryAr: string;
  rating?: number;
}

export interface RecommendationParams {
  ingredients: string[];
  dietaryPreferences?: string[];
  cuisinePreferences?: string[];
  skillLevel?: string;
  season?: string;
  festiveEvent?: string;
}

// Generate recipe recommendations based on ingredients with advanced dietary matching
export async function generateRecipeRecommendations(
  params: RecommendationParams
): Promise<Recipe[]> {
  const { 
    ingredients, 
    dietaryPreferences = [], 
    cuisinePreferences = [], 
    skillLevel = "beginner",
    season,
    festiveEvent
  } = params;

  if (!ingredients || ingredients.length === 0) {
    // Return mock recipes if no ingredients provided
    // Add seasonal context to mock recipes
    const mockRecipes = getMockRecipes();
    if (season || festiveEvent) {
      // Enhance mock recipes with seasonal attributes
      mockRecipes.forEach(recipe => {
        if (season) {
          recipe.description = `${recipe.description} Perfect for ${season} season.`;
          recipe.descriptionAr = `${recipe.descriptionAr} مثالي لموسم ${season}.`;
        }
        if (festiveEvent) {
          recipe.description = `${recipe.description} Great for ${festiveEvent} celebration.`;
          recipe.descriptionAr = `${recipe.descriptionAr} رائع للاحتفال بـ ${festiveEvent}.`;
        }
      });
    }
    return applyDietaryScoring(mockRecipes, dietaryPreferences);
  }

  try {
    // Enhanced dietary requirements prompt
    const dietaryRequirementsPrompt = enhanceDietaryPrompt(dietaryPreferences);
    
    // Add seasonal and festive context to the prompt
    let seasonalPrompt = "";
    if (season) {
      seasonalPrompt += `The recipes should be appropriate for the ${season} season, using seasonal ingredients and flavors.\n`;
    }
    if (festiveEvent) {
      seasonalPrompt += `The recipes should be suitable for ${festiveEvent} celebrations or festivities.\n`;
    }
    
    const prompt = `
      Create 3 recipe recommendations based on these ingredients: ${ingredients.join(", ")}.
      
      ${dietaryRequirementsPrompt}
      
      ${seasonalPrompt}
      
      Cuisine preferences: ${cuisinePreferences.join(", ") || "Any"}.
      Cooking skill level: ${skillLevel}.
      
      For each recipe:
      1. Be VERY precise about nutritional information to ensure dietary compatibility.
      2. Avoid ANY ingredients that conflict with the specified dietary preferences.
      3. Provide detailed nutritional breakdown for proper dietary assessment.
      
      For each recipe, provide the following in JSON format:
      - id: a unique string identifier
      - name: recipe name in English
      - nameAr: recipe name in Arabic
      - matchPercentage: how well this matches their ingredients (70-100)
      - cookTime: cooking time in minutes
      - imageUrl: a placeholder URL (unsplash food images)
      - difficulty: "Easy", "Medium", or "Hard"
      - difficultyAr: Arabic translation of difficulty
      - servings: number of servings as a string (e.g. "4-6")
      - calories: calories per serving
      - ingredients: array of objects with name (English), nameAr (Arabic), and quantity
      - instructions: array of objects with step number, text (English), and textAr (Arabic)
      - description: brief description in English
      - descriptionAr: brief description in Arabic
      - nutritionFacts: including calories, fat, carbs, protein, sodium, fiber
      - cuisine: cuisine type in English
      - cuisineAr: cuisine type in Arabic
      - category: food category in English (main, dessert, etc.)
      - categoryAr: food category in Arabic
      
      Return as JSON array.
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("Empty response from OpenAI");
    }

    const recipes = JSON.parse(content).recipes || JSON.parse(content);
    const recipesArray = Array.isArray(recipes) ? recipes : getMockRecipes();
    
    // Apply our smart dietary matching algorithm to the recipes
    return applyDietaryScoring(recipesArray, dietaryPreferences);
  } catch (error) {
    console.error("Error generating recipes:", error);
    return applyDietaryScoring(getMockRecipes(), dietaryPreferences);
  }
}

/**
 * Apply dietary scoring to recipes
 * This enhances recipes with dietary match scores and explanations
 */
function applyDietaryScoring(recipes: Recipe[], dietaryPreferences: string[] = []): Recipe[] {
  return recipes.map(recipe => {
    // Only compute matches if dietary preferences exist
    if (dietaryPreferences && dietaryPreferences.length > 0) {
      const { score, matchExplanations, conflictExplanations } = computeDietaryMatchScore(recipe, dietaryPreferences);
      
      // Add dietary match information to the recipe
      return {
        ...recipe,
        dietaryMatchScore: score,
        dietaryMatchExplanations: [...matchExplanations, ...conflictExplanations]
      };
    }
    return recipe;
  });
}

// Get recipe by ID
export async function getRecipeById(id: string): Promise<Recipe | null> {
  // In a real app, this would fetch from a database
  // For demo purposes, return a recipe from our mock data
  const recipes = getMockRecipes();
  const recipe = recipes.find(r => r.id === id);
  return recipe || null;
}

// Helper function to get mock recipes when API fails or for testing
function getMockRecipes(): Recipe[] {
  return [
    {
      id: "recipe1",
      name: "Kabsa Rice with Chicken",
      nameAr: "كبسة بالدجاج",
      matchPercentage: 95,
      cookTime: 45,
      imageUrl: "https://images.unsplash.com/photo-1633321702518-7feccafb94d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      difficulty: "Easy",
      difficultyAr: "سهل",
      servings: "4-6 servings",
      calories: 380,
      ingredients: [
        { name: "Chicken, cut into pieces", nameAr: "دجاج، مقطع إلى قطع", quantity: "1 kg" },
        { name: "Basmati rice", nameAr: "أرز بسمتي", quantity: "500 g" },
        { name: "Onions, chopped", nameAr: "بصل، مفروم", quantity: "2" },
        { name: "Tomatoes, chopped", nameAr: "طماطم، مفرومة", quantity: "3" },
        { name: "Kabsa spice mix", nameAr: "خلطة بهارات الكبسة", quantity: "2 tbsp" }
      ],
      instructions: [
        { step: 1, text: "In a large pot, heat olive oil and sauté the chopped onions until translucent.", textAr: "في قدر كبير، سخني زيت الزيتون وقلي البصل المفروم حتى يصبح شفافاً." },
        { step: 2, text: "Add the chicken pieces and brown on all sides. Add the Kabsa spice mix and stir to coat the chicken.", textAr: "أضيفي قطع الدجاج واطهيها حتى تحمر من جميع الجوانب. أضيفي خلطة بهارات الكبسة وقلبي لتغطية الدجاج." },
        { step: 3, text: "Add the chopped tomatoes and cook until soft. Pour in enough water to cover the chicken and bring to a boil.", textAr: "أضيفي الطماطم المفرومة واطهيها حتى تصبح طرية. صبي ما يكفي من الماء لتغطية الدجاج واتركيه حتى يغلي." },
        { step: 4, text: "Reduce heat, cover, and simmer for 20 minutes until chicken is cooked through. Remove chicken and set aside.", textAr: "خففي النار وغطي القدر واتركيه على نار هادئة لمدة 20 دقيقة حتى ينضج الدجاج. أخرجي الدجاج وضعيه جانباً." },
        { step: 5, text: "Add the washed rice to the pot with the cooking liquid. Cover and cook on low heat for 20 minutes until rice is tender.", textAr: "أضيفي الأرز المغسول إلى القدر مع سائل الطهي. غطي القدر واطهي على نار منخفضة لمدة 20 دقيقة حتى ينضج الأرز." },
        { step: 6, text: "Arrange the cooked chicken pieces on top of the rice, cover, and let rest for 5 minutes. Serve hot with yogurt sauce.", textAr: "رتبي قطع الدجاج المطبوخة فوق الأرز، وغطي القدر، واتركيه يرتاح لمدة 5 دقائق. قدميه ساخناً مع صلصة الزبادي." }
      ],
      description: "Kabsa is a popular traditional Saudi Arabian dish consisting of rice, meat, vegetables, and a blend of aromatic spices. This flavorful one-pot dish is perfect for family gatherings and special occasions.",
      descriptionAr: "الكبسة هي طبق سعودي تقليدي شهير يتكون من الأرز واللحم والخضروات ومزيج من التوابل العطرية. هذا الطبق الغني بالنكهة المطبوخ في وعاء واحد مثالي للتجمعات العائلية والمناسبات الخاصة.",
      nutritionFacts: {
        calories: 380,
        fat: "12g",
        carbs: "45g",
        protein: "28g",
        sodium: "320mg",
        fiber: "3g"
      },
      cuisine: "Saudi Arabian",
      cuisineAr: "سعودي",
      category: "Main Dish",
      categoryAr: "طبق رئيسي",
      rating: 4.8
    },
    {
      id: "recipe2",
      name: "Traditional Mansaf",
      nameAr: "منسف تقليدي",
      matchPercentage: 87,
      cookTime: 90,
      imageUrl: "https://images.unsplash.com/photo-1512058564366-18510be2db19?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      difficulty: "Medium",
      difficultyAr: "متوسط",
      servings: "6-8 servings",
      calories: 450,
      ingredients: [
        { name: "Lamb, cut into pieces", nameAr: "لحم ضأن، مقطع إلى قطع", quantity: "1.5 kg" },
        { name: "Jameed (dried yogurt)", nameAr: "جميد (لبن مجفف)", quantity: "500 g" },
        { name: "Rice", nameAr: "أرز", quantity: "750 g" },
        { name: "Shrak bread", nameAr: "خبز شراك", quantity: "4 pieces" },
        { name: "Almonds and pine nuts", nameAr: "لوز وصنوبر", quantity: "100 g" }
      ],
      instructions: [
        { step: 1, text: "Soak the jameed in water overnight, then blend until smooth.", textAr: "انقعي الجميد في الماء طوال الليل، ثم اخلطيه حتى يصبح ناعمًا." },
        { step: 2, text: "In a large pot, cook the lamb pieces with spices until tender, about 1 hour.", textAr: "في قدر كبير، اطهي قطع لحم الضأن مع التوابل حتى تنضج، حوالي ساعة واحدة." },
        { step: 3, text: "Add the jameed mixture to the lamb and simmer for 30 minutes.", textAr: "أضيفي خليط الجميد إلى اللحم واتركيه على نار هادئة لمدة 30 دقيقة." },
        { step: 4, text: "Cook the rice separately with saffron and spices.", textAr: "اطهي الأرز بشكل منفصل مع الزعفران والتوابل." },
        { step: 5, text: "Layer a large serving dish with shrak bread, then rice, topped with the lamb and jameed sauce.", textAr: "ضعي طبقة من خبز الشراك في صحن تقديم كبير، ثم الأرز، وفوقه اللحم وصلصة الجميد." },
        { step: 6, text: "Garnish with toasted almonds and pine nuts. Serve immediately.", textAr: "زينيه باللوز والصنوبر المحمص. قدميه على الفور." }
      ],
      description: "Mansaf is the national dish of Jordan, made with lamb cooked in a sauce of fermented dried yogurt and served with rice. It is traditionally eaten communally from a large platter.",
      descriptionAr: "المنسف هو الطبق الوطني للأردن، مصنوع من لحم الضأن المطبوخ في صلصة من اللبن المجفف المخمر ويقدم مع الأرز. يتم تناوله تقليديًا بشكل جماعي من طبق كبير.",
      nutritionFacts: {
        calories: 450,
        fat: "18g",
        carbs: "42g",
        protein: "32g",
        sodium: "380mg",
        fiber: "2g"
      },
      cuisine: "Jordanian",
      cuisineAr: "أردني",
      category: "Main Dish",
      categoryAr: "طبق رئيسي",
      rating: 4.7
    },
    {
      id: "recipe3",
      name: "Homemade Hummus",
      nameAr: "حمص بيتي",
      matchPercentage: 82,
      cookTime: 15,
      imageUrl: "https://images.unsplash.com/photo-1577805947697-89e18249d767?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500",
      difficulty: "Easy",
      difficultyAr: "سهل",
      servings: "4 servings",
      calories: 180,
      ingredients: [
        { name: "Chickpeas, cooked", nameAr: "حمص، مطبوخ", quantity: "400 g" },
        { name: "Tahini", nameAr: "طحينة", quantity: "3 tbsp" },
        { name: "Garlic cloves", nameAr: "فصوص ثوم", quantity: "2" },
        { name: "Lemon juice", nameAr: "عصير ليمون", quantity: "2 tbsp" },
        { name: "Olive oil", nameAr: "زيت زيتون", quantity: "2 tbsp" },
        { name: "Salt", nameAr: "ملح", quantity: "to taste" }
      ],
      instructions: [
        { step: 1, text: "Drain the chickpeas, reserving some of the liquid.", textAr: "صفي الحمص، مع الاحتفاظ ببعض السائل." },
        { step: 2, text: "In a food processor, combine chickpeas, tahini, garlic, lemon juice, and salt.", textAr: "في محضر الطعام، اخلطي الحمص والطحينة والثوم وعصير الليمون والملح." },
        { step: 3, text: "Process until smooth, adding reserved liquid as needed to reach desired consistency.", textAr: "اخلطي حتى تصبح ناعمة، مع إضافة السائل المحفوظ حسب الحاجة للوصول إلى القوام المطلوب." },
        { step: 4, text: "Transfer to a serving dish, drizzle with olive oil, and garnish as desired with paprika, chopped parsley, or pine nuts.", textAr: "انقليها إلى طبق التقديم، ورشي زيت الزيتون فوقها، وزينيها حسب الرغبة بالبابريكا أو البقدونس المفروم أو الصنوبر." }
      ],
      description: "Hummus is a creamy Middle Eastern dip made from chickpeas, tahini, lemon juice, and garlic. This homemade version is fresh, flavorful, and much better than store-bought varieties.",
      descriptionAr: "الحمص هو غموس كريمي من الشرق الأوسط مصنوع من الحمص والطحينة وعصير الليمون والثوم. هذه النسخة محلية الصنع طازجة وغنية بالنكهة وأفضل بكثير من الأنواع المباعة في المتاجر.",
      nutritionFacts: {
        calories: 180,
        fat: "9g",
        carbs: "20g",
        protein: "5g",
        sodium: "150mg",
        fiber: "5g"
      },
      cuisine: "Middle Eastern",
      cuisineAr: "شرق أوسطي",
      category: "Appetizer",
      categoryAr: "مقبلات",
      rating: 4.6
    }
  ];
}

// Export categories for the app
export function getCategories() {
  return [
    { id: "meat", name: "Meat", nameAr: "لحوم", icon: "fas fa-drumstick-bite" },
    { id: "dessert", name: "Dessert", nameAr: "حلويات", icon: "fas fa-cake-candles" },
    { id: "drinks", name: "Drinks", nameAr: "مشروبات", icon: "fas fa-martini-glass" },
    { id: "vegan", name: "Vegan", nameAr: "نباتي", icon: "fas fa-seedling" }
  ];
}
