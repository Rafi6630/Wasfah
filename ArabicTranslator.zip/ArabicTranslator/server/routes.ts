import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { setupRecipesApi } from "./api/recipes";
import { setupCategoriesApi } from "./api/categories";
import { setupAdminApi } from "./api/admin";
import { 
  createSubscriptionPaymentIntent, 
  handleSuccessfulPayment, 
  stripe
} from "./stripe";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);
  
  // Setup API routes
  setupRecipesApi(app);
  setupCategoriesApi(app);
  setupAdminApi(app);

  // Subscription management endpoint
  app.post("/api/subscription/update", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { tier, billingPeriod } = req.body;

    if (!tier || !billingPeriod) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    if (!["free", "premium"].includes(tier)) {
      return res.status(400).json({ error: "Invalid subscription tier" });
    }

    if (!["monthly", "yearly"].includes(billingPeriod)) {
      return res.status(400).json({ error: "Invalid billing period" });
    }

    try {
      // Set subscription dates
      const now = new Date();
      const endDate = new Date();
      if (billingPeriod === 'monthly') {
        endDate.setMonth(endDate.getMonth() + 1);
      } else {
        endDate.setFullYear(endDate.getFullYear() + 1);
      }

      // Update user subscription details
      const updatedUser = await storage.updateUser(req.user.id, {
        subscription_tier: tier,
        // Use the fields exactly as they appear in the schema
        // The schema has subscription_billing_period defined
        subscription_billing_period: billingPeriod,
        subscription_start_date: now,
        subscription_end_date: endDate,
      });

      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating subscription:", error);
      res.status(500).json({ error: "Failed to update subscription" });
    }
  });

  // Payment processing endpoints
  app.post("/api/payment/create-intent", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Not authenticated" });
    }

    const { tier, billingPeriod } = req.body;

    if (!tier || !billingPeriod) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    if (tier !== "premium") {
      return res.status(400).json({ error: "Invalid subscription tier" });
    }

    if (!["monthly", "yearly"].includes(billingPeriod)) {
      return res.status(400).json({ error: "Invalid billing period" });
    }

    try {
      const result = await createSubscriptionPaymentIntent(
        req.user.id, 
        "premium", 
        billingPeriod as "monthly" | "yearly"
      );

      if (result.error || !result.clientSecret) {
        return res.status(400).json({ error: result.error || "Failed to create payment intent" });
      }

      res.json({ clientSecret: result.clientSecret });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ error: "Failed to create payment intent" });
    }
  });

  // Webhook for handling Stripe events
  app.post("/api/payment/webhook", async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ error: "Stripe is not configured" });
    }

    const signature = req.headers["stripe-signature"] as string;
    
    if (!signature) {
      return res.status(400).json({ error: "Missing Stripe signature" });
    }

    try {
      // Parse the event
      let event;
      
      try {
        event = stripe.webhooks.constructEvent(
          req.body,
          signature,
          process.env.STRIPE_WEBHOOK_SECRET || ''
        );
      } catch (err) {
        return res.status(400).json({ error: `Webhook signature verification failed: ${err.message}` });
      }

      // Handle the event
      if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object;
        
        // Process the successful payment
        await handleSuccessfulPayment(paymentIntent.id);
      }

      res.status(200).json({ received: true });
    } catch (error) {
      console.error("Error handling webhook:", error);
      res.status(500).json({ error: "Failed to process webhook" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
