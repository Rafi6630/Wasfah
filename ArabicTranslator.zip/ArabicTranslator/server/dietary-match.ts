import { Recipe, RecipeIngredient, NutritionFacts } from '@shared/schema';

// Define dietary preference types and their associated constraints
export interface DietaryPreferenceRule {
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  excludedIngredients: string[];
  maxNutritionValues?: Partial<{
    calories: number;
    fat: number; // g
    carbs: number; // g
    protein: number; // g
    sodium: number; // mg
    sugar: number; // g
    cholesterol: number; // mg
  }>;
  minNutritionValues?: Partial<{
    protein: number; // g
    fiber: number; // g
  }>;
  ingredientCategoriesToAvoid: string[];
}

// Define dietary preferences rules
export const dietaryPreferenceRules: Record<string, DietaryPreferenceRule> = {
  'vegetarian': {
    name: 'Vegetarian',
    nameAr: 'نباتي',
    description: 'No meat, poultry, or seafood',
    descriptionAr: 'بدون لحوم أو دواجن أو مأكولات بحرية',
    excludedIngredients: [
      'beef', 'chicken', 'lamb', 'pork', 'fish', 'shrimp', 'bacon', 'ham', 'turkey',
      'meat', 'veal', 'shellfish', 'crab', 'lobster', 'prawn', 'beef broth', 'chicken broth',
      'lحم بقري', 'دجاج', 'لحم ضأن', 'لحم خنزير', 'سمك', 'جمبري', 'لحم مقدد', 'لحم خنزير مقدد', 'ديك رومي'
    ],
    ingredientCategoriesToAvoid: ['meat', 'poultry', 'seafood']
  },
  'vegan': {
    name: 'Vegan',
    nameAr: 'نباتي صرف',
    description: 'No animal products including eggs and dairy',
    descriptionAr: 'بدون منتجات حيوانية بما في ذلك البيض ومنتجات الألبان',
    excludedIngredients: [
      'beef', 'chicken', 'lamb', 'pork', 'fish', 'shrimp', 'bacon', 'ham', 'turkey',
      'meat', 'veal', 'shellfish', 'crab', 'lobster', 'prawn', 'beef broth', 'chicken broth',
      'eggs', 'egg', 'egg whites', 'egg yolks', 'milk', 'cheese', 'butter', 'cream', 'yogurt',
      'honey', 'gelatin', 'whey', 'casein',
      'لحم بقري', 'دجاج', 'لحم ضأن', 'لحم خنزير', 'سمك', 'جمبري', 'لحم مقدد', 'لحم خنزير مقدد', 'ديك رومي',
      'بيض', 'بياض البيض', 'صفار البيض', 'حليب', 'جبن', 'زبدة', 'كريمة', 'زبادي', 'عسل', 'جيلاتين'
    ],
    ingredientCategoriesToAvoid: ['meat', 'poultry', 'seafood', 'dairy', 'eggs', 'honey']
  },
  'gluten-free': {
    name: 'Gluten-Free',
    nameAr: 'خالٍ من الغلوتين',
    description: 'No wheat, barley, rye, or their derivatives',
    descriptionAr: 'بدون قمح أو شعير أو جاودار أو مشتقاتها',
    excludedIngredients: [
      'wheat', 'wheat flour', 'wheat bread', 'barley', 'rye', 'couscous', 'farina', 'graham flour',
      'semolina', 'spelt', 'bulgur', 'durum', 'kamut', 'seitan', 'triticale', 'malt', 'pasta',
      'all-purpose flour', 'bread flour', 'cake flour', 'self-rising flour',
      'قمح', 'طحين القمح', 'خبز القمح', 'شعير', 'جاودار', 'كسكس', 'فارينا', 'طحين جراهام',
      'سميد', 'حنطة', 'برغل', 'دوروم', 'كاموت', 'سيتان', 'تريتيكالي', 'شعير منبت', 'معكرونة'
    ],
    ingredientCategoriesToAvoid: ['wheat', 'gluten', 'barley', 'rye']
  },
  'dairy-free': {
    name: 'Dairy-Free',
    nameAr: 'خالٍ من منتجات الألبان',
    description: 'No milk, cheese, or other dairy products',
    descriptionAr: 'بدون حليب أو جبن أو منتجات ألبان أخرى',
    excludedIngredients: [
      'milk', 'cheese', 'butter', 'cream', 'yogurt', 'whey', 'casein', 'lactose', 'buttermilk',
      'sour cream', 'half-and-half', 'ice cream', 'custard', 'pudding', 'ghee',
      'حليب', 'جبن', 'زبدة', 'كريمة', 'زبادي', 'مصل اللبن', 'كازين', 'لاكتوز', 'لبن', 'كريمة حامضة'
    ],
    ingredientCategoriesToAvoid: ['dairy', 'milk', 'cheese']
  },
  'keto': {
    name: 'Keto',
    nameAr: 'كيتو',
    description: 'Very low carb, high fat diet',
    descriptionAr: 'نظام غذائي منخفض جدًا بالكربوهيدرات، عالي الدهون',
    excludedIngredients: [
      'sugar', 'honey', 'maple syrup', 'corn syrup', 'agave', 'rice', 'pasta', 'bread', 'cereal',
      'oats', 'quinoa', 'potatoes', 'sweet potatoes', 'beans', 'lentils', 'corn', 'banana',
      'apples', 'oranges', 'grapes', 'pineapple', 'fruit juice', 'soda', 'beer',
      'سكر', 'عسل', 'شراب القيقب', 'شراب الذرة', 'أغاف', 'أرز', 'معكرونة', 'خبز', 'حبوب',
      'شوفان', 'كينوا', 'بطاطا', 'بطاطا حلوة', 'فاصوليا', 'عدس', 'ذرة', 'موز'
    ],
    maxNutritionValues: {
      carbs: 30, // max 30g of carbs per day
    },
    ingredientCategoriesToAvoid: ['sugar', 'grains', 'starchy-vegetables', 'high-carb-fruits']
  },
  'low-calorie': {
    name: 'Low-Calorie',
    nameAr: 'منخفض السعرات الحرارية',
    description: 'Reduced calorie content for weight management',
    descriptionAr: 'محتوى منخفض السعرات الحرارية لإدارة الوزن',
    excludedIngredients: [
      'sugar', 'honey', 'corn syrup', 'maple syrup', 'vegetable oil', 'butter', 'lard', 'heavy cream',
      'سكر', 'عسل', 'شراب الذرة', 'شراب القيقب', 'زيت نباتي', 'زبدة', 'شحم', 'كريمة ثقيلة'
    ],
    maxNutritionValues: {
      calories: 400, // max 400 calories per serving
      fat: 15, // max 15g of fat per serving
    },
    ingredientCategoriesToAvoid: ['high-calorie-sweeteners', 'high-fat']
  },
  'low-sodium': {
    name: 'Low-Sodium',
    nameAr: 'قليل الصوديوم',
    description: 'Reduced salt content for heart health',
    descriptionAr: 'محتوى قليل الملح لصحة القلب',
    excludedIngredients: [
      'salt', 'soy sauce', 'fish sauce', 'miso', 'processed meats', 'bacon', 'deli meat',
      'canned soup', 'bouillon', 'salted butter', 'pickles', 'olives', 'salted nuts',
      'ملح', 'صلصة الصويا', 'صلصة السمك', 'ميسو', 'لحوم معالجة', 'لحم مقدد', 'لحم مدخن',
      'شوربة معلبة', 'مرق', 'زبدة مملحة', 'مخللات', 'زيتون', 'مكسرات مملحة'
    ],
    maxNutritionValues: {
      sodium: 500, // max 500mg of sodium per serving
    },
    ingredientCategoriesToAvoid: ['high-sodium', 'canned-foods', 'processed-meats']
  },
  'low-carb': {
    name: 'Low-Carb',
    nameAr: 'قليل الكربوهيدرات',
    description: 'Reduced carbohydrate intake',
    descriptionAr: 'تناول منخفض للكربوهيدرات',
    excludedIngredients: [
      'sugar', 'honey', 'maple syrup', 'corn syrup', 'agave', 'rice', 'pasta', 'bread', 'cereal',
      'oats', 'quinoa', 'potatoes', 'sweet potatoes', 'beans', 'lentils', 'corn',
      'سكر', 'عسل', 'شراب القيقب', 'شراب الذرة', 'أغاف', 'أرز', 'معكرونة', 'خبز', 'حبوب'
    ],
    maxNutritionValues: {
      carbs: 50, // max 50g of carbs per serving
    },
    ingredientCategoriesToAvoid: ['grains', 'starchy-vegetables', 'sugars']
  },
  'high-protein': {
    name: 'High-Protein',
    nameAr: 'عالي البروتين',
    description: 'Increased protein content for muscle building',
    descriptionAr: 'محتوى عالي من البروتين لبناء العضلات',
    excludedIngredients: [],
    minNutritionValues: {
      protein: 20, // min 20g of protein per serving
    },
    ingredientCategoriesToAvoid: []
  },
  'nut-free': {
    name: 'Nut-Free',
    nameAr: 'خالٍ من المكسرات',
    description: 'No nuts or nut products',
    descriptionAr: 'بدون مكسرات أو منتجات المكسرات',
    excludedIngredients: [
      'almond', 'almonds', 'walnut', 'walnuts', 'pecan', 'pecans', 'cashew', 'cashews',
      'pistachio', 'pistachios', 'hazelnut', 'hazelnuts', 'macadamia', 'pine nut', 'pine nuts',
      'brazil nut', 'brazil nuts', 'chestnut', 'chestnuts', 'peanut', 'peanuts', 'peanut butter',
      'almond milk', 'almond butter', 'peanut oil', 'walnut oil', 'mixed nuts',
      'لوز', 'جوز', 'بقان', 'كاجو', 'فستق', 'بندق', 'مكاديميا', 'صنوبر',
      'جوز برازيلي', 'كستناء', 'فول سوداني', 'زبدة الفول السوداني'
    ],
    ingredientCategoriesToAvoid: ['nuts', 'peanuts', 'tree-nuts']
  }
};

/**
 * Compute match score between a recipe and a user's dietary preferences
 * @param recipe The recipe to evaluate
 * @param userDietaryPreferences Array of user's dietary preference strings
 * @returns Match score (0-100) and explanations for matches/conflicts
 */
export function computeDietaryMatchScore(
  recipe: Recipe, 
  userDietaryPreferences: string[]
): { 
  score: number; 
  matchExplanations: string[];
  conflictExplanations: string[];
  matchDetails: {
    [key: string]: {
      matched: boolean;
      reason?: string;
    }
  }
} {
  // If no preferences, return perfect score
  if (!userDietaryPreferences?.length) {
    return { 
      score: 100, 
      matchExplanations: ["No dietary preferences specified."],
      conflictExplanations: [],
      matchDetails: {}
    };
  }

  let totalScore = 0;
  const matchExplanations: string[] = [];
  const conflictExplanations: string[] = [];
  const matchDetails: { [key: string]: { matched: boolean; reason?: string } } = {};
  
  // Extract recipe data
  const ingredients: RecipeIngredient[] = recipe.ingredients || [];
  const ingredientNames = ingredients.map(ing => ing.name.toLowerCase());
  const nutritionFacts = convertNutritionToNumbers(recipe.nutrition_facts);
  
  // Check each dietary preference
  for (const preference of userDietaryPreferences) {
    const rule = dietaryPreferenceRules[preference];
    if (!rule) {
      // Skip unknown preferences
      matchDetails[preference] = { matched: true, reason: "Unknown preference" };
      continue;
    }
    
    // Check for excluded ingredients
    const excludedFound = rule.excludedIngredients.some(excluded => 
      ingredientNames.some(ingredient => 
        ingredient.includes(excluded.toLowerCase())
      )
    );
    
    // Check nutrition requirements if defined in the rule
    let nutritionMismatch = false;
    let nutritionMismatchReason = "";
    
    if (rule.maxNutritionValues && nutritionFacts) {
      for (const [nutrient, maxValue] of Object.entries(rule.maxNutritionValues)) {
        if (nutritionFacts[nutrient] && nutritionFacts[nutrient] > maxValue) {
          nutritionMismatch = true;
          nutritionMismatchReason = `${nutrient} (${nutritionFacts[nutrient]}) exceeds limit of ${maxValue}`;
          break;
        }
      }
    }
    
    if (rule.minNutritionValues && nutritionFacts) {
      for (const [nutrient, minValue] of Object.entries(rule.minNutritionValues)) {
        if (!nutritionFacts[nutrient] || nutritionFacts[nutrient] < minValue) {
          nutritionMismatch = true;
          const actualValue = nutritionFacts[nutrient] || 0;
          nutritionMismatchReason = `${nutrient} (${actualValue}) below minimum of ${minValue}`;
          break;
        }
      }
    }
    
    // If excluded ingredients found or nutrition requirements not met
    if (excludedFound || nutritionMismatch) {
      let reason = "";
      if (excludedFound) {
        reason = "Contains excluded ingredients";
        conflictExplanations.push(`Recipe contains ingredients not suitable for ${rule.name} diet`);
      }
      if (nutritionMismatch) {
        reason = nutritionMismatchReason;
        conflictExplanations.push(`Recipe nutrition profile doesn't meet ${rule.name} requirements: ${nutritionMismatchReason}`);
      }
      
      matchDetails[preference] = { matched: false, reason };
    } else {
      totalScore += 100;
      matchExplanations.push(`Recipe is suitable for ${rule.name} diet`);
      matchDetails[preference] = { matched: true };
    }
  }
  
  // Normalize score based on number of preferences
  const finalScore = userDietaryPreferences.length > 0 
    ? Math.round(totalScore / userDietaryPreferences.length) 
    : 100;
  
  return {
    score: finalScore,
    matchExplanations,
    conflictExplanations,
    matchDetails
  };
}

/**
 * Helper function to convert nutrition facts strings to numbers
 */
function convertNutritionToNumbers(nutrition?: NutritionFacts): Record<string, number> {
  if (!nutrition) return {};
  
  const result: Record<string, number> = {
    calories: nutrition.calories
  };
  
  // Process other nutrition values to extract numeric portions
  const nutritionFields = ['fat', 'carbs', 'protein', 'sodium', 'fiber', 'sugar', 'cholesterol'];
  
  for (const field of nutritionFields) {
    if (nutrition[field as keyof NutritionFacts]) {
      const value = nutrition[field as keyof NutritionFacts] as string;
      const numericValue = parseFloat(value.replace(/[^0-9.]/g, ''));
      if (!isNaN(numericValue)) {
        result[field] = numericValue;
      }
    }
  }
  
  return result;
}

/**
 * Enhance OpenAI prompt with dietary preference details
 */
export function enhanceDietaryPrompt(dietaryPreferences: string[] = []): string {
  if (!dietaryPreferences?.length) {
    return "No specific dietary preferences.";
  }
  
  let enhancedPrompt = "Please ensure that recipes strictly adhere to the following dietary requirements:\n";
  
  for (const pref of dietaryPreferences) {
    const rule = dietaryPreferenceRules[pref];
    if (rule) {
      enhancedPrompt += `- ${rule.name}: ${rule.description}\n`;
      if (rule.excludedIngredients.length > 0) {
        enhancedPrompt += `  * Avoid these ingredients: ${rule.excludedIngredients.slice(0, 10).join(', ')}\n`;
      }
      if (rule.maxNutritionValues) {
        for (const [nutrient, value] of Object.entries(rule.maxNutritionValues)) {
          enhancedPrompt += `  * Maximum ${nutrient}: ${value}\n`;
        }
      }
      if (rule.minNutritionValues) {
        for (const [nutrient, value] of Object.entries(rule.minNutritionValues)) {
          enhancedPrompt += `  * Minimum ${nutrient}: ${value}\n`;
        }
      }
    }
  }
  
  return enhancedPrompt;
}

/**
 * Check if a recipe is compatible with given dietary preferences
 */
export function isDietaryCompatible(recipe: Recipe, dietaryPreferences: string[] = []): boolean {
  if (!dietaryPreferences?.length) return true;
  
  const matchResult = computeDietaryMatchScore(recipe, dietaryPreferences);
  return matchResult.score >= 90; // Consider a 90% match as compatible
}