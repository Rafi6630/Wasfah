import Stripe from "stripe";
import { User } from "@shared/schema";
import { storage } from "./storage";

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn("STRIPE_SECRET_KEY is not set. Stripe payment processing will not work.");
}

// Initialize Stripe with the secret key from environment variables
export const stripe = process.env.STRIPE_SECRET_KEY ? 
  new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2023-10-16" }) : 
  null;

// Create a Stripe customer for a user
export async function createStripeCustomer(user: User): Promise<string | null> {
  if (!stripe) return null;
  
  try {
    const customer = await stripe.customers.create({
      email: user.email,
      name: user.name || undefined,
      metadata: {
        userId: user.id.toString()
      }
    });
    
    return customer.id;
  } catch (error) {
    console.error("Error creating Stripe customer:", error);
    return null;
  }
}

// Create a payment intent for a subscription
export async function createSubscriptionPaymentIntent(
  userId: number, 
  tier: "premium",
  billingPeriod: "monthly" | "yearly"
): Promise<{ clientSecret: string | null, error?: string }> {
  if (!stripe) return { clientSecret: null, error: "Stripe is not configured" };
  
  try {
    const user = await storage.getUser(userId);
    if (!user) {
      return { clientSecret: null, error: "User not found" };
    }
    
    // Determine the amount based on the subscription tier and billing period
    const amount = billingPeriod === "monthly" ? 599 : 5999; // $5.99 monthly or $59.99 yearly
    
    // If user doesn't have a Stripe customer ID, create one
    let stripeCustomerId = user.stripe_customer_id;
    if (!stripeCustomerId) {
      stripeCustomerId = await createStripeCustomer(user);
      if (stripeCustomerId) {
        await storage.updateUser(userId, { stripe_customer_id: stripeCustomerId });
      }
    }
    
    if (!stripeCustomerId) {
      return { clientSecret: null, error: "Failed to create customer" };
    }
    
    // Create a payment intent
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency: "usd",
      customer: stripeCustomerId,
      metadata: {
        userId: userId.toString(),
        tier,
        billingPeriod
      }
    });
    
    return { clientSecret: paymentIntent.client_secret };
  } catch (error) {
    console.error("Error creating payment intent:", error);
    return { clientSecret: null, error: error.message };
  }
}

// Process a successful payment webhook
export async function handleSuccessfulPayment(paymentIntentId: string): Promise<boolean> {
  if (!stripe) return false;
  
  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
    const { userId, tier, billingPeriod } = paymentIntent.metadata;
    
    if (!userId || !tier || !billingPeriod) {
      console.error("Missing metadata in payment intent");
      return false;
    }
    
    // Update user subscription details
    const now = new Date();
    const endDate = new Date();
    
    if (billingPeriod === 'monthly') {
      endDate.setMonth(endDate.getMonth() + 1);
    } else {
      endDate.setFullYear(endDate.getFullYear() + 1);
    }
    
    await storage.updateUser(parseInt(userId), {
      subscription_tier: tier,
      subscription_billing_period: billingPeriod,
      subscription_start_date: now,
      subscription_end_date: endDate,
    });
    
    return true;
  } catch (error) {
    console.error("Error handling successful payment:", error);
    return false;
  }
}

// Update stripe customer information
export async function updateStripeCustomer(
  user: User,
  updateData: {
    email?: string;
    name?: string;
  }
): Promise<boolean> {
  if (!stripe || !user.stripe_customer_id) return false;
  
  try {
    await stripe.customers.update(user.stripe_customer_id, updateData);
    return true;
  } catch (error) {
    console.error("Error updating Stripe customer:", error);
    return false;
  }
}