import { 
  users, 
  recipes, 
  cooking_history, 
  categories,
  badges,
  user_achievements,
  type User, 
  type InsertUser, 
  type Recipe, 
  type CookingHistory,
  type Category,
  type InsertRecipe,
  type Badge,
  type InsertBadge,
  type UserAchievement,
  type InsertUserAchievement
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, isNotNull } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// PostgreSQL session store for express-session
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User>;
  deleteUser(id: number): Promise<void>;
  getAllUsers(): Promise<User[]>;
  
  // Recipe methods
  getRecipe(id: number): Promise<Recipe | undefined>;
  getRecipeByExternalId(externalId: string): Promise<Recipe | undefined>;
  saveRecipe(recipe: any): Promise<Recipe>;
  updateRecipe(id: number, recipeData: Partial<InsertRecipe>): Promise<Recipe>;
  deleteRecipe(id: number): Promise<void>;
  getAllRecipes(): Promise<Recipe[]>;
  getFavoriteRecipes(userId: number): Promise<Recipe[]>;
  toggleFavorite(userId: number, recipeId: string): Promise<void>;
  
  // Cooking history methods
  saveCookingHistory(userId: number, recipeId: string): Promise<CookingHistory>;
  getUserCookingHistory(userId: number): Promise<CookingHistory[]>;
  
  // Categories and cuisines
  getAllCategories(): Promise<Category[]>;
  getAllCuisines(): Promise<{ id: string; name: string; nameAr: string; }[]>;
  
  // Badge and achievement methods
  getAllBadges(): Promise<Badge[]>;
  getBadge(id: number): Promise<Badge | undefined>;
  getBadgeByCode(code: string): Promise<Badge | undefined>;
  createBadge(badge: InsertBadge): Promise<Badge>;
  updateBadge(id: number, badgeData: Partial<InsertBadge>): Promise<Badge>;
  deleteBadge(id: number): Promise<void>;
  getUserAchievement(userId: number, badgeId: number): Promise<UserAchievement | undefined>;
  getUserAchievementsWithBadges(userId: number): Promise<Array<UserAchievement & { badge: Badge }>>;
  createUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement>;
  updateUserAchievement(id: number, achievementData: Partial<InsertUserAchievement>): Promise<UserAchievement>;
  
  // Session store
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;
  
  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true,
      tableName: 'session'
    });
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    try {
      const result = await pool.query(
        'SELECT * FROM users WHERE id = $1',
        [id]
      );
      if (result.rows.length === 0) {
        return undefined;
      }
      return result.rows[0] as User;
    } catch (error) {
      console.error("Error in getUser:", error);
      return undefined;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const result = await pool.query(
        'SELECT * FROM users WHERE email = $1',
        [email]
      );
      if (result.rows.length === 0) {
        return undefined;
      }
      return result.rows[0] as User;
    } catch (error) {
      console.error("Error in getUserByEmail:", error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      // Create the insert data with explicit types
      const userData = {
        email: insertUser.email,
        password: insertUser.password,
        name: insertUser.name || null,
        language: insertUser.language || 'en',
        avatar_url: insertUser.avatar_url || null,
        dietary_preferences: insertUser.dietary_preferences || [],
        cuisine_preferences: insertUser.cuisine_preferences || [],
        skill_level: insertUser.skill_level || 'beginner',
        pantry_ingredients: insertUser.pantry_ingredients || [],
        favorites: insertUser.favorites || [],
        subscription_tier: insertUser.subscription_tier || 'free'
      };
      
      // Using raw query to avoid Drizzle typing issues
      const result = await pool.query(
        `INSERT INTO users (email, password, name, language, avatar_url, dietary_preferences, cuisine_preferences, skill_level, pantry_ingredients, favorites, subscription_tier) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) 
         RETURNING *`,
        [
          userData.email,
          userData.password,
          userData.name,
          userData.language,
          userData.avatar_url,
          JSON.stringify(userData.dietary_preferences),
          JSON.stringify(userData.cuisine_preferences),
          userData.skill_level,
          JSON.stringify(userData.pantry_ingredients),
          JSON.stringify(userData.favorites),
          userData.subscription_tier
        ]
      );
      
      return result.rows[0] as User;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User> {
    try {
      // Create a strongly-typed object for the update
      const updateData: Record<string, any> = {};
      
      // Only include fields that are provided and exist in the current database
      if (userData.email !== undefined) updateData.email = userData.email;
      if (userData.password !== undefined) updateData.password = userData.password;
      if (userData.name !== undefined) updateData.name = userData.name;
      if (userData.language !== undefined) updateData.language = userData.language;
      if (userData.avatar_url !== undefined) updateData.avatar_url = userData.avatar_url;
      if (userData.dietary_preferences !== undefined) updateData.dietary_preferences = userData.dietary_preferences;
      if (userData.cuisine_preferences !== undefined) updateData.cuisine_preferences = userData.cuisine_preferences;
      if (userData.skill_level !== undefined) updateData.skill_level = userData.skill_level;
      if (userData.pantry_ingredients !== undefined) updateData.pantry_ingredients = userData.pantry_ingredients;
      if (userData.favorites !== undefined) updateData.favorites = userData.favorites;
      if (userData.subscription_tier !== undefined) updateData.subscription_tier = userData.subscription_tier;
      
      // Update the user in the database
      const [updatedUser] = await db
        .update(users)
        .set(updateData)
        .where(eq(users.id, id))
        .returning();
      
      return updatedUser;
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  }
  
  // Recipe methods
  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe;
  }
  
  async getRecipeByExternalId(externalId: string): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.external_id, externalId));
    return recipe;
  }
  
  async saveRecipe(recipeData: any): Promise<Recipe> {
    // First check if the recipe already exists
    const existingRecipe = await this.getRecipeByExternalId(recipeData.external_id);
    
    if (existingRecipe) {
      // Update existing recipe
      const [updatedRecipe] = await db
        .update(recipes)
        .set(recipeData)
        .where(eq(recipes.external_id, recipeData.external_id))
        .returning();
      return updatedRecipe;
    } else {
      // Insert new recipe
      const [newRecipe] = await db
        .insert(recipes)
        .values(recipeData)
        .returning();
      return newRecipe;
    }
  }
  
  async getFavoriteRecipes(userId: number): Promise<Recipe[]> {
    // Get user's favorites
    const user = await this.getUser(userId);
    if (!user || !user.favorites || user.favorites.length === 0) {
      return [];
    }
    
    // Get recipes for each external_id in favorites
    // This is a simplification - in a real app, you'd want to query all favorites
    const favoriteRecipes = await db
      .select()
      .from(recipes)
      .where(eq(recipes.external_id, user.favorites[0])); 
      
    return favoriteRecipes;
  }
  
  async toggleFavorite(userId: number, recipeId: string): Promise<void> {
    const user = await this.getUser(userId);
    if (!user) return;
    
    let favorites = user.favorites as string[] || [];
    const index = favorites.indexOf(recipeId);
    
    if (index > -1) {
      // Remove from favorites
      favorites = favorites.filter(id => id !== recipeId);
    } else {
      // Add to favorites
      favorites.push(recipeId);
    }
    
    await this.updateUser(userId, { favorites: favorites });
  }
  
  // Cooking history methods
  async saveCookingHistory(userId: number, recipeId: string): Promise<CookingHistory> {
    const [history] = await db
      .insert(cooking_history)
      .values({
        user_id: userId,
        recipe_id: recipeId,
      })
      .returning();
    return history;
  }
  
  async getUserCookingHistory(userId: number): Promise<CookingHistory[]> {
    return db
      .select()
      .from(cooking_history)
      .where(eq(cooking_history.user_id, userId))
      .orderBy(desc(cooking_history.cooked_at));
  }
  
  // Admin methods
  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }
  
  async getAllUsers(): Promise<User[]> {
    try {
      const result = await pool.query('SELECT * FROM users');
      return result.rows as User[];
    } catch (error) {
      console.error('Error getting all users:', error);
      return [];
    }
  }
  
  async updateRecipe(id: number, recipeData: Partial<any>): Promise<Recipe> {
    const [updatedRecipe] = await db
      .update(recipes)
      .set(recipeData)
      .where(eq(recipes.id, id))
      .returning();
    return updatedRecipe;
  }
  
  async deleteRecipe(id: number): Promise<void> {
    await db.delete(recipes).where(eq(recipes.id, id));
  }
  
  async getAllRecipes(): Promise<Recipe[]> {
    try {
      const result = await pool.query('SELECT * FROM recipes');
      return result.rows as Recipe[];
    } catch (error) {
      console.error('Error getting all recipes:', error);
      return [];
    }
  }
  
  async getAllCategories(): Promise<any[]> {
    try {
      const result = await pool.query('SELECT * FROM categories');
      return result.rows;
    } catch (error) {
      console.error('Error getting all categories:', error);
      // Return some default categories as fallback
      return [
        { id: "meat", name: "Meat", nameAr: "لحوم" },
        { id: "poultry", name: "Poultry", nameAr: "دواجن" },
        { id: "seafood", name: "Seafood", nameAr: "مأكولات بحرية" },
        { id: "vegetarian", name: "Vegetarian", nameAr: "نباتي" },
        { id: "desserts", name: "Desserts", nameAr: "حلويات" }
      ];
    }
  }
  
  async getAllCuisines(): Promise<{ id: string; name: string; nameAr: string; }[]> {
    // For now we'll return a static list since we don't have a cuisines table
    return [
      { id: "arabic", name: "Arabic", nameAr: "عربي" },
      { id: "asian", name: "Asian", nameAr: "آسيوي" },
      { id: "italian", name: "Italian", nameAr: "إيطالي" },
      { id: "indian", name: "Indian", nameAr: "هندي" },
      { id: "mediterranean", name: "Mediterranean", nameAr: "البحر المتوسط" },
      { id: "mexican", name: "Mexican", nameAr: "مكسيكي" },
      { id: "american", name: "American", nameAr: "أمريكي" },
      { id: "french", name: "French", nameAr: "فرنسي" },
      { id: "turkish", name: "Turkish", nameAr: "تركي" },
      { id: "lebanese", name: "Lebanese", nameAr: "لبناني" }
    ];
  }
  
  // Badge methods
  async getAllBadges(): Promise<Badge[]> {
    try {
      const result = await pool.query('SELECT * FROM badges');
      return result.rows as Badge[];
    } catch (error) {
      console.error('Error getting all badges:', error);
      return [];
    }
  }

  async getBadge(id: number): Promise<Badge | undefined> {
    try {
      const result = await pool.query(
        'SELECT * FROM badges WHERE id = $1',
        [id]
      );
      if (result.rows.length === 0) {
        return undefined;
      }
      return result.rows[0] as Badge;
    } catch (error) {
      console.error('Error getting badge:', error);
      return undefined;
    }
  }

  async getBadgeByCode(code: string): Promise<Badge | undefined> {
    try {
      const result = await pool.query(
        'SELECT * FROM badges WHERE code = $1',
        [code]
      );
      if (result.rows.length === 0) {
        return undefined;
      }
      return result.rows[0] as Badge;
    } catch (error) {
      console.error('Error getting badge by code:', error);
      return undefined;
    }
  }

  async createBadge(badge: InsertBadge): Promise<Badge> {
    try {
      const fields = Object.keys(badge);
      const values = Object.values(badge);
      const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
      
      const result = await pool.query(
        `INSERT INTO badges (${fields.join(', ')})
         VALUES (${placeholders})
         RETURNING *`,
        values
      );
      
      return result.rows[0] as Badge;
    } catch (error) {
      console.error('Error creating badge:', error);
      throw error;
    }
  }

  async updateBadge(id: number, badgeData: Partial<InsertBadge>): Promise<Badge> {
    try {
      const fields = Object.keys(badgeData);
      const values = Object.values(badgeData);
      
      if (fields.length === 0) {
        const badge = await this.getBadge(id);
        if (!badge) {
          throw new Error(`Badge with id ${id} not found`);
        }
        return badge;
      }
      
      const setClause = fields.map((field, i) => `${field} = $${i + 1}`).join(', ');
      
      const result = await pool.query(
        `UPDATE badges
         SET ${setClause}
         WHERE id = $${fields.length + 1}
         RETURNING *`,
        [...values, id]
      );
      
      if (result.rows.length === 0) {
        throw new Error(`Badge with id ${id} not found`);
      }
      
      return result.rows[0] as Badge;
    } catch (error) {
      console.error('Error updating badge:', error);
      throw error;
    }
  }

  async deleteBadge(id: number): Promise<void> {
    try {
      await pool.query(
        'DELETE FROM badges WHERE id = $1',
        [id]
      );
    } catch (error) {
      console.error('Error deleting badge:', error);
      throw error;
    }
  }

  // User Achievement methods
  async getUserAchievement(userId: number, badgeId: number): Promise<UserAchievement | undefined> {
    try {
      const result = await pool.query(
        'SELECT * FROM user_achievements WHERE user_id = $1 AND badge_id = $2',
        [userId, badgeId]
      );
      
      if (result.rows.length === 0) {
        return undefined;
      }
      
      return result.rows[0] as UserAchievement;
    } catch (error) {
      console.error('Error getting user achievement:', error);
      return undefined;
    }
  }

  async getUserAchievementsWithBadges(userId: number): Promise<Array<UserAchievement & { badge: Badge }>> {
    try {
      const result = await pool.query(
        `SELECT ua.*, b.*
         FROM user_achievements ua
         JOIN badges b ON ua.badge_id = b.id
         WHERE ua.user_id = $1`,
        [userId]
      );
      
      return result.rows.map(row => {
        // Extract badge fields from the row
        const badge: Badge = {
          id: row.id,
          code: row.code,
          name: row.name,
          name_ar: row.name_ar,
          description: row.description,
          description_ar: row.description_ar,
          icon: row.icon,
          category: row.category,
          type: row.type,
          threshold: row.threshold,
          premium: row.premium,
          created_at: row.created_at
        };
        
        // Extract user achievement fields
        const achievement: UserAchievement = {
          id: row.id,
          user_id: row.user_id,
          badge_id: row.badge_id,
          progress: row.progress,
          completed: row.completed,
          earned_at: row.earned_at,
          created_at: row.created_at
        };
        
        return {
          ...achievement,
          badge
        };
      });
    } catch (error) {
      console.error('Error getting user achievements with badges:', error);
      return [];
    }
  }

  async createUserAchievement(achievement: InsertUserAchievement): Promise<UserAchievement> {
    try {
      const fields = Object.keys(achievement);
      const values = Object.values(achievement);
      const placeholders = values.map((_, i) => `$${i + 1}`).join(', ');
      
      const result = await pool.query(
        `INSERT INTO user_achievements (${fields.join(', ')})
         VALUES (${placeholders})
         RETURNING *`,
        values
      );
      
      return result.rows[0] as UserAchievement;
    } catch (error) {
      console.error('Error creating user achievement:', error);
      throw error;
    }
  }

  async updateUserAchievement(id: number, achievementData: Partial<InsertUserAchievement>): Promise<UserAchievement> {
    try {
      const fields = Object.keys(achievementData);
      const values = Object.values(achievementData);
      
      if (fields.length === 0) {
        throw new Error('No fields to update');
      }
      
      const setClause = fields.map((field, i) => `${field} = $${i + 1}`).join(', ');
      
      const result = await pool.query(
        `UPDATE user_achievements
         SET ${setClause}
         WHERE id = $${fields.length + 1}
         RETURNING *`,
        [...values, id]
      );
      
      if (result.rows.length === 0) {
        throw new Error(`User achievement with id ${id} not found`);
      }
      
      return result.rows[0] as UserAchievement;
    } catch (error) {
      console.error('Error updating user achievement:', error);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();
