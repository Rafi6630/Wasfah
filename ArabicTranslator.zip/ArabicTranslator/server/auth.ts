import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  // Use environment variable for session secret
  if (!process.env.SESSION_SECRET) {
    console.warn("SESSION_SECRET is not set! Using fallback secret.");
  }
  
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "wasfahaisecret",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax'
    }
  };

  app.set('trust proxy', 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(
      { usernameField: 'email' }, // Configure LocalStrategy to use email
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          if (!user || !(await comparePasswords(password, user.password))) {
            return done(null, false);
          } else {
            return done(null, user);
          }
        } catch (error) {
          return done(error);
        }
      }
    ),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const { email, password, name, language } = req.body;
      
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already exists" });
      }

      const user = await storage.createUser({
        email,
        password: await hashPassword(password),
        name,
        language: language || "en",
        dietary_preferences: [],
        cuisine_preferences: [],
        skill_level: "beginner",
        pantry_ingredients: [],
        favorites: [],
        subscription_tier: "free"
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", passport.authenticate("local"), (req, res) => {
    res.status(200).json(req.user);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });

  app.patch("/api/user", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const updatedUser = await storage.updateUser(req.user.id, req.body);
      res.json(updatedUser);
    } catch (error) {
      next(error);
    }
  });
  
  // Endpoints for user preferences
  app.get("/api/user/preferences", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) return res.sendStatus(404);
      
      res.json({
        dietary_preferences: user.dietary_preferences,
        cuisine_preferences: user.cuisine_preferences,
        skill_level: user.skill_level
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });
  
  app.patch("/api/user/preferences", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { dietary_preferences, cuisine_preferences, skill_level } = req.body;
      
      const updatedUser = await storage.updateUser(req.user.id, {
        dietary_preferences,
        cuisine_preferences,
        skill_level
      });
      
      res.json({
        dietary_preferences: updatedUser.dietary_preferences,
        cuisine_preferences: updatedUser.cuisine_preferences,
        skill_level: updatedUser.skill_level
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Endpoints for pantry management
  app.get("/api/user/pantry", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const user = await storage.getUser(req.user.id);
      if (!user) return res.sendStatus(404);
      
      res.json({ pantry_ingredients: user.pantry_ingredients });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pantry ingredients" });
    }
  });
  
  app.patch("/api/user/pantry", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { pantry_ingredients } = req.body;
      const updatedUser = await storage.updateUser(req.user.id, { pantry_ingredients });
      res.json({ pantry_ingredients: updatedUser.pantry_ingredients });
    } catch (error) {
      next(error);
    }
  });
  
  // Endpoints for recipe favorites
  app.get("/api/user/favorites", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const favoriteRecipes = await storage.getFavoriteRecipes(req.user.id);
      res.json({ favorites: favoriteRecipes });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch favorite recipes" });
    }
  });
  
  app.post("/api/user/favorites/:recipeId", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { recipeId } = req.params;
      await storage.toggleFavorite(req.user.id, recipeId);
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({ favorites: user.favorites });
    } catch (error) {
      next(error);
    }
  });
  
  // Endpoint for cooking history
  app.get("/api/user/cooking-history", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const history = await storage.getUserCookingHistory(req.user.id);
      res.json({ cooking_history: history });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cooking history" });
    }
  });
  
  app.post("/api/user/cooking-history/:recipeId", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { recipeId } = req.params;
      const history = await storage.saveCookingHistory(req.user.id, recipeId);
      res.status(201).json(history);
    } catch (error) {
      next(error);
    }
  });
}
