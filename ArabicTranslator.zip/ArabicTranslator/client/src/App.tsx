import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { I18nProvider } from "@/lib/i18n";
import { AnimationProvider } from "@/lib/animation-context";
import { ProtectedRoute } from "@/lib/protected-route";
import { AdminProtectedRoute } from "@/lib/admin-protected-route";
import { StripeProvider } from "@/lib/stripe-provider";
import { TransitionRouter } from "@/components/layout/transition-router";
import NotFound from "@/pages/not-found";
import OnboardingPage from "@/pages/onboarding-page";
import AuthPage from "@/pages/auth-page";
import AdminLoginPage from "@/pages/admin-login";
import PreferencesPage from "@/pages/preferences-page";
import HomePage from "@/pages/home-page";
import SearchPage from "@/pages/search-page";
import RecipeDetailPage from "@/pages/recipe-detail-page";
import GlobalCuisinePage from "@/pages/global-cuisine-page";
import ProfilePage from "@/pages/profile-page";
import PaymentMethodsPage from "@/pages/payment-methods-page";
import CookingHistoryPage from "@/pages/cooking-history-page";
import CreateRecipePage from "@/pages/create-recipe-page";
import SharedRecipesPage from "@/pages/shared-recipes-page";
import SettingsPage from "@/pages/settings-page";
import AboutPage from "@/pages/about-page";
import LegalPage from "@/pages/legal-page";
import MealPlanningPage from "@/pages/meal-planning-page";
import ShoppingListPage from "@/pages/shopping-list-page";
import SmartPantryPage from "@/pages/smart-pantry-page";
import DietaryPreferencesPage from "@/pages/dietary-preferences-page";
import HealthInformationPage from "@/pages/health-information-page";
import SubscriptionPage from "@/pages/subscription-page";
import EditProfilePage from "@/pages/edit-profile-page";
import SplashPage from "@/pages/splash-page";

// Admin pages
import AdminDashboard from "@/pages/admin/index";
import AdminUsers from "@/pages/admin/users";
import AdminRecipes from "@/pages/admin/recipes";
import AdminAnalytics from "@/pages/admin/analytics";
import AdminSettings from "@/pages/admin/settings";
import AdminRecipeApprovals from "@/pages/admin/recipe-approvals";

// For the main app with transitions
function TransitionRouterWrapper() {
  return <TransitionRouter />;
}

// Admin routes don't use the transition router
function AdminRouter() {
  return (
    <Switch>
      <AdminProtectedRoute path="/admin" component={AdminDashboard} />
      <AdminProtectedRoute path="/admin/users" component={AdminUsers} />
      <AdminProtectedRoute path="/admin/recipes" component={AdminRecipes} />
      <AdminProtectedRoute path="/admin/analytics" component={AdminAnalytics} />
      <AdminProtectedRoute path="/admin/settings" component={AdminSettings} />
      <AdminProtectedRoute path="/admin/recipe-approvals" component={AdminRecipeApprovals} />
      <Route path="/admin/*">
        <NotFound />
      </Route>
    </Switch>
  );
}

// Main router that handles both app and admin routing
function Router() {
  return (
    <Switch>
      {/* Admin login route */}
      <Route path="/admin-login" component={AdminLoginPage} />
      
      {/* Admin routes */}
      <Route path="/admin/*">
        <AdminRouter />
      </Route>
      
      {/* Main app routes with transitions */}
      <Route>
        <TransitionRouterWrapper />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <I18nProvider>
          <AuthProvider>
            <StripeProvider>
              <AnimationProvider>
                <Toaster />
                <Router />
              </AnimationProvider>
            </StripeProvider>
          </AuthProvider>
        </I18nProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
