import { apiRequest } from "./queryClient";

// Recipe recommendation interface
export interface RecipeRecommendation {
  id: string;
  name: string;
  nameAr: string;
  matchPercentage: number;
  cookTime: number;
  imageUrl: string;
  difficulty: string;
  servings: string;
  calories: number;
  rating?: number;
  ingredients: Array<{
    name: string;
    nameAr: string;
    quantity: string;
  }>;
  instructions: Array<{
    step: number;
    text: string;
    textAr: string;
  }>;
  description: string;
  descriptionAr: string;
  nutritionFacts: {
    calories: number;
    fat: string;
    carbs: string;
    protein: string;
    sodium: string;
    fiber: string;
  };
  cuisine: string;
  cuisineAr: string;
  category: string;
  categoryAr: string;
}

export interface IngredientSearchParams {
  ingredients: string[];
  dietaryPreferences?: string[];
  cuisinePreferences?: string[];
  skillLevel?: string;
}

// Function to get recipe recommendations based on ingredients
export async function getRecipeRecommendations(
  params: IngredientSearchParams
): Promise<RecipeRecommendation[]> {
  const response = await apiRequest(
    "POST",
    "/api/recipes/recommend",
    params
  );
  return await response.json();
}

// Function to get recipe details
export async function getRecipeById(id: string): Promise<RecipeRecommendation> {
  const response = await apiRequest(
    "GET",
    `/api/recipes/${id}`,
    undefined
  );
  return await response.json();
}

// Function to get popular recipes with optional seasonal parameters
export async function getPopularRecipes(season?: string, festiveEvent?: string): Promise<RecipeRecommendation[]> {
  // Add query parameters if provided
  let url = '/api/recipes/popular';
  const params = new URLSearchParams();
  if (season) params.append('season', season);
  if (festiveEvent) params.append('festiveEvent', festiveEvent);
  
  const queryString = params.toString();
  if (queryString) url += `?${queryString}`;
  
  const response = await apiRequest(
    "GET",
    url,
    undefined
  );
  return await response.json();
}

// Function to get recipe categories
export interface Category {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
}

export async function getCategories(): Promise<Category[]> {
  const response = await apiRequest(
    "GET",
    "/api/categories",
    undefined
  );
  return await response.json();
}
