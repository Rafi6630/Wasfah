import React, { createContext, useState, useContext, ReactNode } from 'react';
import { translations as extraTranslations } from './translations';

// Define the structure of our translations
interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

// Our translations object
const translations: Translations = {
  en: {
    appName: 'Wasfah AI',
    tagline: 'Discover personalized recipes based on your ingredients and preferences',
    getStarted: 'Get Started',
    alreadyHaveAccount: 'Already have an account?',
    dontHaveAccount: "Don't have an account?",
    logIn: 'Log in',
    signUp: 'Sign up',
    email: 'Email',
    password: 'Password',
    confirmPassword: 'Confirm Password',
    passwordWeak: 'Weak',
    passwordFair: 'Fair',
    passwordGood: 'Good',
    passwordStrong: 'Strong',
    passwordsMatch: 'Passwords match',
    passwordsDontMatch: 'Passwords do not match',
    forgotPassword: 'Forgot Password?',
    or: 'OR',
    continueWithGoogle: 'Continue with Google',
    continueWithApple: 'Continue with Apple',
    signIn: 'Sign In',
    yourPreferences: 'Your Preferences',
    preferencesDescription: 'Tell us about your dietary preferences so we can personalize your experience',
    dietaryRestrictions: 'Dietary Restrictions',
    dietaryPrefsTitle: 'Dietary Preferences',
    allergensTitle: 'Food Allergies & Sensitivities',
    vegetarian: 'Vegetarian',
    vegan: 'Vegan',
    pescatarian: 'Pescatarian',
    keto: 'Keto',
    paleo: 'Paleo',
    lowCarb: 'Low Carb',
    lowFat: 'Low Fat',
    highProtein: 'High Protein',
    // Allergens
    gluten: 'Gluten',
    dairy: 'Dairy',
    nuts: 'Tree Nuts',
    peanuts: 'Peanuts',
    shellfish: 'Shellfish',
    fish: 'Fish',
    eggs: 'Eggs',
    soy: 'Soy',
    sesame: 'Sesame',
    cuisinePreferences: 'Cuisine Preferences',
    arabic: 'Arabic',
    italian: 'Italian',
    asian: 'Asian',
    mexican: 'Mexican',
    indian: 'Indian',
    cookingSkillLevel: 'Cooking Skill Level',
    beginner: 'Beginner',
    intermediate: 'Intermediate',
    advanced: 'Advanced',
    continue: 'Continue',
    hello: 'Hello',
    whatCookToday: 'What would you like to cook today?',
    searchRecipes: 'Search recipes or ingredients...',
    all: 'All',
    meat: 'Meat',
    dessert: 'Dessert',
    drinks: 'Drinks',
    basedOnPantry: 'Based on Your Pantry',
    seeAll: 'See All',
    match: 'match',
    popularRecipes: 'Popular Recipes',
    recentSearches: 'Recent Searches',
    home: 'Home',
    search: 'Search',
    global: 'Global',
    favorites: 'Favorites',
    profile: 'Profile',
    whatsInKitchen: "What's in Your Kitchen?",
    tellUsIngredients: "Tell us what ingredients you have and we'll suggest recipes",
    addIngredient: 'Add an ingredient...',
    commonIngredients: 'Common Ingredients',
    yourPantry: 'Your Pantry',
    manage: 'Manage',
    grains: 'Grains',
    proteins: 'Proteins',
    findRecipes: 'Find Recipes',
    easy: 'Easy',
    servings: 'servings',
    calories: 'cal',
    description: 'Description',
    ingredients: 'Ingredients',
    servingSize: 'Serving Size',
    instructions: 'Instructions',
    nutritionFacts: 'Nutrition Facts',
    similarRecipes: 'Similar Recipes',
    allergenWarning: 'Allergen Warning',
    recipeContainsAllergens: 'This recipe contains the following allergens that match your profile',
    allergen: 'Allergen',
    percentDailyValueNote: 'Percent Daily Values are based on a 2,000 calorie diet. Your daily values may be higher or lower depending on your calorie needs.',
    ingredientNutrition: 'Ingredient Nutrition',
    protein: 'Protein',
    fat: 'Fat',
    carbs: 'Carbs',
    fiber: 'Fiber',
    sodium: 'Sodium',
    sugar: 'Sugar',
    startCooking: 'Start Cooking',
    cookingTime: 'min',
    username: 'Username',
    register: 'Register',
    name: 'Name',
    logout: 'Logout',
    editProfile: 'Edit Profile',
    registerNewAccount: 'Register a new account',
    userPreferences: 'Preferences Settings',
    saveChanges: 'Save Changes',
    welcomeBack: 'Welcome Back',
    loginToAccount: 'Login to your account',
    exploreGlobalCuisines: 'Explore Global Cuisines',
    discoverWorldwideRecipes: 'Discover Worldwide Recipes',
    discoverRecipesSubtitle: 'Discover 10,000+ recipes worldwide',
    cuisineFilters: 'Cuisine Filters',
    selectCuisineCountry: 'Select Cuisine Country',
    anyCuisine: 'Any Cuisine',
    mealType: 'Meal Type',
    dietaryOptions: 'Dietary Options',
    searchCuisines: 'Search Cuisines',
    recipeResults: 'Recipe Results',
    tryDifferentCuisine: 'Try a different cuisine',
    globalCuisine: 'Global Cuisine',
    searchPantryItems: 'Search pantry items...',
    noPantryItems: 'No items in your pantry yet',
    ingredientsSection: 'Add Ingredients',
    filtersSection: 'Set Filters',
    quickAccess: 'Quick Access',
    myFavorites: 'Favorites',
    myHistory: 'History',
    createAndShare: 'Create & Share',
    createRecipe: 'Create Your Recipe',
    cookNow: 'Cook Now',
    cookingModeStarted: 'Cooking mode started! Follow the step-by-step instructions.',
    selectSubcategory: 'Select a subcategory',
  },
  ar: {
    appName: 'وصفة AI',
    tagline: 'اكتشف وصفات مخصصة حسب المكونات والتفضيلات الخاصة بك',
    getStarted: 'ابدأ الآن',
    alreadyHaveAccount: 'لديك حساب بالفعل؟',
    dontHaveAccount: 'ليس لديك حساب؟',
    logIn: 'تسجيل الدخول',
    signUp: 'تسجيل',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    passwordWeak: 'ضعيفة',
    passwordFair: 'مقبولة',
    passwordGood: 'جيدة',
    passwordStrong: 'قوية',
    passwordsMatch: 'كلمات المرور متطابقة',
    passwordsDontMatch: 'كلمات المرور غير متطابقة',
    forgotPassword: 'نسيت كلمة المرور؟',
    or: 'أو',
    continueWithGoogle: 'متابعة باستخدام Google',
    continueWithApple: 'متابعة باستخدام Apple',
    signIn: 'تسجيل الدخول',
    yourPreferences: 'تفضيلاتك',
    preferencesDescription: 'أخبرنا عن تفضيلاتك الغذائية حتى نتمكن من تخصيص تجربتك',
    dietaryRestrictions: 'القيود الغذائية',
    dietaryPrefsTitle: 'التفضيلات الغذائية',
    allergensTitle: 'الحساسية الغذائية والمحسسات',
    vegetarian: 'نباتي',
    vegan: 'نباتي صارم',
    pescatarian: 'سمكي نباتي',
    keto: 'كيتو',
    paleo: 'بايليو',
    lowCarb: 'قليل الكربوهيدرات',
    lowFat: 'قليل الدهون',
    highProtein: 'عالي البروتين',
    // Allergens
    gluten: 'الغلوتين',
    dairy: 'منتجات الألبان',
    nuts: 'المكسرات',
    peanuts: 'الفول السوداني',
    shellfish: 'المحار',
    fish: 'السمك',
    eggs: 'البيض',
    soy: 'الصويا',
    sesame: 'السمسم',
    cuisinePreferences: 'تفضيلات المطبخ',
    arabic: 'عربي',
    italian: 'إيطالي',
    asian: 'آسيوي',
    mexican: 'مكسيكي',
    indian: 'هندي',
    cookingSkillLevel: 'مستوى مهارة الطهي',
    beginner: 'مبتدئ',
    intermediate: 'متوسط',
    advanced: 'متقدم',
    continue: 'متابعة',
    hello: 'مرحباً',
    whatCookToday: 'ماذا تريد أن تطبخ اليوم؟',
    searchRecipes: 'ابحث عن وصفات أو مكونات...',
    all: 'الكل',
    meat: 'لحوم',
    dessert: 'حلويات',
    drinks: 'مشروبات',
    basedOnPantry: 'بناءً على مؤونتك',
    seeAll: 'عرض الكل',
    match: 'تطابق',
    popularRecipes: 'وصفات شائعة',
    recentSearches: 'عمليات البحث الأخيرة',
    home: 'الرئيسية',
    search: 'بحث',
    global: 'عالمي',
    favorites: 'المفضلة',
    profile: 'الملف',
    whatsInKitchen: 'ماذا يوجد في مطبخك؟',
    tellUsIngredients: 'أخبرنا بالمكونات التي لديك وسنقترح عليك وصفات',
    addIngredient: 'أضف مكوناً...',
    commonIngredients: 'مكونات شائعة',
    yourPantry: 'مؤونتك',
    manage: 'إدارة',
    grains: 'حبوب',
    proteins: 'بروتينات',
    findRecipes: 'البحث عن وصفات',
    easy: 'سهل',
    servings: 'حصص',
    calories: 'سعرة',
    description: 'الوصف',
    ingredients: 'المكونات',
    servingSize: 'حجم الحصة',
    instructions: 'طريقة التحضير',
    nutritionFacts: 'حقائق غذائية',
    similarRecipes: 'وصفات مشابهة',
    allergenWarning: 'تحذير من مسببات الحساسية',
    recipeContainsAllergens: 'تحتوي هذه الوصفة على مسببات الحساسية التالية التي تتطابق مع ملفك الشخصي',
    allergen: 'مسبب للحساسية',
    percentDailyValueNote: 'تستند النسب المئوية للقيم اليومية على نظام غذائي يحتوي على 2000 سعرة حرارية. قد تكون قيمك اليومية أعلى أو أقل اعتمادًا على احتياجاتك من السعرات الحرارية.',
    ingredientNutrition: 'تغذية المكونات',
    protein: 'بروتين',
    fat: 'دهون',
    carbs: 'كربوهيدرات',
    fiber: 'ألياف',
    sodium: 'صوديوم',
    sugar: 'سكر',
    startCooking: 'ابدأ الطهي',
    cookingTime: 'دقيقة',
    username: 'اسم المستخدم',
    confirmPassword: 'تأكيد كلمة المرور',
    register: 'تسجيل',
    name: 'الاسم',
    logout: 'تسجيل الخروج',
    editProfile: 'تعديل الملف',
    registerNewAccount: 'تسجيل حساب جديد',
    userPreferences: 'إعدادات التفضيلات',
    saveChanges: 'حفظ التغييرات',
    welcomeBack: 'مرحبا بعودتك',
    loginToAccount: 'تسجيل الدخول إلى حسابك',
    exploreGlobalCuisines: 'استكشف المطابخ العالمية',
    discoverWorldwideRecipes: 'اكتشف الوصفات العالمية',
    discoverRecipesSubtitle: 'اكتشف أكثر من 10,000 وصفة حول العالم',
    cuisineFilters: 'تصفية المطابخ',
    selectCuisineCountry: 'اختر بلد المطبخ',
    anyCuisine: 'أي مطبخ',
    mealType: 'نوع الوجبة',
    dietaryOptions: 'خيارات غذائية',
    searchCuisines: 'البحث عن مطابخ',
    recipeResults: 'نتائج الوصفات',
    tryDifferentCuisine: 'جرب مطبخًا مختلفًا',
    globalCuisine: 'المطبخ العالمي',
    searchPantryItems: 'البحث في عناصر المؤونة...',
    noPantryItems: 'لا توجد عناصر في مؤونتك بعد',
    ingredientsSection: 'إضافة مكونات',
    filtersSection: 'ضبط المصفيات',
    quickAccess: 'وصول سريع',
    myFavorites: 'المفضلة',
    myHistory: 'السجل',
    createAndShare: 'إنشاء ومشاركة',
    createRecipe: 'إنشاء وصفتك',
    cookNow: 'اطبخ الآن',
    cookingModeStarted: 'تم بدء وضع الطهي! اتبع التعليمات خطوة بخطوة.',
    selectSubcategory: 'اختر فئة فرعية',
  },
};

// Create the context
interface I18nContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
  isRtl: boolean;
}

const I18nContext = createContext<I18nContextType | null>(null);

// Create the provider component
export function I18nProvider(props: { children: ReactNode }) {
  const [language, setLanguage] = useState<string>('en');

  // Merge translations
  const mergedTranslations: Translations = {
    en: { ...translations.en, ...extraTranslations.en },
    ar: { ...translations.ar, ...extraTranslations.ar }
  };

  // Function to get a translation with parameter replacement
  const t = (key: string, params?: Record<string, string | number>): string => {
    if (!mergedTranslations[language]) return key;
    let text = mergedTranslations[language][key] || key;
    
    // Replace parameters in format: {paramName}
    if (params) {
      Object.entries(params).forEach(([paramKey, paramValue]) => {
        text = text.replace(`{${paramKey}}`, String(paramValue));
      });
    }
    
    return text;
  };

  // Determine if the current language is RTL
  const isRtl = language === 'ar';

  // Create context value
  const contextValue: I18nContextType = {
    language,
    setLanguage,
    t,
    isRtl
  };

  return (
    React.createElement(
      I18nContext.Provider,
      { value: contextValue },
      props.children
    )
  );
}

// Custom hook to use the translations
export function useI18n(): I18nContextType {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}
