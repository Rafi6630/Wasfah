// Royal Gourmet AI Theme
export const theme = {
  colors: {
    // Primary Colors
    primary: {
      DEFAULT: '#6A0DAD', // Vibrant Royal Purple
      dark: '#4B0082',    // Deep Royal Purple
      light: '#8A2BE2',   // Bright Royal Purple
    },
    
    // Secondary Colors (Gold)
    secondary: {
      DEFAULT: '#FFD700', // Bright Gold
      dark: '#C5A942',    // Muted Gold
      light: '#FFDF45',   // Light Gold
    },
    
    // Neutrals
    neutral: {
      50: '#F8F8FF',      // Off-White
      900: '#1A1A1A',     // Charcoal Black
    },
    
    // Status Colors
    success: '#4CAF50',   // Green
    warning: '#FF9800',   // Orange
    error: '#F44336',     // Red
    info: '#2196F3',      // Blue
  },
  
  // Typography
  fontFamily: {
    heading: 'Playfair Display, serif',
    body: 'Montserrat, sans-serif',
  },
  
  // Border Radii
  borderRadius: {
    sm: '0.25rem',
    md: '0.5rem',
    lg: '1rem',
    xl: '1.5rem',
    full: '9999px',
  },
  
  // Shadows
  shadows: {
    sm: '0 1px 2px rgba(0, 0, 0, 0.05)',
    md: '0 4px 6px rgba(0, 0, 0, 0.1)',
    lg: '0 10px 15px rgba(0, 0, 0, 0.1)',
    xl: '0 20px 25px rgba(0, 0, 0, 0.15)',
  },
  
  // Gradients
  gradients: {
    purple: 'linear-gradient(145deg, #6A0DAD 0%, #4B0082 100%)',
    gold: 'linear-gradient(145deg, #FFD700 0%, #C5A942 100%)',
  },
  
  // Animations
  animations: {
    shimmer: 'shimmer 2s linear infinite',
    glow: 'glow 1.5s ease-in-out infinite alternate',
  },
};

// Export types for better TypeScript support
export type ThemeColors = typeof theme.colors;
export type ThemeFontFamily = typeof theme.fontFamily;
export type ThemeBorderRadius = typeof theme.borderRadius;
export type ThemeShadows = typeof theme.shadows;
export type ThemeGradients = typeof theme.gradients;
export type ThemeAnimations = typeof theme.animations;