import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Types
type TransitionType = 'fade' | 'slide' | 'scale' | 'crown' | 'sparkle';
type AnimationSpeed = 'slow' | 'normal' | 'fast';

interface AnimationContextType {
  // Animation preferences
  animationsEnabled: boolean;
  setAnimationsEnabled: (enabled: boolean) => void;
  prefersReducedMotion: boolean;
  setPrefersReducedMotion: (enabled: boolean) => void;
  
  // App-wide transition type
  transitionType: TransitionType;
  setTransitionType: (type: TransitionType) => void;
  
  // Animation speed
  animationSpeed: AnimationSpeed;
  setAnimationSpeed: (speed: AnimationSpeed) => void;
  
  // Helper methods
  getDurationFactor: () => number;
}

// Create context with default values
const AnimationContext = createContext<AnimationContextType>({
  animationsEnabled: true,
  setAnimationsEnabled: () => {},
  prefersReducedMotion: false,
  setPrefersReducedMotion: () => {},
  transitionType: 'fade',
  setTransitionType: () => {},
  animationSpeed: 'normal',
  setAnimationSpeed: () => {},
  getDurationFactor: () => 1,
});

// Storage keys for persistence
const ANIMATION_STORAGE_KEY = 'royal-gourmet-animation-prefs';

// Default values
const defaultPreferences = {
  animationsEnabled: true,
  prefersReducedMotion: false,
  transitionType: 'fade' as TransitionType,
  animationSpeed: 'normal' as AnimationSpeed,
};

// Provider component
export function AnimationProvider({ children }: { children: ReactNode }) {
  // Initialize state from local storage or defaults
  const [preferences, setPreferences] = useState(() => {
    // Try to load from localStorage
    if (typeof window !== 'undefined') {
      const savedPrefs = localStorage.getItem(ANIMATION_STORAGE_KEY);
      if (savedPrefs) {
        try {
          return { ...defaultPreferences, ...JSON.parse(savedPrefs) };
        } catch (e) {
          console.error('Error parsing animation preferences:', e);
        }
      }
    }
    return defaultPreferences;
  });
  
  // Destructure for convenience
  const { 
    animationsEnabled, 
    prefersReducedMotion, 
    transitionType, 
    animationSpeed 
  } = preferences;
  
  // Handler to update a specific preference
  const updatePreference = <K extends keyof typeof preferences>(
    key: K, 
    value: typeof preferences[K]
  ) => {
    setPreferences(prev => {
      const newPrefs = { ...prev, [key]: value };
      
      // Save to localStorage
      if (typeof window !== 'undefined') {
        localStorage.setItem(ANIMATION_STORAGE_KEY, JSON.stringify(newPrefs));
      }
      
      return newPrefs;
    });
  };
  
  // Check for user's system-level reduced motion preference
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
      if (mediaQuery.matches) {
        updatePreference('prefersReducedMotion', true);
      }
      
      // Update when preference changes
      const handleChange = (e: MediaQueryListEvent) => {
        updatePreference('prefersReducedMotion', e.matches);
      };
      
      mediaQuery.addEventListener('change', handleChange);
      return () => mediaQuery.removeEventListener('change', handleChange);
    }
  }, []);
  
  // Calculate animation duration factor based on speed setting
  const getDurationFactor = () => {
    switch (animationSpeed) {
      case 'slow': return 1.5;
      case 'fast': return 0.7;
      case 'normal':
      default: return 1;
    }
  };
  
  // Value object for the context
  const value = {
    // Animation toggle
    animationsEnabled,
    setAnimationsEnabled: (enabled: boolean) => 
      updatePreference('animationsEnabled', enabled),
    
    // Reduced motion
    prefersReducedMotion,
    setPrefersReducedMotion: (enabled: boolean) => 
      updatePreference('prefersReducedMotion', enabled),
    
    // Transition type
    transitionType,
    setTransitionType: (type: TransitionType) => 
      updatePreference('transitionType', type),
    
    // Animation speed
    animationSpeed,
    setAnimationSpeed: (speed: AnimationSpeed) => 
      updatePreference('animationSpeed', speed),
    
    // Helper methods
    getDurationFactor,
  };
  
  return (
    <AnimationContext.Provider value={value}>
      {children}
    </AnimationContext.Provider>
  );
}

// Hook to use the animation context
export function useAnimation() {
  const context = useContext(AnimationContext);
  if (context === undefined) {
    throw new Error('useAnimation must be used within an AnimationProvider');
  }
  return context;
}