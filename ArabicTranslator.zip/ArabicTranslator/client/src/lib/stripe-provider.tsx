import { ReactNode, createContext, useContext, useEffect, useState } from 'react';
import { loadStripe, Stripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';

// Create a context for Stripe
interface StripeContextType {
  isLoading: boolean;
  stripe: Stripe | null;
  error: Error | null;
}

const StripeContext = createContext<StripeContextType | null>(null);

// Function to load Stripe
const getStripe = async (): Promise<Stripe | null> => {
  if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
    console.error('VITE_STRIPE_PUBLIC_KEY is not set');
    return null;
  }
  
  try {
    return await loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);
  } catch (error) {
    console.error('Failed to load Stripe:', error);
    return null;
  }
};

// Provider component
export function StripeProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<StripeContextType>({
    isLoading: true,
    stripe: null,
    error: null,
  });

  useEffect(() => {
    let isMounted = true;

    getStripe()
      .then((stripe) => {
        if (isMounted) {
          setState({
            isLoading: false,
            stripe,
            error: null,
          });
        }
      })
      .catch((error) => {
        if (isMounted) {
          setState({
            isLoading: false,
            stripe: null,
            error: error instanceof Error ? error : new Error(String(error)),
          });
        }
      });

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <StripeContext.Provider value={state}>
      {children}
    </StripeContext.Provider>
  );
}

// Hook to use Stripe
export function useStripe() {
  const context = useContext(StripeContext);
  if (!context) {
    throw new Error('useStripe must be used within a StripeProvider');
  }
  return context;
}

// Elements provider for checkout
export function StripeElementsProvider({ 
  clientSecret, 
  children 
}: { 
  clientSecret: string | null;
  children: ReactNode;
}) {
  const { stripe } = useStripe();
  
  if (!clientSecret) {
    return null;
  }
  
  return (
    <Elements stripe={stripe} options={{ clientSecret }}>
      {children}
    </Elements>
  );
}