import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { motion } from "framer-motion";
import { RecipesCrownIcon } from "@/components/icons/recipes-crown-icon";
import { useLocation } from "wouter";
import { theme } from "@/lib/theme";
import { Sparkles, ChefHat } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export function SplashScreen() {
  const { t, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const [fadeOut, setFadeOut] = React.useState(false);
  const { user } = useAuth();
  
  // Automatically redirect after animation completes
  React.useEffect(() => {
    const timer = setTimeout(() => {
      setFadeOut(true);
      
      setTimeout(() => {
        // Navigate to auth or home page based on authentication state
        setLocation(user ? "/home" : "/auth");
      }, 700); // Duration of fade out animation
    }, 3000); // Display duration
    
    return () => clearTimeout(timer);
  }, [setLocation, user]);
  
  return (
    <motion.div 
      className="fixed inset-0 flex flex-col items-center justify-start overflow-hidden bg-gradient-to-b from-recipes-purple-dark via-recipes-purple to-recipes-purple-light"
      initial={{ opacity: 0 }}
      animate={{ opacity: fadeOut ? 0 : 1 }}
      transition={{ duration: 0.7 }}
    >
      {/* Top logo and crown animation */}
      <motion.div 
        className="mt-20 mb-4 relative"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ 
          type: "spring", 
          damping: 12, 
          stiffness: 100, 
          delay: 0.2 
        }}
      >
        <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-lg relative">
          <ChefHat className="w-14 h-14 text-recipes-purple" />
          <motion.div
            className="absolute -top-1 right-0"
            initial={{ rotate: -15, scale: 0.8 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ 
              type: "spring", 
              damping: 10, 
              stiffness: 80, 
              delay: 0.7 
            }}
          >
            <RecipesCrownIcon className="w-10 h-10 text-recipes-gold" />
          </motion.div>
        </div>
        
        {/* Shimmer effect across the logo */}
        <motion.div
          className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent"
          initial={{ x: -100, opacity: 0 }}
          animate={{ x: 200, opacity: 0.5 }}
          transition={{ 
            duration: 1.5, 
            repeat: 2, 
            repeatType: "loop",
            delay: 1 
          }}
        />
      </motion.div>
      
      {/* App name with elegant animation */}
      <motion.div 
        className="text-center mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.6 }}
      >
        <motion.h1 
          className="font-playfair text-4xl text-white mb-1 tracking-wide relative"
        >
          <span className="mr-2">Recipes</span>
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1, duration: 0.4 }}
            className="text-recipes-gold font-bold"
          >
            Gourmet
          </motion.span>
          
          {/* Floating sparkles animation */}
          <motion.span
            className="absolute -right-7 -top-4"
            initial={{ opacity: 0, rotate: -20 }}
            animate={{ opacity: 1, rotate: 0 }}
            transition={{ delay: 1.3, duration: 0.5 }}
          >
            <Sparkles className="h-5 w-5 text-recipes-gold" />
          </motion.span>
        </motion.h1>
        
        <motion.p 
          className="text-white/80 text-lg max-w-[300px] mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.8 }}
        >
          {t("whereAIMeetsChefsKitchen")}
        </motion.p>
      </motion.div>
      
      {/* Gradient ingredient background with parallax effect */}
      <motion.div 
        className="absolute bottom-0 left-0 right-0 h-2/3 overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 0.8 }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-white/10 to-transparent" />
        
        {/* Ingredient images with floating animation */}
        <div className="grid grid-cols-3 gap-4 p-6 mt-12 relative">
          {ingredients.map((ingredient, index) => (
            <motion.div
              key={ingredient.name}
              className="relative aspect-square bg-white/10 backdrop-blur-sm rounded-lg overflow-hidden flex items-center justify-center"
              initial={{ 
                y: 100 + (index * 10), 
                opacity: 0,
                rotate: index % 2 === 0 ? 5 : -5
              }}
              animate={{ 
                y: 0, 
                opacity: 0.9,
                rotate: 0 
              }}
              transition={{ 
                duration: 0.6, 
                delay: 1 + (index * 0.1),
                type: "spring",
                damping: 15
              }}
            >
              <div className="text-white/90 text-center p-2">
                <div className="font-medium text-sm">{ingredient.name}</div>
                <div className="text-xs mt-1 text-white/60">{ingredient.nameAr}</div>
              </div>
              
              {/* Pulsing ring */}
              <motion.div
                className="absolute inset-0 border border-white/20 rounded-lg"
                animate={{
                  scale: [1, 1.05, 1],
                  opacity: [0.2, 0.4, 0.2]
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: index * 0.3
                }}
              />
            </motion.div>
          ))}
        </div>
        
        {/* Gradient overlay */}
        <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-recipes-purple-dark/80 to-transparent" />
      </motion.div>
      
      {/* Loading indicator */}
      <motion.div 
        className="absolute bottom-16 left-0 right-0 flex flex-col items-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 0.6 }}
      >
        <div className="w-10 h-1 bg-white/20 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-recipes-gold"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 2.5, ease: "easeInOut" }}
          />
        </div>
        <div className="mt-2 text-white/60 text-xs">
          {t("preparingGourmetExperience")}
        </div>
      </motion.div>
    </motion.div>
  );
}

// Premium ingredient data with proper translations
const ingredients = [
  { name: "Saffron", nameAr: "زعفران" },
  { name: "Basmati Rice", nameAr: "أرز بسمتي" },
  { name: "Cardamom", nameAr: "هيل" },
  { name: "Cinnamon", nameAr: "قرفة" },
  { name: "Rose Water", nameAr: "ماء الورد" },
  { name: "Fresh Mint", nameAr: "نعناع طازج" },
];