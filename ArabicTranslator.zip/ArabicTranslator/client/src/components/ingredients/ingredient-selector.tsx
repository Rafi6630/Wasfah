import * as React from "react";
import { useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/hooks/use-auth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Search, Mic, Camera, Upload, Plus, RefreshCw, 
  ChevronRight, X, Check, ShoppingCart, Edit
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { queryClient } from "@/lib/queryClient";
import { useQuery } from "@tanstack/react-query";
import { RecipeIngredient } from "@shared/schema";

// Mock ingredient data for each category (in real app, this would come from API)
const mockPantryItems = [
  { id: "1", name: "Tomato", nameAr: "طماطم", quantity: "3", unit: "pieces", category: "vegetable" },
  { id: "2", name: "Onion", nameAr: "بصل", quantity: "2", unit: "pieces", category: "vegetable" },
  { id: "3", name: "Chicken", nameAr: "دجاج", quantity: "1", unit: "kg", category: "meat" },
  { id: "4", name: "Rice", nameAr: "أرز", quantity: "5", unit: "kg", category: "grain" },
  { id: "5", name: "Olive Oil", nameAr: "زيت زيتون", quantity: "500", unit: "ml", category: "oil" },
  { id: "6", name: "Black Pepper", nameAr: "فلفل أسود", quantity: "100", unit: "g", category: "spice" },
  { id: "7", name: "Salt", nameAr: "ملح", quantity: "200", unit: "g", category: "spice" },
  { id: "8", name: "Lemon", nameAr: "ليمون", quantity: "4", unit: "pieces", category: "fruit" },
  { id: "9", name: "Garlic", nameAr: "ثوم", quantity: "1", unit: "head", category: "vegetable" },
  { id: "10", name: "Cinnamon", nameAr: "قرفة", quantity: "50", unit: "g", category: "spice" },
];

type Ingredient = {
  id: string;
  name: string;
  nameAr: string;
  quantity: string;
  unit: string;
  category: string;
  selected?: boolean;
};

type IngredientSelectorProps = {
  onIngredientSelect: (ingredients: Ingredient[]) => void;
  isOpen: boolean;
  onClose: () => void;
};

export function IngredientSelector({ onIngredientSelect, isOpen, onClose }: IngredientSelectorProps) {
  const { t, language, isRtl } = useI18n();
  const { user } = useAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState("pantry");
  const [pantryItems, setPantryItems] = useState<Ingredient[]>(mockPantryItems);
  const [selectedIngredients, setSelectedIngredients] = useState<Ingredient[]>([]);
  const [newIngredient, setNewIngredient] = useState("");
  const [newQuantity, setNewQuantity] = useState("");
  const [newUnit, setNewUnit] = useState("pieces");
  const [isReviewMode, setIsReviewMode] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [isRecording, setIsRecording] = useState(false);

  // In a real app, fetch pantry items from the API
  const { data: smartPantryItems, isLoading } = useQuery({
    queryKey: ["/api/smart-pantry"],
    queryFn: () => {
      // Simulate API call
      return Promise.resolve(mockPantryItems);
    },
    enabled: isOpen, // Only fetch when dialog is open
  });

  useEffect(() => {
    if (smartPantryItems) {
      setPantryItems(smartPantryItems);
    }
  }, [smartPantryItems]);

  const toggleIngredientSelection = (ingredient: Ingredient) => {
    if (selectedIngredients.some(i => i.id === ingredient.id)) {
      setSelectedIngredients(selectedIngredients.filter(i => i.id !== ingredient.id));
    } else {
      setSelectedIngredients([...selectedIngredients, ingredient]);
    }
  };

  const addNewIngredient = () => {
    if (!newIngredient.trim()) return;
    
    const existingIngredient = pantryItems.find(
      i => i.name.toLowerCase() === newIngredient.toLowerCase()
    );
    
    if (existingIngredient) {
      // If ingredient exists in pantry but not selected, select it
      if (!selectedIngredients.some(i => i.id === existingIngredient.id)) {
        setSelectedIngredients([...selectedIngredients, existingIngredient]);
      }
      
      // Clear input fields
      setNewIngredient("");
      setNewQuantity("");
      setNewUnit("pieces");
      
      toast({
        title: t("ingredientAddedFromPantry"),
        description: existingIngredient.name
      });
      
      return;
    }
    
    // Add new ingredient
    const newItem: Ingredient = {
      id: Date.now().toString(),
      name: newIngredient,
      nameAr: newIngredient, // In a real app, you would use translation service
      quantity: newQuantity || "1",
      unit: newUnit,
      category: "other",
      selected: true
    };
    
    // Add to selected ingredients
    setSelectedIngredients([...selectedIngredients, newItem]);
    
    // Also add to pantry for future use
    setPantryItems([...pantryItems, newItem]);
    
    // Clear input fields
    setNewIngredient("");
    setNewQuantity("");
    setNewUnit("pieces");
    
    toast({
      title: t("newIngredientAdded"),
      description: newItem.name
    });
  };

  const removeIngredient = (ingredient: Ingredient) => {
    setSelectedIngredients(selectedIngredients.filter(i => i.id !== ingredient.id));
  };

  const handleVoiceInput = () => {
    setIsRecording(true);
    
    // Mock voice recognition - in a real app, use Web Speech API
    setTimeout(() => {
      setIsRecording(false);
      setNewIngredient("Tomato");
      
      toast({
        title: t("voiceRecognized"),
        description: "Tomato"
      });
    }, 2000);
  };

  const handleScanInput = () => {
    setIsScanning(true);
    
    // Mock image recognition - in a real app, use a camera API and image recognition
    setTimeout(() => {
      setIsScanning(false);
      
      const scannedIngredients = [
        { id: "scan1", name: "Apple", nameAr: "تفاح", quantity: "3", unit: "pieces", category: "fruit" },
        { id: "scan2", name: "Milk", nameAr: "حليب", quantity: "1", unit: "liter", category: "dairy" }
      ];
      
      setSelectedIngredients([...selectedIngredients, ...scannedIngredients]);
      
      toast({
        title: t("ingredientsScanned"),
        description: `${scannedIngredients.length} ${t("itemsRecognized")}`
      });
    }, 2000);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Mock file upload - in a real app, process the file and extract ingredients
    if (e.target.files && e.target.files.length > 0) {
      toast({
        title: t("fileUploaded"),
        description: e.target.files[0].name
      });
      
      // Mock processing
      setTimeout(() => {
        const uploadedIngredients = [
          { id: "upload1", name: "Eggs", nameAr: "بيض", quantity: "12", unit: "pieces", category: "dairy" },
          { id: "upload2", name: "Flour", nameAr: "طحين", quantity: "500", unit: "g", category: "baking" }
        ];
        
        setSelectedIngredients([...selectedIngredients, ...uploadedIngredients]);
        
        toast({
          title: t("ingredientsExtracted"),
          description: `${uploadedIngredients.length} ${t("itemsRecognized")}`
        });
      }, 1500);
    }
  };

  const confirmSelection = () => {
    if (selectedIngredients.length === 0) {
      toast({
        title: t("noIngredientsSelected"),
        description: t("pleaseSelectIngredients"),
        variant: "destructive"
      });
      return;
    }
    
    if (!isReviewMode) {
      setIsReviewMode(true);
      return;
    }
    
    // Return selected ingredients to parent component
    onIngredientSelect(selectedIngredients);
    
    // Reset state
    setSelectedIngredients([]);
    setIsReviewMode(false);
    onClose();
    
    toast({
      title: t("ingredientsConfirmed"),
      description: `${selectedIngredients.length} ${t("ingredientsAdded")}`
    });
  };

  const cancelSelection = () => {
    if (isReviewMode) {
      setIsReviewMode(false);
      return;
    }
    
    onClose();
  };

  const renderPantryTab = () => (
    <div className="space-y-2">
      <div className="grid grid-cols-2 gap-2">
        {pantryItems.map(ingredient => (
          <div 
            key={ingredient.id}
            className={`flex items-center p-2 border rounded-md cursor-pointer transition-colors ${
              selectedIngredients.some(i => i.id === ingredient.id)
                ? "border-royal-gold bg-royal-gold/10"
                : "border-gray-200 hover:border-royal-purple/50"
            }`}
            onClick={() => toggleIngredientSelection(ingredient)}
          >
            <div className="flex-1 truncate">
              <div className="font-medium text-sm truncate">{language === "en" ? ingredient.name : ingredient.nameAr}</div>
              <div className="text-xs text-gray-500">{ingredient.quantity} {ingredient.unit}</div>
            </div>
            <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
              selectedIngredients.some(i => i.id === ingredient.id)
                ? "bg-royal-gold text-white"
                : "border border-gray-300"
            }`}>
              {selectedIngredients.some(i => i.id === ingredient.id) && <Check className="h-3 w-3" />}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderManualTab = () => (
    <div className="space-y-3">
      <div className="flex gap-1">
        <div className="flex-1">
          <Input
            type="text"
            placeholder={t("ingredientName")}
            value={newIngredient}
            onChange={(e) => setNewIngredient(e.target.value)}
            className="w-full h-9 text-sm"
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                addNewIngredient();
              }
            }}
          />
        </div>
        <div className="w-16">
          <Input
            type="text"
            placeholder={t("qty")}
            value={newQuantity}
            onChange={(e) => setNewQuantity(e.target.value)}
            className="w-full h-9 text-sm"
          />
        </div>
        <div className="w-20">
          <select
            value={newUnit}
            onChange={(e) => setNewUnit(e.target.value)}
            className="w-full h-9 px-2 text-xs border border-input rounded-md"
          >
            <option value="pieces">{t("pieces")}</option>
            <option value="g">{t("grams")}</option>
            <option value="kg">{t("kilograms")}</option>
            <option value="ml">{t("milliliters")}</option>
            <option value="l">{t("liters")}</option>
            <option value="tbsp">{t("tablespoons")}</option>
            <option value="tsp">{t("teaspoons")}</option>
            <option value="cup">{t("cups")}</option>
          </select>
        </div>
        <Button onClick={addNewIngredient} size="icon" variant="default" className="h-9 w-9">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      
      <div className="grid grid-cols-3 gap-1">
        <Button onClick={handleVoiceInput} variant="outline" className="h-9 text-xs py-0 px-1" disabled={isRecording}>
          <Mic className="h-3 w-3 mr-1" />
          {isRecording ? t("listening") : t("addByVoice")}
        </Button>
        <Button onClick={handleScanInput} variant="outline" className="h-9 text-xs py-0 px-1" disabled={isScanning}>
          <Camera className="h-3 w-3 mr-1" />
          {isScanning ? t("scanning") : t("scanIngredients")}
        </Button>
        <div className="relative">
          <input
            type="file"
            id="file-upload"
            className="sr-only"
            accept="image/*"
            onChange={handleFileUpload}
          />
          <label htmlFor="file-upload" className="cursor-pointer w-full">
            <Button variant="outline" className="w-full h-9 text-xs py-0 px-1" asChild>
              <span>
                <Upload className="h-3 w-3 mr-1" />
                {t("upload")}
              </span>
            </Button>
          </label>
        </div>
      </div>
    </div>
  );

  const renderReviewMode = () => (
    <div className="space-y-2">
      {selectedIngredients.length === 0 ? (
        <div className="text-center py-3 text-gray-500 text-sm">{t("noIngredientsSelected")}</div>
      ) : (
        <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
          {selectedIngredients.map(ingredient => (
            <div key={ingredient.id} className="flex items-center justify-between p-2 border rounded-md">
              <div className="flex-1 truncate pr-1">
                <div className="font-medium text-sm truncate">{language === "en" ? ingredient.name : ingredient.nameAr}</div>
                <div className="text-xs text-gray-500">{ingredient.quantity} {ingredient.unit}</div>
              </div>
              <Button variant="ghost" size="icon" className="h-6 w-6 p-0" onClick={() => removeIngredient(ingredient)}>
                <X className="h-3 w-3 text-red-500" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-sm mx-auto p-4" dir={isRtl ? "rtl" : "ltr"}>
        <DialogHeader className="pb-2">
          <DialogTitle className="text-center text-lg font-bold text-royal-purple">
            {isReviewMode ? t("reviewIngredients") : t("selectIngredients")}
          </DialogTitle>
          <DialogDescription className="text-center text-sm">
            {isReviewMode 
              ? t("confirmIngredientsDescription") 
              : t("selectIngredientsDescription")}
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4">
          {isReviewMode ? (
            renderReviewMode()
          ) : (
            <>
              <Tabs defaultValue="pantry" value={tab} onValueChange={setTab}>
                <TabsList className="w-full grid grid-cols-2">
                  <TabsTrigger value="pantry">{t("fromPantry")}</TabsTrigger>
                  <TabsTrigger value="manual">{t("manualEntry")}</TabsTrigger>
                </TabsList>
                <TabsContent value="pantry" className="mt-4">
                  {isLoading ? (
                    <div className="py-4 text-center">
                      <RefreshCw className="animate-spin h-6 w-6 mx-auto text-royal-purple" />
                      <p className="mt-2 text-gray-500">{t("loadingPantry")}</p>
                    </div>
                  ) : (
                    renderPantryTab()
                  )}
                </TabsContent>
                <TabsContent value="manual" className="mt-4">
                  {renderManualTab()}
                </TabsContent>
              </Tabs>
              
              {selectedIngredients.length > 0 && (
                <div className="mt-4 pt-4 border-t">
                  <h3 className="font-medium mb-2">{t("selectedIngredients")}</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedIngredients.map(ingredient => (
                      <div 
                        key={ingredient.id} 
                        className="px-3 py-1 bg-royal-purple/10 rounded-full flex items-center gap-1"
                      >
                        <span>{language === "en" ? ingredient.name : ingredient.nameAr}</span>
                        <button onClick={() => removeIngredient(ingredient)}>
                          <X className="h-3 w-3 text-royal-purple" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
        
        <div className="flex gap-2 mt-3">
          <Button variant="outline" onClick={cancelSelection} className="flex-1 h-9 text-sm">
            {isReviewMode ? t("back") : t("cancel")}
          </Button>
          <Button 
            onClick={confirmSelection} 
            className="flex-1 h-9 text-sm bg-royal-purple hover:bg-royal-purple-dark"
          >
            {isReviewMode ? t("confirm") : t("review")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}