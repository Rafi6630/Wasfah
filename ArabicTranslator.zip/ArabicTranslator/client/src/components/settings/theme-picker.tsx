import * as React from "react";
import { Check, Paintbrush } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";

// Available theme colors
const themeOptions = [
  {
    name: "royal",
    primaryColor: "#6A0DAD", // Royal Purple
    secondaryColor: "#FFD700", // Gold
    label: "Royal Purple & Gold"
  },
  {
    name: "emerald",
    primaryColor: "#046307", // Deep Green
    secondaryColor: "#FFD700", // Gold
    label: "Emerald & Gold"
  },
  {
    name: "sapphire",
    primaryColor: "#0F52BA", // Sapphire Blue
    secondaryColor: "#E5E4E2", // Platinum
    label: "Sapphire & Platinum"
  },
  {
    name: "ruby",
    primaryColor: "#9B111E", // Ruby Red
    secondaryColor: "#FFD700", // Gold
    label: "Ruby & Gold"
  },
  {
    name: "amber",
    primaryColor: "#FF7E00", // Amber
    secondaryColor: "#1C1C1C", // Almost Black
    label: "Amber & Onyx"
  },
  {
    name: "amethyst",
    primaryColor: "#9966CC", // Amethyst
    secondaryColor: "#C0C0C0", // Silver
    label: "Amethyst & Silver"
  }
];

export function ThemePicker() {
  const { t } = useI18n();
  const { user, updateProfileMutation } = useAuth();
  const [currentTheme, setCurrentTheme] = React.useState("royal");

  // Load the user's theme preference when component mounts
  React.useEffect(() => {
    // Access theme preference safely with type checking
    const userTheme = user && (user as any).theme;
    if (userTheme) {
      setCurrentTheme(userTheme);
      applyTheme(userTheme);
    }
  }, [user]);

  // Apply theme function
  const applyTheme = (themeName: string) => {
    const theme = themeOptions.find(t => t.name === themeName);
    if (!theme) return;

    // Apply the theme to CSS variables
    document.documentElement.style.setProperty('--primary-color', theme.primaryColor);
    document.documentElement.style.setProperty('--secondary-color', theme.secondaryColor);
    
    // Calculate HSL values for the CSS variables
    const primaryRgb = hexToRgb(theme.primaryColor);
    const secondaryRgb = hexToRgb(theme.secondaryColor);
    
    if (primaryRgb && secondaryRgb) {
      const primaryHsl = rgbToHsl(primaryRgb.r, primaryRgb.g, primaryRgb.b);
      const secondaryHsl = rgbToHsl(secondaryRgb.r, secondaryRgb.g, secondaryRgb.b);
      
      document.documentElement.style.setProperty('--royal-purple', `${primaryHsl.h} ${primaryHsl.s}% ${primaryHsl.l}%`);
      document.documentElement.style.setProperty('--royal-gold', `${secondaryHsl.h} ${secondaryHsl.s}% ${secondaryHsl.l}%`);
    }
  };

  // Handle theme selection
  const handleThemeSelect = (themeName: string) => {
    setCurrentTheme(themeName);
    applyTheme(themeName);
    
    // Save theme preference to user profile
    if (user) {
      updateProfileMutation.mutate({
        id: user.id,
        // Use type assertion for theme property
        ...(themeName && { theme: themeName as any })
      });
    }
  };

  // Color conversion helpers
  function hexToRgb(hex: string) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }

  function rgbToHsl(r: number, g: number, b: number) {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button 
          variant="outline" 
          className="w-10 h-10 p-0 rounded-full"
          style={{ 
            background: `linear-gradient(135deg, ${
              themeOptions.find(t => t.name === currentTheme)?.primaryColor || "#6A0DAD"
            } 0%, ${
              themeOptions.find(t => t.name === currentTheme)?.secondaryColor || "#FFD700"
            } 100%)` 
          }}
        >
          <Paintbrush className="h-4 w-4 text-white" />
          <span className="sr-only">{t("selectTheme")}</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-64">
        <div className="space-y-2">
          <h4 className="font-medium">{t("selectTheme")}</h4>
          <div className="grid grid-cols-3 gap-2">
            {themeOptions.map((theme) => (
              <button
                key={theme.name}
                className={cn(
                  "h-8 w-8 rounded-full flex items-center justify-center ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                  currentTheme === theme.name && "ring-2 ring-secondary ring-offset-2"
                )}
                style={{ 
                  background: `linear-gradient(135deg, ${theme.primaryColor} 0%, ${theme.secondaryColor} 100%)` 
                }}
                onClick={() => handleThemeSelect(theme.name)}
                title={theme.label}
              >
                {currentTheme === theme.name && (
                  <Check className="h-4 w-4 text-white" />
                )}
                <span className="sr-only">{theme.label}</span>
              </button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-1 pt-2 text-xs text-muted-foreground">
            {themeOptions.map((theme) => (
              <div key={theme.name} className="flex items-center">
                <div 
                  className="h-2 w-2 rounded-full mr-1"
                  style={{ 
                    background: `linear-gradient(135deg, ${theme.primaryColor} 0%, ${theme.secondaryColor} 100%)` 
                  }}
                />
                <span>{theme.label}</span>
              </div>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}