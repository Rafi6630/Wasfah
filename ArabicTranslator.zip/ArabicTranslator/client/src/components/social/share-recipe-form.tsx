import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Copy, 
  Image, 
  Hash,
  Check
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";

interface Recipe {
  id: string;
  title: string;
  titleAr: string;
  imageUrl: string;
  description?: string;
  descriptionAr?: string;
  ingredients: string[];
  cookTime: number;
  servings: number;
  cuisine: string;
  cuisineAr?: string;
  category: string;
  categoryAr?: string;
}

interface ShareRecipeFormProps {
  recipe: Recipe;
  onClose: () => void;
}

// Available templates for sharing
const SHARE_TEMPLATES = [
  {
    id: "elegant",
    name: "Elegant Royal",
    namеAr: "ملكي أنيق",
    background: "bg-gradient-to-br from-royal-purple/90 to-royal-purple-dark",
    textColor: "text-white",
    borderColor: "border-royal-gold/50",
    accentColor: "text-royal-gold",
    overlay: "bg-black/30",
  },
  {
    id: "golden",
    name: "Golden Palace",
    namеAr: "القصر الذهبي",
    background: "bg-gradient-to-br from-royal-gold/90 to-royal-gold-dark",
    textColor: "text-royal-purple-dark",
    borderColor: "border-royal-purple/50",
    accentColor: "text-royal-purple",
    overlay: "bg-white/20",
  },
  {
    id: "minimal",
    name: "Minimalist",
    namеAr: "بسيط",
    background: "bg-white",
    textColor: "text-royal-purple-dark",
    borderColor: "border-royal-gold/30",
    accentColor: "text-royal-gold",
    overlay: "bg-transparent",
  },
];

// Popular hashtags for food recipes
const POPULAR_HASHTAGS = [
  { id: "gourmet", tag: "RoyalGourmet", tagAr: "مطبخ_ملكي" },
  { id: "foodie", tag: "FoodieHeaven", tagAr: "جنة_الطعام" },
  { id: "homemade", tag: "HomemadeDelights", tagAr: "أطباق_منزلية" },
  { id: "chef", tag: "ChefInspired", tagAr: "إبداع_الطهاة" },
  { id: "healthy", tag: "HealthyEating", tagAr: "أكل_صحي" },
  { id: "quick", tag: "QuickMeals", tagAr: "وجبات_سريعة" },
  { id: "fusion", tag: "FusionCuisine", tagAr: "مطبخ_مدمج" },
  { id: "dessert", tag: "SweetTreats", tagAr: "حلويات_شهية" },
  { id: "comfort", tag: "ComfortFood", tagAr: "طعام_مريح" },
  { id: "traditional", tag: "TraditionalRecipes", tagAr: "وصفات_تقليدية" },
  { id: "rg", tag: "RoyalGourmetAI", tagAr: "الذكاء_الاصطناعي_للمطبخ_الملكي" },
];

export function ShareRecipeForm({ recipe, onClose }: ShareRecipeFormProps) {
  const { t, language, isRtl } = useI18n();
  const [selectedTemplate, setSelectedTemplate] = React.useState(SHARE_TEMPLATES[0]);
  const [shareText, setShareText] = React.useState("");
  const [selectedHashtags, setSelectedHashtags] = React.useState<string[]>(["rg"]);
  const [customHashtag, setCustomHashtag] = React.useState("");
  const [includeIngredients, setIncludeIngredients] = React.useState(true);
  const [includeCookingTime, setIncludeCookingTime] = React.useState(true);
  const [generatedPreview, setGeneratedPreview] = React.useState<string | null>(null);
  const [copied, setCopied] = React.useState(false);

  // Generate a default share text based on the recipe
  React.useEffect(() => {
    const title = language === "ar" ? recipe.titleAr : recipe.title;
    const description = language === "ar" ? recipe.descriptionAr : recipe.description;
    const cuisine = language === "ar" ? recipe.cuisineAr : recipe.cuisine;
    
    let text = `${t("justCreatedDelicious")} ${title}! `;
    
    if (description) {
      text += `${description.substring(0, 80)}${description.length > 80 ? '...' : ''} `;
    }
    
    if (includeCookingTime) {
      text += `${t("readyInMinutes", { minutes: recipe.cookTime })}. `;
    }
    
    if (includeIngredients && recipe.ingredients.length > 0) {
      text += `${t("keyIngredients")}: ${recipe.ingredients.slice(0, 3).join(", ")}${recipe.ingredients.length > 3 ? '...' : ''} `;
    }
    
    text += `${t("tryThisRecipe")}! `;
    
    setShareText(text);
  }, [recipe, language, includeIngredients, includeCookingTime]);

  // Generate the hashtags string based on selected hashtags
  const hashtagsString = React.useMemo(() => {
    const tags = selectedHashtags.map(id => {
      const hashtag = POPULAR_HASHTAGS.find(h => h.id === id);
      return hashtag ? (language === "ar" ? hashtag.tagAr : hashtag.tag) : id;
    });
    
    if (customHashtag.trim()) {
      tags.push(customHashtag.trim().replace(/\s+/g, ''));
    }
    
    return tags.map(tag => `#${tag}`).join(' ');
  }, [selectedHashtags, customHashtag, language]);

  // Toggle hashtag selection
  const toggleHashtag = (id: string) => {
    setSelectedHashtags(prev => 
      prev.includes(id)
        ? prev.filter(h => h !== id)
        : [...prev, id]
    );
  };

  // Share to different platforms
  const handleShare = (platform: 'facebook' | 'instagram' | 'twitter' | 'copy') => {
    const fullText = `${shareText}\n\n${hashtagsString}`;
    
    // Mock platform sharing - in a real app, this would integrate with platform-specific APIs
    if (platform === 'copy') {
      navigator.clipboard.writeText(fullText).then(() => {
        setCopied(true);
        toast({
          title: t("copiedToClipboard"),
          description: t("pasteInSocialMedia"),
        });
        setTimeout(() => setCopied(false), 2000);
      });
    } else {
      // Mock sharing to social media
      toast({
        title: t("sharedTo", { platform: platform.charAt(0).toUpperCase() + platform.slice(1) }),
        description: t("shareSuccessful"),
      });
    }
    
    // Generate a preview for the user to see how it might look
    setGeneratedPreview(fullText);
  };

  return (
    <div className="p-1">
      <Tabs defaultValue="content" className="w-full">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="content">{t("content")}</TabsTrigger>
          <TabsTrigger value="template">{t("template")}</TabsTrigger>
          <TabsTrigger value="hashtags">{t("hashtags")}</TabsTrigger>
        </TabsList>
        
        {/* Content Tab */}
        <TabsContent value="content">
          <div className="space-y-4">
            <div>
              <Label>{t("shareText")}</Label>
              <Textarea
                value={shareText}
                onChange={(e) => setShareText(e.target.value)}
                placeholder={t("describeYourRecipe")}
                className="min-h-[120px]"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Switch
                  id="include-ingredients"
                  checked={includeIngredients}
                  onCheckedChange={setIncludeIngredients}
                />
                <Label htmlFor="include-ingredients">{t("includeIngredients")}</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch
                  id="include-time"
                  checked={includeCookingTime}
                  onCheckedChange={setIncludeCookingTime}
                />
                <Label htmlFor="include-time">{t("includeCookingTime")}</Label>
              </div>
            </div>
            
            <div>
              <Label className="flex items-center mb-2">
                <Hash className="h-4 w-4 mr-1" />
                {t("selectedHashtags")}
              </Label>
              <div className="bg-gray-50 p-2 rounded-md min-h-[40px]">
                {selectedHashtags.length > 0 ? (
                  <div className="flex flex-wrap gap-1">
                    {selectedHashtags.map(id => {
                      const hashtag = POPULAR_HASHTAGS.find(h => h.id === id);
                      return (
                        <Badge key={id} variant="secondary" className="bg-royal-purple/10 hover:bg-royal-purple/20">
                          #{language === "ar" ? hashtag?.tagAr : hashtag?.tag}
                        </Badge>
                      );
                    })}
                    {customHashtag && (
                      <Badge variant="secondary" className="bg-royal-gold/10 hover:bg-royal-gold/20">
                        #{customHashtag.trim().replace(/\s+/g, '')}
                      </Badge>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-400 text-sm italic">{t("noHashtagsSelected")}</p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>
        
        {/* Template Tab */}
        <TabsContent value="template">
          <div className="space-y-4">
            <div>
              <Label>{t("selectTemplate")}</Label>
              <RadioGroup 
                value={selectedTemplate.id}
                onValueChange={(value) => {
                  const template = SHARE_TEMPLATES.find(t => t.id === value);
                  if (template) setSelectedTemplate(template);
                }}
                className="grid grid-cols-1 gap-3 mt-2"
              >
                {SHARE_TEMPLATES.map(template => (
                  <div 
                    key={template.id}
                    className={`border rounded-lg overflow-hidden ${
                      selectedTemplate.id === template.id 
                        ? 'border-royal-gold ring-1 ring-royal-gold/50' 
                        : 'border-gray-200'
                    }`}
                  >
                    <div className={`flex items-start p-3 ${template.background}`}>
                      <RadioGroupItem 
                        value={template.id} 
                        id={`template-${template.id}`}
                        className="mt-1"
                      />
                      <div className="ml-3 flex-1">
                        <Label 
                          htmlFor={`template-${template.id}`}
                          className={`font-medium ${template.textColor}`}
                        >
                          {language === "ar" ? template.namеAr : template.name}
                        </Label>
                        <div className={`p-3 mt-2 rounded border ${template.borderColor} ${template.overlay}`}>
                          <div className={`text-sm ${template.textColor}`}>
                            {t("sampleText")}
                          </div>
                          <div className={`text-xs mt-1 font-bold ${template.accentColor}`}>
                            #RoyalGourmetAI #FoodieHeaven
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </div>
        </TabsContent>
        
        {/* Hashtags Tab */}
        <TabsContent value="hashtags">
          <div className="space-y-4">
            <div>
              <Label>{t("popularHashtags")}</Label>
              <div className="flex flex-wrap gap-2 mt-2">
                {POPULAR_HASHTAGS.map(hashtag => (
                  <Badge 
                    key={hashtag.id}
                    variant="outline"
                    className={`cursor-pointer ${
                      selectedHashtags.includes(hashtag.id)
                        ? 'bg-royal-purple text-white hover:bg-royal-purple-dark'
                        : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                    onClick={() => toggleHashtag(hashtag.id)}
                  >
                    #{language === "ar" ? hashtag.tagAr : hashtag.tag}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div>
              <Label>{t("customHashtag")}</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <span className="absolute inset-y-0 left-3 flex items-center text-gray-400">
                    #
                  </span>
                  <Input
                    value={customHashtag}
                    onChange={(e) => setCustomHashtag(e.target.value)}
                    placeholder={t("enterCustomHashtag")}
                    className="pl-7"
                  />
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  type="button"
                  onClick={() => setCustomHashtag("")}
                  disabled={!customHashtag}
                >
                  {t("clear")}
                </Button>
              </div>
            </div>
            
            <div>
              <Label>{t("allHashtags")}</Label>
              <div className="p-3 bg-gray-50 rounded-md mt-2">
                <p className="text-sm break-words">
                  {hashtagsString || t("noHashtagsSelected")}
                </p>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Preview of the share */}
      {generatedPreview && (
        <Card className={`mt-4 ${selectedTemplate.background}`}>
          <CardContent className={`p-4 ${selectedTemplate.textColor}`}>
            <div className="flex mb-3">
              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-white">
                <img src={recipe.imageUrl} alt={language === "ar" ? recipe.titleAr : recipe.title} className="w-full h-full object-cover" />
              </div>
              <div className="ml-3">
                <div className="font-bold">Royal Gourmet Chef</div>
                <div className="text-sm opacity-80">@royalgourmet</div>
              </div>
            </div>
            <p className="mb-2 text-sm whitespace-pre-line">{shareText}</p>
            <p className={`text-xs font-bold ${selectedTemplate.accentColor}`}>
              {hashtagsString}
            </p>
          </CardContent>
        </Card>
      )}
      
      {/* Share buttons */}
      <div className="flex gap-2 mt-6 mb-2">
        <Button variant="outline" className="flex-1" onClick={() => handleShare('facebook')}>
          <Facebook className="mr-2 h-4 w-4" />
          Facebook
        </Button>
        <Button variant="outline" className="flex-1" onClick={() => handleShare('instagram')}>
          <Instagram className="mr-2 h-4 w-4" />
          Instagram
        </Button>
        <Button variant="outline" className="flex-1" onClick={() => handleShare('twitter')}>
          <Twitter className="mr-2 h-4 w-4" />
          Twitter
        </Button>
      </div>
      
      <Button 
        className="w-full gap-2"
        variant="default"
        onClick={() => handleShare('copy')}
      >
        {copied ? (
          <>
            <Check className="h-4 w-4" />
            {t("copied")}
          </>
        ) : (
          <>
            <Copy className="h-4 w-4" />
            {t("copyText")}
          </>
        )}
      </Button>
    </div>
  );
}