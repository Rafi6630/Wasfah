import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { RoyalCrownIcon } from "@/components/icons/crown-icon";
import { RoyalShimmer } from "@/components/animations/royal-shimmer";
import { useAnimation } from "@/lib/animation-context";

interface RoyalLoadingProps extends React.HTMLAttributes<HTMLDivElement> {
  // Size of the loading indicator
  size?: "sm" | "md" | "lg";
  // Optional text/message to display
  message?: string;
  // Type of loading animation
  type?: "crown" | "shimmer" | "pulse";
  // Whether to center the loader in its container
  centered?: boolean;
}

export function RoyalLoading({
  size = "md",
  message,
  type = "crown",
  centered = true,
  className,
  ...props
}: RoyalLoadingProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Scale the animation speed based on animation settings
  const speedFactor = getDurationFactor();
  
  // Determine sizes based on the size prop
  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-12 h-12",
    lg: "w-20 h-20",
  };
  
  // Container size classes
  const containerSizeClasses = {
    sm: "w-16 h-16",
    md: "w-32 h-32",
    lg: "w-40 h-40",
  };
  
  // Font size for message
  const messageSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  };
  
  // Don't animate if animations are disabled or reduced motion is preferred
  const showAnimation = animationsEnabled && !prefersReducedMotion;
  
  // Crown float animation
  const crownAnimationVariants = {
    initial: {
      y: 0,
    },
    animate: {
      y: showAnimation ? [0, -8, 0] : 0,
      transition: {
        repeat: Infinity,
        duration: 1.5 / speedFactor,
        ease: "easeInOut",
      },
    },
  };
  
  // Pulse animation
  const pulseAnimationVariants = {
    initial: {
      scale: 0.9,
      opacity: 0.7,
    },
    animate: {
      scale: showAnimation ? [0.9, 1.05, 0.9] : 1,
      opacity: showAnimation ? [0.7, 1, 0.7] : 1,
      transition: {
        repeat: Infinity,
        duration: 1.8 / speedFactor,
        ease: "easeInOut",
      },
    },
  };
  
  return (
    <div 
      className={cn(
        "flex flex-col items-center justify-center",
        centered && "absolute inset-0 bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm z-20",
        className
      )}
      {...props}
    >
      {type === "crown" && (
        <div className="relative">
          <motion.div
            className={cn("text-royal-gold", sizeClasses[size])}
            initial="initial"
            animate="animate"
            variants={crownAnimationVariants}
          >
            <RoyalCrownIcon />
          </motion.div>
          <div className={cn("mt-6 mb-4", message ? "block" : "hidden")}>
            <motion.p 
              className={cn("text-royal-purple font-medium", messageSizeClasses[size])}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              {message}
            </motion.p>
          </div>
        </div>
      )}
      
      {type === "shimmer" && (
        <div className="relative">
          <div className={cn(containerSizeClasses[size], "relative")}>
            <RoyalShimmer className="absolute inset-0 rounded-lg" />
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                className={cn("text-royal-gold", sizeClasses[size])}
                initial="initial"
                animate="animate"
                variants={pulseAnimationVariants}
              >
                <RoyalCrownIcon />
              </motion.div>
            </div>
          </div>
          <div className={cn("mt-6 mb-4 text-center", message ? "block" : "hidden")}>
            <motion.p 
              className={cn("text-royal-purple font-medium", messageSizeClasses[size])}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              {message}
            </motion.p>
          </div>
        </div>
      )}
      
      {type === "pulse" && (
        <div className="relative">
          <motion.div
            className={cn(
              "rounded-full bg-gradient-to-r from-royal-purple to-royal-purple-dark",
              containerSizeClasses[size],
              "flex items-center justify-center"
            )}
            initial="initial"
            animate="animate"
            variants={pulseAnimationVariants}
          >
            <div className={cn("text-white", sizeClasses[size])}>
              <RoyalCrownIcon />
            </div>
          </motion.div>
          <div className={cn("mt-6 mb-4 text-center", message ? "block" : "hidden")}>
            <motion.p 
              className={cn("text-royal-purple font-medium", messageSizeClasses[size])}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              {message}
            </motion.p>
          </div>
        </div>
      )}
    </div>
  );
}