import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAnimation } from '@/lib/animation-context';
import { RoyalCrownIcon } from '@/components/icons/crown-icon';
import { Star, Crown, Sparkles } from 'lucide-react';

interface AnimationDemoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  demoText?: string;
}

export function AnimationDemo({ 
  className = "", 
  size = 'md', 
  demoText = 'Royal Animation' 
}: AnimationDemoProps) {
  const { 
    animationsEnabled, 
    prefersReducedMotion, 
    transitionType,
    getDurationFactor
  } = useAnimation();
  
  const [playing, setPlaying] = useState(true);
  const [showDemo, setShowDemo] = useState(false);
  
  // Don't animate if animations are disabled or reduced motion is preferred
  const shouldAnimate = animationsEnabled && !prefersReducedMotion;
  
  // Duration factor based on animation speed settings
  const durationFactor = getDurationFactor();
  
  // Set sizes based on the size prop
  const getSizeClasses = () => {
    switch(size) {
      case 'sm': return 'h-20 w-full';
      case 'lg': return 'h-48 w-full';
      case 'md':
      default: return 'h-32 w-full';
    }
  };
  
  // Toggle animation on/off
  const togglePlaying = () => {
    setPlaying(!playing);
  };
  
  // Restart the demo animation every 4 seconds
  useEffect(() => {
    if (!shouldAnimate || !playing) return;
    
    setShowDemo(true);
    
    const timer = setTimeout(() => {
      setShowDemo(false);
      
      // After exit animation completes, show again
      const resetTimer = setTimeout(() => {
        setShowDemo(true);
      }, 1000 * durationFactor);
      
      return () => clearTimeout(resetTimer);
    }, 4000);
    
    return () => clearTimeout(timer);
  }, [shouldAnimate, playing, transitionType, durationFactor]);
  
  // Transition variants based on selected type
  const getVariants = () => {
    switch(transitionType) {
      case 'slide':
        return {
          initial: { x: '-100%', opacity: 0 },
          animate: { x: '0%', opacity: 1 },
          exit: { x: '100%', opacity: 0 },
        };
      case 'scale':
        return {
          initial: { scale: 0.5, opacity: 0 },
          animate: { scale: 1, opacity: 1 },
          exit: { scale: 0.5, opacity: 0 },
        };
      case 'crown':
        return {
          initial: { y: 20, opacity: 0, rotate: -2 },
          animate: { y: 0, opacity: 1, rotate: 0 },
          exit: { y: -20, opacity: 0, rotate: 2 },
        };
      case 'sparkle':
        return {
          initial: { 
            opacity: 0,
            filter: 'brightness(1.2) contrast(1.1)',
            scale: 0.9,
          },
          animate: { 
            opacity: 1,
            filter: 'brightness(1) contrast(1)',
            scale: 1,
          },
          exit: { 
            opacity: 0,
            filter: 'brightness(0.9) contrast(0.95)',
            scale: 1.1,
          },
        };
      case 'fade':
      default:
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
        };
    }
  };
  
  // Get the appropriate icon based on transition type
  const getIcon = () => {
    switch(transitionType) {
      case 'crown':
        return <Crown className="h-6 w-6 text-royal-gold" />;
      case 'sparkle':
        return <Sparkles className="h-6 w-6 text-royal-gold" />;
      default:
        return <RoyalCrownIcon className="h-6 w-6" animated={shouldAnimate} />;
    }
  };
  
  return (
    <div 
      className={`relative bg-gray-50 rounded-md border border-gray-200 overflow-hidden flex items-center justify-center ${getSizeClasses()} ${className}`}
    >
      {/* Animation demo area */}
      <AnimatePresence mode="wait">
        {showDemo && shouldAnimate && playing ? (
          <motion.div
            key="animation-demo"
            initial="initial"
            animate="animate"
            exit="exit"
            variants={getVariants()}
            transition={{
              duration: 0.7 * durationFactor,
              ease: "easeInOut"
            }}
            className="bg-white border-2 border-royal-gold/30 rounded-lg px-4 py-3 shadow-sm flex items-center justify-center space-x-2"
          >
            {getIcon()}
            <span className="font-medium text-royal-purple">{demoText}</span>
          </motion.div>
        ) : (
          <motion.div
            key="animation-placeholder"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center p-4"
          >
            {!shouldAnimate ? (
              <div className="text-sm text-gray-500">
                <p className="font-medium">Animations disabled</p>
                <p className="text-xs mt-1">Enable in settings</p>
              </div>
            ) : !playing ? (
              <div className="text-sm text-gray-500">
                <p className="font-medium">Animation paused</p>
                <p className="text-xs mt-1">Click to resume</p>
              </div>
            ) : (
              <div className="text-sm text-gray-400">
                <Star className="h-5 w-5 mx-auto mb-1 opacity-40" />
                <p>Loading demo...</p>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Click overlay to toggle animation */}
      <div 
        className="absolute inset-0 cursor-pointer"
        onClick={togglePlaying}
        aria-label={playing ? "Pause animation" : "Play animation"}
      />
      
      {/* Label showing the current animation type */}
      <div className="absolute bottom-1 right-2">
        <p className="text-xs text-gray-400 font-mono">
          {transitionType}
        </p>
      </div>
    </div>
  );
}