import { motion } from 'framer-motion';
import { RoyalCrownIcon } from '../icons/crown-icon';

interface CrownAnimationProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function CrownAnimation({ className = '', size = 'md' }: CrownAnimationProps) {
  // Size mapping
  const sizeMap = {
    sm: 'h-6 w-6',
    md: 'h-10 w-10',
    lg: 'h-16 w-16',
  };

  // Floating animation for the crown
  const floatVariants = {
    initial: { y: 0, rotateZ: 0 },
    animate: {
      y: [-3, 3, -3],
      rotateZ: [-2, 2, -2],
      transition: {
        y: {
          repeat: Infinity,
          duration: 2.5,
          ease: 'easeInOut',
        },
        rotateZ: {
          repeat: Infinity,
          duration: 3,
          ease: 'easeInOut',
        }
      }
    }
  };

  // Glowing effect animation
  const glowVariants = {
    initial: { 
      filter: 'drop-shadow(0 0 2px rgba(255, 215, 0, 0.3))' 
    },
    animate: {
      filter: [
        'drop-shadow(0 0 2px rgba(255, 215, 0, 0.3))',
        'drop-shadow(0 0 6px rgba(255, 215, 0, 0.7))',
        'drop-shadow(0 0 2px rgba(255, 215, 0, 0.3))'
      ],
      transition: {
        repeat: Infinity,
        duration: 2,
        ease: 'easeInOut',
      }
    }
  };

  return (
    <motion.div
      className={`relative ${className}`}
      initial="initial"
      animate="animate"
      variants={floatVariants}
    >
      <motion.div
        initial="initial"
        animate="animate"
        variants={glowVariants}
      >
        <RoyalCrownIcon className={`text-royal-gold ${sizeMap[size]}`} />
      </motion.div>
    </motion.div>
  );
}