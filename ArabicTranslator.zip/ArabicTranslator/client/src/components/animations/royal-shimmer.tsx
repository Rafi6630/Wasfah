import React, { ReactNode } from "react";
import { motion, MotionStyle } from "framer-motion";
import { cn } from "@/lib/utils";
import { useAnimation } from "@/lib/animation-context";

interface RoyalShimmerProps {
  children: ReactNode;
  className?: string;
  shimmerWidth?: number;  // Width of the shimmer effect in percent (1-100)
  shimmerOpacity?: number; // Opacity of the shimmer effect (0-1)
  direction?: "left-to-right" | "right-to-left" | "top-to-bottom" | "diagonal"; // Direction of shimmer
  color?: string; // Custom shimmer color
  disabled?: boolean; // Disable shimmer animation
  delay?: number; // Delay before animation starts (in seconds)
  containerClassName?: string; // Class for the container
}

/**
 * RoyalShimmer - Adds a shimmering effect to child elements
 */
export function RoyalShimmer({
  children,
  className = "",
  shimmerWidth = 30,
  shimmerOpacity = 0.2,
  direction = "left-to-right",
  color = "#C5A942", // Royal gold
  disabled = false,
  delay = 0,
  containerClassName = "",
}: RoyalShimmerProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Don't animate if animations are disabled or reduced motion is preferred
  const shouldAnimate = animationsEnabled && !prefersReducedMotion && !disabled;
  
  // Get speed factor based on animation settings
  const durationFactor = getDurationFactor();
  
  // Generate the appropriate gradient based on direction
  const getGradient = (): MotionStyle => {
    // Base colors with specified shimmer color
    const transparent = `rgba(255, 255, 255, 0)`;
    const shimmerColor = `${color}`;
    
    // Calculate duration based on direction and speed settings
    const getDuration = () => {
      // Base durations for different directions
      const baseDurations = {
        "left-to-right": 2.5,
        "right-to-left": 2.5,
        "top-to-bottom": 3,
        "diagonal": 3.5,
      };
      
      return baseDurations[direction] / durationFactor;
    };
    
    // Direction-specific gradient and animation settings
    switch (direction) {
      case "right-to-left":
        return {
          backgroundImage: `linear-gradient(to left, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`,
          backgroundSize: "200% 100%",
          backgroundRepeat: "no-repeat",
          backgroundPosition: shouldAnimate ? ["100% 0%", "0% 0%"] : "100% 0%",
          transition: {
            backgroundPosition: {
              repeat: Infinity,
              duration: getDuration(),
              ease: "linear",
              delay: delay,
            }
          }
        };
      case "top-to-bottom":
        return {
          backgroundImage: `linear-gradient(to bottom, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`,
          backgroundSize: "100% 200%",
          backgroundRepeat: "no-repeat",
          backgroundPosition: shouldAnimate ? ["0% 0%", "0% 100%"] : "0% 0%",
          transition: {
            backgroundPosition: {
              repeat: Infinity,
              duration: getDuration(),
              ease: "linear",
              delay: delay,
            }
          }
        };
      case "diagonal":
        return {
          backgroundImage: `linear-gradient(135deg, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`,
          backgroundSize: "200% 200%",
          backgroundRepeat: "no-repeat",
          backgroundPosition: shouldAnimate ? ["100% 100%", "0% 0%"] : "100% 100%",
          transition: {
            backgroundPosition: {
              repeat: Infinity,
              duration: getDuration(),
              ease: "linear",
              delay: delay,
            }
          }
        };
      case "left-to-right":
      default:
        return {
          backgroundImage: `linear-gradient(to right, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`,
          backgroundSize: "200% 100%",
          backgroundRepeat: "no-repeat",
          backgroundPosition: shouldAnimate ? ["0% 0%", "100% 0%"] : "0% 0%",
          transition: {
            backgroundPosition: {
              repeat: Infinity,
              duration: getDuration(),
              ease: "linear",
              delay: delay,
            }
          }
        };
    }
  };

  return (
    <div className={cn("relative overflow-hidden", containerClassName)}>
      {/* The main content */}
      <div className={cn("relative z-10", className)}>
        {children}
      </div>
      
      {/* The shimmer overlay */}
      <motion.div
        className="absolute inset-0 z-20 pointer-events-none"
        style={{
          mixBlendMode: "overlay",
          opacity: shimmerOpacity,
          ...getGradient()
        }}
        aria-hidden="true"
      />
    </div>
  );
}

interface ShimmerButtonProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
}

/**
 * ShimmerButton - A button with a shimmering effect
 */
export function ShimmerButton({
  children,
  className = "",
  onClick,
  disabled = false,
}: ShimmerButtonProps) {
  return (
    <RoyalShimmer 
      shimmerWidth={40}
      shimmerOpacity={0.3}
      direction="diagonal"
      disabled={disabled}
      containerClassName={cn(
        "rounded-md overflow-hidden",
        disabled ? "opacity-70 cursor-not-allowed" : "cursor-pointer",
        className
      )}
    >
      <button
        className="px-4 py-2 bg-royal-purple text-white font-medium rounded-md w-full h-full"
        onClick={onClick}
        disabled={disabled}
      >
        {children}
      </button>
    </RoyalShimmer>
  );
}