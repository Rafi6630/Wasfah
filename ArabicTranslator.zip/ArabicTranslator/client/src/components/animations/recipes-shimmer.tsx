import React, { ReactNode } from "react";
import { motion, MotionStyle } from "framer-motion";
import { cn } from "@/lib/utils";
import { useAnimation } from "@/lib/animation-context";

interface RecipesShimmerProps {
  children: ReactNode;
  className?: string;
  shimmerWidth?: number;  // Width of the shimmer effect in percent (1-100)
  shimmerOpacity?: number; // Opacity of the shimmer effect (0-1)
  direction?: "left-to-right" | "right-to-left" | "top-to-bottom" | "diagonal"; // Direction of shimmer
  color?: string; // Custom shimmer color
  disabled?: boolean; // Disable shimmer animation
  delay?: number; // Delay before animation starts (in seconds)
  containerClassName?: string; // Class for the container
}

/**
 * RecipesShimmer - Adds a shimmering effect to child elements
 */
export function RecipesShimmer({
  children,
  className = "",
  shimmerWidth = 30,
  shimmerOpacity = 0.2,
  direction = "left-to-right",
  color = "#C5A942", // Gold color
  disabled = false,
  delay = 0,
  containerClassName = "",
}: RecipesShimmerProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Don't animate if animations are disabled or reduced motion is preferred
  const shouldAnimate = animationsEnabled && !prefersReducedMotion && !disabled;
  
  // Get speed factor based on animation settings
  const durationFactor = getDurationFactor();
  
  // Base colors
  const transparent = `rgba(255, 255, 255, 0)`;
  const shimmerColor = `${color}`;
  
  // Calculate duration based on direction and speed settings
  const getDuration = () => {
    // Base durations for different directions
    const baseDurations = {
      "left-to-right": 2.5,
      "right-to-left": 2.5,
      "top-to-bottom": 3,
      "diagonal": 3.5,
    };
    
    return baseDurations[direction] / durationFactor;
  };
  
  // Set up background style based on direction
  let backgroundImage = "";
  let backgroundSize = "";
  let backgroundStart = "";
  let backgroundEnd = "";
  
  switch (direction) {
    case "right-to-left":
      backgroundImage = `linear-gradient(to left, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`;
      backgroundSize = "200% 100%";
      backgroundStart = "100% 0%";
      backgroundEnd = "0% 0%";
      break;
    case "top-to-bottom":
      backgroundImage = `linear-gradient(to bottom, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`;
      backgroundSize = "100% 200%";
      backgroundStart = "0% 0%";
      backgroundEnd = "0% 100%";
      break;
    case "diagonal":
      backgroundImage = `linear-gradient(135deg, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`;
      backgroundSize = "200% 200%";
      backgroundStart = "100% 100%";
      backgroundEnd = "0% 0%";
      break;
    case "left-to-right":
    default:
      backgroundImage = `linear-gradient(to right, ${transparent}, ${shimmerColor} ${shimmerWidth/2}%, ${transparent} ${shimmerWidth}%)`;
      backgroundSize = "200% 100%";
      backgroundStart = "0% 0%";
      backgroundEnd = "100% 0%";
      break;
  }
  
  return (
    <div className={cn("relative overflow-hidden", containerClassName)}>
      {/* The main content */}
      <div className={cn("relative z-10", className)}>
        {children}
      </div>
      
      {/* The shimmer overlay */}
      {shouldAnimate ? (
        <motion.div
          className="absolute inset-0 z-20 pointer-events-none"
          style={{
            mixBlendMode: "overlay",
            opacity: shimmerOpacity,
            backgroundImage,
            backgroundSize,
            backgroundRepeat: "no-repeat",
            backgroundPosition: backgroundStart,
          }}
          animate={{
            backgroundPosition: [backgroundStart, backgroundEnd],
          }}
          transition={{
            backgroundPosition: {
              repeat: Infinity,
              duration: getDuration(),
              ease: "linear",
              delay,
            }
          }}
          aria-hidden="true"
        />
      ) : (
        <div
          className="absolute inset-0 z-20 pointer-events-none"
          style={{
            mixBlendMode: "overlay",
            opacity: shimmerOpacity,
            backgroundImage,
            backgroundSize,
            backgroundRepeat: "no-repeat",
            backgroundPosition: backgroundStart,
          }}
          aria-hidden="true"
        />
      )}
    </div>
  );
}

interface ShimmerButtonProps {
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
}

/**
 * ShimmerButton - A button with a shimmering effect
 */
export function ShimmerButton({
  children,
  className = "",
  onClick,
  disabled = false,
}: ShimmerButtonProps) {
  return (
    <RecipesShimmer 
      shimmerWidth={40}
      shimmerOpacity={0.3}
      direction="diagonal"
      disabled={disabled}
      containerClassName={cn(
        "rounded-md overflow-hidden",
        disabled ? "opacity-70 cursor-not-allowed" : "cursor-pointer",
        className
      )}
    >
      <button
        className="px-4 py-2 bg-recipes-purple text-white font-medium rounded-md w-full h-full"
        onClick={onClick}
        disabled={disabled}
      >
        {children}
      </button>
    </RecipesShimmer>
  );
}

// For backward compatibility
export const RoyalShimmer = RecipesShimmer;
export type { RecipesShimmerProps };
export type { RecipesShimmerProps as RoyalShimmerProps };