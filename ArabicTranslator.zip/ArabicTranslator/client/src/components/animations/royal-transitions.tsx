import React, { ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAnimation } from "@/lib/animation-context";

interface FadeInProps {
  children: ReactNode;
  duration?: number;
  delay?: number;
  className?: string;
  direction?: "up" | "down" | "left" | "right" | "none";
  distance?: number; // in pixels
  once?: boolean; // animate only once
  staggerChildren?: boolean; // stagger children animations
  staggerDelay?: number; // delay between children in seconds
}

/**
 * RoyalFadeIn - Fade in animation with optional direction
 */
export function RoyalFadeIn({
  children,
  duration,
  delay = 0,
  className = "",
  direction = "up",
  distance = 20,
  once = false,
  staggerChildren = false,
  staggerDelay = 0.1,
}: FadeInProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Disable animations if global setting is off or user prefers reduced motion
  const shouldAnimate = animationsEnabled && !prefersReducedMotion;
  
  // Adjust duration based on animation speed settings
  const durationFactor = getDurationFactor();
  const animationDuration = duration ? duration / durationFactor : 0.5 / durationFactor;
  
  // Set initial and animate properties based on direction
  const getDirectionalProps = () => {
    switch (direction) {
      case "up":
        return { y: distance, opacity: 0 };
      case "down":
        return { y: -distance, opacity: 0 };
      case "left":
        return { x: distance, opacity: 0 };
      case "right":
        return { x: -distance, opacity: 0 };
      case "none":
      default:
        return { opacity: 0 };
    }
  };
  
  // Animation variants
  const variants = {
    hidden: getDirectionalProps(),
    visible: {
      y: 0,
      x: 0,
      opacity: 1,
      transition: {
        duration: animationDuration,
        delay: delay,
        ease: "easeOut",
        when: "beforeChildren",
        staggerChildren: staggerChildren ? staggerDelay : 0,
      }
    }
  };
  
  // If animations are disabled, don't apply any motion effects
  if (!shouldAnimate) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="visible"
      variants={variants}
      viewport={{ once }}
    >
      {children}
    </motion.div>
  );
}

interface SlideInProps {
  children: ReactNode;
  duration?: number;
  delay?: number;
  className?: string;
  direction?: "up" | "down" | "left" | "right";
  distance?: number | string; // in pixels or percentage
  once?: boolean;
}

/**
 * RoyalSlideIn - Slide in animation with optional direction
 */
export function RoyalSlideIn({
  children,
  duration,
  delay = 0,
  className = "",
  direction = "left",
  distance = "100%",
  once = false,
}: SlideInProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Disable animations if global setting is off or user prefers reduced motion
  const shouldAnimate = animationsEnabled && !prefersReducedMotion;
  
  // Adjust duration based on animation speed settings
  const durationFactor = getDurationFactor();
  const animationDuration = duration ? duration / durationFactor : 0.7 / durationFactor;
  
  // Set initial properties based on direction
  const getInitialProps = () => {
    switch (direction) {
      case "up": return { y: typeof distance === "number" ? distance : distance, opacity: 0 };
      case "down": return { y: typeof distance === "number" ? -distance : `-${distance}`, opacity: 0 };
      case "left": return { x: typeof distance === "number" ? distance : distance, opacity: 0 };
      case "right": return { x: typeof distance === "number" ? -distance : `-${distance}`, opacity: 0 };
      default: return { x: typeof distance === "number" ? distance : distance, opacity: 0 };
    }
  };
  
  // If animations are disabled, don't apply any motion effects
  if (!shouldAnimate) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      className={className}
      initial={getInitialProps()}
      animate={{ x: 0, y: 0, opacity: 1 }}
      transition={{
        duration: animationDuration,
        delay: delay,
        ease: [0.25, 0.1, 0.25, 1], // custom cubic bezier for royal feel
      }}
      viewport={{ once }}
    >
      {children}
    </motion.div>
  );
}

interface StaggerChildrenProps {
  children: ReactNode[];
  className?: string;
  childClassName?: string;
  staggerDelay?: number;
  duration?: number;
  direction?: "up" | "down" | "left" | "right" | "none";
  distance?: number;
}

/**
 * RoyalStaggerChildren - Stagger animation for multiple children
 */
export function RoyalStaggerChildren({
  children,
  className = "",
  childClassName = "",
  staggerDelay = 0.1,
  duration,
  direction = "up",
  distance = 15,
}: StaggerChildrenProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Disable animations if global setting is off or user prefers reduced motion
  const shouldAnimate = animationsEnabled && !prefersReducedMotion;
  
  // Adjust duration based on animation speed settings
  const durationFactor = getDurationFactor();
  const animationDuration = duration ? duration / durationFactor : 0.4 / durationFactor;
  
  // Set initial properties based on direction
  const getDirectionalProps = () => {
    switch (direction) {
      case "up": return { y: distance, opacity: 0 };
      case "down": return { y: -distance, opacity: 0 };
      case "left": return { x: distance, opacity: 0 };
      case "right": return { x: -distance, opacity: 0 };
      case "none":
      default: return { opacity: 0 };
    }
  };
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: staggerDelay / durationFactor,
      }
    }
  };
  
  const itemVariants = {
    hidden: getDirectionalProps(),
    visible: {
      x: 0,
      y: 0,
      opacity: 1,
      transition: {
        duration: animationDuration,
        ease: "easeOut",
      }
    }
  };
  
  // If animations are disabled, render without animations
  if (!shouldAnimate) {
    return (
      <div className={className}>
        {children.map((child, index) => (
          <div key={index} className={childClassName}>
            {child}
          </div>
        ))}
      </div>
    );
  }

  return (
    <motion.div
      className={className}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {children.map((child, index) => (
        <motion.div
          key={index}
          className={childClassName}
          variants={itemVariants}
        >
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}

interface RoyalPresenceProps {
  children: ReactNode;
  show: boolean;
  type?: "fade" | "slide" | "scale" | "crown" | "sparkle";
  className?: string;
  duration?: number;
  distance?: number;
}

/**
 * RoyalPresence - AnimatePresence wrapper with royal theme transitions
 */
export function RoyalPresence({
  children,
  show,
  type = "fade",
  className = "",
  duration,
  distance = 30,
}: RoyalPresenceProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Disable animations if global setting is off or user prefers reduced motion
  const shouldAnimate = animationsEnabled && !prefersReducedMotion;
  
  // Adjust duration based on animation speed settings
  const durationFactor = getDurationFactor();
  const animationDuration = duration ? duration / durationFactor : 0.3 / durationFactor;
  
  // Define variants for different transition types
  const variants = {
    fade: {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0 },
    },
    slide: {
      initial: { x: -distance, opacity: 0 },
      animate: { x: 0, opacity: 1 },
      exit: { x: distance, opacity: 0 },
    },
    scale: {
      initial: { scale: 0.9, opacity: 0 },
      animate: { scale: 1, opacity: 1 },
      exit: { scale: 0.9, opacity: 0 },
    },
    crown: {
      initial: { y: distance, opacity: 0, rotate: -2 },
      animate: { y: 0, opacity: 1, rotate: 0 },
      exit: { y: -distance, opacity: 0, rotate: 2 },
    },
    sparkle: {
      initial: { 
        opacity: 0,
        filter: "brightness(1.2) contrast(1.1)",
        scale: 0.97,
      },
      animate: { 
        opacity: 1,
        filter: "brightness(1) contrast(1)",
        scale: 1,
      },
      exit: { 
        opacity: 0,
        filter: "brightness(0.9) contrast(0.95)",
        scale: 1.03,
      },
    },
  };
  
  // Transition settings
  const transition = {
    duration: animationDuration,
    ease: type === "crown" ? "anticipate" : "easeInOut",
  };
  
  // If animations are disabled, render simpler version
  if (!shouldAnimate) {
    return show ? <div className={className}>{children}</div> : null;
  }

  return (
    <AnimatePresence mode="wait">
      {show && (
        <motion.div
          className={className}
          key="royal-presence"
          initial="initial"
          animate="animate"
          exit="exit"
          variants={variants[type]}
          transition={transition}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}