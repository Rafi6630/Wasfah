import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RecipeListItem } from "@/components/recipe/recipe-list-item";
import { RecipeRecommendation } from "@/lib/openai";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { format, addDays, startOfWeek, isSameDay } from "date-fns";
import { enUS, ar } from "date-fns/locale";

interface MealPlan {
  date: Date;
  meals: {
    breakfast?: RecipeRecommendation;
    lunch?: RecipeRecommendation;
    dinner?: RecipeRecommendation;
    snack?: RecipeRecommendation;
  };
}

// Sample recipe data for demo
const sampleRecipes: RecipeRecommendation[] = [
  {
    id: "recipe1",
    name: "Shakshuka with Fresh Herbs",
    nameAr: "شكشوكة بالأعشاب الطازجة",
    matchPercentage: 95,
    cookTime: 25,
    imageUrl: "https://images.unsplash.com/photo-1590412200988-a436970781fa?w=300&auto=format&fit=crop",
    difficulty: "easy",
    servings: "2",
    calories: 320,
    description: "A flavorful Middle Eastern dish of eggs poached in a sauce of tomatoes, peppers, and spices.",
    descriptionAr: "طبق شرق أوسطي مليء بالنكهات من البيض المسلوق في صلصة الطماطم والفلفل والتوابل.",
    ingredients: [],
    instructions: [],
    nutritionFacts: {
      calories: 320,
      protein: "15g",
      fat: "22g",
      carbs: "18g",
      fiber: "5g",
      sodium: "580mg"
    },
    cuisine: "Middle Eastern",
    cuisineAr: "شرق أوسطي",
    category: "Breakfast",
    categoryAr: "فطور"
  },
  {
    id: "recipe2",
    name: "Grilled Chicken Salad",
    nameAr: "سلطة دجاج مشوي",
    matchPercentage: 88,
    cookTime: 20,
    imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=300&auto=format&fit=crop",
    difficulty: "easy",
    servings: "1",
    calories: 280,
    description: "A healthy and delicious salad with grilled chicken, mixed greens, and a light vinaigrette.",
    descriptionAr: "سلطة صحية ولذيذة مع دجاج مشوي وخضروات متنوعة وصلصة خفيفة.",
    ingredients: [],
    instructions: [],
    nutritionFacts: {
      calories: 280,
      protein: "32g",
      fat: "12g",
      carbs: "14g",
      fiber: "4g",
      sodium: "320mg"
    },
    cuisine: "International",
    cuisineAr: "عالمي",
    category: "Lunch",
    categoryAr: "غداء"
  },
  {
    id: "recipe3",
    name: "Beef Kabsa",
    nameAr: "كبسة لحم",
    matchPercentage: 92,
    cookTime: 60,
    imageUrl: "https://images.unsplash.com/photo-1572862905000-c5b6244027a5?w=300&auto=format&fit=crop",
    difficulty: "medium",
    servings: "4",
    calories: 620,
    description: "A traditional Saudi rice dish made with aromatic rice, beef, and a blend of spices.",
    descriptionAr: "طبق أرز سعودي تقليدي مصنوع من الأرز العطري واللحم ومزيج من التوابل.",
    ingredients: [],
    instructions: [],
    nutritionFacts: {
      calories: 620,
      protein: "28g",
      fat: "24g",
      carbs: "75g",
      fiber: "3g",
      sodium: "720mg"
    },
    cuisine: "Saudi",
    cuisineAr: "سعودي",
    category: "Dinner",
    categoryAr: "عشاء"
  }
];

export function MealCalendar() {
  const { t, isRtl } = useI18n();
  const [date, setDate] = React.useState<Date>(new Date());
  const [weekStart, setWeekStart] = React.useState<Date>(startOfWeek(new Date(), { weekStartsOn: 0 }));
  const [mealPlans, setMealPlans] = React.useState<MealPlan[]>([]);
  const [selectedDay, setSelectedDay] = React.useState<Date>(new Date());
  const [mealTypeToAdd, setMealTypeToAdd] = React.useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  
  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  
  const locale = isRtl ? ar : enUS;
  
  // Initialize some sample meal plans for demo
  React.useEffect(() => {
    const today = new Date();
    const tomorrow = addDays(today, 1);
    
    const initialPlans: MealPlan[] = [
      {
        date: today,
        meals: {
          breakfast: sampleRecipes[0],
          lunch: sampleRecipes[1]
        }
      },
      {
        date: tomorrow,
        meals: {
          dinner: sampleRecipes[2]
        }
      }
    ];
    
    setMealPlans(initialPlans);
  }, []);
  
  const handlePrevWeek = () => {
    setWeekStart(addDays(weekStart, -7));
  };
  
  const handleNextWeek = () => {
    setWeekStart(addDays(weekStart, 7));
  };
  
  const getMealsForDay = (day: Date) => {
    return mealPlans.find(plan => isSameDay(plan.date, day))?.meals || {};
  };
  
  const handleAddMeal = (day: Date, mealType: string) => {
    setSelectedDay(day);
    setMealTypeToAdd(mealType);
    setIsDialogOpen(true);
  };
  
  const handleSelectRecipe = (recipe: RecipeRecommendation) => {
    if (!mealTypeToAdd) return;
    
    const existingPlanIndex = mealPlans.findIndex(plan => isSameDay(plan.date, selectedDay));
    
    if (existingPlanIndex >= 0) {
      // Update existing plan
      const updatedPlans = [...mealPlans];
      updatedPlans[existingPlanIndex] = {
        ...updatedPlans[existingPlanIndex],
        meals: {
          ...updatedPlans[existingPlanIndex].meals,
          [mealTypeToAdd]: recipe
        }
      };
      setMealPlans(updatedPlans);
    } else {
      // Create new plan
      const newPlan: MealPlan = {
        date: selectedDay,
        meals: {
          [mealTypeToAdd]: recipe
        }
      };
      setMealPlans([...mealPlans, newPlan]);
    }
    
    setIsDialogOpen(false);
  };
  
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>{t("mealPlanner")}</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="week">
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="week">{t("weekView")}</TabsTrigger>
              <TabsTrigger value="month">{t("monthView")}</TabsTrigger>
            </TabsList>
            
            <TabsContent value="week">
              <div className="flex justify-between items-center mb-4">
                <Button variant="outline" size="sm" onClick={handlePrevWeek}>
                  <ChevronLeft size={16} />
                </Button>
                <h3 className="text-lg font-semibold">
                  {format(weekStart, "MMMM d", { locale })} - {format(addDays(weekStart, 6), "MMMM d, yyyy", { locale })}
                </h3>
                <Button variant="outline" size="sm" onClick={handleNextWeek}>
                  <ChevronRight size={16} />
                </Button>
              </div>
              
              <div className="space-y-6">
                {weekDays.map((day) => {
                  const meals = getMealsForDay(day);
                  const mealCount = Object.keys(meals).length;
                  
                  return (
                    <Card key={format(day, "yyyy-MM-dd")} className={isSameDay(day, new Date()) ? "border-primary" : ""}>
                      <CardHeader className="py-3">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-sm text-muted-foreground">
                              {format(day, "EEEE", { locale })}
                            </p>
                            <p className="font-semibold">{format(day, "MMMM d", { locale })}</p>
                          </div>
                          {mealCount > 0 && (
                            <Badge variant="outline">
                              {mealCount} {mealCount === 1 ? t("meal") : t("meals")}
                            </Badge>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent className="py-2">
                        <div className="space-y-3">
                          {["breakfast", "lunch", "dinner", "snack"].map((mealType) => (
                            <div key={mealType} className="flex justify-between items-center">
                              <p className="capitalize text-sm font-medium">
                                {t(mealType)}
                              </p>
                              
                              {meals[mealType as keyof typeof meals] ? (
                                <div className="flex-1 ml-4">
                                  <RecipeListItem 
                                    recipe={meals[mealType as keyof typeof meals] as RecipeRecommendation} 
                                    onClick={() => {}}
                                  />
                                </div>
                              ) : (
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  className="ml-auto"
                                  onClick={() => handleAddMeal(day, mealType)}
                                >
                                  <Plus size={16} className="mr-1" />
                                  {t("addMeal")}
                                </Button>
                              )}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
            
            <TabsContent value="month">
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={(date) => date && setDate(date)}
                  className="rounded-md border"
                  disabled={{ before: new Date() }}
                />
              </div>
              
              <div className="mt-6">
                <h3 className="font-semibold mb-2">
                  {format(date, "EEEE, MMMM d, yyyy", { locale })}
                </h3>
                
                <Card>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      {["breakfast", "lunch", "dinner", "snack"].map((mealType) => {
                        const meals = getMealsForDay(date);
                        
                        return (
                          <div key={mealType} className="flex justify-between items-center">
                            <p className="capitalize text-sm font-medium">
                              {t(mealType)}
                            </p>
                            
                            {meals[mealType as keyof typeof meals] ? (
                              <div className="flex-1 ml-4">
                                <RecipeListItem 
                                  recipe={meals[mealType as keyof typeof meals] as RecipeRecommendation} 
                                  onClick={() => {}}
                                />
                              </div>
                            ) : (
                              <Button 
                                variant="ghost" 
                                size="sm"
                                className="ml-auto"
                                onClick={() => handleAddMeal(date, mealType)}
                              >
                                <Plus size={16} className="mr-1" />
                                {t("addMeal")}
                              </Button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {t("selectRecipeFor")} {mealTypeToAdd && t(mealTypeToAdd)}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {sampleRecipes.map((recipe) => (
              <div key={recipe.id} onClick={() => handleSelectRecipe(recipe)} className="cursor-pointer">
                <RecipeListItem recipe={recipe} onClick={() => handleSelectRecipe(recipe)} />
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}