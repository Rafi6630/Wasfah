import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useI18n } from "@/lib/i18n";
import { Loader2 } from "lucide-react";
import { StripeElementsProvider } from "@/lib/stripe-provider";
import { StripePaymentForm } from "./stripe-payment-form";

interface StripePaymentContainerProps {
  onSuccess?: () => void;
  onCancel?: () => void;
  tier: "premium";
  billingPeriod: "monthly" | "yearly";
}

export function StripePaymentContainer({
  onSuccess,
  onCancel,
  tier,
  billingPeriod,
}: StripePaymentContainerProps) {
  const { t } = useI18n();
  const { toast } = useToast();
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const createPaymentIntent = async () => {
      try {
        setLoading(true);
        
        const response = await apiRequest("POST", "/api/payment/create-intent", {
          tier,
          billingPeriod,
        });
        
        const data = await response.json();
        
        if (response.ok) {
          setClientSecret(data.clientSecret);
        } else {
          setError(data.error || "Failed to create payment intent");
          toast({
            title: t("error"),
            description: data.error || t("failedToCreatePaymentIntent"),
            variant: "destructive",
          });
        }
      } catch (err) {
        console.error("Payment intent creation error:", err);
        setError(String(err));
        toast({
          title: t("error"),
          description: String(err),
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    createPaymentIntent();
  }, [tier, billingPeriod, toast, t]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="mt-3 text-sm text-muted-foreground">{t("preparingPayment")}</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 text-center">
        <h3 className="text-red-600 font-medium">{t("paymentError")}</h3>
        <p className="text-sm text-muted-foreground mt-2">{error}</p>
        {onCancel && (
          <button
            className="mt-4 text-primary text-sm underline"
            onClick={onCancel}
          >
            {t("goBack")}
          </button>
        )}
      </div>
    );
  }

  return (
    <StripeElementsProvider clientSecret={clientSecret}>
      <StripePaymentForm
        onSuccess={onSuccess}
        onCancel={onCancel}
        tier={tier}
        billingPeriod={billingPeriod}
      />
    </StripeElementsProvider>
  );
}