import { useState } from "react";
import {
  PaymentElement,
  useStripe as useStripeElements,
  useElements,
} from "@stripe/react-stripe-js";
import { Button } from "@/components/ui/button";
import { Loader2, Crown, CreditCard, Shield, Check, SparkleIcon, CalendarClock } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface StripePaymentFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
  tier: "premium";
  billingPeriod: "monthly" | "yearly";
}

export function StripePaymentForm({
  onSuccess,
  onCancel,
  tier,
  billingPeriod,
}: StripePaymentFormProps) {
  const { t } = useI18n();
  const stripe = useStripeElements();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [saveCard, setSaveCard] = useState(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      toast({
        title: t("error"),
        description: t("stripeNotLoaded"),
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Confirm the payment
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/subscription?success=true`,
          payment_method_data: {
            billing_details: {
              name: localStorage.getItem("cardholder_name") || undefined,
            },
          },
          save_payment_method: saveCard,
        },
        redirect: "if_required",
      });

      if (error) {
        toast({
          title: t("paymentFailed"),
          description: error.message,
          variant: "destructive",
        });
      } else {
        // Payment succeeded, update the user's subscription
        await apiRequest("POST", "/api/subscription/update", {
          tier,
          billingPeriod,
        });

        toast({
          title: t("paymentSuccessful"),
          description: t("subscriptionActivated"),
        });

        if (onSuccess) {
          onSuccess();
        }
      }
    } catch (error) {
      console.error("Payment error:", error);
      toast({
        title: t("paymentFailed"),
        description: String(error),
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-xl mx-auto">
      {/* Premium Subscription Info Card */}
      <div className="royal-card-premium mb-6">
        <div className="royal-card-premium-inner p-4">
          <div className="flex items-center gap-2 mb-3">
            <Crown className="h-5 w-5 text-royal-gold royal-crown" />
            <h3 className="text-md font-bold text-royal-purple">
              {tier === "premium" ? (t("premiumSubscription") || "Premium Subscription") : (t("choosePremiumPlan") || "Royal Premium")}
            </h3>
          </div>
          
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-royal-purple-dark flex items-center gap-1">
                <CalendarClock className="h-4 w-4 text-royal-purple" />
                <span>
                  {billingPeriod === "monthly" ? t("monthlyBilling") || "Monthly Billing" : t("yearlyBilling") || "Yearly Billing"}
                </span>
              </p>
              <p className="text-xs text-royal-purple-dark/70 mt-1 pl-5">
                {billingPeriod === "yearly" && (
                  <span className="text-royal-purple bg-royal-gold/20 px-2 py-0.5 rounded-full text-xs font-medium">
                    {t("saveWithYearly") || "Save 17%"}
                  </span>
                )}
              </p>
            </div>
            <div className="text-right">
              <p className="text-xl font-bold text-royal-purple">
                {billingPeriod === "monthly" ? "$5.99" : "$59.99"}
              </p>
              <p className="text-xs text-royal-purple-dark/70">
                {billingPeriod === "monthly" ? t("perMonth") || "per month" : t("perYear") || "per year"}
              </p>
            </div>
          </div>
          
          <div className="mt-4 pt-4 border-t border-royal-gold/20">
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-sm text-royal-purple-dark">
                <Check className="h-4 w-4 text-royal-gold flex-shrink-0" />
                <span>{t("unlimitedRecipes") || "Unlimited AI recipe recommendations"}</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-royal-purple-dark">
                <Check className="h-4 w-4 text-royal-gold flex-shrink-0" />
                <span>{t("advancedMealPlanning") || "Advanced meal planning tools"}</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-royal-purple-dark">
                <Check className="h-4 w-4 text-royal-gold flex-shrink-0" />
                <span>{t("noAds") || "Ad-free experience"}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Payment Element with royal styling */}
      <div className="royal-card p-5">
        <div className="flex items-center gap-2 mb-4">
          <CreditCard className="h-5 w-5 text-royal-purple" />
          <h3 className="font-semibold text-royal-purple">{t("paymentDetails") || "Payment Details"}</h3>
        </div>
        <PaymentElement className="py-2" />
      </div>

      {/* Save Card Option */}
      <div className="flex items-center space-x-2 mt-4 royal-card p-4">
        <div className="flex items-center">
          <input
            type="checkbox"
            id="saveForFuture"
            checked={saveCard}
            onChange={(e) => setSaveCard(e.target.checked)}
            className="h-4 w-4 rounded border-royal-gold text-royal-purple focus:ring-royal-gold"
          />
          <label htmlFor="saveForFuture" className="ml-2 text-sm text-royal-purple-dark">
            {t("saveCardForFuturePayments") || "Save this card for future payments"}
          </label>
        </div>
      </div>

      {/* Total and Submit Button */}
      <div className="royal-card-premium p-0.5 rounded-lg">
        <div className="royal-card-premium-inner">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-royal-purple-dark">{t("totalAmount") || "Total Amount"}</p>
              <p className="text-xl font-bold text-royal-purple">
                {billingPeriod === "monthly" ? "$5.99" : "$59.99"}
              </p>
            </div>

            <button 
              type="submit" 
              disabled={isProcessing}
              className="royal-btn-primary royal-glow px-6"
            >
              {isProcessing ? (
                <span className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t("processing") || "Processing..."}
                </span>
              ) : (
                <span className="flex items-center gap-1">
                  <Crown className="h-4 w-4" />
                  {t("completeSubscription") || "Complete Subscription"}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Cancel Button */}
      {onCancel && (
        <button
          type="button"
          className="royal-btn-outline w-full"
          onClick={onCancel}
          disabled={isProcessing}
        >
          {t("cancel") || "Cancel"}
        </button>
      )}

      {/* Security Notice */}
      <div className="text-center">
        <p className="text-xs flex items-center justify-center gap-1 text-royal-purple-dark/70">
          <Shield className="h-3 w-3" />
          {t("securePaymentDisclaimer") || "Your payment information is processed securely"}
        </p>
      </div>
    </form>
  );
}