import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface Category {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
  image: string;
}

// Main categories with more attractive images for hero carousel
const categories: Category[] = [
  {
    id: "food",
    name: "Food",
    nameAr: "طعام",
    icon: "🍲",
    image: "https://images.unsplash.com/photo-1547592180-85f173990554?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=400&q=80"
  },
  {
    id: "desserts",
    name: "Desserts",
    nameAr: "حلويات",
    icon: "🍰",
    image: "https://images.unsplash.com/photo-1559715745-e1b33a271c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=400&q=80"
  },
  {
    id: "drinks",
    name: "Drinks",
    nameAr: "مشروبات",
    icon: "🥤",
    image: "https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1080&h=400&q=80"
  }
];

interface HeroCarouselProps {
  onCategorySelect?: (categoryId: string) => void;
}

export function HeroCarousel({ onCategorySelect }: HeroCarouselProps) {
  const { t, language, isRtl } = useI18n();
  const [_, navigate] = useLocation();
  const [currentSlide, setCurrentSlide] = React.useState(0);
  
  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === categories.length - 1 ? 0 : prev + 1));
  };
  
  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? categories.length - 1 : prev - 1));
  };
  
  // Auto-advance slides every 5 seconds
  React.useEffect(() => {
    const timer = setInterval(() => {
      nextSlide();
    }, 5000);
    
    return () => clearInterval(timer);
  }, []);
  
  const handleCategoryClick = (categoryId: string) => {
    // Update the selected category in the parent component
    if (onCategorySelect) {
      onCategorySelect(categoryId);
    } else {
      // Fallback behavior: navigate to search with category filter
      navigate(`/search?category=${categoryId}`);
    }
  };
  
  return (
    <div className="mb-6">
      <h2 className="text-lg font-bold mb-4">{t("mainCategories")}</h2>
      
      {/* Main Categories - 3 in a row with circular design */}
      <div className="grid grid-cols-3 gap-4 items-center mb-2">
        {categories.map((category) => (
          <div 
            key={category.id}
            className="flex flex-col items-center cursor-pointer transition-all"
            onClick={() => handleCategoryClick(category.id)}
          >
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full mb-2 overflow-hidden border-4 border-royal-gold/70 shadow-lg hover:shadow-[0_0_20px_rgba(218,165,32,0.8)] transition-all">
              <div 
                className="w-full h-full flex items-center justify-center"
                style={{ 
                  backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.15), rgba(75, 0, 130, 0.4)), url(${category.image})`,
                  backgroundSize: 'cover',
                  backgroundPosition: 'center'
                }}
              >
              </div>
            </div>
            <h3 className="text-lg font-bold text-center">
              {language === 'ar' ? category.nameAr : category.name}
            </h3>
          </div>
        ))}
      </div>
    </div>
  );
}