import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface Subcategory {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
}

interface SubcategoryByCategoryMap {
  [key: string]: Subcategory[];
}

// Map of subcategories for each main category as per requirements
const subcategoriesByCategory: SubcategoryByCategoryMap = {
  food: [
    { id: "main_dishes", name: "Main Dishes", nameAr: "أطباق رئيسية", icon: "🍽️" },
    { id: "appetizers", name: "Appetizers", nameAr: "مقبلات", icon: "🥗" },
    { id: "pickles", name: "Pickles", nameAr: "مخللات", icon: "🥒" },
    { id: "soups", name: "Soups", nameAr: "شوربات", icon: "🍲" },
    { id: "sauces", name: "Sauces", nameAr: "صلصات", icon: "🧂" },
    { id: "others", name: "Others", nameAr: "أخرى", icon: "🍴" },
  ],
  desserts: [
    { id: "traditional", name: "Traditional", nameAr: "تقليدي", icon: "🍮" },
    { id: "western", name: "Western", nameAr: "غربي", icon: "🍰" },
    { id: "pastries", name: "Pastries", nameAr: "معجنات", icon: "🥐" },
    { id: "ice_cream", name: "Ice Cream", nameAr: "آيس كريم", icon: "🍦" },
    { id: "others", name: "Others", nameAr: "أخرى", icon: "🍬" },
  ],
  drinks: [
    { id: "detox", name: "Detox", nameAr: "ديتوكس", icon: "🥤" },
    { id: "cocktails", name: "Cocktails", nameAr: "كوكتيلات", icon: "🍹" },
    { id: "non_alcoholic", name: "Non-Alcoholic", nameAr: "غير كحولية", icon: "🧃" },
    { id: "hot_drinks", name: "Hot Drinks", nameAr: "مشروبات ساخنة", icon: "☕" },
    { id: "others", name: "Others", nameAr: "أخرى", icon: "🍷" },
  ],
};

interface DynamicSubcategoryPanelProps {
  selectedCategory: string;
  onSelectSubcategory?: (categoryId: string, subcategoryId: string) => void;
}

export function DynamicSubcategoryPanel({
  selectedCategory,
  onSelectSubcategory,
}: DynamicSubcategoryPanelProps) {
  const { t, language, isRtl } = useI18n();
  const [_, navigate] = useLocation();
  const [selectedSubcategory, setSelectedSubcategory] = React.useState<string | null>(null);
  
  const subcategories = subcategoriesByCategory[selectedCategory] || [];
  
  const handleSubcategoryClick = (subcategoryId: string) => {
    setSelectedSubcategory(subcategoryId);
    if (onSelectSubcategory) {
      onSelectSubcategory(selectedCategory, subcategoryId);
    } else {
      // Default navigation to search page with category and subcategory as query parameters
      navigate(`/search?category=${selectedCategory}&subcategory=${subcategoryId}`);
    }
  };
  
  if (subcategories.length === 0) {
    return null;
  }
  
  return (
    <div className="mb-4">
      <h3 className="text-lg font-bold mb-3">
        {t("categories")}
      </h3>
      
      <ScrollArea className="w-full">
        <div className={cn(
          "flex space-x-3 pb-2",
          isRtl && "space-x-reverse"
        )}>
          {subcategories.map((subcategory) => (
            <div 
              key={subcategory.id}
              className={cn(
                "flex flex-col items-center justify-center min-w-[80px] cursor-pointer transition-all",
                selectedSubcategory === subcategory.id
                  ? "text-royal-purple"
                  : "text-gray-700 hover:text-royal-purple-light"
              )}
              onClick={() => handleSubcategoryClick(subcategory.id)}
            >
              <div className={cn(
                "w-14 h-14 rounded-full flex items-center justify-center mb-2 shadow-sm transition-all",
                selectedSubcategory === subcategory.id
                  ? "bg-royal-gold/20 border-2 border-royal-gold"
                  : "bg-white border border-gray-200 hover:border-royal-gold/50"
              )}>
                <span className="text-2xl">{subcategory.icon}</span>
              </div>
              <span className="text-xs text-center font-medium">
                {language === 'ar' ? subcategory.nameAr : subcategory.name}
              </span>
            </div>
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}