import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Snowflake, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { getPopularRecipes } from "@/lib/openai";
import { Recipe } from "@shared/schema";
import { cn } from "@/lib/utils";

interface SeasonalRecipeCarouselProps {
  onRecipeSelect?: (recipeId: string) => void;
}

export function SeasonalRecipeCarousel({ onRecipeSelect }: SeasonalRecipeCarouselProps) {
  const { t, isRtl } = useI18n();
  const [_, setLocation] = useLocation();
  const [currentIndex, setCurrentIndex] = React.useState(0);
  
  // Get current season and festive events
  const currentDate = new Date();
  const currentMonth = currentDate.getMonth();
  
  // Determine season and festive themes
  let season = "";
  let festiveEvent = "";
  
  // Northern hemisphere seasons
  if (currentMonth >= 2 && currentMonth <= 4) {
    season = "spring";
  } else if (currentMonth >= 5 && currentMonth <= 7) {
    season = "summer";
  } else if (currentMonth >= 8 && currentMonth <= 10) {
    season = "autumn";
  } else {
    season = "winter";
  }
  
  // Special festive events by month
  switch (currentMonth) {
    case 0: // January
      festiveEvent = "new-year";
      break;
    case 1: // February
      festiveEvent = "valentine";
      break;
    case 3: // April
      festiveEvent = "easter";
      break;
    case 9: // October
      festiveEvent = "halloween";
      break;
    case 10: // November
      festiveEvent = "thanksgiving";
      break;
    case 11: // December
      festiveEvent = "christmas";
      break;
    default:
      festiveEvent = "";
  }
  
  // Fetch popular/seasonal recipes with filtering based on season or festive event
  const { data: recipes = [], isLoading } = useQuery({
    queryKey: ["/api/recipes/popular", { season, festiveEvent }],
    queryFn: () => getPopularRecipes(season, festiveEvent),
  });
  
  const displayRecipes = recipes.slice(0, 5); // Limit display to 5 recipes
  
  const handlePrev = () => {
    setCurrentIndex((prev) => 
      prev === 0 ? displayRecipes.length - 1 : prev - 1
    );
  };
  
  const handleNext = () => {
    setCurrentIndex((prev) => 
      prev === displayRecipes.length - 1 ? 0 : prev + 1
    );
  };
  
  const handleRecipeClick = (recipeId: string) => {
    if (onRecipeSelect) {
      onRecipeSelect(recipeId);
    } else {
      setLocation(`/recipe/${recipeId}`);
    }
  };
  
  // Auto-advance carousel
  React.useEffect(() => {
    const timer = setInterval(() => {
      handleNext();
    }, 5000);
    
    return () => clearInterval(timer);
  }, [displayRecipes.length]);
  
  if (isLoading || displayRecipes.length === 0) {
    return null;
  }
  
  // Get seasonal theme colors and icons
  const getSeasonalTheme = () => {
    switch (season) {
      case "spring":
        return {
          gradient: "from-green-500 to-pink-300",
          icon: "🌸",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='52' height='26' viewBox='0 0 52 26' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Cpath d='M10 10c0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6h2c0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4 3.314 0 6 2.686 6 6 0 2.21 1.79 4 4 4v2c-3.314 0-6-2.686-6-6 0-2.21-1.79-4-4-4-3.314 0-6-2.686-6-6zm25.464-1.95l8.486 8.486-1.414 1.414-8.486-8.486 1.414-1.414z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")"
        };
      case "summer":
        return {
          gradient: "from-yellow-400 to-orange-400",
          icon: "🌞",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E\")"
        };
      case "autumn":
        return {
          gradient: "from-amber-600 to-red-500",
          icon: "🍂",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='44' height='12' viewBox='0 0 44 12' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M20 12v-2L0 0v10l4 2h16zm18 0l4-2V0L22 10v2h16zM20 0v8L4 0h16zm18 0L22 8V0h16z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E\")"
        };
      case "winter":
      default:
        return {
          gradient: "from-blue-500 to-purple-500",
          icon: "❄️",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'%3E%3Cpath d='M20 18.858V20H4v-1.142l8-7.429 8 7.429zm0-3.716l-8-7.429-8 7.429V4h16v11.142z'/%3E%3C/g%3E%3C/svg%3E\")"
        };
    }
  };
  
  // Get festive theme if available
  const getFestiveTheme = () => {
    switch (festiveEvent) {
      case "christmas":
        return {
          gradient: "from-red-600 to-green-600",
          icon: "🎄",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M12 18.88A6 6 0 0 1 6.24 16.7l.2-.3a6 6 0 0 1-1.4-3.4H5a6 6 0 0 1 6-6 1 1 0 0 1 1 1v.1a6 6 0 0 1 1.5 0V8a1 1 0 0 1 1-1 6 6 0 0 1 6 6h.04a6 6 0 0 1-1.4 3.4l.2.3a6 6 0 0 1-5.76 2.18z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E\")"
        };
      case "halloween":
        return {
          gradient: "from-orange-500 to-purple-700",
          icon: "🎃",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M15 0C6.716 0 0 6.716 0 15c8.284 0 15-6.716 15-15zM0 15c0 8.284 6.716 15 15 15 0-8.284-6.716-15-15-15zm30 0c0-8.284-6.716-15-15-15 0 8.284 6.716 15 15 15zm0 0c0 8.284-6.716 15-15 15 0-8.284 6.716-15 15-15z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E\")"
        };
      case "new-year":
        return {
          gradient: "from-blue-600 to-purple-500",
          icon: "✨",
          pattern: "url(\"data:image/svg+xml,%3Csvg width='100' height='20' viewBox='0 0 100 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M21.184 20c.357-.13.72-.264.888-.14 1.005-.174 1.837-.826 2.603-1.613 3.13-3.225 2.463-13.027 2.463-13.027s.346.5.02-2.82c-.84-8.52-6.835-8.373-6.835-8.373s-6.17-.27-6.37 7.884c-.2 9.54 4.69 13.76 5.7 15.35.434.674.706 1.32.408 1.6-.853.71-3.934-3.83-5.83-7.19-.76-1.348-1.26-2.164-1.405-2.014-.274.243-.217 1.802.263 4.36.7 3.46 2.66 7.59 3.886 8.6.465.384.848.438 1.218.25.37-.188 2.226-1.19 3.04-2.16.105-.122.206-.244.306-.366 3.412.288 8.938.013 10.793-3.207.832-1.45.692-2.744.27-3.568-.43-.825-1.195-1.462-2.044-1.943-.124-.07-.228-.17-.328-.26 1.808.21 3.164-.176 3.376-1.3.078-.415-.01-.783-.196-1.114l-.137-.27c-.38-.748-.853-1.522-1.453-2.33.28.182 2.824 1.192 2.26-1.25-.175-.772-2.15-1.39-2.69-1.533-1.517-.66-1.912-.735-1.912-.735s.38 1.106-.25 2.187c-.176.302-.432.582-.76.813-.07.05-.12.11-.17.17-1.04.78-2.58 1.08-4.307.9-.863-.1-1.445-.5-1.705-.83l-.127-.16c.007.31.02.63.03.94.01.33.02.66.02.98 0 .51-.05 1.02-.16 1.52-.25 1.21-1.79 8.66.22 10.423.22.18.48.34.79.46 2.8 1.09 4.88-1.21 6.7-3.15 1.4-1.49 2.48-3.28 2.26-4.52-.06-.32-.17-.6-.33-.84.15.1.29.22.42.34.55.48 1.08 1.12 1.26 2.03.17.9-.34 1.93-.96 2.76-.46.62-1.06 1.17-1.74 1.61.17.17.36.33.56.46.98.66 2.34.84 3.59.53.29-.07.55-.18.78-.31-.4 1.18-.34 2.43.41 3.59.35.54.84 1.02 1.49 1.41 1.37.82 4.35 1.7 7.07-.16.32-.22.62-.47.89-.75-.14.51-.36 1.04-.7 1.59-1.95 3.15-6.02 5.1-13.89 3.18-.9-.22-1.71-.48-2.4-.79-.18-.08-.34-.17-.5-.27-2.21.71-4.8.3-6.5-1.128-2.05-1.71-2.66-4.72-2.95-8.05.05-.102.01-.171-.02-.26-.1-.41-.33-.75-.63-1.03.02-.04.04-.09.05-.14.36-1.19.8-4.43.28-6.86-.06-.28-.18-.54-.36-.78-.13-.18-.67-.78-.67-.78s-1.21.49-2.13.93c-.17.08-.36.19-.55.28-.54.27-1.07.51-1.55.68-.4.14-.76.25-1.08.31-.28.05-.5.09-.68.1-.07.01-.12.01-.15.01-.02 0-.03 0-.03 0h.03c-.04-.01-.08-.01-.13-.02-.32-.04-.67-.11-1.05-.23-.63-.21-1.32-.53-2.03-.95-.69-.42-1.39-.95-2.06-1.58-.66-.63-1.27-1.35-1.77-2.16-.18-.29-.33-.58-.46-.87-.12-.28-.24-.55-.33-.83.13 0 .36.01.65.03.7.05 1.8.15 3.05.39.56.11 1.15.25 1.74.42.59.17 1.17.38 1.73.63.56.25 1.1.54 1.58.88.49.33.9.72 1.19 1.13.18.26.32.55.4.85.08.3.1.63.06.96-.16 1.3-1.47 2.7-3.19 3.59-1.71.88-3.83 1.27-5.51.83-.46-.12-.8-.3-1.08-.52-.28-.22-.49-.49-.62-.8-.13-.32-.19-.68-.18-1.09.01-.4.08-.85.22-1.34.14-.49.34-1.03.63-1.6.28-.57.65-1.18 1.07-1.83.43-.64.92-1.32 1.46-2 .31-.38.61-.77.92-1.16.31-.39.62-.78.91-1.18.31-.4.59-.8.86-1.21.27-.41.51-.82.73-1.24.22-.42.41-.84.57-1.27.16-.42.28-.85.36-1.28.08-.43.1-.87.07-1.31-.03-.44-.13-.88-.29-1.31.95.51 1.95 1.04 2.64 1.86.09.3.16.61.23.93.07.32.13.65.17 1.01.04.36.07.74.07 1.15-.01.41-.05.86-.14 1.33-.08.48-.22.98-.4 1.52-.35 1.07-.89 2.3-1.63 3.67-.75 1.37-1.71 2.88-2.9 4.51-1.19 1.63-2.6 3.39-4.25 5.26z' fill='%23ffffff' fill-opacity='0.1' fill-rule='evenodd'/%3E%3C/svg%3E\")"
        };
      default:
        return getSeasonalTheme();
    }
  };
  
  const theme = festiveEvent ? getFestiveTheme() : getSeasonalTheme();
  const seasonalTitle = festiveEvent 
    ? t(`seasonal.${festiveEvent}`) 
    : t(`seasonal.${season}`);
  
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <span className="text-xl">{theme.icon}</span>
          <span>{seasonalTitle}</span>
        </h2>
        <div className="flex gap-1">
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={handlePrev}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={handleNext}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="relative overflow-hidden rounded-xl">
        <div
          className={cn(
            "transition-all duration-500 ease-in-out flex",
            isRtl ? "flex-row-reverse" : "flex-row"
          )}
          style={{
            transform: `translateX(${isRtl ? '' : '-'}${currentIndex * 100}%)`,
            width: `${displayRecipes.length * 100}%`
          }}
        >
          {displayRecipes.map((recipe) => (
            <div
              key={recipe.id} 
              className="w-full px-1 shrink-0"
              onClick={() => handleRecipeClick(recipe.id)}
            >
              <Card 
                className={cn(
                  "relative overflow-hidden cursor-pointer h-48 w-full bg-gradient-to-r shadow-md", 
                  theme.gradient
                )}
                style={{ backgroundImage: theme.pattern }}
              >
                <div className="absolute inset-0 flex items-center justify-center">
                  <img
                    src={recipe.imageUrl || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c"}
                    alt={recipe.name}
                    className="h-full w-full object-cover opacity-85"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                </div>
                
                <div className="absolute bottom-0 left-0 right-0 p-3 text-white">
                  <h3 className="text-lg font-bold line-clamp-1">{recipe.name}</h3>
                  <p className="text-sm line-clamp-1 opacity-90">{recipe.description}</p>
                  
                  {/* Dietary match indicator */}
                  {recipe.matchPercentage && (
                    <div className="absolute top-2 right-2 bg-green-600/80 text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                      <Sparkles className="h-3 w-3" />
                      <span>{recipe.matchPercentage}% {t("match")}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between mt-1 text-xs">
                    <span className="flex items-center gap-1">
                      ⏱️ {recipe.cookTime} {t("min")}
                    </span>
                    <span className="flex items-center gap-1">
                      🔥 {recipe.difficulty || t("easy")}
                    </span>
                  </div>
                </div>
              </Card>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}