import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Clock, ChefHat, Star, User, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { DietaryMatchIndicator } from "./dietary-match-indicator";
import type { Recipe } from "@shared/schema";
import type { RecipeRecommendation } from "@/lib/openai";

interface RecipeCardProps {
  recipe: Recipe | RecipeRecommendation;
  onClick?: () => void;
  showMatchPercentage?: boolean;
  showDietaryMatch?: boolean;
}

export function RecipeCard({ 
  recipe, 
  onClick, 
  showMatchPercentage = true,
  showDietaryMatch = true
}: RecipeCardProps) {
  const { isRtl } = useI18n();
  const [isFavorite, setIsFavorite] = React.useState(false);
  
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
    // In a real app, this would update the database
  };
  
  // Handle different property formats based on recipe type
  const recipeImage = 'imageUrl' in recipe 
    ? recipe.imageUrl 
    : (recipe.image_url || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c');
    
  const recipeName = isRtl 
    ? ('nameAr' in recipe ? recipe.nameAr : recipe.name_ar) || ''
    : recipe.name;
    
  const matchPercentage = 'matchPercentage' in recipe 
    ? recipe.matchPercentage 
    : (recipe.match_percentage || 0);
    
  const matchText = `${matchPercentage}% match`;
  
  return (
    <div 
      className="rounded-xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      <div className="relative">
        <img 
          src={recipeImage} 
          alt={recipeName}
          className="w-full h-32 object-cover"
        />
        
        {/* Badges area (top-left): match percentage or dietary match */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {/* Ingredient match percentage badge */}
          {showMatchPercentage && matchPercentage > 0 && (
            <div className="bg-black/50 text-white text-xs px-2 py-1 rounded-full">
              {matchText}
            </div>
          )}
          
          {/* Dietary match indicator */}
          {showDietaryMatch && ('dietaryMatchScore' in recipe) && recipe.dietaryMatchScore !== undefined && (
            <DietaryMatchIndicator 
              matchScore={recipe.dietaryMatchScore} 
              matchExplanations={recipe.dietaryMatchExplanations}
              size="sm"
            />
          )}
        </div>
        
        {/* Favorite button */}
        <Button
          size="icon"
          variant="ghost"
          className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white"
          onClick={handleFavoriteClick}
        >
          <Heart 
            className={cn(
              "h-4 w-4", 
              isFavorite ? "fill-red-500 text-red-500" : "text-gray-600"
            )}
          />
        </Button>
      </div>
      
      <div className="p-3">
        <h3 className="font-medium text-sm line-clamp-1">{recipeName}</h3>
        
        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{('cookTime' in recipe ? recipe.cookTime : recipe.cook_time) || 30} min</span>
          </div>
          
          <div className="flex items-center gap-1">
            <ChefHat className="h-3 w-3" />
            <span>{recipe.difficulty}</span>
          </div>
          
          <div className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            <span>{recipe.rating || 4.5}</span>
          </div>
        </div>
      </div>
    </div>
  );
}