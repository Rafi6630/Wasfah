import { useState } from "react";
import { cn } from "@/lib/utils";

interface InstructionItemProps {
  step: number;
  text: string;
}

export function InstructionItem({ step, text }: InstructionItemProps) {
  const [isCompleted, setIsCompleted] = useState(false);
  
  return (
    <div 
      className={cn(
        "bg-neutral-200 rounded-xl p-4 flex cursor-pointer",
        isCompleted && "bg-opacity-50"
      )}
      onClick={() => setIsCompleted(!isCompleted)}
    >
      <div className={cn(
        "w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center mr-3",
        isCompleted ? "bg-secondary text-white" : "bg-primary text-white"
      )}>
        {isCompleted ? <i className="fas fa-check"></i> : <span>{step}</span>}
      </div>
      <p className={cn(isCompleted && "text-gray-500")}>{text}</p>
    </div>
  );
}
