import * as React from "react";
import { Check } from "lucide-react";

interface IngredientItemProps {
  name: string;
  quantity: string;
  servingMultiplier?: number;
}

export function IngredientItem({ 
  name, 
  quantity, 
  servingMultiplier = 1 
}: IngredientItemProps) {
  const [isChecked, setIsChecked] = React.useState(false);
  
  const handleToggleCheck = () => {
    setIsChecked(!isChecked);
  };
  
  // Attempt to parse the quantity to adjust for serving size
  let adjustedQuantity = quantity;
  
  try {
    // First, extract any numeric values from the quantity string
    const matches = quantity.match(/(\d+(\.\d+)?)/);
    
    if (matches && matches[1]) {
      const numericValue = parseFloat(matches[1]);
      const adjustedValue = (numericValue * servingMultiplier).toFixed(1);
      // Replace the original numeric value with the adjusted one
      adjustedQuantity = quantity.replace(matches[1], adjustedValue);
      
      // Remove trailing zeros after decimal
      adjustedQuantity = adjustedQuantity.replace(/\.0+$/, '');
    }
  } catch (error) {
    // If parsing fails, just use the original quantity
    console.error("Failed to adjust quantity:", error);
  }
  
  return (
    <li className="flex items-center gap-2 p-2 rounded-md hover:bg-gray-50">
      <button
        type="button"
        onClick={handleToggleCheck}
        className={`w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center border ${
          isChecked 
            ? 'bg-primary border-primary text-white' 
            : 'border-gray-300'
        }`}
      >
        {isChecked && <Check className="h-3 w-3" />}
      </button>
      
      <div className={`flex-1 ${isChecked ? 'line-through text-gray-400' : ''}`}>
        <span className="font-medium">{name}</span>
      </div>
      
      <div className="text-sm text-gray-500">
        {adjustedQuantity}
      </div>
    </li>
  );
}