import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Info, AlertCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/hooks/use-auth";
import type { RecipeRecommendation } from "@/lib/openai";

interface NutritionDetailProps {
  recipe: RecipeRecommendation;
  servingSize: number;
}

export function NutritionDetail({ recipe, servingSize }: NutritionDetailProps) {
  const { t, isRtl } = useI18n();
  const { user } = useAuth();
  
  // Calculate serving multiplier for nutritional values
  const servingMultiplier = servingSize / (parseInt(recipe.servings) || 4);
  
  // Helper function to apply serving multiplier to numerical values
  const adjustForServing = (value: number): number => {
    return Math.round(value * servingMultiplier);
  };
  
  // Helper function to format nutritional values
  const formatNutrient = (value: string): { amount: number; unit: string } => {
    const match = value.match(/(\d+\.?\d*)(\s*\w+)?/);
    if (match) {
      return {
        amount: parseFloat(match[1]),
        unit: match[2]?.trim() || 'g',
      };
    }
    return { amount: 0, unit: 'g' };
  };
  
  // Calculate daily percentages (based on a 2000 calorie diet)
  const getDailyPercentage = (nutrient: string, value: number): number => {
    const dailyValues: Record<string, number> = {
      'fat': 65, // g
      'carbs': 300, // g
      'protein': 50, // g
      'fiber': 25, // g
      'sodium': 2300, // mg
    };
    
    if (dailyValues[nutrient]) {
      // Convert string values like "10g" to numbers
      return Math.min(100, Math.round((value / dailyValues[nutrient]) * 100));
    }
    
    return 0;
  };
  
  // Extract user allergens for highlighting
  const userAllergens = user?.allergens as string[] || [];
  
  // Check if recipe contains any allergens the user is sensitive to
  const findRecipeAllergens = (): string[] => {
    // Return empty array if not logged in or no allergens
    if (!user || !userAllergens || !userAllergens.length) return [];
    
    const ingredients = recipe.ingredients.map(i => 
      isRtl ? i.nameAr.toLowerCase() : i.name.toLowerCase()
    );
    
    const allergenMap: Record<string, string[]> = {
      'gluten': ['wheat', 'barley', 'rye', 'flour', 'bread', 'pasta'],
      'dairy': ['milk', 'cheese', 'butter', 'cream', 'yogurt'],
      'nuts': ['almond', 'walnut', 'pecan', 'cashew', 'pistachio', 'hazelnut'],
      'peanuts': ['peanut', 'groundnut'],
      'shellfish': ['shrimp', 'crab', 'lobster', 'prawn'],
      'fish': ['fish', 'salmon', 'tuna', 'cod', 'halibut'],
      'eggs': ['egg', 'omelette', 'meringue'],
      'soy': ['soy', 'tofu', 'edamame', 'miso'],
      'sesame': ['sesame', 'tahini']
    };
    
    const detectedAllergens: string[] = [];
    
    userAllergens.forEach((allergen: string) => {
      const keywords = allergenMap[allergen] || [];
      
      // Check if any ingredient contains allergen keywords
      const hasAllergen = ingredients.some(ingredient => 
        keywords.some(keyword => ingredient.includes(keyword))
      );
      
      if (hasAllergen) {
        detectedAllergens.push(allergen);
      }
    });
    
    return detectedAllergens;
  };
  
  const recipeAllergens = findRecipeAllergens();
  
  // Format nutrition facts
  const calories = adjustForServing(recipe.nutritionFacts.calories);
  const protein = formatNutrient(recipe.nutritionFacts.protein);
  const fat = formatNutrient(recipe.nutritionFacts.fat);
  const carbs = formatNutrient(recipe.nutritionFacts.carbs);
  const fiber = formatNutrient(recipe.nutritionFacts.fiber);
  const sodium = formatNutrient(recipe.nutritionFacts.sodium);
  
  // Adjust nutrient amounts for serving size
  const proteinAdjusted = adjustForServing(protein.amount);
  const fatAdjusted = adjustForServing(fat.amount);
  const carbsAdjusted = adjustForServing(carbs.amount);
  const fiberAdjusted = adjustForServing(fiber.amount);
  const sodiumAdjusted = adjustForServing(sodium.amount);
  
  // Calculate percentages for the visual representation
  const proteinPercent = getDailyPercentage('protein', proteinAdjusted);
  const fatPercent = getDailyPercentage('fat', fatAdjusted);
  const carbsPercent = getDailyPercentage('carbs', carbsAdjusted);
  const fiberPercent = getDailyPercentage('fiber', fiberAdjusted);
  const sodiumPercent = getDailyPercentage('sodium', sodiumAdjusted);

  return (
    <div className="space-y-4">
      {/* Allergen warning (if any) */}
      {recipeAllergens.length > 0 && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-red-700">{t("allergenWarning")}</h4>
              <p className="text-sm text-red-600 mt-1">
                {t("recipeContainsAllergens")}:
              </p>
              <ul className="list-disc list-inside text-sm text-red-600 mt-1">
                {recipeAllergens.map(allergen => (
                  <li key={allergen}>{t(allergen)}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
      
      {/* Calories section */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="font-medium mb-3">{t("nutritionFacts")}</h3>
        <div className="border-b pb-2 mb-3">
          <div className="text-sm text-gray-500">{t("calories")}</div>
          <div className="text-2xl font-bold">{calories}</div>
        </div>
        
        {/* Macronutrient breakdown */}
        <div className="space-y-3">
          {/* Protein */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium">{t("protein")}</div>
              <div className="text-sm">
                {proteinAdjusted}{protein.unit} 
                <span className="text-gray-500 ml-1">({proteinPercent}% DV)</span>
              </div>
            </div>
            <Progress value={proteinPercent} className="h-2 bg-gray-200" />
          </div>
          
          {/* Fat */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium">{t("fat")}</div>
              <div className="text-sm">
                {fatAdjusted}{fat.unit} 
                <span className="text-gray-500 ml-1">({fatPercent}% DV)</span>
              </div>
            </div>
            <Progress value={fatPercent} className="h-2 bg-gray-200" />
          </div>
          
          {/* Carbs */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium">{t("carbs")}</div>
              <div className="text-sm">
                {carbsAdjusted}{carbs.unit} 
                <span className="text-gray-500 ml-1">({carbsPercent}% DV)</span>
              </div>
            </div>
            <Progress value={carbsPercent} className="h-2 bg-gray-200" />
          </div>
          
          {/* Fiber */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium">{t("fiber")}</div>
              <div className="text-sm">
                {fiberAdjusted}{fiber.unit} 
                <span className="text-gray-500 ml-1">({fiberPercent}% DV)</span>
              </div>
            </div>
            <Progress value={fiberPercent} className="h-2 bg-gray-200" />
          </div>
          
          {/* Sodium */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <div className="text-sm font-medium">{t("sodium")}</div>
              <div className="text-sm">
                {sodiumAdjusted}{sodium.unit} 
                <span className="text-gray-500 ml-1">({sodiumPercent}% DV)</span>
              </div>
            </div>
            <Progress value={sodiumPercent} className="h-2 bg-gray-200" />
          </div>
        </div>
        
        {/* Footnote */}
        <div className="mt-4 text-xs text-gray-500 border-t pt-3">
          <p className="flex gap-1 items-start">
            <Info className="h-4 w-4 mr-1 flex-shrink-0 mt-0.5" />
            <span>
              {t("percentDailyValueNote")}
            </span>
          </p>
        </div>
      </div>
      
      {/* Ingredient nutrition information */}
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h3 className="font-medium mb-3">{t("ingredientNutrition")}</h3>
        
        <div className="space-y-2">
          {recipe.ingredients.map((ingredient, index) => (
            <div 
              key={index} 
              className={`p-3 rounded-lg border ${
                recipeAllergens.some(allergen => {
                  const allergenMap: Record<string, string[]> = {
                    'gluten': ['wheat', 'barley', 'rye', 'flour', 'bread', 'pasta'],
                    'dairy': ['milk', 'cheese', 'butter', 'cream', 'yogurt'],
                    'nuts': ['almond', 'walnut', 'pecan', 'cashew', 'pistachio', 'hazelnut'],
                    'peanuts': ['peanut', 'groundnut'],
                    'shellfish': ['shrimp', 'crab', 'lobster', 'prawn'],
                    'fish': ['fish', 'salmon', 'tuna', 'cod', 'halibut'],
                    'eggs': ['egg', 'omelette', 'meringue'],
                    'soy': ['soy', 'tofu', 'edamame', 'miso'],
                    'sesame': ['sesame', 'tahini']
                  };
                  
                  const keywords = allergenMap[allergen] || [];
                  const ingredientName = isRtl ? ingredient.nameAr.toLowerCase() : ingredient.name.toLowerCase();
                  
                  return keywords.some(keyword => ingredientName.includes(keyword));
                }) 
                ? 'bg-red-50 border-red-200' 
                : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex justify-between items-center">
                <div className="font-medium">
                  {isRtl ? ingredient.nameAr : ingredient.name}
                  {recipeAllergens.some(allergen => {
                    const allergenMap: Record<string, string[]> = {
                      'gluten': ['wheat', 'barley', 'rye', 'flour', 'bread', 'pasta'],
                      'dairy': ['milk', 'cheese', 'butter', 'cream', 'yogurt'],
                      'nuts': ['almond', 'walnut', 'pecan', 'cashew', 'pistachio', 'hazelnut'],
                      'peanuts': ['peanut', 'groundnut'],
                      'shellfish': ['shrimp', 'crab', 'lobster', 'prawn'],
                      'fish': ['fish', 'salmon', 'tuna', 'cod', 'halibut'],
                      'eggs': ['egg', 'omelette', 'meringue'],
                      'soy': ['soy', 'tofu', 'edamame', 'miso'],
                      'sesame': ['sesame', 'tahini']
                    };
                    
                    const keywords = allergenMap[allergen] || [];
                    const ingredientName = isRtl ? ingredient.nameAr.toLowerCase() : ingredient.name.toLowerCase();
                    
                    return keywords.some(keyword => ingredientName.includes(keyword));
                  }) && (
                    <span className="ml-2 text-xs px-2 py-0.5 bg-red-200 text-red-800 rounded-full">
                      {t("allergen")}
                    </span>
                  )}
                </div>
                <div className="text-sm text-gray-500">{ingredient.quantity}</div>
              </div>
              
              {/* Macronutrient estimates - in a real app, these would come from a database */}
              <div className="mt-2 text-xs text-gray-500 grid grid-cols-3 gap-2">
                <div>~{Math.round(Math.random() * 10)}{t("calories")}</div>
                <div>~{(Math.random() * 2).toFixed(1)}g {t("protein")}</div>
                <div>~{(Math.random() * 3).toFixed(1)}g {t("carbs")}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}