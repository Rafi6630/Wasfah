import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Clock, ChefHat, Star, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { RecipeRecommendation } from "@/lib/openai";

interface RecipeListItemProps {
  recipe: RecipeRecommendation;
  onClick?: () => void;
  showMatchPercentage?: boolean;
}

export function RecipeListItem({ 
  recipe, 
  onClick, 
  showMatchPercentage = true 
}: RecipeListItemProps) {
  const { isRtl } = useI18n();
  const [isFavorite, setIsFavorite] = React.useState(false);
  
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
    // In a real app, this would update the database
  };
  
  const recipeImage = recipe.imageUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c';
  const recipeName = isRtl ? recipe.nameAr : recipe.name;
  const recipeDescription = isRtl ? recipe.descriptionAr : recipe.description;
  const matchText = recipe.matchPercentage ? `${recipe.matchPercentage}% match` : '';
  
  return (
    <div 
      className="flex bg-white rounded-lg overflow-hidden border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
      onClick={onClick}
    >
      {/* Recipe Image */}
      <div className="relative w-1/3">
        <img 
          src={recipeImage} 
          alt={recipeName}
          className="w-full h-full object-cover min-h-[120px]"
        />
        
        {/* Match percentage badge */}
        {showMatchPercentage && recipe.matchPercentage && (
          <div className="absolute top-2 left-2 bg-black/50 text-white text-xs px-2 py-1 rounded-full">
            {matchText}
          </div>
        )}
      </div>
      
      {/* Recipe Details */}
      <div className="flex-1 p-3 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-start">
            <h3 className="font-medium text-base line-clamp-1">{recipeName}</h3>
            <Button
              size="icon"
              variant="ghost"
              className="h-7 w-7 rounded-full ml-1 -mt-1 -mr-1"
              onClick={handleFavoriteClick}
            >
              <Heart 
                className={cn(
                  "h-4 w-4", 
                  isFavorite ? "fill-red-500 text-red-500" : "text-gray-500"
                )}
              />
            </Button>
          </div>
          
          <p className="text-xs text-gray-600 line-clamp-2 mt-1">{recipeDescription}</p>
        </div>
        
        <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            <span>{recipe.cookTime} min</span>
          </div>
          
          <div className="flex items-center gap-1">
            <ChefHat className="h-3 w-3" />
            <span>{recipe.difficulty}</span>
          </div>
          
          <div className="flex items-center gap-1">
            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            <span>{4.5}</span>
          </div>
        </div>
      </div>
    </div>
  );
}