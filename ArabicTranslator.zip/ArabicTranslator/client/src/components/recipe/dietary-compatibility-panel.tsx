import React from 'react';
import { useI18n } from "@/lib/i18n";
import { 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  ShieldAlert, 
  ShieldCheck, 
  Info 
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Recipe } from "@shared/schema";
import { cn } from "@/lib/utils";

interface DietaryCompatibilityPanelProps {
  recipe: Recipe;
  className?: string;
}

export function DietaryCompatibilityPanel({
  recipe,
  className,
}: DietaryCompatibilityPanelProps) {
  const { t } = useI18n();
  
  // If no dietary match data, show a placeholder
  if (recipe.dietaryMatchScore === undefined) {
    return (
      <Card className={cn("", className)}>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <ShieldAlert className="h-5 w-5 text-muted-foreground" />
            {t("dietaryCompatibility")}
          </CardTitle>
          <CardDescription>{t("noDietaryPreferencesSet")}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4 text-muted-foreground text-sm">
            <p>{t("setDietaryPreferencesInProfile")}</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Calculate compatibility status
  const getCompatibilityStatus = (score: number) => {
    if (score >= 90) return { 
      label: t("highlyCompatible"), 
      icon: <ShieldCheck className="h-5 w-5 text-green-500" />,
      color: 'text-green-500',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200'
    };
    if (score >= 70) return { 
      label: t("moderatelyCompatible"), 
      icon: <Info className="h-5 w-5 text-amber-500" />,
      color: 'text-amber-500',
      bgColor: 'bg-amber-50',
      borderColor: 'border-amber-200'
    };
    return { 
      label: t("lowCompatibility"), 
      icon: <ShieldAlert className="h-5 w-5 text-red-500" />,
      color: 'text-red-500',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200'
    };
  };
  
  const status = getCompatibilityStatus(recipe.dietaryMatchScore);
  const hasExplanations = recipe.dietaryMatchExplanations && recipe.dietaryMatchExplanations.length > 0;
  
  return (
    <Card className={cn("", className)}>
      <CardHeader className={cn("pb-3", status.bgColor, status.borderColor)}>
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          {status.icon}
          <span>{t("dietaryCompatibility")}</span>
          <Badge variant="outline" className={cn("ml-auto", status.bgColor, status.color)}>
            {status.label}
          </Badge>
        </CardTitle>
        <CardDescription className="mt-1">
          {hasExplanations 
            ? t("compatibilityDetails") 
            : t("scoreBasedOnPreferences")}
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {/* Score meter */}
        <div className="mb-6 mt-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">{t("compatibilityScore")}</span>
            <span className={cn(
              "text-sm font-bold", 
              recipe.dietaryMatchScore >= 90 ? "text-green-600" : 
              recipe.dietaryMatchScore >= 70 ? "text-amber-600" : 
              "text-red-600"
            )}>
              {recipe.dietaryMatchScore}%
            </span>
          </div>
          <Progress 
            value={recipe.dietaryMatchScore} 
            className={cn(
              "h-2",
              recipe.dietaryMatchScore >= 90 ? "bg-green-100" : 
              recipe.dietaryMatchScore >= 70 ? "bg-amber-100" : 
              "bg-red-100"
            )}
            indicatorClassName={cn(
              recipe.dietaryMatchScore >= 90 ? "bg-green-600" : 
              recipe.dietaryMatchScore >= 70 ? "bg-amber-600" : 
              "bg-red-600"
            )}
          />
        </div>
        
        {/* Match explanations */}
        {hasExplanations && (
          <div className="mt-4">
            <h4 className="text-sm font-semibold mb-2">{t("dietaryMatchDetails")}</h4>
            <ScrollArea className="h-[150px] rounded-md border p-2">
              <div className="space-y-2">
                {recipe.dietaryMatchExplanations.map((explanation, idx) => {
                  const isPositive = explanation.includes("suitable") || !explanation.includes("not");
                  return (
                    <div 
                      key={idx} 
                      className={cn(
                        "flex items-start gap-2 p-2 rounded text-sm",
                        isPositive ? "bg-green-50" : "bg-red-50"
                      )}
                    >
                      {isPositive ? (
                        <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                      )}
                      <div className={isPositive ? "text-green-800" : "text-red-800"}>
                        {explanation}
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </div>
        )}
        
        {/* Dietary suggestions */}
        <div className="mt-5">
          <Separator className="mb-4" />
          <h4 className="text-sm font-semibold mb-2">{t("recommendations")}</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            {recipe.dietaryMatchScore < 90 && (
              <li className="flex items-start gap-2">
                <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                <span>{t("considerDietaryAlternatives")}</span>
              </li>
            )}
            {recipe.dietaryMatchScore >= 90 && (
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5" />
                <span>{t("recipeMeetsPreferences")}</span>
              </li>
            )}
            <li className="flex items-start gap-2">
              <Info className="h-4 w-4 text-blue-500 mt-0.5" />
              <span>{t("trackNutritionValues")}</span>
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}