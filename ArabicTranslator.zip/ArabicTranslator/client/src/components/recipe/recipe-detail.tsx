import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Clock, 
  ChefHat, 
  Utensils, 
  Info, 
  Heart, 
  Share,
  Star, 
  BookmarkPlus,
  Plus,
  PlayCircle,
  Eye,
  Bookmark,
  ThumbsUp,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { Recipe } from "@shared/schema";
import { RecipeRecommendation } from "@/lib/openai";
import { IngredientItem } from "./ingredient-item";
import { NutritionDetail } from "./nutrition-detail";
import { DietaryCompatibilityPanel } from "./dietary-compatibility-panel";

interface RecipeDetailProps {
  recipe: Recipe | RecipeRecommendation;
  onBackClick: () => void;
}

export function RecipeDetail({ recipe, onBackClick }: RecipeDetailProps) {
  const { t, isRtl } = useI18n();
  const [isFavorite, setIsFavorite] = React.useState(false);
  
  // Handle different recipe property formats
  const servings = 'servings' in recipe ? recipe.servings : (recipe.servings_count || '4');
  const [servingSize, setServingSize] = React.useState(parseInt(servings) || 4);
  const [activeTab, setActiveTab] = React.useState("ingredients");
  
  // Engagement metrics (in a real app, these would come from the backend)
  const [metrics, setMetrics] = React.useState({
    likes: Math.floor(Math.random() * 100) + 5,
    views: Math.floor(Math.random() * 1000) + 100,
    shares: Math.floor(Math.random() * 50) + 1,
    saves: Math.floor(Math.random() * 80) + 10
  });
  
  const handleFavoriteToggle = () => {
    setIsFavorite(!isFavorite);
    // Update metrics
    setMetrics(prev => ({
      ...prev,
      likes: isFavorite ? prev.likes - 1 : prev.likes + 1
    }));
    // In a real app, this would update the database
  };
  
  const handleShareClick = () => {
    setMetrics(prev => ({
      ...prev,
      shares: prev.shares + 1
    }));
    handleShareRecipe();
  };
  
  const handleSaveClick = () => {
    setMetrics(prev => ({
      ...prev,
      saves: prev.saves + 1
    }));
    handleSaveToMealPlan();
  };
  
  const handleServingSizeChange = (change: number) => {
    setServingSize(Math.max(1, servingSize + change));
  };
  
  const handleShareRecipe = () => {
    // In a real app, this would open a share dialog
    alert(t("shareFeatureNotImplemented"));
  };
  
  const handleSaveToMealPlan = () => {
    // In a real app, this would open a meal plan modal
    alert(t("mealPlanFeatureNotImplemented"));
  };
  
  const handleAddToShoppingList = () => {
    // In a real app, this would add ingredients to shopping list
    alert(t("shoppingListFeatureNotImplemented"));
  };
  
  const handleCookNow = () => {
    // In a real app, this would start cooking mode with step-by-step instructions
    setActiveTab("instructions");
    alert(t("cookingModeStarted"));
  };
  
  const recipeName = isRtl ? recipe.nameAr : recipe.name;
  const recipeDescription = isRtl ? recipe.descriptionAr : recipe.description;
  
  return (
    <div className="flex flex-col min-h-screen pb-20">
      {/* Recipe Header */}
      <div className="relative">
        <img 
          src={recipe.imageUrl || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c'} 
          alt={recipeName}
          className="w-full h-[250px] object-cover"
        />
        
        <div className="absolute top-0 left-0 right-0 p-4">
          <Button
            variant="ghost"
            size="icon"
            className="bg-white/80 hover:bg-white rounded-full"
            onClick={onBackClick}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold">{recipeName}</h1>
              <div className="flex items-center gap-2">
                <p className="text-sm opacity-90">{recipe.cuisine}</p>
                {recipe.dietaryMatchScore !== undefined && recipe.dietaryMatchScore > 0 && (
                  <div className="px-1.5 py-0.5 rounded-sm text-xs bg-green-600/80 flex items-center gap-1">
                    <ShieldCheck className="h-3 w-3" />
                    <span>{recipe.dietaryMatchScore}%</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="bg-white/20 hover:bg-white/30 text-white rounded-full"
                onClick={handleFavoriteToggle}
              >
                <Heart className={cn("h-5 w-5", isFavorite && "fill-red-500")} />
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                className="bg-white/20 hover:bg-white/30 text-white rounded-full"
                onClick={handleShareClick}
              >
                <Share className="h-5 w-5" />
              </Button>
            </div>
          </div>
          
          <div className="flex gap-4 mt-2">
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span className="text-sm">{recipe.cookTime} min</span>
            </div>
            
            <div className="flex items-center gap-1">
              <ChefHat className="h-4 w-4" />
              <span className="text-sm">{recipe.difficulty}</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-yellow-400" />
              <span className="text-sm">{recipe.rating || 4.5}</span>
            </div>
            
            <div className="flex items-center gap-1">
              <Utensils className="h-4 w-4" />
              <span className="text-sm">{recipe.servings} {t("servings")}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recipe description */}
      <div className="p-4 bg-white">
        <p className="text-sm text-gray-700">{recipeDescription}</p>
        
        {/* Engagement metrics */}
        <div className="mt-4 flex justify-between items-center pt-3 border-t border-gray-100">
          <div className="flex items-center gap-3">
            <div className="flex items-center text-gray-500">
              <Eye className="h-4 w-4 mr-1" />
              <span className="text-xs">{metrics.views}</span>
            </div>
            <div className="flex items-center text-gray-500">
              <ThumbsUp className="h-4 w-4 mr-1" />
              <span className="text-xs">{metrics.likes}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center text-gray-500">
              <Share className="h-4 w-4 mr-1" />
              <span className="text-xs">{metrics.shares}</span>
            </div>
            <div className="flex items-center text-gray-500">
              <Bookmark className="h-4 w-4 mr-1" />
              <span className="text-xs">{metrics.saves}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Recipe tabs */}
      <div className="flex-1 bg-gray-50">
        <Tabs defaultValue="ingredients" value={activeTab} onValueChange={setActiveTab}>
          <div className="bg-white border-b sticky top-0 z-10">
            <TabsList className="w-full justify-start p-1 bg-transparent h-auto">
              <TabsTrigger
                value="ingredients"
                className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md"
              >
                {t("ingredients")}
              </TabsTrigger>
              <TabsTrigger
                value="instructions"
                className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md"
              >
                {t("instructions")}
              </TabsTrigger>
              <TabsTrigger
                value="nutrition"
                className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md"
              >
                {t("nutrition")}
              </TabsTrigger>
              <TabsTrigger
                value="dietary"
                className="data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-md"
              >
                {t("dietary")}
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* Ingredients tab */}
          <TabsContent value="ingredients" className="p-4 space-y-4">
            <div className="flex items-center justify-between bg-white p-3 rounded-lg shadow-sm">
              <span>{t("servingSize")}</span>
              <div className="flex items-center gap-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => handleServingSizeChange(-1)}
                  disabled={servingSize <= 1}
                >
                  -
                </Button>
                <span>{servingSize}</span>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => handleServingSizeChange(1)}
                >
                  +
                </Button>
              </div>
            </div>
            
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h3 className="font-medium mb-3">{t("ingredients")}</h3>
              <ul className="space-y-2">
                {recipe.ingredients.map((ingredient, index) => (
                  <IngredientItem
                    key={index}
                    name={isRtl ? ingredient.nameAr : ingredient.name}
                    quantity={ingredient.quantity}
                    servingMultiplier={servingSize / (parseInt(recipe.servings) || 4)}
                  />
                ))}
              </ul>
              
              <Button
                className="w-full mt-4"
                size="sm"
                variant="outline"
                onClick={handleAddToShoppingList}
              >
                <Plus className="h-4 w-4 mr-1" />
                {t("addToShoppingList")}
              </Button>
            </div>
          </TabsContent>
          
          {/* Instructions tab */}
          <TabsContent value="instructions" className="p-4">
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h3 className="font-medium mb-3">{t("cookingInstructions")}</h3>
              <ol className="space-y-4">
                {recipe.instructions.map((instruction) => (
                  <li key={instruction.step} className="flex gap-3">
                    <div className="flex-shrink-0 w-7 h-7 rounded-full bg-primary/10 text-primary flex items-center justify-center font-medium">
                      {instruction.step}
                    </div>
                    <p className="flex-1 text-sm">
                      {isRtl ? instruction.textAr : instruction.text}
                    </p>
                  </li>
                ))}
              </ol>
            </div>
          </TabsContent>
          
          {/* Nutrition tab */}
          <TabsContent value="nutrition" className="p-4">
            <NutritionDetail recipe={recipe} servingSize={servingSize} />
          </TabsContent>
          
          {/* Dietary tab */}
          <TabsContent value="dietary" className="p-4">
            <DietaryCompatibilityPanel recipe={recipe} />
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Action buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.05)] flex gap-2">
        <Button
          className="flex-1"
          variant="outline"
          onClick={handleSaveClick}
        >
          <BookmarkPlus className="h-5 w-5 mr-1" />
          {t("saveToMealPlan")}
        </Button>
        
        <Button
          className="flex-1 bg-green-600 hover:bg-green-700"
          onClick={handleCookNow}
        >
          <PlayCircle className="h-5 w-5 mr-1" />
          {t("cookNow")}
        </Button>
        
        <Button
          className="flex-1"
          onClick={handleAddToShoppingList}
        >
          <Plus className="h-5 w-5 mr-1" />
          {t("addToShoppingList")}
        </Button>
      </div>
    </div>
  );
}