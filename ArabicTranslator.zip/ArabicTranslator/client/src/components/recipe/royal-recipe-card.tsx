import React from "react";
import { cn } from "@/lib/utils";
import { Clock, ChefHat, Award, Heart, Bookmark, Star } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { RoyalCrownIcon } from "../icons/crown-icon";
import { RoyalButton } from "../ui/royal-button";

interface Recipe {
  id: string;
  name: string;
  nameAr?: string;
  cookTime: number;
  imageUrl: string;
  difficulty: string;
  matchPercentage?: number;
  calories?: number;
  rating?: number;
  cuisine?: string;
  cuisineAr?: string;
  isPremium?: boolean;
  isChefsPick?: boolean;
}

interface RoyalRecipeCardProps {
  recipe: Recipe;
  onClick?: (id: string) => void;
  onFavoriteClick?: (id: string) => void;
  onBookmarkClick?: (id: string) => void;
  isFavorited?: boolean;
  isBookmarked?: boolean;
  variant?: "standard" | "compact" | "featured";
  className?: string;
}

export function RoyalRecipeCard({
  recipe,
  onClick,
  onFavoriteClick,
  onBookmarkClick,
  isFavorited,
  isBookmarked,
  variant = "standard",
  className,
}: RoyalRecipeCardProps) {
  const { t, isRtl } = useI18n();
  const isCompact = variant === "compact";
  const isFeatured = variant === "featured";
  
  // Get localized recipe name
  const recipeName = isRtl && recipe.nameAr ? recipe.nameAr : recipe.name;
  
  // Get localized cuisine name if available
  const cuisineName = isRtl && recipe.cuisineAr ? recipe.cuisineAr : recipe.cuisine;
  
  // Handle favorite button click
  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onFavoriteClick) {
      onFavoriteClick(recipe.id);
    }
  };
  
  // Handle bookmark button click
  const handleBookmarkClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onBookmarkClick) {
      onBookmarkClick(recipe.id);
    }
  };
  
  // Card click handler
  const handleCardClick = () => {
    if (onClick) {
      onClick(recipe.id);
    }
  };
  
  return (
    <div
      className={cn(
        "group cursor-pointer overflow-hidden transition-all duration-300",
        isFeatured ? "royal-card-premium" : "royal-card",
        className
      )}
      onClick={handleCardClick}
    >
      <div className={cn(
        isFeatured ? "royal-card-premium-inner p-0 h-full" : ""
      )}>
        {/* Card Image Container */}
        <div className="relative">
          {/* Recipe Image */}
          <div className={cn(
            "overflow-hidden",
            isCompact ? "h-24" : isFeatured ? "h-52" : "h-40"
          )}>
            <img
              src={recipe.imageUrl}
              alt={recipeName}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </div>
          
          {/* Top Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {/* Chef's Pick Badge */}
            {recipe.isChefsPick && (
              <div className="bg-royal-gold text-royal-purple-dark text-xs font-bold py-0.5 px-2 rounded-full shadow-sm flex items-center gap-1">
                <Award className="h-3 w-3" />
                <span>{t("chefsPick") || "Chef's Pick"}</span>
              </div>
            )}
            
            {/* Match Percentage */}
            {recipe.matchPercentage && (
              <div className="bg-white/90 text-royal-purple text-xs font-bold py-0.5 px-2 rounded-full shadow-sm">
                {Math.round(recipe.matchPercentage)}% {t("match") || "Match"}
              </div>
            )}
          </div>
          
          {/* Premium Badge */}
          {recipe.isPremium && (
            <div className="absolute top-2 right-2">
              <div className="flex items-center gap-1 bg-royal-purple/90 text-white text-xs font-bold py-0.5 px-2 rounded-full shadow-sm">
                <RoyalCrownIcon className="h-3 w-3 text-royal-gold" />
                <span>{t("premium") || "Premium"}</span>
              </div>
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="absolute -bottom-3 right-2 flex gap-1">
            {onFavoriteClick && (
              <button
                className={cn(
                  "p-1.5 rounded-full shadow-md transition-all",
                  isFavorited 
                    ? "bg-red-500 text-white" 
                    : "bg-white text-gray-400 hover:text-red-500"
                )}
                onClick={handleFavoriteClick}
                aria-label={t("addToFavorites") || "Add to favorites"}
              >
                <Heart className="h-4 w-4" fill={isFavorited ? "white" : "none"} />
              </button>
            )}
            
            {onBookmarkClick && (
              <button
                className={cn(
                  "p-1.5 rounded-full shadow-md transition-all",
                  isBookmarked 
                    ? "bg-royal-purple text-white" 
                    : "bg-white text-gray-400 hover:text-royal-purple"
                )}
                onClick={handleBookmarkClick}
                aria-label={t("addToBookmarks") || "Add to bookmarks"}
              >
                <Bookmark className="h-4 w-4" fill={isBookmarked ? "white" : "none"} />
              </button>
            )}
          </div>
        </div>
        
        {/* Card Content */}
        <div className={cn(
          "p-3",
          isCompact ? "pt-2" : "pt-4"
        )}>
          {/* Title */}
          <h3 className={cn(
            "font-bold text-royal-purple-dark",
            isCompact ? "text-sm" : "text-base"
          )}>
            {recipeName}
          </h3>
          
          {/* Metadata */}
          <div className={cn(
            "flex items-center gap-3 text-royal-purple-dark/70 mt-1",
            isCompact ? "text-xs" : "text-sm"
          )}>
            {/* Cooking Time */}
            {recipe.cookTime && (
              <div className="flex items-center gap-1">
                <Clock className={isCompact ? "h-3 w-3" : "h-4 w-4"} />
                <span>{recipe.cookTime} {t("minutes") || "min"}</span>
              </div>
            )}
            
            {/* Difficulty */}
            {recipe.difficulty && !isCompact && (
              <div className="flex items-center gap-1">
                <ChefHat className="h-4 w-4" />
                <span>{recipe.difficulty}</span>
              </div>
            )}
            
            {/* Rating */}
            {recipe.rating && (
              <div className="flex items-center gap-1">
                <Star className={isCompact ? "h-3 w-3 text-royal-gold" : "h-4 w-4 text-royal-gold"} fill="#FFD700" />
                <span>{recipe.rating.toFixed(1)}</span>
              </div>
            )}
          </div>
          
          {/* Cuisine Type */}
          {cuisineName && !isCompact && (
            <div className="mt-2">
              <span className="inline-block bg-royal-purple/10 px-2 py-0.5 rounded-full text-xs text-royal-purple">
                {cuisineName}
              </span>
            </div>
          )}
          
          {/* Nutrition (Featured cards only) */}
          {isFeatured && recipe.calories && (
            <div className="mt-3 text-xs text-royal-purple-dark/70">
              <span className="font-medium">{t("calories") || "Calories"}: </span>
              <span>{recipe.calories} kcal</span>
            </div>
          )}
          
          {/* View button (Featured only) */}
          {isFeatured && (
            <div className="mt-4">
              <RoyalButton 
                variant="primary" 
                size="sm" 
                isFullWidth 
                withGlow
              >
                {t("viewRecipe") || "View Recipe"}
              </RoyalButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}