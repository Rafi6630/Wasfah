import React from 'react';
import { useI18n } from "@/lib/i18n";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Info, AlertCircle, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface DietaryMatchIndicatorProps {
  matchScore?: number;
  matchExplanations?: string[];
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showExplanation?: boolean;
}

export function DietaryMatchIndicator({
  matchScore,
  matchExplanations = [],
  className,
  size = 'md',
  showExplanation = true,
}: DietaryMatchIndicatorProps) {
  const { t } = useI18n();
  
  // If no match score, don't render
  if (matchScore === undefined) return null;
  
  // Determine color based on match score
  const getColorClass = (score: number) => {
    if (score >= 90) return "bg-green-100 text-green-800 border-green-300";
    if (score >= 70) return "bg-yellow-100 text-yellow-800 border-yellow-300";
    return "bg-red-100 text-red-800 border-red-300";
  };
  
  // Determine icon based on match score
  const getIcon = (score: number) => {
    if (score >= 90) return <CheckCircle2 className="h-3.5 w-3.5" />;
    if (score >= 70) return <Info className="h-3.5 w-3.5" />;
    return <AlertCircle className="h-3.5 w-3.5" />;
  };
  
  // Determine size class
  const getSizeClass = (size: string) => {
    switch (size) {
      case 'sm': return 'text-xs py-0.5 px-1.5';
      case 'lg': return 'text-sm py-1 px-3';
      default: return 'text-xs py-0.5 px-2';
    }
  };
  
  // If no explanations, create a default explanation
  const explanations = matchExplanations.length > 0
    ? matchExplanations
    : (matchScore >= 90 
      ? [t("dietaryMatchPerfect")] 
      : (matchScore >= 70 
        ? [t("dietaryMatchPartial")] 
        : [t("dietaryMatchPoor")]));
  
  return (
    <div className={cn("flex items-center", className)}>
      {showExplanation ? (
        <Popover>
          <PopoverTrigger asChild>
            <Badge 
              variant="outline" 
              className={cn(
                "cursor-pointer border flex items-center gap-1 transition-colors",
                getSizeClass(size),
                getColorClass(matchScore)
              )}
            >
              {getIcon(matchScore)}
              <span>{matchScore}% {t("match")}</span>
            </Badge>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-3">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">{t("dietaryCompatibility")}</h4>
              <div className="space-y-1">
                {explanations.map((explanation, idx) => (
                  <p key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="mt-0.5">{getIcon(matchScore)}</span>
                    <span>{explanation}</span>
                  </p>
                ))}
              </div>
            </div>
          </PopoverContent>
        </Popover>
      ) : (
        <Badge 
          variant="outline" 
          className={cn(
            "flex items-center gap-1",
            getSizeClass(size),
            getColorClass(matchScore)
          )}
        >
          {getIcon(matchScore)}
          <span>{matchScore}%</span>
        </Badge>
      )}
    </div>
  );
}