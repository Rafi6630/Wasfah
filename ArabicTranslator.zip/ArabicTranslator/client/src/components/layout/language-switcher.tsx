import { Button } from "@/components/ui/button";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/hooks/use-auth";

export function LanguageSwitcher() {
  const { language, setLanguage, isRtl } = useI18n();
  const { user, updateProfileMutation } = useAuth();
  
  const toggleLanguage = () => {
    const newLang = language === 'en' ? 'ar' : 'en';
    setLanguage(newLang);
    document.documentElement.setAttribute('dir', newLang === 'ar' ? 'rtl' : 'ltr');
    
    // If user is logged in, update their language preference
    if (user) {
      updateProfileMutation.mutate({ language: newLang });
    }
  };

  return (
    <Button 
      variant="outline" 
      size="icon" 
      className="w-8 h-8 rounded-full bg-white text-neutral-800 shadow-md"
      onClick={toggleLanguage}
    >
      <span className="text-xs font-medium">{language.toUpperCase()}</span>
    </Button>
  );
}
