import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { useAnimation } from '@/lib/animation-context';

interface PageTransitionProps {
  children: ReactNode;
  className?: string;
}

export function PageTransition({ children, className = "" }: PageTransitionProps) {
  const { animationsEnabled, prefersReducedMotion, transitionType, getDurationFactor } = useAnimation();
  
  // Don't animate if animations are disabled or reduced motion is preferred
  const shouldAnimate = animationsEnabled && !prefersReducedMotion;
  
  // Adjust duration based on animation speed settings
  const durationFactor = getDurationFactor();
  
  // Define variants based on the selected transition type
  const getVariants = () => {
    switch (transitionType) {
      case 'slide':
        return {
          initial: { x: -20, opacity: 0 },
          animate: { x: 0, opacity: 1 },
          exit: { x: 20, opacity: 0 },
        };
      case 'scale':
        return {
          initial: { scale: 0.96, opacity: 0 },
          animate: { scale: 1, opacity: 1 },
          exit: { scale: 0.96, opacity: 0 },
        };
      case 'crown':
        return {
          initial: { y: 20, opacity: 0, rotate: -1 },
          animate: { y: 0, opacity: 1, rotate: 0 },
          exit: { y: -20, opacity: 0, rotate: 1 },
        };
      case 'sparkle':
        return {
          initial: { 
            opacity: 0, 
            filter: "brightness(1.1) contrast(1.05)",
            scale: 0.98,
          },
          animate: { 
            opacity: 1, 
            filter: "brightness(1) contrast(1)",
            scale: 1,
          },
          exit: { 
            opacity: 0, 
            filter: "brightness(0.95) contrast(0.95)",
            scale: 0.98,
          },
        };
      case 'fade':
      default:
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
        };
    }
  };
  
  // If animations are disabled, render children without motion effects
  if (!shouldAnimate) {
    return <div className={className}>{children}</div>;
  }
  
  return (
    <motion.div
      className={className}
      initial="initial"
      animate="animate"
      exit="exit"
      variants={getVariants()}
      transition={{
        duration: 0.35 / durationFactor,
        ease: transitionType === 'crown' ? "anticipate" : "easeInOut",
      }}
    >
      {children}
    </motion.div>
  );
}