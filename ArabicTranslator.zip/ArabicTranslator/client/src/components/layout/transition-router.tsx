import React, { useEffect, useState } from 'react';
import { Route, Router, Switch, useLocation } from 'wouter';
import { AnimatePresence } from 'framer-motion';
import { PageTransition } from './page-transition';
import { ProtectedRoute } from '@/lib/protected-route';

// Import all pages
import HomePage from '@/pages/home-page';
import NotFoundPage from '@/pages/not-found';
import AuthPage from '@/pages/auth-page';
import SearchPage from '@/pages/search-page';
import RecipeDetailPage from '@/pages/recipe-detail-page';
import ProfilePage from '@/pages/profile-page';
import SettingsPage from '@/pages/settings-page';
import CookingHistoryPage from '@/pages/cooking-history-page';
import MealPlanningPage from '@/pages/meal-planning-page';
import ShoppingListPage from '@/pages/shopping-list-page';
import SmartPantryPage from '@/pages/smart-pantry-page';
import AnimationSettingsPage from '@/pages/animation-settings-page';
import AnimationShowcasePage from '@/pages/animation-showcase-page';
import DietaryPreferencesPage from '@/pages/dietary-preferences-page';
import GlobalCuisinePage from '@/pages/global-cuisine-page';
import SubscriptionPage from '@/pages/subscription-page';
import PaymentMethodsPage from '@/pages/payment-methods-page';
import SharedRecipesPage from '@/pages/shared-recipes-page';
import SplashPage from '@/pages/splash-page';

export function TransitionRouter() {
  // Current location from wouter
  const [location] = useLocation();
  
  // Create a key for AnimatePresence based on the current location
  const [pageKey, setPageKey] = useState(location);
  
  // Update the key when location changes to trigger animations
  useEffect(() => {
    setPageKey(location);
  }, [location]);
  
  return (
    <AnimatePresence mode="wait">
      <PageTransition key={pageKey}>
        <Switch>
          {/* Public Routes */}
          <Route path="/" component={SplashPage} />
          <Route path="/auth" component={AuthPage} />
          
          {/* Protected Routes */}
          <ProtectedRoute path="/home" component={HomePage} />
          <ProtectedRoute path="/search" component={SearchPage} />
          <ProtectedRoute path="/recipe/:id" component={RecipeDetailPage} />
          <ProtectedRoute path="/profile" component={ProfilePage} />
          
          {/* Settings Pages */}
          <ProtectedRoute path="/settings" component={SettingsPage} />
          <ProtectedRoute path="/settings/animations" component={AnimationSettingsPage} />
          <ProtectedRoute path="/animation-showcase" component={AnimationShowcasePage} />
          <ProtectedRoute path="/settings/dietary-preferences" component={DietaryPreferencesPage} />
          
          {/* Feature Pages */}
          <ProtectedRoute path="/cooking-history" component={CookingHistoryPage} />
          <ProtectedRoute path="/meal-planning" component={MealPlanningPage} />
          <ProtectedRoute path="/shopping-list" component={ShoppingListPage} />
          <ProtectedRoute path="/smart-pantry" component={SmartPantryPage} />
          <ProtectedRoute path="/global-cuisine" component={GlobalCuisinePage} />
          <ProtectedRoute path="/shared-recipes" component={SharedRecipesPage} />
          
          {/* Subscription Pages */}
          <ProtectedRoute path="/subscription" component={SubscriptionPage} />
          <ProtectedRoute path="/payment-methods" component={PaymentMethodsPage} />
          
          {/* 404 Page */}
          <Route component={NotFoundPage} />
        </Switch>
      </PageTransition>
    </AnimatePresence>
  );
}