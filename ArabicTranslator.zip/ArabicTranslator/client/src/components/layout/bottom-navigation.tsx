import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Globe2, Package, Heart, User, UtensilsCrossed, Apple, Refrigerator, ChefHat, MapPin } from "lucide-react";
import { RoyalCrownIcon } from "../icons/crown-icon";
import React from "react";

interface NavItem {
  icon: React.ReactNode;
  activeIcon?: React.ReactNode;
  label: string;
  path: string;
}

export function BottomNavigation() {
  const { t, isRtl } = useI18n();
  const [location, setLocation] = useLocation();

  // Custom colored icons with royal theme colors - more vibrant and attractive
  const HomeIcon = ({ isActive }: { isActive: boolean }) => (
    <div className={`relative rounded-full p-1.5 ${isActive ? "bg-royal-gold/20" : ""}`}>
      <ChefHat className={`h-5 w-5 ${isActive ? "stroke-royal-gold fill-royal-gold/10" : "stroke-gray-500"}`} 
        strokeWidth={isActive ? 2.5 : 2} />
    </div>
  );
  
  const GlobeIcon = ({ isActive }: { isActive: boolean }) => (
    <div className={`relative rounded-full p-1.5 ${isActive ? "bg-blue-600/20" : ""}`}>
      <MapPin className={`h-5 w-5 ${isActive ? "stroke-blue-600 fill-blue-100" : "stroke-gray-500"}`} 
        strokeWidth={isActive ? 2.5 : 2} />
    </div>
  );
  
  const PantryIcon = ({ isActive }: { isActive: boolean }) => (
    <div className={`relative rounded-full p-1.5 ${isActive ? "bg-emerald-600/20" : ""}`}>
      <Refrigerator className={`h-5 w-5 ${isActive ? "stroke-emerald-600 fill-emerald-100" : "stroke-gray-500"}`} 
        strokeWidth={isActive ? 2.5 : 2} />
    </div>
  );
  
  const FavoritesIcon = ({ isActive }: { isActive: boolean }) => (
    <div className={`relative rounded-full p-1.5 ${isActive ? "bg-rose-600/20" : ""}`}>
      <Heart className={`h-5 w-5 ${isActive ? "stroke-rose-600 fill-rose-100" : "stroke-gray-500"}`} 
        strokeWidth={isActive ? 2.5 : 2} />
    </div>
  );
  
  const ProfileIcon = ({ isActive }: { isActive: boolean }) => (
    <div className={`relative rounded-full p-1.5 ${isActive ? "bg-violet-600/20" : ""}`}>
      <User className={`h-5 w-5 ${isActive ? "stroke-violet-600 fill-violet-100" : "stroke-gray-500"}`} 
        strokeWidth={isActive ? 2.5 : 2} />
    </div>
  );

  const navItems: NavItem[] = [
    { 
      icon: <HomeIcon isActive={false} />,
      activeIcon: <HomeIcon isActive={true} />,
      label: t("home"), 
      path: "/" 
    },
    { 
      icon: <GlobeIcon isActive={false} />,
      activeIcon: <GlobeIcon isActive={true} />,
      label: t("global"), 
      path: "/global-cuisine" 
    },
    { 
      icon: <PantryIcon isActive={false} />,
      activeIcon: <PantryIcon isActive={true} />,
      label: t("smartPantry"), 
      path: "/smart-pantry" 
    },
    { 
      icon: <FavoritesIcon isActive={false} />,
      activeIcon: <FavoritesIcon isActive={true} />,
      label: t("favorites"), 
      path: "/profile?tab=saved" 
    },
    { 
      icon: <ProfileIcon isActive={false} />,
      activeIcon: <ProfileIcon isActive={true} />,
      label: t("profile"), 
      path: "/profile" 
    },
  ];

  return (
    <div className={cn(
      "bg-white flex items-center justify-around py-3 px-4 shadow-[0_-4px_16px_rgba(0,0,0,0.15)] border-t border-royal-gold/40 bg-gradient-to-r from-white via-royal-gold/5 to-white",
      isRtl && "flex-row-reverse"
    )}>
      {navItems.map((item) => {
        // Check if the current path matches item path, with special handling for profile?tab=saved
        const isActive = item.path === "/profile?tab=saved" 
          ? location.startsWith("/profile") && window.location.search.includes("tab=saved")
          : location === item.path;
        return (
          <div 
            key={item.path}
            className={cn(
              "flex flex-col items-center cursor-pointer group transition-all relative",
              isActive 
                ? "text-royal-purple" 
                : "text-gray-500 hover:text-royal-purple-light"
            )}
            onClick={() => setLocation(item.path)}
          >
            {/* Show crown icon above active item */}
            {isActive && (
              <div className="absolute -top-3.5">
                <RoyalCrownIcon className="h-5 w-5 text-royal-gold animate-crown-float" />
              </div>
            )}
            
            {/* Icon with elevated container for active item */}
            <div className={cn(
              "relative transition-all mb-1",
              isActive && "transform -translate-y-1 scale-110"
            )}>
              {isActive ? item.activeIcon || item.icon : item.icon}
              
              {/* Animated glow effect for active item */}
              {isActive && (
                <span className="absolute inset-0 rounded-full royal-glow opacity-40"></span>
              )}
            </div>
            
            {/* Label */}
            <span className={cn(
              "text-xs font-medium",
              isActive ? "font-semibold" : "opacity-80"
            )}>
              {item.label}
            </span>
            
            {/* Dot indicator for active item */}
            {isActive && (
              <div className="h-1 w-1 rounded-full bg-royal-gold mt-1"></div>
            )}
          </div>
        );
      })}
    </div>
  );
}
