import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const recipesBadgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none",
  {
    variants: {
      variant: {
        default: "border-transparent bg-recipes-purple text-white hover:bg-recipes-purple-dark",
        gold: "border-recipes-gold/20 bg-recipes-gold/10 text-recipes-gold hover:bg-recipes-gold/20",
        outline: "border-recipes-purple/20 text-recipes-purple-dark hover:bg-recipes-purple/5",
        premium: "border-recipes-gold/20 bg-gradient-to-r from-recipes-gold/20 to-recipes-gold/10 text-recipes-gold hover:from-recipes-gold/30 hover:to-recipes-gold/15",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

export interface RecipesBadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof recipesBadgeVariants> {}

function RecipesBadge({ className, variant, ...props }: RecipesBadgeProps) {
  return (
    <div className={cn(recipesBadgeVariants({ variant }), className)} {...props} />
  )
}

// For backward compatibility
const royalBadgeVariants = recipesBadgeVariants;

function RoyalBadge({ className, variant, ...props }: RecipesBadgeProps) {
  return (
    <RecipesBadge className={className} variant={variant} {...props} />
  )
}

export { RecipesBadge, recipesBadgeVariants, RoyalBadge, royalBadgeVariants }
export type { RecipesBadgeProps as RoyalBadgeProps }