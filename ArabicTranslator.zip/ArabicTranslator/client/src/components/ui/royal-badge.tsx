import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const royalBadgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none",
  {
    variants: {
      variant: {
        default: "border-transparent bg-royal-purple text-white hover:bg-royal-purple-dark",
        gold: "border-royal-gold/20 bg-royal-gold/10 text-royal-gold hover:bg-royal-gold/20",
        outline: "border-royal-purple/20 text-royal-purple-dark hover:bg-royal-purple/5",
        premium: "border-royal-gold/20 bg-gradient-to-r from-royal-gold/20 to-royal-gold/10 text-royal-gold hover:from-royal-gold/30 hover:to-royal-gold/15",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

export interface RoyalBadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof royalBadgeVariants> {}

function RoyalBadge({ className, variant, ...props }: RoyalBadgeProps) {
  return (
    <div className={cn(royalBadgeVariants({ variant }), className)} {...props} />
  )
}

export { RoyalBadge, royalBadgeVariants }