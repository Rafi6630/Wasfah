import React from "react";
import { cn } from "@/lib/utils";
import { cva, type VariantProps } from "class-variance-authority";

const inputVariants = cva(
  // Base styles
  "block w-full rounded-md border transition-colors focus:outline-none",
  {
    variants: {
      variant: {
        // Default recipes input
        default: "recipes-input",
        
        // Fancy input with gold glow on focus
        fancy: "border-recipes-gold-dark/30 focus:border-recipes-gold focus:ring-2 focus:ring-recipes-gold/30",
        
        // Subtle input with lighter styling
        subtle: "border-gray-200 focus:border-recipes-purple-light/50 focus:ring-1 focus:ring-recipes-purple-light/30",
        
        // Filled input with background
        filled: "bg-recipes-purple/5 border-transparent focus:bg-recipes-purple/10 focus:border-recipes-purple/30",
      },
      size: {
        sm: "px-3 py-1 text-sm",
        md: "px-4 py-2",
        lg: "px-4 py-3 text-lg",
      },
      state: {
        error: "border-red-500 focus:border-red-500 focus:ring-red-500/30",
        success: "border-green-500 focus:border-green-500 focus:ring-green-500/30",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "md",
    },
  }
);

export interface RecipesInputProps
  extends React.InputHTMLAttributes<HTMLInputElement>,
    VariantProps<typeof inputVariants> {
  label?: string;
  helperText?: string;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  wrapperClassName?: string;
}

const RecipesInput = React.forwardRef<HTMLInputElement, RecipesInputProps>(
  (
    {
      className,
      variant,
      size,
      state,
      label,
      helperText,
      error,
      leftIcon,
      rightIcon,
      wrapperClassName,
      ...props
    },
    ref
  ) => {
    // Determine the state based on error
    const inputState = error ? "error" : state;
    
    return (
      <div className={cn("space-y-1", wrapperClassName)}>
        {/* Label */}
        {label && (
          <label 
            htmlFor={props.id} 
            className="block text-sm font-medium text-recipes-purple-dark"
          >
            {label}
          </label>
        )}
        
        {/* Input with optional icons */}
        <div className="relative">
          {leftIcon && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-recipes-purple-dark/50">
              {leftIcon}
            </div>
          )}
          
          <input
            ref={ref}
            className={cn(
              inputVariants({ variant, size, state: inputState }),
              leftIcon && "pl-10",
              rightIcon && "pr-10",
              className
            )}
            {...props}
          />
          
          {rightIcon && (
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-recipes-purple-dark/50">
              {rightIcon}
            </div>
          )}
        </div>
        
        {/* Helper text or error message */}
        {(helperText || error) && (
          <p 
            className={cn(
              "text-xs",
              error ? "text-red-500" : "text-recipes-purple-dark/70"
            )}
          >
            {error || helperText}
          </p>
        )}
      </div>
    );
  }
);

RecipesInput.displayName = "RecipesInput";

// For backward compatibility
const RoyalInput = React.forwardRef<HTMLInputElement, RecipesInputProps>(
  (props, ref) => {
    return <RecipesInput ref={ref} {...props} />;
  }
);

RoyalInput.displayName = "RoyalInput";

export { RecipesInput, RoyalInput };
export type { RecipesInputProps as RoyalInputProps };