import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Button, ButtonProps } from "./button";
import { useAnimation } from "@/lib/animation-context";

interface RecipesButtonProps extends ButtonProps {
  shimmer?: boolean;
  glow?: boolean;
  crown?: boolean;
  sparkle?: boolean;
  className?: string;
  leftIcon?: React.ReactNode;
}

export function RecipesButton({
  shimmer = false,
  glow = false,
  crown = false,
  sparkle = false,
  className = "",
  children,
  disabled,
  leftIcon,
  ...props
}: RecipesButtonProps) {
  const { animationsEnabled, prefersReducedMotion } = useAnimation();
  
  // Check if animations should be shown
  const showAnimations = animationsEnabled && !prefersReducedMotion && !disabled;

  // Shimmer effect animation
  const shimmerVariants = {
    initial: {
      backgroundPosition: "200% 0",
    },
    animate: {
      backgroundPosition: showAnimations ? ["-200% 0", "200% 0"] : "0% 0",
      transition: {
        repeat: Infinity,
        duration: 3,
      },
    },
  };

  // Glow effect animation
  const glowVariants = {
    initial: {
      boxShadow: "0 0 0 rgba(218, 165, 32, 0)",
    },
    animate: {
      boxShadow: showAnimations 
        ? ["0 0 5px rgba(218, 165, 32, 0.4), 0 0 20px rgba(218, 165, 32, 0.2)", 
           "0 0 10px rgba(218, 165, 32, 0.6), 0 0 30px rgba(218, 165, 32, 0.4)",
           "0 0 5px rgba(218, 165, 32, 0.4), 0 0 20px rgba(218, 165, 32, 0.2)"]
        : "0 0 0 rgba(218, 165, 32, 0)",
      transition: {
        repeat: Infinity,
        duration: 2,
      },
    },
  };

  // Combine all classNames
  const buttonClassName = cn(
    // Basic button styling
    "relative overflow-hidden",
    // Shimmer effect
    shimmer && showAnimations && "bg-gradient-to-r from-transparent via-recipes-gold/30 to-transparent bg-[length:200%_100%]",
    // Add other classes
    className
  );

  return (
    <motion.div
      className="inline-block"
      initial="initial"
      animate="animate"
      variants={glow && showAnimations ? glowVariants : {}}
    >
      <Button 
        className={buttonClassName}
        disabled={disabled}
        {...props}
        asChild={false}
      >
        {/* Button content */}
        <motion.span 
          className="relative z-10 flex items-center justify-center"
          variants={shimmer && showAnimations ? shimmerVariants : {}}
        >
          {leftIcon && <span className="mr-2">{leftIcon}</span>}
          {children}
        </motion.span>
      </Button>
    </motion.div>
  );
}

interface RecipesPrimaryButtonProps extends RecipesButtonProps {}

export function RecipesPrimaryButton({
  className = "",
  shimmer = true,
  glow = true,
  ...props
}: RecipesPrimaryButtonProps) {
  return (
    <RecipesButton
      className={cn(
        "bg-recipes-purple hover:bg-recipes-purple-dark text-white",
        className
      )}
      shimmer={shimmer}
      glow={glow}
      {...props}
    />
  );
}

interface RecipesSecondaryButtonProps extends RecipesButtonProps {}

export function RecipesSecondaryButton({
  className = "",
  shimmer = true,
  glow = true,
  ...props
}: RecipesSecondaryButtonProps) {
  return (
    <RecipesButton
      className={cn(
        "bg-recipes-gold hover:bg-recipes-gold-dark text-recipes-purple-dark font-semibold",
        className
      )}
      shimmer={shimmer}
      glow={glow}
      {...props}
    />
  );
}

interface RecipesOutlineButtonProps extends RecipesButtonProps {}

export function RecipesOutlineButton({
  className = "",
  shimmer = false,
  glow = true,
  ...props
}: RecipesOutlineButtonProps) {
  return (
    <RecipesButton
      className={cn(
        "border border-recipes-purple text-recipes-purple hover:bg-recipes-purple/10 bg-transparent",
        className
      )}
      shimmer={shimmer}
      glow={glow}
      variant="outline"
      {...props}
    />
  );
}

// For backward compatibility
export const RoyalButton = RecipesButton;
export const RoyalPrimaryButton = RecipesPrimaryButton;
export const RoyalSecondaryButton = RecipesSecondaryButton;
export const RoyalOutlineButton = RecipesOutlineButton;

export type { RecipesButtonProps, RecipesPrimaryButtonProps, RecipesSecondaryButtonProps, RecipesOutlineButtonProps };
export type { RecipesButtonProps as RoyalButtonProps };