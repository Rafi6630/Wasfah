import * as React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "./card";
import { CutleryDivider } from "@/components/icons/crown-icon";
import { useAnimation } from "@/lib/animation-context";

interface RecipesCardProps extends React.HTMLAttributes<HTMLDivElement> {
  premium?: boolean;
  shimmer?: boolean;
  glow?: boolean;
  hover?: boolean;
  className?: string;
  children: React.ReactNode;
}

export function RecipesCard({
  premium = false,
  shimmer = false,
  glow = false,
  hover = true,
  className = "",
  children,
  ...props
}: RecipesCardProps) {
  const { animationsEnabled, prefersReducedMotion } = useAnimation();
  
  // Check if animations should be shown
  const showAnimations = animationsEnabled && !prefersReducedMotion;

  // Shimmer effect animation
  const shimmerVariants = {
    initial: {
      backgroundPosition: "200% 0",
    },
    animate: {
      backgroundPosition: showAnimations ? ["-200% 0", "200% 0"] : "0% 0",
      transition: {
        repeat: Infinity,
        duration: 3,
      },
    },
  };

  // Glow effect animation
  const glowVariants = {
    initial: {
      boxShadow: "0 0 0 rgba(218, 165, 32, 0)",
    },
    animate: {
      boxShadow: showAnimations 
        ? ["0 0 5px rgba(218, 165, 32, 0.2), 0 0 20px rgba(218, 165, 32, 0.1)", 
           "0 0 8px rgba(218, 165, 32, 0.3), 0 0 25px rgba(218, 165, 32, 0.15)",
           "0 0 5px rgba(218, 165, 32, 0.2), 0 0 20px rgba(218, 165, 32, 0.1)"]
        : "0 0 0 rgba(218, 165, 32, 0)",
      transition: {
        repeat: Infinity,
        duration: 2.5,
      },
    },
  };

  // Hover animation
  const hoverVariants = {
    initial: {
      y: 0,
      scale: 1,
    },
    hover: {
      y: -5,
      scale: 1.02,
      transition: { duration: 0.3 },
    },
  };

  if (premium) {
    return (
      <motion.div
        className={cn(
          "bg-gradient-to-r from-recipes-purple-dark to-recipes-purple p-0.5 rounded-lg",
          glow && showAnimations && "animate-glow",
          className
        )}
        initial="initial"
        animate="animate"
        whileHover={hover && showAnimations ? "hover" : undefined}
        variants={hover && showAnimations ? hoverVariants : {}}
        {...props}
      >
        <motion.div
          className="bg-white dark:bg-gray-900 rounded-[calc(theme(borderRadius.lg)-2px)] h-full"
          variants={shimmer && showAnimations ? shimmerVariants : {}}
        >
          {children}
        </motion.div>
      </motion.div>
    );
  }

  return (
    <motion.div
      className={cn(
        "bg-white dark:bg-gray-900 rounded-lg border border-recipes-gold-dark/30 shadow-md overflow-hidden",
        className
      )}
      initial="initial"
      animate="animate"
      whileHover={hover && showAnimations ? "hover" : undefined}
      variants={
        showAnimations
          ? {
              ...(hover ? hoverVariants : {}),
              ...(glow ? glowVariants : {}),
            }
          : {}
      }
      {...props}
    >
      <motion.div
        className={cn(
          "h-full w-full",
          shimmer && showAnimations && "bg-gradient-to-r from-transparent via-recipes-gold/20 to-transparent bg-[length:200%_100%]"
        )}
        variants={shimmer && showAnimations ? shimmerVariants : {}}
      >
        {children}
      </motion.div>
    </motion.div>
  );
}

// Re-export shadcn Card components
export const RecipesCardHeader = CardHeader;
export const RecipesCardFooter = CardFooter;
export const RecipesCardContent = CardContent;
export const RecipesCardDescription = CardDescription;

// Custom RecipesCardTitle with underline animation
export function RecipesCardTitle({
  className = "",
  children,
  ...props
}: React.HTMLAttributes<HTMLHeadingElement>) {
  const { animationsEnabled, prefersReducedMotion } = useAnimation();
  
  // Check if animations should be shown
  const showAnimations = animationsEnabled && !prefersReducedMotion;

  return (
    <div className="space-y-1">
      <CardTitle className={cn("text-recipes-purple", className)} {...props}>
        {children}
      </CardTitle>
      {showAnimations ? (
        <CutleryDivider className="w-24 h-3 text-recipes-gold" />
      ) : (
        <div className="border-b border-recipes-gold/40 w-24 mt-1 mb-2" />
      )}
    </div>
  );
}

// Section Header Component
export function RecipesSectionHeader({
  className = "",
  children,
  ...props
}: React.HTMLAttributes<HTMLHeadingElement>) {
  const { animationsEnabled, prefersReducedMotion } = useAnimation();
  
  // Check if animations should be shown
  const showAnimations = animationsEnabled && !prefersReducedMotion;
  
  return (
    <div className="flex flex-col items-center my-4 text-center">
      <h2 
        className={cn("text-xl md:text-2xl font-bold text-recipes-purple", className)} 
        {...props}
      >
        {children}
      </h2>
      {showAnimations ? (
        <CutleryDivider className="w-32 h-4 text-recipes-gold mt-1" />
      ) : (
        <div className="border-b-2 border-recipes-gold/60 w-32 mt-1" />
      )}
    </div>
  );
}

// For backward compatibility
export const RoyalCard = RecipesCard;
export const RoyalCardHeader = RecipesCardHeader;
export const RoyalCardFooter = RecipesCardFooter;
export const RoyalCardContent = RecipesCardContent;
export const RoyalCardDescription = RecipesCardDescription;
export const RoyalCardTitle = RecipesCardTitle;
export const RoyalSectionHeader = RecipesSectionHeader;

export type { RecipesCardProps };
export type { RecipesCardProps as RoyalCardProps };