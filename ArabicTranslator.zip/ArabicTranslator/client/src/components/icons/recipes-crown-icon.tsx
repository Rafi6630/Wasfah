import React from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useAnimation } from "@/lib/animation-context";

interface CrownIconProps extends React.SVGProps<SVGSVGElement> {
  className?: string;
  animated?: boolean;
}

export function RecipesCrownIcon({ 
  className = "",
  animated = true,
  ...props 
}: CrownIconProps) {
  const { animationsEnabled, prefersReducedMotion, getDurationFactor } = useAnimation();
  
  // Adjust animation speed based on settings
  const speedFactor = getDurationFactor();
  
  // Don't animate if animations are disabled
  const showAnimation = animated && animationsEnabled && !prefersReducedMotion;
  
  // Crown float animation
  const crownFloatVariants = {
    initial: {
      rotate: 0,
    },
    animate: {
      rotate: showAnimation ? [-2, 2, -2] : 0,
      y: showAnimation ? [0, -3, 0] : 0,
      transition: {
        rotate: {
          repeat: Infinity,
          duration: 3 / speedFactor,
          ease: "easeInOut",
        },
        y: {
          repeat: Infinity,
          duration: 2.5 / speedFactor,
          ease: "easeInOut",
        },
      },
    },
  };
  
  // Shimmer effect on the jewels
  const jewelShimmerVariants = {
    initial: {
      opacity: 0.7,
    },
    animate: {
      opacity: showAnimation ? [0.7, 1, 0.7] : 0.8,
      transition: {
        repeat: Infinity,
        duration: 2 / speedFactor,
        ease: "easeInOut",
      },
    },
  };

  const Component = showAnimation ? motion.svg : "svg";
  const JewelComponent = showAnimation ? motion.circle : "circle";

  return (
    <Component
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={cn("text-recipes-gold w-6 h-6", className)}
      initial="initial"
      animate="animate"
      variants={crownFloatVariants}
      {...props}
    >
      {/* Crown base */}
      <path
        d="M3 17h18v2c0 .6-.4 1-1 1H4c-.6 0-1-.4-1-1v-2Z"
        fill="currentColor"
        fillOpacity={0.2}
      />
      <path
        d="M3 8v9h18V8l-4 4-5-5-5 5-4-4Z"
        fill="currentColor"
        fillOpacity={0.1}
      />
      <path d="M3 8v9h18V8l-4 4-5-5-5 5-4-4Z" />
      
      {/* Jewels */}
      <JewelComponent
        cx="12"
        cy="6"
        r="1"
        fill="#C5A942"
        stroke="none"
        variants={jewelShimmerVariants}
      />
      <JewelComponent
        cx="19"
        cy="8"
        r="1"
        fill="#C5A942"
        stroke="none"
        variants={jewelShimmerVariants}
      />
      <JewelComponent
        cx="5"
        cy="8"
        r="1"
        fill="#C5A942"
        stroke="none"
        variants={jewelShimmerVariants}
      />
    </Component>
  );
}

export function CutleryDivider({ className = "", ...props }: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 120 12"
      fill="none"
      className={cn("w-24 h-3", className)}
      {...props}
    >
      {/* Left decorative swirl */}
      <path
        d="M0 6h25"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M35 6h-5c-1.5 0-2.5-1-2.5-2.5S30 1 32 1"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      
      {/* Fork icon */}
      <path
        d="M40 1v10M44 1v10M48 1v5M44 6h4"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      
      {/* Center dot */}
      <circle
        cx="60"
        cy="6"
        r="2"
        fill="currentColor"
      />
      
      {/* Knife icon */}
      <path
        d="M80 1l-8 10h8V1z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      
      {/* Right decorative swirl */}
      <path
        d="M95 6h25"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
      <path
        d="M85 6h5c1.5 0 2.5-1 2.5-2.5S91.5 1 89.5 1"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
      />
    </svg>
  );
}

// For backward compatibility
export const RoyalCrownIcon = RecipesCrownIcon;
export type { CrownIconProps };