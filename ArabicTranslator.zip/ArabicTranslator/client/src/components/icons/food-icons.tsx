import { cn } from "@/lib/utils";

interface FoodIconsProps {
  category: string;
  isActive?: boolean;
}

export function FoodIcons({ category, isActive = false }: FoodIconsProps) {
  // Function to get the appropriate icon and color based on category
  const getCategoryStyles = () => {
    switch (category) {
      case 'meat':
        return {
          icon: "fas fa-drumstick-bite",
          bgColor: isActive ? "bg-secondary bg-opacity-10" : "bg-gray-200",
          textColor: isActive ? "text-secondary" : "text-gray-500"
        };
      case 'dessert':
        return {
          icon: "fas fa-cake-candles",
          bgColor: isActive ? "bg-accent bg-opacity-10" : "bg-gray-200",
          textColor: isActive ? "text-accent" : "text-gray-500"
        };
      case 'drinks':
        return {
          icon: "fas fa-martini-glass",
          bgColor: isActive ? "bg-blue-500 bg-opacity-10" : "bg-gray-200",
          textColor: isActive ? "text-blue-500" : "text-gray-500"
        };
      case 'vegan':
        return {
          icon: "fas fa-seedling",
          bgColor: isActive ? "bg-green-600 bg-opacity-10" : "bg-gray-200",
          textColor: isActive ? "text-green-600" : "text-gray-500"
        };
      default:
        return {
          icon: "fas fa-utensils",
          bgColor: isActive ? "bg-primary bg-opacity-10" : "bg-gray-200",
          textColor: isActive ? "text-primary" : "text-gray-500"
        };
    }
  };
  
  const { icon, bgColor, textColor } = getCategoryStyles();
  
  return (
    <div className={cn(
      "w-14 h-14 rounded-full flex items-center justify-center",
      bgColor
    )}>
      <i className={cn(icon, "text-xl", textColor)}></i>
    </div>
  );
}
