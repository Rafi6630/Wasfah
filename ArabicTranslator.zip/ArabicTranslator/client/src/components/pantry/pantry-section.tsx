import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Plus } from "lucide-react";
import { IngredientChip } from "./ingredient-chip";

// Common pantry items for demonstration
const COMMON_PANTRY_ITEMS = [
  "Olive oil",
  "Salt",
  "Black pepper",
  "Garlic",
  "Onions",
  "Rice",
  "Pasta",
  "Flour",
  "Sugar",
  "Eggs",
  "Milk",
  "Butter",
  "Chicken broth",
  "Tomatoes",
  "Lemon",
  "Potatoes",
  "Carrots",
  "Cinnamon",
  "Cumin",
  "Paprika",
  "Turmeric",
  "Ginger",
  "Honey",
  "Soy sauce",
];

interface PantrySectionProps {
  onIngredientSelect?: (ingredient: string) => void;
}

export function PantrySection({ onIngredientSelect }: PantrySectionProps) {
  const { t, isRtl } = useI18n();
  const [searchTerm, setSearchTerm] = React.useState("");
  const [myPantryItems, setMyPantryItems] = React.useState<string[]>([]);
  const [commonPantryItems] = React.useState<string[]>(COMMON_PANTRY_ITEMS);

  // Filter pantry items based on search term
  const filteredCommonItems = commonPantryItems.filter(item => 
    searchTerm ? item.toLowerCase().includes(searchTerm.toLowerCase()) : true
  );
  
  const filteredMyItems = myPantryItems.filter(item => 
    searchTerm ? item.toLowerCase().includes(searchTerm.toLowerCase()) : true
  );

  React.useEffect(() => {
    // In a real app, this would fetch the user's saved pantry items from the database
    const loadPantryItems = async () => {
      try {
        // Mock loading from local storage for demo
        const savedItems = localStorage.getItem("myPantryItems");
        if (savedItems) {
          setMyPantryItems(JSON.parse(savedItems));
        }
      } catch (error) {
        console.error("Failed to load pantry items:", error);
      }
    };
    
    loadPantryItems();
  }, []);

  const handleIngredientClick = (ingredient: string) => {
    if (onIngredientSelect) {
      onIngredientSelect(ingredient);
    }
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        <Input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={t("searchPantryItems")}
          className="pl-10"
        />
      </div>

      {/* My Pantry Items */}
      <div className="space-y-2">
        <h3 className="text-sm font-medium">{t("myPantryItems")}</h3>
        <div className="flex flex-wrap gap-2">
          {filteredMyItems.length > 0 ? (
            filteredMyItems.map((item, index) => (
              <Button
                key={`my-${index}`}
                variant="outline"
                className="rounded-full"
                onClick={() => handleIngredientClick(item)}
              >
                {item}
                <Plus className="ml-1 h-3 w-3" />
              </Button>
            ))
          ) : (
            <p className="text-gray-500 text-sm">{t("noPantryItems")}</p>
          )}
        </div>
      </div>

      {/* Common Pantry Items */}
      <div className="space-y-2">
        <h3 className="text-sm font-medium">{t("commonPantryItems")}</h3>
        <div className="flex flex-wrap gap-2">
          {filteredCommonItems.map((item, index) => (
            <Button
              key={`common-${index}`}
              variant="outline"
              className="rounded-full"
              onClick={() => handleIngredientClick(item)}
            >
              {item}
              <Plus className="ml-1 h-3 w-3" />
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}