import * as React from "react";
import { X } from "lucide-react";
import { useI18n } from "@/lib/i18n";

interface IngredientChipProps {
  name: string;
  nameAr?: string;
  onRemove?: () => void;
}

export function IngredientChip({ name, nameAr, onRemove }: IngredientChipProps) {
  const { isRtl } = useI18n();
  const displayName = isRtl && nameAr ? nameAr : name;

  return (
    <div className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">
      <span>{displayName}</span>
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="rounded-full p-1 hover:bg-primary/20 transition-colors"
        >
          <X className="h-3 w-3" />
        </button>
      )}
    </div>
  );
}