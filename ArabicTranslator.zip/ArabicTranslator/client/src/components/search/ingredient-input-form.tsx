import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { PantrySection } from "@/components/pantry/pantry-section";
import { Mic, Camera, Upload, Plus, X, Search } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { IngredientChip } from "../pantry/ingredient-chip";

interface IngredientItem {
  name: string;
  [key: string]: any;
}

interface IngredientInputFormProps {
  onSubmit: (ingredients: string[]) => void;
  onSave?: (ingredients: string[]) => void;
  initialIngredients?: string[] | IngredientItem[];
}

export function IngredientInputForm({
  onSubmit,
  onSave,
  initialIngredients = [],
}: IngredientInputFormProps) {
  const { t, isRtl } = useI18n();
  const [activeTab, setActiveTab] = React.useState("manual");
  const [ingredients, setIngredients] = React.useState<string[]>(() => {
    // Handle both string[] and object[] with name property
    if (initialIngredients && initialIngredients.length > 0) {
      if (typeof initialIngredients[0] === 'string') {
        return initialIngredients as string[];
      } else if (typeof initialIngredients[0] === 'object') {
        // Safely access the name property with type checking
        return (initialIngredients as IngredientItem[])
          .filter(item => item && typeof item === 'object' && 'name' in item)
          .map(item => item.name);
      }
    }
    return [];
  });
  const [inputValue, setInputValue] = React.useState("");
  const [quantity, setQuantity] = React.useState("");
  const [unit, setUnit] = React.useState("");
  const [isRecording, setIsRecording] = React.useState(false);
  const [isCapturing, setIsCapturing] = React.useState(false);
  
  const handleAddIngredient = () => {
    if (inputValue.trim()) {
      const newIngredient = quantity && unit
        ? `${inputValue} (${quantity} ${unit})`
        : inputValue;
      
      if (!ingredients.includes(newIngredient)) {
        setIngredients([...ingredients, newIngredient]);
      }
      
      // Reset form
      setInputValue("");
      setQuantity("");
      setUnit("");
    }
  };
  
  const handleRemoveIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAddIngredient();
    }
  };
  
  const handlePantryIngredientSelect = (ingredient: string) => {
    if (!ingredients.includes(ingredient)) {
      setIngredients([...ingredients, ingredient]);
    }
  };
  
  const handleSubmit = () => {
    onSubmit(ingredients);
  };
  
  const handleSave = () => {
    if (onSave) onSave(ingredients);
  };
  
  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // In a real app, this would handle voice recording logic
    if (isRecording) {
      // Stop recording and process
      setIsRecording(false);
      // Simulate processing voice to text after 2 seconds
      setTimeout(() => {
        setInputValue(inputValue + (inputValue ? ", " : "") + "tomatoes");
      }, 2000);
    } else {
      // Start recording
      setIsRecording(true);
    }
  };
  
  const toggleCapture = () => {
    setIsCapturing(!isCapturing);
    // In a real app, this would handle camera capture logic
    if (isCapturing) {
      setIsCapturing(false);
      // Simulate processing image after 2 seconds
      setTimeout(() => {
        setInputValue(inputValue + (inputValue ? ", " : "") + "onions, garlic");
      }, 2000);
    } else {
      setIsCapturing(true);
    }
  };
  
  const handleUpload = () => {
    // In a real app, this would handle file upload logic
    // Simulate processing upload after 1 second
    setTimeout(() => {
      setInputValue(inputValue + (inputValue ? ", " : "") + "chicken, rice, vegetables");
    }, 1000);
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{t("ingredientSearch")}</CardTitle>
        <CardDescription>{t("ingredientSearchDescription")}</CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="manual" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="manual">{t("manualEntry")}</TabsTrigger>
            <TabsTrigger value="pantry">{t("myPantry")}</TabsTrigger>
          </TabsList>
          
          <TabsContent value="manual" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex-1">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder={t("ingredientInputPlaceholder")}
                  />
                </div>
                
                <Button 
                  type="button" 
                  size="icon" 
                  variant="outline"
                  className={isRecording ? "bg-red-100" : ""}
                  onClick={toggleRecording}
                >
                  <Mic className={isRecording ? "text-red-500" : ""} />
                </Button>
                
                <Button 
                  type="button" 
                  size="icon" 
                  variant="outline"
                  className={isCapturing ? "bg-blue-100" : ""}
                  onClick={toggleCapture}
                >
                  <Camera className={isCapturing ? "text-blue-500" : ""} />
                </Button>
                
                <Button 
                  type="button" 
                  size="icon" 
                  variant="outline"
                  onClick={handleUpload}
                >
                  <Upload />
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                <div className="w-1/3">
                  <Input
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    placeholder={t("quantity")}
                    type="number"
                    min="0"
                    step="0.1"
                  />
                </div>
                
                <div className="w-2/3">
                  <Select value={unit} onValueChange={setUnit}>
                    <SelectTrigger>
                      <SelectValue placeholder={t("unit")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="g">{t("grams")}</SelectItem>
                      <SelectItem value="kg">{t("kilograms")}</SelectItem>
                      <SelectItem value="ml">{t("milliliters")}</SelectItem>
                      <SelectItem value="l">{t("liters")}</SelectItem>
                      <SelectItem value="cup">{t("cups")}</SelectItem>
                      <SelectItem value="tbsp">{t("tablespoons")}</SelectItem>
                      <SelectItem value="tsp">{t("teaspoons")}</SelectItem>
                      <SelectItem value="pcs">{t("pieces")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleAddIngredient}
                  className="mt-2 w-full"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  {t("addIngredient")}
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="pantry">
            <PantrySection onIngredientSelect={handlePantryIngredientSelect} />
          </TabsContent>
          
          {/* Ingredient List - visible in both tabs */}
          <div className="mt-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium">{t("yourIngredients")}</h3>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setIngredients([])}
                disabled={ingredients.length === 0}
              >
                {t("clearAll")}
              </Button>
            </div>
            
            <div className="flex flex-wrap gap-2 min-h-20 p-2 border rounded-md bg-gray-50">
              {ingredients.length === 0 ? (
                <p className="text-gray-500 text-sm p-2">{t("noIngredientsAdded")}</p>
              ) : (
                ingredients.map((ingredient, index) => (
                  <IngredientChip
                    key={index}
                    name={ingredient || ''}
                    onRemove={() => handleRemoveIngredient(index)}
                  />
                ))
              )}
            </div>
          </div>
        </Tabs>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        {onSave && (
          <Button variant="outline" onClick={handleSave}>
            {t("saveToMyPantry")}
          </Button>
        )}
        <Button 
          onClick={handleSubmit}
          disabled={ingredients.length === 0}
          className={`${onSave ? '' : 'w-full'}`}
        >
          <Search className="mr-2 h-4 w-4" />
          {t("findRecipes")}
        </Button>
      </CardFooter>
    </Card>
  );
}