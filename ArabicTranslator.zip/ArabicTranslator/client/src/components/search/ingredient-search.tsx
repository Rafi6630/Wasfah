import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { IngredientChip } from "@/components/pantry/ingredient-chip";
import { Search, Mic, Camera, Plus, X } from "lucide-react";

// Sample suggested ingredients - in a real app this would come from an API based on popular searches and user history
const suggestedIngredients = [
  "Tomatoes",
  "Chicken",
  "Rice",
  "Lentils",
  "Pasta",
  "Bread",
  "Onions",
  "Garlic",
  "Potatoes",
  "Eggs",
  "Cheese",
  "Yogurt"
];

interface IngredientSearchProps {
  onSearch: (ingredients: string[]) => void;
}

export function IngredientSearch({ onSearch }: IngredientSearchProps) {
  const { t, isRtl } = useI18n();
  const { user } = useAuth();
  
  const [ingredientInput, setIngredientInput] = React.useState("");
  const [selectedIngredients, setSelectedIngredients] = React.useState<string[]>(
    user?.pantry_ingredients || []
  );
  const [isRecording, setIsRecording] = React.useState(false);
  
  // Add ingredient
  const addIngredient = (ingredient: string) => {
    if (ingredient && !selectedIngredients.includes(ingredient)) {
      setSelectedIngredients([...selectedIngredients, ingredient]);
    }
    setIngredientInput("");
  };
  
  // Remove ingredient
  const removeIngredient = (ingredient: string) => {
    setSelectedIngredients(selectedIngredients.filter(i => i !== ingredient));
  };
  
  const handleVoiceInput = () => {
    // Mock voice recognition for now
    setIsRecording(true);
    setTimeout(() => {
      setIsRecording(false);
      // Simulate voice recognition result
      setSelectedIngredients([...selectedIngredients, "Tomatoes", "Onions", "Olive Oil"]);
    }, 2000);
  };

  const handleCameraInput = () => {
    // Mock camera input for now
    // In a real app, this would open the camera for ingredient detection
    alert("Camera functionality would be implemented here");
  };
  
  const handleSearch = () => {
    onSearch(selectedIngredients);
  };
  
  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Input
            placeholder={t("addIngredient")}
            value={ingredientInput}
            onChange={(e) => setIngredientInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && ingredientInput.trim()) {
                addIngredient(ingredientInput.trim());
              }
            }}
            className="pr-10"
          />
          {ingredientInput && (
            <button
              className="absolute top-1/2 transform -translate-y-1/2 right-2 text-gray-400 hover:text-gray-600"
              onClick={() => setIngredientInput("")}
            >
              <X size={16} />
            </button>
          )}
        </div>
        <Button
          size="icon"
          onClick={() => addIngredient(ingredientInput)}
          disabled={!ingredientInput.trim()}
        >
          <Plus size={18} />
        </Button>
        <Button
          size="icon"
          variant="outline"
          onClick={handleVoiceInput}
          className={isRecording ? "animate-pulse bg-red-100" : ""}
        >
          <Mic size={18} />
        </Button>
        <Button size="icon" variant="outline" onClick={handleCameraInput}>
          <Camera size={18} />
        </Button>
      </div>
      
      <div>
        <h3 className="font-medium mb-2">{t("selectedIngredients")}</h3>
        <div className="flex flex-wrap gap-2 min-h-[40px]">
          {selectedIngredients.length === 0 ? (
            <p className="text-sm text-gray-500">{t("noIngredientsSelected")}</p>
          ) : (
            selectedIngredients.map((ingredient) => (
              <IngredientChip
                key={ingredient}
                name={ingredient}
                onRemove={() => removeIngredient(ingredient)}
              />
            ))
          )}
        </div>
      </div>
      
      <div className="border-t border-gray-200 pt-4">
        <h3 className="font-medium mb-2">{t("suggestedIngredients")}</h3>
        <div className="flex flex-wrap gap-2">
          {suggestedIngredients.map(ingredient => (
            <Button
              key={ingredient}
              variant="outline"
              size="sm"
              className="rounded-full bg-gray-50 hover:bg-gray-100"
              onClick={() => addIngredient(ingredient)}
              disabled={selectedIngredients.includes(ingredient)}
            >
              {ingredient}
            </Button>
          ))}
        </div>
      </div>
      
      <div className="border-t border-gray-200 pt-4">
        <Button 
          className="w-full" 
          onClick={handleSearch}
          disabled={selectedIngredients.length === 0}
        >
          <Search className="mr-2 h-4 w-4" />
          {t("searchWithIngredients")}
        </Button>
      </div>
    </div>
  );
}