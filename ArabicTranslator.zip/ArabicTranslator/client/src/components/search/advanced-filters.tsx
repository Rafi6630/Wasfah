import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Check, ChevronDown, Filter } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// Define options
const dietaryOptions = [
  { value: "normal", label: "Normal", labelAr: "عادي", icon: "🍽️" },
  { value: "vegetarian", label: "Vegetarian", labelAr: "نباتي", icon: "🥗" },
  { value: "vegan", label: "Vegan", labelAr: "نباتي صرف", icon: "🌱" },
  { value: "pescatarian", label: "Pescatarian", labelAr: "سمكي نباتي", icon: "🐟" },
  { value: "keto", label: "Keto", labelAr: "كيتو", icon: "🥑" },
  { value: "lowCarb", label: "Low Carb", labelAr: "قليل الكربوهيدرات", icon: "🥦" },
  { value: "paleo", label: "Paleo", labelAr: "حمية بدائية", icon: "🍖" },
  { value: "mediterranean", label: "Mediterranean", labelAr: "متوسطي", icon: "🫒" },
];

const cookingTimeOptions = [
  { value: "under15", label: "Under 15 min", labelAr: "أقل من 15 دقيقة", icon: "⚡" },
  { value: "under30", label: "Under 30 min", labelAr: "أقل من 30 دقيقة", icon: "🕧" },
  { value: "under60", label: "Under 1 hour", labelAr: "أقل من ساعة", icon: "🕐" },
  { value: "over60", label: "Over 1 hour", labelAr: "أكثر من ساعة", icon: "🕒" },
];

const difficultyOptions = [
  { value: "easy", label: "Easy", labelAr: "سهل", icon: "😊" },
  { value: "medium", label: "Medium", labelAr: "متوسط", icon: "😐" },
  { value: "hard", label: "Hard", labelAr: "صعب", icon: "😅" },
];

const cuisineOptions = [
  { value: "middleEastern", label: "Middle Eastern", labelAr: "شرق أوسطي", icon: "🇱🇧" },
  { value: "italian", label: "Italian", labelAr: "إيطالي", icon: "🇮🇹" },
  { value: "chinese", label: "Chinese", labelAr: "صيني", icon: "🇨🇳" },
  { value: "mexican", label: "Mexican", labelAr: "مكسيكي", icon: "🇲🇽" },
  { value: "indian", label: "Indian", labelAr: "هندي", icon: "🇮🇳" },
  { value: "japanese", label: "Japanese", labelAr: "ياباني", icon: "🇯🇵" },
  { value: "french", label: "French", labelAr: "فرنسي", icon: "🇫🇷" },
  { value: "american", label: "American", labelAr: "أمريكي", icon: "🇺🇸" },
  { value: "thai", label: "Thai", labelAr: "تايلندي", icon: "🇹🇭" },
  { value: "spanish", label: "Spanish", labelAr: "إسباني", icon: "🇪🇸" },
  { value: "greek", label: "Greek", labelAr: "يوناني", icon: "🇬🇷" },
  { value: "moroccan", label: "Moroccan", labelAr: "مغربي", icon: "🇲🇦" },
  { value: "turkish", label: "Turkish", labelAr: "تركي", icon: "🇹🇷" },
];

const mealTypeOptions = [
  { value: "breakfast", label: "Breakfast", labelAr: "إفطار", icon: "☕" },
  { value: "lunch", label: "Lunch", labelAr: "غداء", icon: "🍲" },
  { value: "dinner", label: "Dinner", labelAr: "عشاء", icon: "🍽️" },
  { value: "snack", label: "Snack", labelAr: "وجبة خفيفة", icon: "🥨" },
  { value: "dessert", label: "Dessert", labelAr: "حلوى", icon: "🍰" },
  { value: "drink", label: "Drink", labelAr: "مشروب", icon: "🥤" },
];

const allergenOptions = [
  { value: "nutFree", label: "Nut-free", labelAr: "خالي من المكسرات", icon: "🥜" },
  { value: "glutenFree", label: "Gluten-free", labelAr: "خالي من الغلوتين", icon: "🌾" },
  { value: "dairyFree", label: "Dairy-free", labelAr: "خالي من منتجات الألبان", icon: "🥛" },
  { value: "eggFree", label: "Egg-free", labelAr: "خالي من البيض", icon: "🥚" },
  { value: "shellfishFree", label: "Shellfish-free", labelAr: "خالي من المحار", icon: "🦐" },
  { value: "soyFree", label: "Soy-free", labelAr: "خالي من الصويا", icon: "🫘" },
];

const religiousOptions = [
  { value: "halal", label: "Halal", labelAr: "حلال", icon: "☪️" },
  { value: "kosher", label: "Kosher", labelAr: "كوشر", icon: "✡️" },
  { value: "hindu", label: "Hindu", labelAr: "هندوسي", icon: "🕉️" },
];

const healthGoalOptions = [
  { value: "weightLoss", label: "Weight Loss", labelAr: "فقدان الوزن", icon: "⚖️" },
  { value: "muscleGain", label: "Muscle Gain", labelAr: "زيادة العضلات", icon: "💪" },
  { value: "heartHealthy", label: "Heart Healthy", labelAr: "صحة القلب", icon: "❤️" },
  { value: "lowSodium", label: "Low Sodium", labelAr: "قليل الصوديوم", icon: "🧂" },
  { value: "diabeticFriendly", label: "Diabetic Friendly", labelAr: "مناسب لمرضى السكري", icon: "🩸" },
  { value: "highProtein", label: "High Protein", labelAr: "غني بالبروتين", icon: "🥩" },
];

interface AdvancedFiltersProps {
  onApplyFilters: (filters: any) => void;
}

export function AdvancedFilters({ onApplyFilters }: AdvancedFiltersProps) {
  const { t, isRtl } = useI18n();
  const [filters, setFilters] = React.useState({
    dietary: "",
    cookingTime: "",
    difficulty: "",
    cuisine: "",
    mealType: "",
    allergenFree: [] as string[],
    religiousDietary: [] as string[],
    healthGoals: [] as string[],
  });
  
  const [isExpanded, setIsExpanded] = React.useState(false);

  // Toggle an array filter (for multi-select options)
  const toggleArrayFilter = (
    type: "allergenFree" | "religiousDietary" | "healthGoals",
    value: string
  ) => {
    setFilters((prev) => {
      const current = prev[type];
      return {
        ...prev,
        [type]: current.includes(value)
          ? current.filter((item) => item !== value)
          : [...current, value],
      };
    });
  };

  // Set a single value filter
  const setFilter = (
    key: "dietary" | "cookingTime" | "difficulty" | "cuisine" | "mealType",
    value: string
  ) => {
    setFilters((prev) => ({
      ...prev,
      [key]: prev[key] === value ? "" : value,
    }));
  };

  const resetFilters = () => {
    setFilters({
      dietary: "",
      cookingTime: "",
      difficulty: "",
      cuisine: "",
      mealType: "",
      allergenFree: [],
      religiousDietary: [],
      healthGoals: [],
    });
  };

  const applyFilters = () => {
    onApplyFilters(filters);
  };

  return (
    <div className="w-full">
      <Button 
        variant="outline" 
        className="w-full flex items-center justify-between mb-4"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center">
          <Filter className="mr-2 h-4 w-4" />
          <span>{t("advancedFilters")}</span>
        </div>
        <span>{isExpanded ? "▲" : "▼"}</span>
      </Button>
      
      {isExpanded && (
        <Card className="w-full">
          <CardHeader className="pb-2">
            <CardDescription>{t("filterDescription")}</CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="dietary">
                <AccordionTrigger>{t("dietaryPreferences")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {dietaryOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.dietary === option.value ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => setFilter("dietary", option.value)}
                      >
                        {filters.dietary === option.value ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="cookingTime">
                <AccordionTrigger>{t("cookingTime")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {cookingTimeOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.cookingTime === option.value ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => setFilter("cookingTime", option.value)}
                      >
                        {filters.cookingTime === option.value ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="difficulty">
                <AccordionTrigger>{t("difficultyLevel")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {difficultyOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.difficulty === option.value ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => setFilter("difficulty", option.value)}
                      >
                        {filters.difficulty === option.value ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="cuisine">
                <AccordionTrigger>{t("cuisineType")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {cuisineOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.cuisine === option.value ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => setFilter("cuisine", option.value)}
                      >
                        {filters.cuisine === option.value ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="mealType">
                <AccordionTrigger>{t("mealType")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {mealTypeOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.mealType === option.value ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => setFilter("mealType", option.value)}
                      >
                        {filters.mealType === option.value ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="allergenFree">
                <AccordionTrigger>{t("allergenFree")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {allergenOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.allergenFree.includes(option.value) ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => toggleArrayFilter("allergenFree", option.value)}
                      >
                        {filters.allergenFree.includes(option.value) ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="religiousDietary">
                <AccordionTrigger>{t("religiousDietary")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {religiousOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.religiousDietary.includes(option.value) ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => toggleArrayFilter("religiousDietary", option.value)}
                      >
                        {filters.religiousDietary.includes(option.value) ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="healthGoals">
                <AccordionTrigger>{t("healthGoals")}</AccordionTrigger>
                <AccordionContent>
                  <div className="grid grid-cols-2 gap-2">
                    {healthGoalOptions.map((option) => (
                      <Button 
                        key={option.value}
                        type="button"
                        variant={filters.healthGoals.includes(option.value) ? "default" : "outline"}
                        className="justify-start h-auto py-2"
                        onClick={() => toggleArrayFilter("healthGoals", option.value)}
                      >
                        {filters.healthGoals.includes(option.value) ? (
                          <Check className="mr-2 h-4 w-4" />
                        ) : (
                          <span className="mr-2">{option.icon}</span>
                        )}
                        <span>{isRtl ? option.labelAr : option.label}</span>
                      </Button>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>

          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={resetFilters}>
              {t("resetFilters")}
            </Button>
            <Button 
              onClick={() => {
                applyFilters();
                setIsExpanded(false);
              }}
            >
              {t("applyFilters")}
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
}