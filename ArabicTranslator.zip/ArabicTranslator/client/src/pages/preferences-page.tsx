import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { LanguageSwitcher } from "@/components/layout/language-switcher";

// Cuisine preferences
const cuisineTypes = [
  { id: "arabic", name: "arabic", nameAr: "عربي" },
  { id: "italian", name: "italian", nameAr: "إيطالي" },
  { id: "asian", name: "asian", nameAr: "آسيوي" },
  { id: "mexican", name: "mexican", nameAr: "مكسيكي" },
  { id: "indian", name: "indian", nameAr: "هندي" }
];

// Dietary preferences
const dietaryPreferences = [
  { id: "vegetarian", name: "vegetarian", nameAr: "نباتي", icon: "🍃" },
  { id: "vegan", name: "vegan", nameAr: "نباتي صارم", icon: "🌱" },
  { id: "pescatarian", name: "pescatarian", nameAr: "سمكي نباتي", icon: "🐟" },
  { id: "keto", name: "keto", nameAr: "كيتو", icon: "🥑" },
  { id: "paleo", name: "paleo", nameAr: "بايليو", icon: "🍖" },
  { id: "lowCarb", name: "lowCarb", nameAr: "قليل الكربوهيدرات", icon: "📉" },
  { id: "lowFat", name: "lowFat", nameAr: "قليل الدهون", icon: "💧" },
  { id: "highProtein", name: "highProtein", nameAr: "عالي البروتين", icon: "💪" }
];

// Allergens
const allergens = [
  { id: "gluten", name: "gluten", nameAr: "الغلوتين", icon: "🌾" },
  { id: "dairy", name: "dairy", nameAr: "منتجات الألبان", icon: "🥛" },
  { id: "nuts", name: "nuts", nameAr: "المكسرات", icon: "🥜" },
  { id: "peanuts", name: "peanuts", nameAr: "الفول السوداني", icon: "🥜" },
  { id: "shellfish", name: "shellfish", nameAr: "المحار", icon: "🦐" },
  { id: "fish", name: "fish", nameAr: "السمك", icon: "🐟" },
  { id: "eggs", name: "eggs", nameAr: "البيض", icon: "🥚" },
  { id: "soy", name: "soy", nameAr: "الصويا", icon: "🫘" },
  { id: "sesame", name: "sesame", nameAr: "السمسم", icon: "⚪" }
];

export default function PreferencesPage() {
  const { t, isRtl } = useI18n();
  const [_, navigate] = useLocation();
  const { user, updateProfileMutation } = useAuth();
  
  // State for user preferences
  const [dietaryPrefs, setDietaryPrefs] = useState<Record<string, boolean>>({
    vegetarian: false,
    vegan: false,
    pescatarian: false,
    keto: false,
    paleo: false,
    lowCarb: false,
    lowFat: false,
    highProtein: false
  });
  
  // State for allergens
  const [allergies, setAllergies] = useState<Record<string, boolean>>({
    gluten: false,
    dairy: false,
    nuts: false,
    peanuts: false,
    shellfish: false,
    fish: false,
    eggs: false,
    soy: false,
    sesame: false
  });
  
  const [cuisines, setCuisines] = useState<string[]>([]);
  const [skillLevel, setSkillLevel] = useState<string>("beginner");
  
  const handleCuisineToggle = (cuisineId: string) => {
    setCuisines(prev => 
      prev.includes(cuisineId)
        ? prev.filter(c => c !== cuisineId)
        : [...prev, cuisineId]
    );
  };
  
  const handleDietaryToggle = (dietaryId: string) => {
    setDietaryPrefs(prev => ({
      ...prev,
      [dietaryId]: !prev[dietaryId]
    }));
  };
  
  const handleAllergenToggle = (allergenId: string) => {
    setAllergies(prev => ({
      ...prev,
      [allergenId]: !prev[allergenId]
    }));
  };
  
  const handleSavePreferences = () => {
    // Extract selected dietary preferences
    const selectedDietaryPrefs = Object.entries(dietaryPrefs)
      .filter(([_, value]) => value)
      .map(([key, _]) => key);
      
    // Extract selected allergens
    const selectedAllergens = Object.entries(allergies)
      .filter(([_, value]) => value)
      .map(([key, _]) => key);
    
    // Save preferences to user profile
    updateProfileMutation.mutate({
      dietary_preferences: selectedDietaryPrefs,
      allergens: selectedAllergens,
      cuisine_preferences: cuisines,
      skill_level: skillLevel
    }, {
      onSuccess: () => {
        navigate("/home");
      }
    });
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-auto">
      {/* Language Switcher */}
      <div className="absolute top-3 right-3 z-50">
        <LanguageSwitcher />
      </div>
      
      <div className="flex items-center p-6">
        <h1 className="text-2xl font-bold text-neutral-800">
          {t("yourPreferences")}
        </h1>
      </div>
      
      <div className="px-6">
        <p className="text-neutral-800 opacity-75 mb-6">
          {t("preferencesDescription")}
        </p>
        
        <div className="space-y-6 pb-32">
          {/* Dietary Preferences */}
          <div className="space-y-4">
            <h2 className="font-medium text-lg text-neutral-800">
              {t("dietaryPrefsTitle")}
            </h2>
            
            <div className="grid grid-cols-1 gap-3">
              {dietaryPreferences.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-neutral-100 rounded-lg shadow-sm border border-neutral-200">
                  <div className="flex items-center">
                    <span className="text-lg mr-3">{item.icon}</span>
                    <span>{t(item.name)}</span>
                  </div>
                  <Switch
                    checked={dietaryPrefs[item.id]}
                    onCheckedChange={() => handleDietaryToggle(item.id)}
                  />
                </div>
              ))}
            </div>
          </div>
          
          {/* Allergens */}
          <div className="space-y-4">
            <h2 className="font-medium text-lg text-neutral-800">
              {t("allergensTitle")}
            </h2>
            
            <div className="grid grid-cols-1 gap-3">
              {allergens.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 bg-rose-50 rounded-lg shadow-sm border border-rose-100">
                  <div className="flex items-center">
                    <span className="text-lg mr-3">{item.icon}</span>
                    <span>{t(item.name)}</span>
                  </div>
                  <Switch
                    checked={allergies[item.id]}
                    onCheckedChange={() => handleAllergenToggle(item.id)}
                  />
                </div>
              ))}
            </div>
          </div>
          
          {/* Cuisine Preferences */}
          <div className="space-y-4">
            <h2 className="font-medium text-lg text-neutral-800">
              {t("cuisinePreferences")}
            </h2>
            
            <div className="flex flex-wrap gap-3">
              {cuisineTypes.map((cuisine) => (
                <div
                  key={cuisine.id}
                  className={cn(
                    "border rounded-full px-4 py-2 flex items-center cursor-pointer",
                    cuisines.includes(cuisine.id)
                      ? "bg-secondary bg-opacity-20 border-secondary"
                      : "bg-white border-gray-300"
                  )}
                  onClick={() => handleCuisineToggle(cuisine.id)}
                >
                  <span className={cuisines.includes(cuisine.id) ? "text-secondary" : ""}>
                    {t(cuisine.name)}
                  </span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Cooking Skill Level */}
          <div className="space-y-4">
            <h2 className="font-medium text-lg text-neutral-800">
              {t("cookingSkillLevel")}
            </h2>
            
            <RadioGroup
              value={skillLevel}
              onValueChange={setSkillLevel}
              className="flex flex-col space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="beginner" id="beginner" />
                <Label htmlFor="beginner">{t("beginner")}</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="intermediate" id="intermediate" />
                <Label htmlFor="intermediate">{t("intermediate")}</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="advanced" id="advanced" />
                <Label htmlFor="advanced">{t("advanced")}</Label>
              </div>
            </RadioGroup>
          </div>
        </div>
      </div>
      
      {/* Fixed button at bottom */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white p-6 shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <Button
          className="w-full bg-primary text-white py-6 rounded-lg font-medium shadow hover:bg-opacity-90 transition"
          onClick={handleSavePreferences}
          disabled={updateProfileMutation.isPending}
        >
          {t("continue")}
        </Button>
      </div>
    </div>
  );
}
