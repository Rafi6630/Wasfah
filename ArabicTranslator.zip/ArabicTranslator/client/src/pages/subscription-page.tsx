import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  CheckCircle, 
  XCircle, 
  Zap, 
  CreditCard,
  Crown,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Badge } from "@/components/ui/badge";
import { RoyalBadge } from "@/components/ui/royal-badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { RoyalButton } from "@/components/ui/royal-button";
import { RoyalCrownIcon } from "@/components/icons/crown-icon";

// Types
type SubscriptionTier = 'free' | 'premium';

interface SubscriptionPlan {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  price: number;
  billingPeriod: 'monthly' | 'yearly';
  discount?: number;
  features: {
    label: string;
    labelAr: string;
    included: boolean;
  }[];
}

export default function SubscriptionPage() {
  const { t, language, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user, updateSubscriptionMutation, isPremium } = useAuth();
  
  const [currentPlan, setCurrentPlan] = React.useState<SubscriptionTier>(isPremium ? 'premium' : 'free');
  const [billingPeriod, setBillingPeriod] = React.useState<'monthly' | 'yearly'>(
    user?.subscription_billing_period === 'yearly' ? 'yearly' : 'monthly'
  );
  
  // Subscription plans based on requirements
  const plans: Record<'monthly' | 'yearly', SubscriptionPlan[]> = {
    monthly: [
      {
        id: 'free',
        name: t("freePlan"),
        nameAr: t("freePlanAr"),
        description: t("freePlanDescription"),
        descriptionAr: t("freePlanDescriptionAr"),
        price: 0,
        billingPeriod: 'monthly',
        features: [
          { 
            label: t("basicRecipeSearch"), 
            labelAr: t("basicRecipeSearchAr"), 
            included: true 
          },
          { 
            label: t("limitedFilters"), 
            labelAr: t("limitedFiltersAr"), 
            included: true 
          },
          { 
            label: t("basicRecipes"), 
            labelAr: t("basicRecipesAr"), 
            included: true 
          },
          { 
            label: t("limitedPantryTracking"), 
            labelAr: t("limitedPantryTrackingAr"), 
            included: true 
          },
          { 
            label: t("adsSupported"), 
            labelAr: t("adsSupportedAr"), 
            included: true 
          },
          { 
            label: t("advancedAiRecommendations"), 
            labelAr: t("advancedAiRecommendationsAr"), 
            included: false 
          },
          { 
            label: t("exclusiveRecipes"), 
            labelAr: t("exclusiveRecipesAr"), 
            included: false 
          },
          { 
            label: t("exclusiveMealPlans"), 
            labelAr: t("exclusiveMealPlansAr"), 
            included: false 
          },
          { 
            label: t("unlimitedPantryTracking"), 
            labelAr: t("unlimitedPantryTrackingAr"), 
            included: false 
          },
          { 
            label: t("detailedCookingInstructions"), 
            labelAr: t("detailedCookingInstructionsAr"), 
            included: false 
          },
          { 
            label: t("nutritionInformation"), 
            labelAr: t("nutritionInformationAr"), 
            included: false 
          },
          { 
            label: t("recipeSharing"), 
            labelAr: t("recipeSharingAr"), 
            included: false 
          },
          { 
            label: t("nutritionalGoalTracking"), 
            labelAr: t("nutritionalGoalTrackingAr"), 
            included: false 
          },
          { 
            label: t("adFree"), 
            labelAr: t("adFreeAr"), 
            included: false 
          }
        ]
      },
      {
        id: 'premium',
        name: t("premiumPlan"),
        nameAr: t("premiumPlanAr"),
        description: t("premiumPlanDescription"),
        descriptionAr: t("premiumPlanDescriptionAr"),
        price: 5.99,
        billingPeriod: 'monthly',
        features: [
          { 
            label: t("basicRecipeSearch"), 
            labelAr: t("basicRecipeSearchAr"), 
            included: true 
          },
          { 
            label: t("advancedAiRecommendations"), 
            labelAr: t("advancedAiRecommendationsAr"), 
            included: true 
          },
          { 
            label: t("exclusiveRecipes"), 
            labelAr: t("exclusiveRecipesAr"), 
            included: true 
          },
          { 
            label: t("exclusiveMealPlans"), 
            labelAr: t("exclusiveMealPlansAr"), 
            included: true 
          },
          { 
            label: t("unlimitedPantryTracking"), 
            labelAr: t("unlimitedPantryTrackingAr"), 
            included: true 
          },
          { 
            label: t("detailedCookingInstructions"), 
            labelAr: t("detailedCookingInstructionsAr"), 
            included: true 
          },
          { 
            label: t("nutritionInformation"), 
            labelAr: t("nutritionInformationAr"), 
            included: true 
          },
          { 
            label: t("recipeSharing"), 
            labelAr: t("recipeSharingAr"), 
            included: true 
          },
          { 
            label: t("nutritionalGoalTracking"), 
            labelAr: t("nutritionalGoalTrackingAr"), 
            included: true 
          },
          { 
            label: t("adFree"), 
            labelAr: t("adFreeAr"), 
            included: true 
          }
        ]
      }
    ],
    yearly: [
      {
        id: 'free',
        name: t("freePlan"),
        nameAr: t("freePlanAr"),
        description: t("freePlanDescription"),
        descriptionAr: t("freePlanDescriptionAr"),
        price: 0,
        billingPeriod: 'yearly',
        features: [
          { 
            label: t("basicRecipeSearch"), 
            labelAr: t("basicRecipeSearchAr"), 
            included: true 
          },
          { 
            label: t("limitedFilters"), 
            labelAr: t("limitedFiltersAr"), 
            included: true 
          },
          { 
            label: t("basicRecipes"), 
            labelAr: t("basicRecipesAr"), 
            included: true 
          },
          { 
            label: t("limitedPantryTracking"), 
            labelAr: t("limitedPantryTrackingAr"), 
            included: true 
          },
          { 
            label: t("adsSupported"), 
            labelAr: t("adsSupportedAr"), 
            included: true 
          },
          { 
            label: t("advancedAiRecommendations"), 
            labelAr: t("advancedAiRecommendationsAr"), 
            included: false 
          },
          { 
            label: t("exclusiveRecipes"), 
            labelAr: t("exclusiveRecipesAr"), 
            included: false 
          },
          { 
            label: t("exclusiveMealPlans"), 
            labelAr: t("exclusiveMealPlansAr"), 
            included: false 
          },
          { 
            label: t("unlimitedPantryTracking"), 
            labelAr: t("unlimitedPantryTrackingAr"), 
            included: false 
          },
          { 
            label: t("detailedCookingInstructions"), 
            labelAr: t("detailedCookingInstructionsAr"), 
            included: false 
          },
          { 
            label: t("nutritionInformation"), 
            labelAr: t("nutritionInformationAr"), 
            included: false 
          },
          { 
            label: t("recipeSharing"), 
            labelAr: t("recipeSharingAr"), 
            included: false 
          },
          { 
            label: t("nutritionalGoalTracking"), 
            labelAr: t("nutritionalGoalTrackingAr"), 
            included: false 
          },
          { 
            label: t("adFree"), 
            labelAr: t("adFreeAr"), 
            included: false 
          }
        ]
      },
      {
        id: 'premium',
        name: t("premiumPlan"),
        nameAr: t("premiumPlanAr"),
        description: t("premiumPlanDescription"),
        descriptionAr: t("premiumPlanDescriptionAr"),
        price: 59.99,
        billingPeriod: 'yearly',
        discount: 16.6, // ~2 months free
        features: [
          { 
            label: t("basicRecipeSearch"), 
            labelAr: t("basicRecipeSearchAr"), 
            included: true 
          },
          { 
            label: t("advancedAiRecommendations"), 
            labelAr: t("advancedAiRecommendationsAr"), 
            included: true 
          },
          { 
            label: t("exclusiveRecipes"), 
            labelAr: t("exclusiveRecipesAr"), 
            included: true 
          },
          { 
            label: t("exclusiveMealPlans"), 
            labelAr: t("exclusiveMealPlansAr"), 
            included: true 
          },
          { 
            label: t("unlimitedPantryTracking"), 
            labelAr: t("unlimitedPantryTrackingAr"), 
            included: true 
          },
          { 
            label: t("detailedCookingInstructions"), 
            labelAr: t("detailedCookingInstructionsAr"), 
            included: true 
          },
          { 
            label: t("nutritionInformation"), 
            labelAr: t("nutritionInformationAr"), 
            included: true 
          },
          { 
            label: t("recipeSharing"), 
            labelAr: t("recipeSharingAr"), 
            included: true 
          },
          { 
            label: t("nutritionalGoalTracking"), 
            labelAr: t("nutritionalGoalTrackingAr"), 
            included: true 
          },
          { 
            label: t("adFree"), 
            labelAr: t("adFreeAr"), 
            included: true 
          }
        ]
      }
    ]
  };
  
  const handlePurchase = (plan: SubscriptionPlan) => {
    if (plan.id === 'free') {
      // Update subscription to free tier
      updateSubscriptionMutation.mutate({
        tier: 'free',
        billingPeriod: billingPeriod
      });
      setCurrentPlan('free');
      return;
    }
    
    // For premium plans, directly open the payment dialog
    setLocation("/payment-methods?upgrade=premium&billing=" + billingPeriod);
  };
  
  const handleCancelSubscription = () => {
    // Update subscription to free tier
    updateSubscriptionMutation.mutate({
      tier: 'free',
      billingPeriod: billingPeriod
    });
    
    toast({
      title: t("subscriptionCanceled"),
      description: t("planActiveUntilEndBillingPeriod"),
    });
    setCurrentPlan('free');
  };
  
  const handleGoBack = () => {
    setLocation("/settings");
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10">
        <div className="relative flex items-center justify-center py-4 px-6 bg-gradient-to-r from-royal-purple-dark to-royal-purple text-white">
          <button 
            className="absolute left-2 p-2 text-white/80 hover:text-white transition-colors"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="font-semibold flex items-center gap-2">
            <Crown className="h-5 w-5 text-royal-gold" />
            <span>{t("subscription")}</span>
          </h1>
        </div>
      </div>
      
      {/* Current Plan */}
      <div className="p-4 bg-gradient-to-b from-royal-purple/10 to-white border-b">
        <div className="royal-card-premium p-0.5 rounded-lg">
          <div className="royal-card-premium-inner p-5 rounded-lg">
            <div className="flex items-center">
              <div className="mr-4">
                {currentPlan === 'premium' ? (
                  <div className="w-14 h-14 bg-royal-purple/10 text-royal-purple rounded-full flex items-center justify-center royal-glow">
                    <Crown className="h-7 w-7 text-royal-gold" />
                  </div>
                ) : (
                  <div className="w-14 h-14 bg-slate-100 rounded-full flex items-center justify-center">
                    <Zap className="h-7 w-7 text-slate-400" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h2 className="font-playfair text-xl text-royal-purple-dark flex items-center">
                  {currentPlan === 'premium' ? (
                    <>
                      {t("premiumPlan")}
                      <span className="ml-2">
                        <Sparkles className="h-4 w-4 text-royal-gold animate-pulse" />
                      </span>
                    </>
                  ) : (
                    t("freePlan")
                  )}
                </h2>
                <p className="text-sm text-royal-purple-dark/60">
                  {currentPlan === 'premium' 
                    ? t("yourPremiumPlanActive") 
                    : t("currentlyOnFreePlan")}
                </p>
              </div>
            </div>
            
            {currentPlan === 'premium' && (
              <div className="mt-4 flex justify-end">
                <RoyalButton 
                  variant="outline" 
                  size="sm"
                  onClick={handleCancelSubscription}
                >
                  {t("cancelSubscription")}
                </RoyalButton>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Plan Selection */}
      <div className="p-4">
        <h2 className="font-playfair text-xl text-royal-purple-dark mb-4 flex items-center gap-2">
          <RoyalCrownIcon className="h-5 w-5 text-royal-gold" />
          <span>{t("choosePlan")}</span>
        </h2>
        
        <Tabs 
          defaultValue="monthly"
          value={billingPeriod}
          onValueChange={(value) => setBillingPeriod(value as 'monthly' | 'yearly')}
          className="mb-6"
        >
          <TabsList className="grid grid-cols-2 w-full bg-royal-purple/5 border border-royal-gold/20 p-1 rounded-lg">
            <TabsTrigger value="monthly">
              {t("monthly")}
            </TabsTrigger>
            <TabsTrigger value="yearly">
              {t("yearly")}
              <RoyalBadge variant="gold" className="ml-2">
                {t("savePercent", { percent: "16%" })}
              </RoyalBadge>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="grid gap-4">
          {plans[billingPeriod].map((plan) => (
            <Card 
              key={plan.id}
              className={cn(
                "relative overflow-hidden",
                plan.id === 'premium' 
                  ? "border-royal-gold/40 bg-gradient-to-b from-white to-royal-gold/5" 
                  : ""
              )}
            >
              {plan.id === 'premium' && (
                <>
                  <div 
                    className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-royal-gold text-white text-xs px-3 py-1 rounded-full font-medium shadow-sm"
                  >
                    {t("mostPopular")}
                  </div>
                  <div className="absolute top-0 right-0 w-24 h-24 bg-royal-gold/10 rounded-full -translate-x-12 -translate-y-12 z-0"></div>
                  <div className="absolute bottom-0 left-0 w-16 h-16 bg-royal-gold/10 rounded-full translate-x-8 translate-y-8 z-0"></div>
                </>
              )}
              
              <CardHeader className="relative z-10">
                <CardTitle className="flex items-center justify-between">
                  <div>
                    <span className="font-playfair text-xl text-royal-purple-dark flex items-center">
                      {plan.id === 'premium' ? (
                        <Crown className="h-5 w-5 mr-2 text-royal-gold" />
                      ) : (
                        <Zap className="h-5 w-5 mr-2 text-slate-400" />
                      )}
                      {language === 'ar' ? plan.nameAr : plan.name}
                    </span>
                    <CardDescription className="mt-1">
                      {language === 'ar' ? plan.descriptionAr : plan.description}
                    </CardDescription>
                  </div>
                  
                  {plan.id === 'premium' && <Sparkles className="h-5 w-5 text-royal-gold animate-pulse" />}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4 flex items-baseline">
                  <span className="text-3xl font-bold text-royal-purple-dark">
                    ${plan.price}
                  </span>
                  <span className="text-muted-foreground ml-1">
                    / {plan.billingPeriod === 'monthly' ? t("month") : t("year")}
                  </span>
                  
                  {plan.discount && (
                    <RoyalBadge variant="premium" className="ml-2">
                      {t("savePercent", { percent: `${plan.discount}%` })}
                    </RoyalBadge>
                  )}
                </div>
                
                <Separator className="my-4" />
                
                <h3 className="font-playfair text-base text-royal-purple-dark mb-3 flex items-center gap-1.5">
                  <RoyalCrownIcon className="h-4 w-4 text-royal-gold" />
                  {t("includes")}
                </h3>
                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      {feature.included ? (
                        <CheckCircle className="h-5 w-5 text-royal-gold mr-2 mt-0.5 shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-muted-foreground/40 mr-2 mt-0.5 shrink-0" />
                      )}
                      <span className={cn(
                        "text-sm",
                        feature.included 
                          ? "text-royal-purple-dark" 
                          : "text-muted-foreground/60"
                      )}>
                        {language === 'ar' ? feature.labelAr : feature.label}
                      </span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <RoyalButton 
                  className="w-full" 
                  variant={plan.id === 'premium' ? "premium" : "outline"}
                  onClick={() => handlePurchase(plan)}
                  leftIcon={plan.id === 'premium' ? <Crown className="h-4 w-4" /> : undefined}
                >
                  {plan.id === 'free' ? t("currentPlan") : (
                    currentPlan === 'premium' ? t("managePlan") : t("subscribeToPlan")
                  )}
                </RoyalButton>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        {/* Payment Method Preview */}
        {currentPlan === 'premium' && (
          <div className="mt-6 rounded-lg border border-royal-gold/20 p-5 bg-gradient-to-b from-white to-royal-gold/5">
            <h3 className="font-playfair text-base text-royal-purple-dark mb-3 flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-royal-gold" />
              {t("paymentMethod")}
            </h3>
            <div className="flex items-center">
              <div className="w-12 h-7 bg-gradient-to-r from-royal-purple to-royal-purple-dark rounded-md mr-3 flex items-center justify-center text-white text-xs font-medium shadow-sm">
                VISA
              </div>
              <div>
                <p className="text-sm font-medium text-royal-purple-dark">
                  •••• •••• •••• 4242
                </p>
                <p className="text-xs text-royal-purple-dark/60">
                  {t("expiresOn")} 12/25
                </p>
              </div>
              <RoyalButton 
                variant="ghost" 
                size="sm" 
                className="ml-auto"
                leftIcon={<CreditCard className="h-3.5 w-3.5" />}
                onClick={() => setLocation("/payment-methods")}
              >
                {t("change")}
              </RoyalButton>
            </div>
          </div>
        )}
        
        <div className="text-xs text-muted-foreground text-center mt-6">
          {t("subscriptionDisclaimer")}
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}