import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft,
  AlertCircle,
  Info,
  ExternalLink,
  BarChart3,
  ActivitySquare,
  Heart,
  Pizza
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Badge } from "@/components/ui/badge";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { format, subDays } from "date-fns";
import { ar } from "date-fns/locale";

// Types
interface NutritionGoals {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  sodium: number;
}

interface DailyNutritionLog {
  date: Date;
  meals: {
    id: string;
    name: string;
    nutrition: {
      calories: number;
      protein: number;
      carbs: number;
      fat: number;
      fiber: number;
      sodium: number;
    };
  }[];
  totals: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    sodium: number;
  };
}

interface Allergen {
  id: string;
  name: string;
  nameAr: string;
  severity: 'mild' | 'moderate' | 'severe';
}

export default function HealthInformationPage() {
  const { t, language, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const goals: NutritionGoals = {
    calories: 2000,
    protein: 100,
    carbs: 225,
    fat: 65,
    fiber: 30,
    sodium: 2300
  };
  
  // Generate sample nutrition logs
  const today = new Date();
  const logs: DailyNutritionLog[] = [
    {
      date: today,
      meals: [
        {
          id: "breakfast1",
          name: t("breakfastToday"),
          nutrition: {
            calories: 420,
            protein: 22,
            carbs: 45,
            fat: 18,
            fiber: 6,
            sodium: 320
          }
        },
        {
          id: "lunch1",
          name: t("lunchToday"),
          nutrition: {
            calories: 650,
            protein: 35,
            carbs: 65,
            fat: 25,
            fiber: 8,
            sodium: 850
          }
        }
      ],
      totals: {
        calories: 1070,
        protein: 57,
        carbs: 110,
        fat: 43,
        fiber: 14,
        sodium: 1170
      }
    },
    {
      date: subDays(today, 1),
      meals: [
        {
          id: "breakfast2",
          name: t("breakfastYesterday"),
          nutrition: {
            calories: 380,
            protein: 18,
            carbs: 48,
            fat: 14,
            fiber: 5,
            sodium: 290
          }
        },
        {
          id: "lunch2",
          name: t("lunchYesterday"),
          nutrition: {
            calories: 550,
            protein: 32,
            carbs: 60,
            fat: 20,
            fiber: 7,
            sodium: 780
          }
        },
        {
          id: "dinner2",
          name: t("dinnerYesterday"),
          nutrition: {
            calories: 720,
            protein: 38,
            carbs: 75,
            fat: 28,
            fiber: 9,
            sodium: 920
          }
        }
      ],
      totals: {
        calories: 1650,
        protein: 88,
        carbs: 183,
        fat: 62,
        fiber: 21,
        sodium: 1990
      }
    }
  ];
  
  // User allergens
  const userAllergens: Allergen[] = [
    { 
      id: "dairy", 
      name: t("dairy"), 
      nameAr: t("dairyAr"), 
      severity: 'moderate' 
    },
    { 
      id: "peanuts", 
      name: t("peanuts"), 
      nameAr: t("peanutsAr"), 
      severity: 'severe' 
    }
  ];
  
  const isPremium = false;
  
  const handleGoBack = () => {
    setLocation("/profile");
  };
  
  // Calculate percentage of goal
  const calculatePercentage = (value: number, goal: number) => {
    return Math.min(Math.round((value / goal) * 100), 100);
  };
  
  // Get nutrition progress color
  const getNutritionProgressColor = (value: number, goal: number, isReverse = false) => {
    const percentage = (value / goal) * 100;
    
    if (isReverse) {
      // For nutrients we want to limit (sodium, etc.)
      if (percentage > 100) return "bg-red-500";
      if (percentage > 80) return "bg-amber-500";
      return "bg-green-500";
    } else {
      // For nutrients we want to meet (protein, fiber, etc.)
      if (percentage >= 90) return "bg-green-500";
      if (percentage >= 60) return "bg-amber-500";
      return "bg-red-500";
    }
  };
  
  // Format nutrition value with units
  const formatNutritionValue = (value: number, nutrient: keyof NutritionGoals) => {
    switch (nutrient) {
      case 'calories':
        return `${value} kcal`;
      case 'sodium':
        return `${value} mg`;
      default:
        return `${value} g`;
    }
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white">
        <div className="relative flex items-center justify-center p-4 border-b">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-2"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">{t("healthInformation")}</h1>
        </div>
      </div>
      
      {/* Main Content */}
      <Tabs defaultValue="nutrition" className="p-4">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="nutrition">
            <BarChart3 className="h-4 w-4 mr-2" />
            {t("nutrition")}
          </TabsTrigger>
          <TabsTrigger value="allergens">
            <AlertCircle className="h-4 w-4 mr-2" />
            {t("allergens")}
          </TabsTrigger>
        </TabsList>
        
        {/* Nutrition Tab */}
        <TabsContent value="nutrition" className="mt-0">
          {isPremium ? (
            <>
              <div className="mb-4">
                <h2 className="font-medium text-lg">{t("todayNutrition")}</h2>
                <p className="text-sm text-muted-foreground mb-4">
                  {format(today, 'EEEE, MMMM d', { locale: language === 'ar' ? ar : undefined })}
                </p>
              </div>
              
              {/* Summary Card */}
              <Card className="mb-6">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">
                    {t("dailySummary")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <div className="text-sm font-medium">{t("caloriesHealth")}</div>
                        <div className="text-sm">
                          {logs[0].totals.calories} / {goals.calories} kcal
                        </div>
                      </div>
                      <Progress 
                        value={calculatePercentage(logs[0].totals.calories, goals.calories)} 
                        className="h-2"
                      />
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4">
                      {/* Protein */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <div className="text-xs font-medium">{t("proteinHealth")}</div>
                          <div className="text-xs">
                            {logs[0].totals.protein}g
                          </div>
                        </div>
                        <Progress 
                          value={calculatePercentage(logs[0].totals.protein, goals.protein)} 
                          className={cn(
                            "h-1.5",
                            getNutritionProgressColor(logs[0].totals.protein, goals.protein)
                          )}
                        />
                      </div>
                      
                      {/* Carbs */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <div className="text-xs font-medium">{t("carbsHealth")}</div>
                          <div className="text-xs">
                            {logs[0].totals.carbs}g
                          </div>
                        </div>
                        <Progress 
                          value={calculatePercentage(logs[0].totals.carbs, goals.carbs)} 
                          className={cn(
                            "h-1.5",
                            getNutritionProgressColor(logs[0].totals.carbs, goals.carbs)
                          )}
                        />
                      </div>
                      
                      {/* Fat */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <div className="text-xs font-medium">{t("fatHealth")}</div>
                          <div className="text-xs">
                            {logs[0].totals.fat}g
                          </div>
                        </div>
                        <Progress 
                          value={calculatePercentage(logs[0].totals.fat, goals.fat)} 
                          className={cn(
                            "h-1.5",
                            getNutritionProgressColor(logs[0].totals.fat, goals.fat)
                          )}
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      {/* Fiber */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <div className="text-xs font-medium">{t("fiberHealth")}</div>
                          <div className="text-xs">
                            {logs[0].totals.fiber}g
                          </div>
                        </div>
                        <Progress 
                          value={calculatePercentage(logs[0].totals.fiber, goals.fiber)} 
                          className={cn(
                            "h-1.5",
                            getNutritionProgressColor(logs[0].totals.fiber, goals.fiber)
                          )}
                        />
                      </div>
                      
                      {/* Sodium */}
                      <div>
                        <div className="flex justify-between mb-1">
                          <div className="text-xs font-medium">{t("sodiumHealth")}</div>
                          <div className="text-xs">
                            {logs[0].totals.sodium}mg
                          </div>
                        </div>
                        <Progress 
                          value={calculatePercentage(logs[0].totals.sodium, goals.sodium)} 
                          className={cn(
                            "h-1.5",
                            getNutritionProgressColor(logs[0].totals.sodium, goals.sodium, true)
                          )}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Meals Log */}
              <div className="mb-4">
                <h3 className="font-medium text-base mb-2">{t("mealsToday")}</h3>
                <div className="space-y-3">
                  {logs[0].meals.map(meal => (
                    <div 
                      key={meal.id} 
                      className="border rounded-lg p-3 hover:bg-muted/50"
                    >
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium">{meal.name}</div>
                        <div className="text-sm">{meal.nutrition.calories} kcal</div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-2 text-xs">
                        <div>
                          <span className="text-muted-foreground">{t("protein")}: </span>
                          {meal.nutrition.protein}g
                        </div>
                        <div>
                          <span className="text-muted-foreground">{t("carbs")}: </span>
                          {meal.nutrition.carbs}g
                        </div>
                        <div>
                          <span className="text-muted-foreground">{t("fat")}: </span>
                          {meal.nutrition.fat}g
                        </div>
                      </div>
                    </div>
                  ))}
                  
                  <Button
                    variant="outline"
                    className="w-full border-dashed"
                    onClick={() => toast({
                      description: t("addMealNotImplemented"),
                    })}
                  >
                    + {t("addMeal")}
                  </Button>
                </div>
              </div>
              
              {/* History */}
              <div className="mb-4">
                <h3 className="font-medium text-base mb-2">{t("nutritionHistory")}</h3>
                <div className="space-y-3">
                  {logs.slice(1).map((log, index) => (
                    <div 
                      key={index} 
                      className="border rounded-lg p-3 hover:bg-muted/50"
                    >
                      <div className="flex justify-between items-center mb-2">
                        <div className="font-medium">
                          {format(log.date, 'EEEE, MMMM d', { locale: language === 'ar' ? ar : undefined })}
                        </div>
                        <div className="text-sm">{log.totals.calories} / {goals.calories} kcal</div>
                      </div>
                      
                      <Progress 
                        value={calculatePercentage(log.totals.calories, goals.calories)} 
                        className="h-2 mb-2"
                      />
                      
                      <div className="text-xs text-muted-foreground">
                        {log.meals.length} {t("mealsLogged")}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            // Premium Feature Banner
            <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg p-6 text-center">
              <div className="flex flex-col items-center">
                <BarChart3 className="h-12 w-12 text-primary/60 mb-4" />
                <h2 className="text-lg font-medium mb-2">{t("nutritionTrackingPremium")}</h2>
                <p className="text-sm text-muted-foreground mb-6 max-w-xs mx-auto">
                  {t("nutritionTrackingPremiumDescription")}
                </p>
                <Button 
                  onClick={() => setLocation("/subscription")}
                  className="mb-2"
                >
                  {t("upgradeToAccess")}
                </Button>
                <div className="grid grid-cols-3 gap-4 w-full mt-6">
                  <div className="flex flex-col items-center">
                    <ActivitySquare className="h-8 w-8 text-primary/40 mb-2" />
                    <span className="text-xs text-center">{t("trackDailyIntake")}</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <Heart className="h-8 w-8 text-primary/40 mb-2" />
                    <span className="text-xs text-center">{t("healthInsights")}</span>
                  </div>
                  <div className="flex flex-col items-center">
                    <Pizza className="h-8 w-8 text-primary/40 mb-2" />
                    <span className="text-xs text-center">{t("recipeNutrition")}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </TabsContent>
        
        {/* Allergens Tab */}
        <TabsContent value="allergens" className="mt-0">
          <div className="mb-4">
            <h2 className="font-medium">{t("allergenInformation")}</h2>
            <p className="text-sm text-muted-foreground mb-4">
              {t("allergenInformationDescription")}
            </p>
          </div>
          
          {userAllergens.length > 0 ? (
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">
                    {t("yourAllergens")}
                  </CardTitle>
                  <CardDescription>
                    {t("yourAllergensDescription")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {userAllergens.map(allergen => (
                      <div 
                        key={allergen.id}
                        className="flex items-center justify-between p-2 border rounded-md"
                      >
                        <div>
                          <div className="font-medium">
                            {language === 'ar' ? allergen.nameAr : allergen.name}
                          </div>
                        </div>
                        <Badge
                          variant="outline"
                          className={cn(
                            "ml-auto",
                            allergen.severity === 'mild' && "bg-amber-100 text-amber-800 border-amber-200",
                            allergen.severity === 'moderate' && "bg-orange-100 text-orange-800 border-orange-200",
                            allergen.severity === 'severe' && "bg-red-100 text-red-800 border-red-200"
                          )}
                        >
                          {t(allergen.severity)}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="pt-0">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setLocation("/dietary-preferences")}
                  >
                    {t("manageDietaryPreferences")}
                  </Button>
                </CardFooter>
              </Card>
              
              <div className="bg-amber-50 border border-amber-100 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertCircle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                  <div>
                    <h3 className="font-medium text-amber-800 mb-1">
                      {t("allergenAlert")}
                    </h3>
                    <p className="text-sm text-amber-700 mb-2">
                      {t("allergenAlertDescription")}
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="bg-white border-amber-200 hover:bg-amber-50"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      {t("learnAboutFoodAllergies")}
                    </Button>
                  </div>
                </div>
              </div>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">
                    {t("commonAllergens")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("milk")}</span>
                      <span className="text-muted-foreground">{t("milkAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("eggs")}</span>
                      <span className="text-muted-foreground">{t("eggsAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("fish")}</span>
                      <span className="text-muted-foreground">{t("fishAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("shellfish")}</span>
                      <span className="text-muted-foreground">{t("shellfishAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("treeNuts")}</span>
                      <span className="text-muted-foreground">{t("treeNutsAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("peanuts")}</span>
                      <span className="text-muted-foreground">{t("peanutsAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("wheat")}</span>
                      <span className="text-muted-foreground">{t("wheatAllergenDescription")}</span>
                    </li>
                    <li className="flex items-start">
                      <span className="font-medium min-w-24">{t("soy")}</span>
                      <span className="text-muted-foreground">{t("soyAllergenDescription")}</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center p-6 bg-muted/30 rounded-lg">
              <AlertCircle className="h-12 w-12 text-muted-foreground/40 mb-4" />
              <h3 className="text-lg font-medium mb-2">{t("noAllergensSet")}</h3>
              <p className="text-sm text-muted-foreground mb-4 text-center">
                {t("noAllergensSetDescription")}
              </p>
              <Button
                onClick={() => setLocation("/dietary-preferences")}
              >
                {t("setUpAllergens")}
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      <BottomNavigation />
    </div>
  );
}