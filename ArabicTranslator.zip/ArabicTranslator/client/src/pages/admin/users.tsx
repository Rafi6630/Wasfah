import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Loader2,
  MoreHorizontal,
  Search,
  UserPlus,
  CheckCircle,
  XCircle,
  Crown,
  User,
  MailCheck,
  MailQuestion,
  Edit,
  Trash2,
  ShieldAlert,
  Download,
  Pencil,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { User as UserType } from "@shared/schema";
import AdminLayout from "./admin-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";

export default function AdminUsersPage() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<number | null>(null);

  const { data: users, isLoading } = useQuery<UserType[]>({
    queryKey: ["/api/admin/users"],
    staleTime: 30000,
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      await apiRequest("DELETE", `/api/admin/users/${userId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: t("admin.user_deleted"),
        description: t("admin.user_deleted_description"),
      });
      setIsConfirmDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: t("admin.delete_failed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateUserStatusMutation = useMutation({
    mutationFn: async ({
      userId,
      status,
    }: {
      userId: number;
      status: string;
    }) => {
      await apiRequest("PATCH", `/api/admin/users/${userId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: t("admin.user_updated"),
        description: t("admin.user_status_updated"),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t("admin.update_failed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateUserRoleMutation = useMutation({
    mutationFn: async ({
      userId,
      role,
    }: {
      userId: number;
      role: string;
    }) => {
      await apiRequest("PATCH", `/api/admin/users/${userId}`, { role });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: t("admin.user_updated"),
        description: t("admin.user_role_updated"),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t("admin.update_failed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const confirmDelete = (userId: number) => {
    setUserToDelete(userId);
    setIsConfirmDialogOpen(true);
  };

  const handleDelete = () => {
    if (userToDelete) {
      deleteUserMutation.mutate(userToDelete);
    }
  };

  // Filter users based on search query, status and role
  const filteredUsers = users
    ? users.filter((user) => {
        const matchesSearch =
          searchQuery === "" ||
          user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (user.name &&
            user.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (user.username &&
            user.username.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesStatus =
          !selectedStatus || user.status === selectedStatus;
        const matchesRole = !selectedRole || user.role === selectedRole;

        return matchesSearch && matchesStatus && matchesRole;
      })
    : [];

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-full items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <h2 className="font-playFair text-3xl font-bold tracking-tight">
            {t("admin.user_management")}
          </h2>

          <Button
            className="w-full md:w-auto"
            onClick={() => {
              toast({
                title: t("admin.coming_soon"),
                description: t("admin.feature_in_development"),
              });
            }}
          >
            <UserPlus className="mr-2 h-4 w-4" />
            {t("admin.add_user")}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{t("admin.users")}</CardTitle>
            <CardDescription>
              {t("admin.users_description", { count: filteredUsers.length })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4 md:flex-row md:space-x-4 md:space-y-0">
              <div className="relative w-full md:w-1/3">
                <Search className="text-muted-foreground absolute left-2.5 top-2.5 h-4 w-4" />
                <Input
                  placeholder={t("admin.search_users")}
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <Select
                value={selectedStatus || ""}
                onValueChange={(value) =>
                  setSelectedStatus(value === "" ? null : value)
                }
              >
                <SelectTrigger className="w-full md:w-1/4">
                  <SelectValue placeholder={t("admin.filter_by_status")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t("admin.all_statuses")}</SelectItem>
                  <SelectItem value="ACTIVE">
                    {t("admin.status_active")}
                  </SelectItem>
                  <SelectItem value="PENDING">
                    {t("admin.status_pending")}
                  </SelectItem>
                  <SelectItem value="SUSPENDED">
                    {t("admin.status_suspended")}
                  </SelectItem>
                </SelectContent>
              </Select>

              <Select
                value={selectedRole || ""}
                onValueChange={(value) =>
                  setSelectedRole(value === "" ? null : value)
                }
              >
                <SelectTrigger className="w-full md:w-1/4">
                  <SelectValue placeholder={t("admin.filter_by_role")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t("admin.all_roles")}</SelectItem>
                  <SelectItem value="USER">{t("admin.role_user")}</SelectItem>
                  <SelectItem value="ADMIN">{t("admin.role_admin")}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="mt-6 overflow-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("admin.user")}</TableHead>
                    <TableHead>{t("admin.email")}</TableHead>
                    <TableHead>{t("admin.status")}</TableHead>
                    <TableHead>{t("admin.role")}</TableHead>
                    <TableHead>{t("admin.joined")}</TableHead>
                    <TableHead>{t("admin.subscription")}</TableHead>
                    <TableHead className="w-[70px]">{t("admin.actions")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center">
                            <div className="bg-primary/10 mr-2 h-8 w-8 rounded-full">
                              <div className="flex h-full w-full items-center justify-center text-primary">
                                {user.username?.[0]?.toUpperCase() ||
                                  user.name?.[0]?.toUpperCase() ||
                                  user.email[0].toUpperCase()}
                              </div>
                            </div>
                            <div>
                              <div>{user.username || user.name}</div>
                              <div className="text-muted-foreground text-xs">
                                ID: {user.id}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            {user.status === 'ACTIVE' ? (
                              <MailCheck className="text-green-500 mr-1 h-4 w-4" />
                            ) : (
                              <MailQuestion className="text-amber-500 mr-1 h-4 w-4" />
                            )}
                            {user.email}
                          </div>
                        </TableCell>
                        <TableCell>
                          {user.status === "ACTIVE" ? (
                            <Badge className="bg-green-500 hover:bg-green-600">
                              <CheckCircle className="mr-1 h-3 w-3" />
                              {t("admin.status_active")}
                            </Badge>
                          ) : user.status === "PENDING" ? (
                            <Badge className="bg-amber-500 hover:bg-amber-600">
                              {t("admin.status_pending")}
                            </Badge>
                          ) : (
                            <Badge className="bg-red-500 hover:bg-red-600">
                              <XCircle className="mr-1 h-3 w-3" />
                              {t("admin.status_suspended")}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {user.role === "ADMIN" ? (
                            <Badge className="bg-purple-600 hover:bg-purple-700">
                              <Crown className="mr-1 h-3 w-3" />
                              {t("admin.role_admin")}
                            </Badge>
                          ) : (
                            <Badge variant="outline">
                              <User className="mr-1 h-3 w-3" />
                              {t("admin.role_user")}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {user.created_at
                            ? format(new Date(user.created_at), "MMM d, yyyy")
                            : "-"}
                        </TableCell>
                        <TableCell>
                          {user.subscription_tier === "premium" ? (
                            <Badge className="bg-yellow-600 hover:bg-yellow-700">
                              <Crown className="mr-1 h-3 w-3" />
                              {t("admin.premium")}
                            </Badge>
                          ) : (
                            <Badge variant="outline">
                              {t("admin.free")}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                className="h-8 w-8 p-0"
                              >
                                <span className="sr-only">{t("admin.open_menu")}</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>{t("admin.actions")}</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => {
                                  toast({
                                    title: t("admin.coming_soon"),
                                    description: t("admin.feature_in_development"),
                                  });
                                }}
                              >
                                <Edit className="mr-2 h-4 w-4" />
                                {t("admin.view_profile")}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => {
                                  toast({
                                    title: t("admin.coming_soon"),
                                    description: t("admin.feature_in_development"),
                                  });
                                }}
                              >
                                <Pencil className="mr-2 h-4 w-4" />
                                {t("admin.edit_user")}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              
                              {/* Status Update Menu */}
                              <DropdownMenu>
                                <DropdownMenuTrigger className="w-full">
                                  <div className="flex w-full items-center px-2 py-1.5 text-sm">
                                    {user.status === "ACTIVE" ? (
                                      <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                    ) : user.status === "PENDING" ? (
                                      <MailQuestion className="mr-2 h-4 w-4 text-amber-500" />
                                    ) : (
                                      <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                    )}
                                    {t("admin.change_status")}
                                  </div>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem
                                    disabled={user.status === "ACTIVE"}
                                    onClick={() => {
                                      updateUserStatusMutation.mutate({
                                        userId: user.id,
                                        status: "ACTIVE",
                                      });
                                    }}
                                  >
                                    <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                    {t("admin.status_active")}
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    disabled={user.status === "PENDING"}
                                    onClick={() => {
                                      updateUserStatusMutation.mutate({
                                        userId: user.id,
                                        status: "PENDING",
                                      });
                                    }}
                                  >
                                    <MailQuestion className="mr-2 h-4 w-4 text-amber-500" />
                                    {t("admin.status_pending")}
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    disabled={user.status === "SUSPENDED"}
                                    onClick={() => {
                                      updateUserStatusMutation.mutate({
                                        userId: user.id,
                                        status: "SUSPENDED",
                                      });
                                    }}
                                  >
                                    <XCircle className="mr-2 h-4 w-4 text-red-500" />
                                    {t("admin.status_suspended")}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>

                              {/* Role Update Menu */}
                              <DropdownMenu>
                                <DropdownMenuTrigger className="w-full">
                                  <div className="flex w-full items-center px-2 py-1.5 text-sm">
                                    {user.role === "ADMIN" ? (
                                      <Crown className="mr-2 h-4 w-4 text-purple-500" />
                                    ) : (
                                      <User className="mr-2 h-4 w-4" />
                                    )}
                                    {t("admin.change_role")}
                                  </div>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                  <DropdownMenuItem
                                    disabled={user.role === "USER"}
                                    onClick={() => {
                                      updateUserRoleMutation.mutate({
                                        userId: user.id,
                                        role: "USER",
                                      });
                                    }}
                                  >
                                    <User className="mr-2 h-4 w-4" />
                                    {t("admin.role_user")}
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    disabled={user.role === "ADMIN"}
                                    onClick={() => {
                                      updateUserRoleMutation.mutate({
                                        userId: user.id,
                                        role: "ADMIN",
                                      });
                                    }}
                                  >
                                    <Crown className="mr-2 h-4 w-4 text-purple-500" />
                                    {t("admin.role_admin")}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>

                              <DropdownMenuSeparator />
                              
                              <DropdownMenuItem
                                onClick={() => confirmDelete(user.id)}
                                className="text-red-600 focus:text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                {t("admin.delete_user")}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-32 text-center">
                        <div className="flex flex-col items-center justify-center space-y-2">
                          <div className="bg-muted/30 flex h-12 w-12 items-center justify-center rounded-full">
                            <Search className="text-muted-foreground h-6 w-6" />
                          </div>
                          <div className="text-muted-foreground text-sm">
                            {t("admin.no_users_found")}
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between">
            <p className="text-muted-foreground text-sm">
              {t("admin.showing_users", { count: filteredUsers.length })}
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                toast({
                  title: t("admin.coming_soon"),
                  description: t("admin.feature_in_development"),
                });
              }}
            >
              <Download className="mr-2 h-4 w-4" />
              {t("admin.export_users")}
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("admin.confirm_delete")}</DialogTitle>
            <DialogDescription>
              {t("admin.delete_user_confirmation")}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsConfirmDialogOpen(false)}
            >
              {t("admin.cancel")}
            </Button>
            <Button
              onClick={handleDelete}
              variant="destructive"
              disabled={deleteUserMutation.isPending}
            >
              {deleteUserMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t("admin.deleting")}
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  {t("admin.delete")}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}