import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Loader2,
  MoreHorizontal,
  Search,
  PlusCircle,
  Check,
  X,
  Eye,
  Edit,
  Trash2,
  Flame,
  Clock,
  Star,
  Download,
  Tag,
  Coffee,
  Utensils,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Recipe as RecipeType } from "@shared/schema";
import AdminLayout from "./admin-layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";

export default function AdminRecipesPage() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedCuisine, setSelectedCuisine] = useState<string | null>(null);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [recipeToDelete, setRecipeToDelete] = useState<number | null>(null);

  const { data: recipes, isLoading } = useQuery<RecipeType[]>({
    queryKey: ["/api/admin/recipes"],
    staleTime: 30000,
  });

  const { data: categories } = useQuery<{id: string, name: string}[]>({
    queryKey: ["/api/categories"],
    enabled: !isLoading,
  });

  const { data: cuisines } = useQuery<{id: string, name: string}[]>({
    queryKey: ["/api/cuisines"],
    enabled: !isLoading,
  });

  const deleteRecipeMutation = useMutation({
    mutationFn: async (recipeId: number) => {
      await apiRequest("DELETE", `/api/admin/recipes/${recipeId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/recipes"] });
      toast({
        title: t("admin.recipe_deleted"),
        description: t("admin.recipe_deleted_description"),
      });
      setIsConfirmDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: t("admin.delete_failed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const confirmDelete = (recipeId: number) => {
    setRecipeToDelete(recipeId);
    setIsConfirmDialogOpen(true);
  };

  const handleDelete = () => {
    if (recipeToDelete) {
      deleteRecipeMutation.mutate(recipeToDelete);
    }
  };

  // Filter recipes based on search query, category and cuisine
  const filteredRecipes = recipes
    ? recipes.filter((recipe) => {
        const matchesSearch =
          searchQuery === "" ||
          recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (recipe.nameAr &&
            recipe.nameAr.toLowerCase().includes(searchQuery.toLowerCase())) ||
          (recipe.description &&
            recipe.description.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesCategory = !selectedCategory || recipe.category === selectedCategory;
        const matchesCuisine = !selectedCuisine || recipe.cuisine === selectedCuisine;

        return matchesSearch && matchesCategory && matchesCuisine;
      })
    : [];

  // Map difficulty levels to user-friendly display
  const getDifficultyDisplay = (difficulty: string) => {
    switch(difficulty?.toUpperCase()) {
      case 'EASY':
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
            <Check className="mr-1 h-3 w-3" />
            {t("admin.difficulty_easy")}
          </Badge>
        );
      case 'MEDIUM':
        return (
          <Badge variant="outline" className="bg-amber-100 text-amber-800 border-amber-300">
            <Coffee className="mr-1 h-3 w-3" />
            {t("admin.difficulty_medium")}
          </Badge>
        );
      case 'HARD':
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800 border-red-300">
            <Flame className="mr-1 h-3 w-3" />
            {t("admin.difficulty_hard")}
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {t("admin.difficulty_unknown")}
          </Badge>
        );
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-full items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <h2 className="font-playFair text-3xl font-bold tracking-tight">
            {t("admin.recipe_management")}
          </h2>

          <Button
            className="w-full md:w-auto"
            onClick={() => {
              toast({
                title: t("admin.coming_soon"),
                description: t("admin.feature_in_development"),
              });
            }}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            {t("admin.add_recipe")}
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{t("admin.recipes")}</CardTitle>
            <CardDescription>
              {t("admin.recipes_description", { count: filteredRecipes.length })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col space-y-4 md:flex-row md:space-x-4 md:space-y-0">
              <div className="relative w-full md:w-1/3">
                <Search className="text-muted-foreground absolute left-2.5 top-2.5 h-4 w-4" />
                <Input
                  placeholder={t("admin.search_recipes")}
                  className="pl-9"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <Select
                value={selectedCategory || ""}
                onValueChange={(value) =>
                  setSelectedCategory(value === "" ? null : value)
                }
              >
                <SelectTrigger className="w-full md:w-1/4">
                  <SelectValue placeholder={t("admin.filter_by_category")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t("admin.all_categories")}</SelectItem>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={selectedCuisine || ""}
                onValueChange={(value) =>
                  setSelectedCuisine(value === "" ? null : value)
                }
              >
                <SelectTrigger className="w-full md:w-1/4">
                  <SelectValue placeholder={t("admin.filter_by_cuisine")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">{t("admin.all_cuisines")}</SelectItem>
                  {cuisines?.map((cuisine) => (
                    <SelectItem key={cuisine.id} value={cuisine.id}>
                      {cuisine.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="mt-6 overflow-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>{t("admin.recipe")}</TableHead>
                    <TableHead>{t("admin.category")}</TableHead>
                    <TableHead>{t("admin.cuisine")}</TableHead>
                    <TableHead>{t("admin.difficulty")}</TableHead>
                    <TableHead>{t("admin.cook_time")}</TableHead>
                    <TableHead>{t("admin.rating")}</TableHead>
                    <TableHead className="w-[70px]">{t("admin.actions")}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRecipes.length > 0 ? (
                    filteredRecipes.map((recipe) => (
                      <TableRow key={recipe.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center">
                            <div className="mr-2 h-12 w-12 overflow-hidden rounded-md">
                              {recipe.imageUrl ? (
                                <img 
                                  src={recipe.imageUrl} 
                                  alt={recipe.name} 
                                  className="h-full w-full object-cover"
                                />
                              ) : (
                                <div className="bg-primary/10 flex h-full w-full items-center justify-center">
                                  <Utensils className="h-6 w-6 text-primary/40" />
                                </div>
                              )}
                            </div>
                            <div>
                              <div className="font-medium">{recipe.name}</div>
                              <div className="text-muted-foreground text-xs">
                                {recipe.nameAr}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            <Tag className="mr-1 h-3 w-3" />
                            {recipe.category || t("admin.uncategorized")}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {recipe.cuisine || t("admin.unknown")}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {getDifficultyDisplay(recipe.difficulty)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Clock className="text-muted-foreground mr-1 h-4 w-4" />
                            <span>
                              {recipe.cookTime ? 
                                `${recipe.cookTime} ${t("admin.minutes")}` : 
                                t("admin.unknown")}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Star className="text-yellow-500 mr-1 h-4 w-4" />
                            <span>{recipe.rating?.toFixed(1) || "-"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                className="h-8 w-8 p-0"
                              >
                                <span className="sr-only">{t("admin.open_menu")}</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>{t("admin.actions")}</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => {
                                  toast({
                                    title: t("admin.coming_soon"),
                                    description: t("admin.feature_in_development"),
                                  });
                                }}
                              >
                                <Eye className="mr-2 h-4 w-4" />
                                {t("admin.view_recipe")}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => {
                                  toast({
                                    title: t("admin.coming_soon"),
                                    description: t("admin.feature_in_development"),
                                  });
                                }}
                              >
                                <Edit className="mr-2 h-4 w-4" />
                                {t("admin.edit_recipe")}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                onClick={() => confirmDelete(recipe.id)}
                                className="text-red-600 focus:text-red-600"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                {t("admin.delete_recipe")}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} className="h-32 text-center">
                        <div className="flex flex-col items-center justify-center space-y-2">
                          <div className="bg-muted/30 flex h-12 w-12 items-center justify-center rounded-full">
                            <Search className="text-muted-foreground h-6 w-6" />
                          </div>
                          <div className="text-muted-foreground text-sm">
                            {t("admin.no_recipes_found")}
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
          <CardFooter className="flex items-center justify-between">
            <p className="text-muted-foreground text-sm">
              {t("admin.showing_recipes", { count: filteredRecipes.length })}
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                toast({
                  title: t("admin.coming_soon"),
                  description: t("admin.feature_in_development"),
                });
              }}
            >
              <Download className="mr-2 h-4 w-4" />
              {t("admin.export_recipes")}
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t("admin.confirm_delete")}</DialogTitle>
            <DialogDescription>
              {t("admin.delete_recipe_confirmation")}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsConfirmDialogOpen(false)}
            >
              {t("admin.cancel")}
            </Button>
            <Button
              onClick={handleDelete}
              variant="destructive"
              disabled={deleteRecipeMutation.isPending}
            >
              {deleteRecipeMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t("admin.deleting")}
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  {t("admin.delete")}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}