import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { format, subDays, subMonths } from "date-fns";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Loader2,
  BarChart4,
  TrendingUp,
  Activity,
  Users,
  BookOpen,
  Clock,
  Star,
  Utensils,
  Search,
  Heart,
  ShoppingBag,
  Calendar,
  Crown,
  Download,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import AdminLayout from "./admin-layout";
import { Button } from "@/components/ui/button";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Sector,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface AnalyticsData {
  // User metrics
  userGrowth: {
    date: string;
    total: number;
    new: number;
    premium: number;
  }[];
  userEngagement: {
    date: string;
    activeUsers: number;
    sessionsPerUser: number;
    avgSessionDuration: number;
  }[];
  userRetention: {
    cohort: string;
    week0: number;
    week1: number;
    week2: number;
    week3: number;
    week4: number;
  }[];
  
  // Content metrics
  recipeEngagement: {
    recipeId: string;
    recipeName: string;
    views: number;
    likes: number;
    cooks: number;
    avgRating: number;
  }[];
  topCategories: {
    name: string;
    count: number;
  }[];
  topCuisines: {
    name: string;
    count: number;
  }[];
  
  // Feature usage
  featureUsage: {
    feature: string;
    usageCount: number;
    percentUsers: number;
  }[];
  
  // Business metrics
  conversionRate: {
    date: string;
    rate: number;
    trials: number;
    conversions: number;
  }[];
  revenue: {
    date: string;
    amount: number;
    subscriptions: number;
  }[];
  churnRate: {
    date: string;
    rate: number;
    cancelations: number;
  }[];
}

// Generate color array for charts
const chartColors = [
  "#6A0DAD", // Royal Purple
  "#4B0082", // Indigo
  "#FFD700", // Gold
  "#C5A942", // Amber Gold
  "#9370DB", // Medium Purple
  "#B8860B", // Dark Goldenrod
  "#800080", // Purple
  "#DAA520", // Goldenrod
];

export default function AdminAnalyticsPage() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [timeRange, setTimeRange] = useState("month"); // week, month, quarter, year
  
  // Fetch analytics data from API
  const { data: analyticsData, isLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/admin/analytics", timeRange],
    staleTime: 300000, // 5 minutes
  });
  
  // For demo data, we'll simulate analytics data based on the selected time range
  const simulatedData: AnalyticsData = {
    userGrowth: Array.from({ length: timeRange === "week" ? 7 : timeRange === "month" ? 30 : 90 }).map((_, i) => {
      const date = timeRange === "week" 
        ? format(subDays(new Date(), 7 - i), "MMM dd")
        : format(subDays(new Date(), (timeRange === "month" ? 30 : 90) - i), "MMM dd");
      
      // Create an upward trend with some randomness
      const baseFactor = i / (timeRange === "week" ? 7 : timeRange === "month" ? 30 : 90);
      return {
        date,
        total: Math.floor(1000 + (3000 * baseFactor) + (Math.random() * 200 - 100)),
        new: Math.floor(10 + (50 * baseFactor) + (Math.random() * 20 - 10)),
        premium: Math.floor(100 + (900 * baseFactor) + (Math.random() * 50 - 25)),
      };
    }),
    
    userEngagement: Array.from({ length: timeRange === "week" ? 7 : timeRange === "month" ? 30 : 90 }).map((_, i) => {
      const date = timeRange === "week" 
        ? format(subDays(new Date(), 7 - i), "MMM dd")
        : format(subDays(new Date(), (timeRange === "month" ? 30 : 90) - i), "MMM dd");
      
      return {
        date,
        activeUsers: Math.floor(200 + (Math.random() * 100)),
        sessionsPerUser: 2 + (Math.random() * 2),
        avgSessionDuration: 5 + (Math.random() * 10),
      };
    }),
    
    userRetention: [
      {
        cohort: "Jan 1-7",
        week0: 100,
        week1: 75,
        week2: 60,
        week3: 55,
        week4: 52,
      },
      {
        cohort: "Jan 8-14",
        week0: 100,
        week1: 78,
        week2: 62,
        week3: 58,
        week4: 54,
      },
      {
        cohort: "Jan 15-21",
        week0: 100,
        week1: 80,
        week2: 70,
        week3: 65,
        week4: 60,
      },
      {
        cohort: "Jan 22-28",
        week0: 100,
        week1: 82,
        week2: 72,
        week3: 67,
        week4: 63,
      },
      {
        cohort: "Feb 1-7",
        week0: 100,
        week1: 85,
        week2: 75,
        week3: 70,
        week4: 68,
      },
    ],
    
    recipeEngagement: [
      { recipeId: "1", recipeName: "Shawarma", views: 1200, likes: 350, cooks: 180, avgRating: 4.7 },
      { recipeId: "2", recipeName: "Falafel Wrap", views: 980, likes: 280, cooks: 150, avgRating: 4.5 },
      { recipeId: "3", recipeName: "Biryani", views: 1500, likes: 420, cooks: 220, avgRating: 4.8 },
      { recipeId: "4", recipeName: "Chicken Tikka", views: 850, likes: 230, cooks: 120, avgRating: 4.4 },
      { recipeId: "5", recipeName: "Hummus", views: 750, likes: 200, cooks: 90, avgRating: 4.3 },
      { recipeId: "6", recipeName: "Tabbouleh", views: 600, likes: 150, cooks: 70, avgRating: 4.2 },
      { recipeId: "7", recipeName: "Mansaf", views: 950, likes: 300, cooks: 160, avgRating: 4.6 },
      { recipeId: "8", recipeName: "Kunafa", views: 1100, likes: 380, cooks: 90, avgRating: 4.9 },
    ],
    
    topCategories: [
      { name: "Main Dishes", count: 450 },
      { name: "Desserts", count: 320 },
      { name: "Appetizers", count: 280 },
      { name: "Soups", count: 180 },
      { name: "Salads", count: 220 },
      { name: "Beverages", count: 150 },
    ],
    
    topCuisines: [
      { name: "Middle Eastern", count: 380 },
      { name: "Indian", count: 310 },
      { name: "Italian", count: 260 },
      { name: "Mexican", count: 210 },
      { name: "Thai", count: 180 },
      { name: "French", count: 150 },
    ],
    
    featureUsage: [
      { feature: "Recipe Search", usageCount: 15000, percentUsers: 92 },
      { feature: "Meal Planning", usageCount: 8500, percentUsers: 65 },
      { feature: "Shopping List", usageCount: 7200, percentUsers: 58 },
      { feature: "Dietary Preferences", usageCount: 6300, percentUsers: 52 },
      { feature: "Smart Pantry", usageCount: 5800, percentUsers: 48 },
      { feature: "Recipe Sharing", usageCount: 4500, percentUsers: 38 },
    ],
    
    conversionRate: Array.from({ length: timeRange === "week" ? 7 : timeRange === "month" ? 30 : 90 }).map((_, i) => {
      const date = timeRange === "week" 
        ? format(subDays(new Date(), 7 - i), "MMM dd")
        : format(subDays(new Date(), (timeRange === "month" ? 30 : 90) - i), "MMM dd");
      
      const trialBase = 20 + Math.floor(Math.random() * 10);
      const conversionBase = 3 + Math.floor(Math.random() * 6);
      return {
        date,
        rate: (conversionBase / trialBase) * 100,
        trials: trialBase,
        conversions: conversionBase,
      };
    }),
    
    revenue: Array.from({ length: timeRange === "week" ? 7 : timeRange === "month" ? 30 : 90 }).map((_, i) => {
      const date = timeRange === "week" 
        ? format(subDays(new Date(), 7 - i), "MMM dd")
        : format(subDays(new Date(), (timeRange === "month" ? 30 : 90) - i), "MMM dd");
      
      const subs = 5 + Math.floor(Math.random() * 8);
      return {
        date,
        amount: subs * 5.99,
        subscriptions: subs,
      };
    }),
    
    churnRate: Array.from({ length: timeRange === "week" ? 7 : timeRange === "month" ? 30 : 90 }).map((_, i) => {
      const date = timeRange === "week" 
        ? format(subDays(new Date(), 7 - i), "MMM dd")
        : format(subDays(new Date(), (timeRange === "month" ? 30 : 90) - i), "MMM dd");
      
      const cancellations = Math.floor(Math.random() * 3);
      return {
        date,
        rate: cancellations * 2.5,
        cancelations: cancellations,
      };
    }),
  };

  // Use the fetched data or the simulated data for presentation
  const data = analyticsData || simulatedData;
  
  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-full items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <div>
            <h2 className="font-playFair text-3xl font-bold tracking-tight">
              {t("admin.advanced_analytics")}
            </h2>
            <p className="text-muted-foreground mt-1">
              {t("admin.analytics_description")}
            </p>
          </div>
          
          <div className="flex space-x-2">
            <Tabs defaultValue={timeRange} className="w-[300px]" onValueChange={setTimeRange}>
              <TabsList className="w-full">
                <TabsTrigger value="week">{t("admin.last_week")}</TabsTrigger>
                <TabsTrigger value="month">{t("admin.last_month")}</TabsTrigger>
                <TabsTrigger value="quarter">{t("admin.last_quarter")}</TabsTrigger>
              </TabsList>
            </Tabs>
            
            <Button variant="outline" size="icon" onClick={() => {
              toast({
                title: t("admin.coming_soon"),
                description: t("admin.export_analytics_feature"),
              });
            }}>
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        {/* Analytics dashboard */}
        <Tabs defaultValue="users" className="w-full">
          <TabsList className="w-full max-w-md grid grid-cols-4">
            <TabsTrigger value="users">
              <Users className="mr-2 h-4 w-4" />
              {t("admin.users")}
            </TabsTrigger>
            <TabsTrigger value="content">
              <BookOpen className="mr-2 h-4 w-4" />
              {t("admin.content")}
            </TabsTrigger>
            <TabsTrigger value="usage">
              <Activity className="mr-2 h-4 w-4" />
              {t("admin.usage")}
            </TabsTrigger>
            <TabsTrigger value="business">
              <BarChart4 className="mr-2 h-4 w-4" />
              {t("admin.business")}
            </TabsTrigger>
          </TabsList>
          
          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4 pt-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.user_growth")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={data.userGrowth}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="totalColor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6A0DAD" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#6A0DAD" stopOpacity={0.1}/>
                        </linearGradient>
                        <linearGradient id="premiumColor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#FFD700" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#FFD700" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{fontSize: 10}}
                        tickFormatter={(value) => timeRange === "week" ? value : value.split(" ")[0]}
                      />
                      <YAxis />
                      <Tooltip />
                      <Area 
                        type="monotone" 
                        dataKey="total" 
                        name={t("admin.total_users")}
                        stroke="#6A0DAD" 
                        fillOpacity={1} 
                        fill="url(#totalColor)" 
                      />
                      <Area 
                        type="monotone" 
                        dataKey="premium" 
                        name={t("admin.premium_users")}
                        stroke="#FFD700" 
                        fillOpacity={1} 
                        fill="url(#premiumColor)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.user_engagement")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={data.userEngagement}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{fontSize: 10}}
                        tickFormatter={(value) => timeRange === "week" ? value : value.split(" ")[0]}
                      />
                      <YAxis yAxisId="left" />
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      <Line 
                        yAxisId="left"
                        type="monotone" 
                        dataKey="activeUsers" 
                        name={t("admin.active_users")}
                        stroke="#6A0DAD" 
                        activeDot={{ r: 8 }} 
                      />
                      <Line 
                        yAxisId="right"
                        type="monotone" 
                        dataKey="sessionsPerUser" 
                        name={t("admin.sessions_per_user")}
                        stroke="#FFD700" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.user_retention")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={data.userRetention}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="cohort" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="week0" name={t("admin.week_0")} fill={chartColors[0]} />
                      <Bar dataKey="week1" name={t("admin.week_1")} fill={chartColors[1]} />
                      <Bar dataKey="week2" name={t("admin.week_2")} fill={chartColors[2]} />
                      <Bar dataKey="week3" name={t("admin.week_3")} fill={chartColors[3]} />
                      <Bar dataKey="week4" name={t("admin.week_4")} fill={chartColors[4]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Content Tab */}
          <TabsContent value="content" className="space-y-4 pt-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.top_recipes_engagement")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={data.recipeEngagement}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis 
                        dataKey="recipeName" 
                        type="category" 
                        tick={{ fontSize: 12 }} 
                      />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="views" name={t("admin.views")} fill={chartColors[0]} />
                      <Bar dataKey="likes" name={t("admin.likes")} fill={chartColors[1]} />
                      <Bar dataKey="cooks" name={t("admin.cooks")} fill={chartColors[2]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card className="lg:row-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.content_distribution")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[630px]">
                  <div className="space-y-6">
                    <div className="h-[300px]">
                      <h4 className="mb-4 text-sm font-medium">{t("admin.by_category")}</h4>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={data.topCategories}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="count"
                            nameKey="name"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {data.topCategories.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={chartColors[index % chartColors.length]} 
                              />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value, name) => [`${value} recipes`, name]} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    
                    <div className="h-[300px]">
                      <h4 className="mb-4 text-sm font-medium">{t("admin.by_cuisine")}</h4>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={data.topCuisines}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="count"
                            nameKey="name"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {data.topCuisines.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={chartColors[index % chartColors.length]} 
                              />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value, name) => [`${value} recipes`, name]} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.recipe_rating_distribution")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={data.recipeEngagement}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="recipeName" />
                      <YAxis domain={[0, 5]} />
                      <Tooltip />
                      <Bar 
                        dataKey="avgRating" 
                        name={t("admin.average_rating")} 
                        fill="#FFD700" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Feature Usage Tab */}
          <TabsContent value="usage" className="space-y-4 pt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.feature_usage")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={data.featureUsage}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis 
                        dataKey="feature" 
                        type="category" 
                        width={120}
                        tick={{ fontSize: 12 }} 
                      />
                      <Tooltip />
                      <Legend />
                      <Bar 
                        dataKey="usageCount" 
                        name={t("admin.usage_count")} 
                        fill="#6A0DAD" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.feature_adoption")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={data.featureUsage}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      layout="vertical"
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" domain={[0, 100]} />
                      <YAxis 
                        dataKey="feature" 
                        type="category" 
                        width={120}
                        tick={{ fontSize: 12 }} 
                      />
                      <Tooltip formatter={(value) => [`${value}%`, t("admin.percent_users")]} />
                      <Bar 
                        dataKey="percentUsers" 
                        name={t("admin.percent_users")} 
                        fill="#FFD700" 
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid gap-4 grid-cols-1 md:grid-cols-3">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("admin.search_usage")}</CardTitle>
                  <Search className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">15,230</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500 inline-flex items-center">
                      <TrendingUp className="mr-1 h-3 w-3" />
                      +12.5%
                    </span>
                    {" "}
                    {t("admin.from_previous", { period: t(`admin.${timeRange}`) })}
                  </p>
                  <div className="mt-4 h-[80px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={data.userEngagement.slice(-10)}
                      >
                        <Line
                          type="monotone"
                          dataKey="activeUsers"
                          stroke="#6A0DAD"
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("admin.favorites_usage")}</CardTitle>
                  <Heart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">8,954</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500 inline-flex items-center">
                      <TrendingUp className="mr-1 h-3 w-3" />
                      +8.2%
                    </span>
                    {" "}
                    {t("admin.from_previous", { period: t(`admin.${timeRange}`) })}
                  </p>
                  <div className="mt-4 h-[80px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={data.userEngagement.slice(-10)}
                      >
                        <Line
                          type="monotone"
                          dataKey="sessionsPerUser"
                          stroke="#FFD700"
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t("admin.meal_plans_created")}</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3,421</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-green-500 inline-flex items-center">
                      <TrendingUp className="mr-1 h-3 w-3" />
                      +15.7%
                    </span>
                    {" "}
                    {t("admin.from_previous", { period: t(`admin.${timeRange}`) })}
                  </p>
                  <div className="mt-4 h-[80px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={data.userEngagement.slice(-10)}
                      >
                        <Line
                          type="monotone"
                          dataKey="avgSessionDuration"
                          stroke="#4B0082"
                          strokeWidth={2}
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          {/* Business Tab */}
          <TabsContent value="business" className="space-y-4 pt-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card className="col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.revenue_trend")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={data.revenue}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <defs>
                        <linearGradient id="revenueColor" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#FFD700" stopOpacity={0.8}/>
                          <stop offset="95%" stopColor="#FFD700" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{fontSize: 10}}
                        tickFormatter={(value) => timeRange === "week" ? value : value.split(" ")[0]}
                      />
                      <YAxis />
                      <Tooltip formatter={(value, name) => [
                        name === "amount" ? `$${value.toFixed(2)}` : value,
                        name === "amount" ? t("admin.revenue") : t("admin.subscriptions")
                      ]} />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="amount" 
                        name={t("admin.revenue")}
                        stroke="#FFD700" 
                        fillOpacity={1} 
                        fill="url(#revenueColor)" 
                      />
                      <Line
                        type="monotone"
                        dataKey="subscriptions"
                        name={t("admin.subscriptions")}
                        stroke="#6A0DAD"
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.subscription_metrics")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium">{t("admin.monthly_recurring_revenue")}</div>
                        <div className="font-medium">$4,230.89</div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">
                          <TrendingUp className="mr-1 h-3 w-3" />
                          +18.2%
                        </span>
                        {" "}
                        {t("admin.from_previous_month")}
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium">{t("admin.active_subscriptions")}</div>
                        <div className="font-medium">706</div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">
                          <TrendingUp className="mr-1 h-3 w-3" />
                          +9.5%
                        </span>
                        {" "}
                        {t("admin.from_previous_month")}
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium">{t("admin.annual_recurring_revenue")}</div>
                        <div className="font-medium">$50,770.68</div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">
                          <TrendingUp className="mr-1 h-3 w-3" />
                          +21.8%
                        </span>
                        {" "}
                        {t("admin.from_previous_month")}
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-medium">{t("admin.average_revenue_per_user")}</div>
                        <div className="font-medium">$5.99</div>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        <span className="text-green-500 inline-flex items-center">
                          <TrendingUp className="mr-1 h-3 w-3" />
                          +0.0%
                        </span>
                        {" "}
                        {t("admin.from_previous_month")}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.conversion_churn_rates")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={data.conversionRate}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{fontSize: 10}}
                        tickFormatter={(value) => timeRange === "week" ? value : value.split(" ")[0]}
                      />
                      <YAxis />
                      <Tooltip formatter={(value, name) => [
                        `${value.toFixed(2)}%`,
                        name === "rate" ? t("admin.conversion_rate") : t("admin.churn_rate")
                      ]} />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="rate" 
                        name={t("admin.conversion_rate")}
                        stroke="#6A0DAD" 
                        activeDot={{ r: 8 }} 
                      />
                      <Line 
                        type="monotone" 
                        data={data.churnRate}
                        dataKey="rate" 
                        name={t("admin.churn_rate")}
                        stroke="#FF0000" 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">
                    {t("admin.premium_features_usage")}
                  </CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: t("admin.meal_planning"), value: 45 },
                          { name: t("admin.premium_recipes"), value: 30 },
                          { name: t("admin.smart_pantry"), value: 15 },
                          { name: t("admin.nutritional_analysis"), value: 10 },
                        ]}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      >
                        {chartColors.map((color, index) => (
                          <Cell key={`cell-${index}`} fill={color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value}%`, t("admin.usage")]} />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
}