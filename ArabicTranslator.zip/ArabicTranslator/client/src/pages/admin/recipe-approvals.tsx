import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Loader2,
  CheckCircle2,
  XCircle,
  FileWarning,
  Clock,
  Filter,
  Search,
  Eye,
  Clock8,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import AdminLayout from "./admin-layout";
import { format } from "date-fns";

// Recipe type
interface Recipe {
  id: number;
  external_id: string;
  name: string;
  name_ar: string;
  created_by: number;
  created_at: string;
  is_approved: boolean;
  is_user_generated: boolean;
  rejection_reason?: string;
  cuisine?: string;
  category?: string;
  submitter?: {
    id: number;
    username: string;
    email: string;
  };
  ingredients: {
    name: string;
    nameAr: string;
    quantity: string;
    unit?: string;
  }[];
  instructions: {
    step: number;
    text: string;
    textAr: string;
  }[];
  image_url?: string;
}

// Stats type
interface ApprovalStats {
  pendingCount: number;
  approvedCount: number;
  rejectedCount: number;
  totalCount: number;
  averageApprovalTime: string;
}

export default function RecipeApprovalsPage() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [viewMode, setViewMode] = useState<"preview" | "review">("preview");
  const [rejectionReason, setRejectionReason] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState<string>("pending");
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);

  const rejectionReasons = [
    "Incomplete recipe",
    "Inappropriate content",
    "Low quality images",
    "Missing crucial information",
    "Duplicate content",
    "Unclear instructions",
    "Unsafe cooking methods",
    "Other (please specify)",
  ];

  // Fetch pending recipes
  const {
    data: recipes = [],
    isLoading,
    isError,
  } = useQuery<Recipe[]>({
    queryKey: ["/api/admin/recipes/pending"],
    refetchInterval: 60000, // Refetch every minute
  });

  // Fetch approval stats (in a real app this would be an API call)
  const { data: stats } = useQuery<ApprovalStats>({
    queryKey: ["/api/admin/recipes/stats"],
    queryFn: async () => {
      // In a real application, this would be fetched from the server
      return {
        pendingCount: recipes.filter(r => !r.is_approved && r.is_user_generated).length,
        approvedCount: 127,
        rejectedCount: 43,
        totalCount: 127 + 43 + recipes.filter(r => !r.is_approved && r.is_user_generated).length,
        averageApprovalTime: "8 hours",
      };
    },
    enabled: !isLoading,
  });

  // Approve recipe mutation
  const approveMutation = useMutation({
    mutationFn: async (recipeId: string) => {
      const response = await apiRequest("POST", `/api/admin/recipes/${recipeId}/approval`, {
        action: "approve",
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t("admin.recipe_approved"),
        description: t("admin.recipe_approved_description"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/recipes/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/recipes/stats"] });
      setReviewDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: t("admin.approval_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Reject recipe mutation
  const rejectMutation = useMutation({
    mutationFn: async ({ recipeId, reason }: { recipeId: string; reason: string }) => {
      const response = await apiRequest("POST", `/api/admin/recipes/${recipeId}/approval`, {
        action: "reject",
        rejectionReason: reason,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t("admin.recipe_rejected"),
        description: t("admin.recipe_rejected_description"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/recipes/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/recipes/stats"] });
      setReviewDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: t("admin.rejection_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter recipes based on search and status
  const filteredRecipes = recipes.filter((recipe) => {
    // Search filter
    const matchesSearch =
      searchQuery === "" ||
      recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      recipe.submitter?.username?.toLowerCase().includes(searchQuery.toLowerCase());

    // Status filter
    let matchesStatus = true;
    if (selectedStatus === "pending") {
      matchesStatus = !recipe.is_approved;
    } else if (selectedStatus === "approved") {
      matchesStatus = recipe.is_approved === true;
    } else if (selectedStatus === "rejected") {
      matchesStatus = recipe.is_approved === false && recipe.rejection_reason !== undefined;
    }

    return matchesSearch && matchesStatus;
  });

  const handleOpenReview = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setRejectionReason("");
    setReviewDialogOpen(true);
  };

  const handleOpenPreview = (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    setPreviewDialogOpen(true);
  };

  const handleApprove = () => {
    if (selectedRecipe) {
      approveMutation.mutate(selectedRecipe.external_id);
    }
  };

  const handleReject = () => {
    if (selectedRecipe && rejectionReason.trim()) {
      rejectMutation.mutate({
        recipeId: selectedRecipe.external_id,
        reason: rejectionReason,
      });
    } else {
      toast({
        title: t("admin.validation_error"),
        description: t("admin.rejection_reason_required"),
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-full items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  if (isError) {
    return (
      <AdminLayout>
        <div className="flex h-full flex-col items-center justify-center">
          <FileWarning className="h-12 w-12 text-destructive" />
          <h2 className="mt-4 text-xl font-semibold">
            {t("admin.error_loading_approvals")}
          </h2>
          <p className="text-muted-foreground mt-2">
            {t("admin.error_loading_approvals_description")}
          </p>
          <Button
            className="mt-4"
            onClick={() => {
              queryClient.invalidateQueries({ queryKey: ["/api/admin/recipes/pending"] });
            }}
          >
            {t("admin.try_again")}
          </Button>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h2 className="font-playFair text-3xl font-bold tracking-tight">
            {t("admin.recipe_approvals")}
          </h2>
          <p className="text-muted-foreground mt-1">
            {t("admin.recipe_approvals_description")}
          </p>
        </div>

        {/* Stats cards */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.pending_approvals")}
              </CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.pendingCount || 0}</div>
              <p className="text-xs text-muted-foreground">
                {t("admin.avg_time", { time: stats?.averageApprovalTime || "N/A" })}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.approved_recipes")}
              </CardTitle>
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.approvedCount || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.totalCount
                  ? t("admin.approval_rate", {
                      rate: Math.round(
                        (stats.approvedCount / stats.totalCount) * 100
                      ),
                    })
                  : t("admin.no_data")}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.rejected_recipes")}
              </CardTitle>
              <XCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.rejectedCount || 0}</div>
              <p className="text-xs text-muted-foreground">
                {stats?.totalCount
                  ? t("admin.rejection_rate", {
                      rate: Math.round(
                        (stats.rejectedCount / stats.totalCount) * 100
                      ),
                    })
                  : t("admin.no_data")}
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.total_submissions")}
              </CardTitle>
              <Clock8 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalCount || 0}</div>
              <p className="text-xs text-muted-foreground">
                {t("admin.all_time")}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filtering and search */}
        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div className="flex space-x-2">
            <div className="flex w-full max-w-sm items-center space-x-2">
              <Input
                placeholder={t("admin.search_recipes")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="h-9"
              />
              <Button
                variant="outline"
                size="sm"
                className="h-9 px-3"
                onClick={() => setSearchQuery("")}
                disabled={!searchQuery}
              >
                {t("admin.clear")}
              </Button>
            </div>
            <Select
              value={selectedStatus}
              onValueChange={setSelectedStatus}
            >
              <SelectTrigger className="h-9 w-[140px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">{t("admin.pending")}</SelectItem>
                <SelectItem value="approved">{t("admin.approved")}</SelectItem>
                <SelectItem value="rejected">{t("admin.rejected")}</SelectItem>
                <SelectItem value="all">{t("admin.all")}</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* List of recipes for approval */}
        <Card>
          <CardHeader>
            <CardTitle>{t("admin.submitted_recipes")}</CardTitle>
            <CardDescription>
              {t("admin.review_and_approve_description")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableCaption>
                {filteredRecipes.length === 0
                  ? t("admin.no_recipes_found")
                  : t("admin.recipes_count", { count: filteredRecipes.length })}
              </TableCaption>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("admin.recipe_name")}</TableHead>
                  <TableHead>{t("admin.submitted_by")}</TableHead>
                  <TableHead>{t("admin.submitted_on")}</TableHead>
                  <TableHead>{t("admin.status")}</TableHead>
                  <TableHead className="text-right">{t("admin.actions")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecipes.map((recipe) => (
                  <TableRow key={recipe.id}>
                    <TableCell className="font-medium">{recipe.name}</TableCell>
                    <TableCell>
                      {recipe.submitter?.username || "User " + recipe.created_by}
                    </TableCell>
                    <TableCell>
                      {recipe.created_at
                        ? format(new Date(recipe.created_at), "MMM dd, yyyy")
                        : "N/A"}
                    </TableCell>
                    <TableCell>
                      {recipe.is_approved === true ? (
                        <Badge className="bg-green-500 hover:bg-green-600">
                          {t("admin.approved")}
                        </Badge>
                      ) : recipe.rejection_reason ? (
                        <Badge variant="destructive">
                          {t("admin.rejected")}
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-amber-100 text-amber-800 hover:bg-amber-200">
                          {t("admin.pending")}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleOpenPreview(recipe)}
                        >
                          <Eye className="mr-1 h-4 w-4" />
                          {t("admin.view")}
                        </Button>
                        {!recipe.is_approved && !recipe.rejection_reason && (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => handleOpenReview(recipe)}
                          >
                            {t("admin.review")}
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Recipe Preview Dialog */}
        <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
          <DialogContent className="sm:max-w-[900px]">
            <DialogHeader>
              <DialogTitle className="font-playFair text-2xl">
                {selectedRecipe?.name}
              </DialogTitle>
              <DialogDescription>
                {t("admin.submitted_by_user", {
                  user: selectedRecipe?.submitter?.username || "User " + selectedRecipe?.created_by,
                  date: selectedRecipe?.created_at
                    ? format(new Date(selectedRecipe.created_at), "MMM dd, yyyy")
                    : "N/A",
                })}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-6 md:grid-cols-2">
              <div>
                {selectedRecipe?.image_url ? (
                  <div className="aspect-video w-full overflow-hidden rounded-md">
                    <img
                      src={selectedRecipe.image_url}
                      alt={selectedRecipe.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="flex aspect-video w-full items-center justify-center rounded-md border">
                    <p className="text-muted-foreground">{t("admin.no_image")}</p>
                  </div>
                )}

                <div className="mt-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="font-medium">{t("admin.category")}:</span>
                    <span>{selectedRecipe?.category || t("admin.not_specified")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">{t("admin.cuisine")}:</span>
                    <span>{selectedRecipe?.cuisine || t("admin.not_specified")}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">{t("admin.status")}:</span>
                    <span>
                      {selectedRecipe?.is_approved === true
                        ? t("admin.approved")
                        : selectedRecipe?.rejection_reason
                        ? t("admin.rejected")
                        : t("admin.pending")}
                    </span>
                  </div>
                  {selectedRecipe?.rejection_reason && (
                    <div className="mt-4">
                      <span className="font-medium">{t("admin.rejection_reason")}:</span>
                      <p className="mt-1 rounded-md border border-destructive bg-destructive/10 p-2 text-sm">
                        {selectedRecipe.rejection_reason}
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="font-playFair text-lg font-medium">
                    {t("admin.ingredients")}
                  </h3>
                  <ul className="mt-2 list-inside list-disc space-y-1">
                    {selectedRecipe?.ingredients.map((ingredient, i) => (
                      <li key={i}>
                        {ingredient.quantity} {ingredient.unit}{" "}
                        {ingredient.name}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h3 className="font-playFair text-lg font-medium">
                    {t("admin.instructions")}
                  </h3>
                  <ol className="mt-2 list-inside list-decimal space-y-2">
                    {selectedRecipe?.instructions.map((instruction) => (
                      <li key={instruction.step} className="pl-1">
                        <span className="ml-2">{instruction.text}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setPreviewDialogOpen(false)}
              >
                {t("admin.close")}
              </Button>
              {!selectedRecipe?.is_approved && !selectedRecipe?.rejection_reason && (
                <Button onClick={() => {
                  setPreviewDialogOpen(false);
                  handleOpenReview(selectedRecipe!);
                }}>
                  {t("admin.review")}
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Recipe Review Dialog */}
        <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
          <DialogContent className="sm:max-w-[700px]">
            <DialogHeader>
              <DialogTitle className="font-playFair text-2xl">
                {t("admin.review_recipe")}
              </DialogTitle>
              <DialogDescription>
                {t("admin.review_recipe_description")}
              </DialogDescription>
            </DialogHeader>

            <Tabs
              value={viewMode}
              onValueChange={(value) => setViewMode(value as "preview" | "review")}
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="preview">
                  <Eye className="mr-2 h-4 w-4" />
                  {t("admin.preview")}
                </TabsTrigger>
                <TabsTrigger value="review">
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  {t("admin.decision")}
                </TabsTrigger>
              </TabsList>

              <TabsContent value="preview" className="mt-4">
                <div className="max-h-[400px] overflow-y-auto">
                  {selectedRecipe?.image_url && (
                    <div className="mb-4 aspect-video max-h-[200px] overflow-hidden rounded-md">
                      <img
                        src={selectedRecipe.image_url}
                        alt={selectedRecipe.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  )}

                  <h3 className="font-playFair text-xl">{selectedRecipe?.name}</h3>
                  <p className="text-muted-foreground mb-4">
                    {t("admin.submitted_by_user", {
                      user: selectedRecipe?.submitter?.username || "User " + selectedRecipe?.created_by,
                      date: selectedRecipe?.created_at
                        ? format(new Date(selectedRecipe.created_at), "MMM dd, yyyy")
                        : "N/A",
                    })}
                  </p>

                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium">{t("admin.ingredients")}</h4>
                      <ul className="mt-2 list-inside list-disc space-y-1">
                        {selectedRecipe?.ingredients.map((ingredient, i) => (
                          <li key={i}>
                            {ingredient.quantity} {ingredient.unit}{" "}
                            {ingredient.name}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium">{t("admin.instructions")}</h4>
                      <ol className="mt-2 list-inside list-decimal space-y-2">
                        {selectedRecipe?.instructions.map((instruction) => (
                          <li key={instruction.step} className="pl-1">
                            <span className="ml-2">{instruction.text}</span>
                          </li>
                        ))}
                      </ol>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="review" className="mt-4">
                <div className="space-y-4">
                  <div className="rounded-md border p-4">
                    <h3 className="font-medium">{t("admin.approval_criteria")}</h3>
                    <ul className="mt-2 space-y-2">
                      <li className="flex items-start space-x-2">
                        <Checkbox id="criteria-1" />
                        <label
                          htmlFor="criteria-1"
                          className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("admin.criteria_complete")}
                        </label>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Checkbox id="criteria-2" />
                        <label
                          htmlFor="criteria-2"
                          className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("admin.criteria_appropriate")}
                        </label>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Checkbox id="criteria-3" />
                        <label
                          htmlFor="criteria-3"
                          className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("admin.criteria_original")}
                        </label>
                      </li>
                      <li className="flex items-start space-x-2">
                        <Checkbox id="criteria-4" />
                        <label
                          htmlFor="criteria-4"
                          className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {t("admin.criteria_clear")}
                        </label>
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">{t("admin.decision")}</h3>
                    <div className="flex space-x-2">
                      <Button
                        variant="default"
                        className="flex-1 bg-green-600 hover:bg-green-700"
                        onClick={handleApprove}
                        disabled={approveMutation.isPending}
                      >
                        {approveMutation.isPending && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {t("admin.approve")}
                      </Button>
                      <Button
                        variant="destructive"
                        className="flex-1"
                        onClick={() => {
                          // Just toggle the next section
                        }}
                      >
                        {t("admin.reject")}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h3 className="font-medium">{t("admin.rejection_reason")}</h3>
                    <Select
                      onValueChange={(value) => {
                        if (value === "other") {
                          setRejectionReason("");
                        } else {
                          setRejectionReason(value);
                        }
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={t("admin.select_reason")} />
                      </SelectTrigger>
                      <SelectContent>
                        {rejectionReasons.map((reason) => (
                          <SelectItem key={reason} value={reason}>
                            {reason}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Textarea
                      placeholder={t("admin.custom_reason")}
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      className="min-h-[100px]"
                    />
                    <Button
                      variant="destructive"
                      className="w-full"
                      onClick={handleReject}
                      disabled={!rejectionReason.trim() || rejectMutation.isPending}
                    >
                      {rejectMutation.isPending && (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      )}
                      {t("admin.confirm_rejection")}
                    </Button>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setReviewDialogOpen(false)}
              >
                {t("admin.cancel")}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}