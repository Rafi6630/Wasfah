import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import {
  Loader2,
  Save,
  Server,
  Settings,
  FileCheck,
  Bell,
  Key,
  Mail,
  Shield,
  User,
  Wrench,
  Bot,
  Globe,
  ListFilter,
} from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import AdminLayout from "./admin-layout";
import { Textarea } from "@/components/ui/textarea";

// Define form schemas
const generalSettingsSchema = z.object({
  siteName: z.string().min(2, { message: "Site name is required" }),
  siteDescription: z.string(),
  logo: z.string().optional(),
  featuredRecipesCount: z.coerce.number().int().min(1).max(20),
  defaultLanguage: z.string(),
  enablePublicRecipes: z.boolean(),
  enableRecipeSubmissions: z.boolean(),
  requireApproval: z.boolean(),
});

const emailSettingsSchema = z.object({
  emailFromName: z.string(),
  emailFromAddress: z.string().email(),
  emailSignature: z.string(),
  welcomeEmailEnabled: z.boolean(),
  notificationEmailsEnabled: z.boolean(),
  digestEmailsEnabled: z.boolean(),
  digestFrequency: z.string(),
});

const apiSettingsSchema = z.object({
  openaiApiKey: z.string().optional(),
  stripePublicKey: z.string().optional(),
  stripeSecretKey: z.string().optional(),
  stripeWebhookSecret: z.string().optional(),
});

// Mock settings to initialize forms (in real app, this would come from API)
const mockSettings = {
  general: {
    siteName: "Recipes Gourmet AI",
    siteDescription: "AI-powered recipe recommendations with culinary elegance",
    logo: "/logo.png",
    featuredRecipesCount: 8,
    defaultLanguage: "en",
    enablePublicRecipes: true,
    enableRecipeSubmissions: true,
    requireApproval: true,
  },
  email: {
    emailFromName: "Recipes Gourmet AI",
    emailFromAddress: "notifications@recipesgourmet.ai",
    emailSignature: "The Recipes Gourmet AI Team",
    welcomeEmailEnabled: true,
    notificationEmailsEnabled: true,
    digestEmailsEnabled: false,
    digestFrequency: "weekly",
  },
  api: {
    openaiApiKey: "•••••••••••••••••••••••••••••••",
    stripePublicKey: "pk_•••••••••••••••••••••••••",
    stripeSecretKey: "sk_•••••••••••••••••••••••••",
    stripeWebhookSecret: "whsec_••••••••••••••••••",
  },
  recipe: {
    autoTagging: true,
    enableAIDescriptions: true,
    maximumUserSubmissionsPerDay: 5,
    enableComments: true,
    requireLoginToView: false,
    defaultPrivacy: "public",
  },
  moderation: {
    autoModerateComments: true,
    autoModerateRecipes: true,
    profanityFilter: true,
    adminNotificationOnSubmission: true,
    maximumPendingQueue: 100,
    rejectionReasons: [
      "Incomplete recipe",
      "Inappropriate content",
      "Low quality",
      "Duplicate content",
      "Copyright concerns",
    ],
  },
};

const contentApprovalLevels = [
  { value: "none", label: "No approval needed" },
  { value: "minimal", label: "Basic auto-approval" },
  { value: "moderate", label: "Auto-approval with human review flags" },
  { value: "strict", label: "All content requires approval" },
];

export default function AdminSettingsPage() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");

  // Load settings (in a real app, this would fetch from API)
  const { data: settings, isLoading } = useQuery({
    queryKey: ["/api/admin/settings"],
    queryFn: async () => {
      // In a real app, fetch from API
      return mockSettings;
    },
  });

  // Setup forms
  const generalForm = useForm<z.infer<typeof generalSettingsSchema>>({
    resolver: zodResolver(generalSettingsSchema),
    defaultValues: settings?.general || {},
  });

  const emailForm = useForm<z.infer<typeof emailSettingsSchema>>({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: settings?.email || {},
  });

  const apiForm = useForm<z.infer<typeof apiSettingsSchema>>({
    resolver: zodResolver(apiSettingsSchema),
    defaultValues: settings?.api || {},
  });

  // Save mutations
  const saveGeneralSettings = useMutation({
    mutationFn: async (data: z.infer<typeof generalSettingsSchema>) => {
      const response = await apiRequest("POST", "/api/admin/settings/general", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t("admin.settings_saved"),
        description: t("admin.general_settings_updated"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
    },
    onError: (error) => {
      toast({
        title: t("admin.settings_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveEmailSettings = useMutation({
    mutationFn: async (data: z.infer<typeof emailSettingsSchema>) => {
      const response = await apiRequest("POST", "/api/admin/settings/email", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t("admin.settings_saved"),
        description: t("admin.email_settings_updated"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
    },
    onError: (error) => {
      toast({
        title: t("admin.settings_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveApiSettings = useMutation({
    mutationFn: async (data: z.infer<typeof apiSettingsSchema>) => {
      const response = await apiRequest("POST", "/api/admin/settings/api", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: t("admin.settings_saved"),
        description: t("admin.api_settings_updated"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/settings"] });
    },
    onError: (error) => {
      toast({
        title: t("admin.settings_error"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submissions
  const onSubmitGeneral = (data: z.infer<typeof generalSettingsSchema>) => {
    saveGeneralSettings.mutate(data);
  };

  const onSubmitEmail = (data: z.infer<typeof emailSettingsSchema>) => {
    saveEmailSettings.mutate(data);
  };

  const onSubmitApi = (data: z.infer<typeof apiSettingsSchema>) => {
    saveApiSettings.mutate(data);
  };

  // Loading state
  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-full items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h2 className="font-playFair text-3xl font-bold tracking-tight">
            {t("admin.settings")}
          </h2>
          <p className="text-muted-foreground mt-1">
            {t("admin.settings_description")}
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-3xl grid-cols-5">
            <TabsTrigger value="general">
              <Settings className="mr-2 h-4 w-4" />
              {t("admin.general")}
            </TabsTrigger>
            <TabsTrigger value="email">
              <Mail className="mr-2 h-4 w-4" />
              {t("admin.email")}
            </TabsTrigger>
            <TabsTrigger value="api">
              <Key className="mr-2 h-4 w-4" />
              {t("admin.api_keys")}
            </TabsTrigger>
            <TabsTrigger value="recipes">
              <FileCheck className="mr-2 h-4 w-4" />
              {t("admin.recipes")}
            </TabsTrigger>
            <TabsTrigger value="moderation">
              <Shield className="mr-2 h-4 w-4" />
              {t("admin.moderation")}
            </TabsTrigger>
          </TabsList>

          <div className="mt-6">
            {/* General Settings */}
            <TabsContent value="general" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.general_settings")}</CardTitle>
                  <CardDescription>
                    {t("admin.general_settings_description")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...generalForm}>
                    <form
                      id="general-form"
                      onSubmit={generalForm.handleSubmit(onSubmitGeneral)}
                      className="space-y-6"
                    >
                      <div className="grid gap-6 md:grid-cols-2">
                        <FormField
                          control={generalForm.control}
                          name="siteName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.site_name")}</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={generalForm.control}
                          name="featuredRecipesCount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.featured_recipes_count")}</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  min={1}
                                  max={20}
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                              <FormDescription>
                                {t("admin.featured_recipes_count_description")}
                              </FormDescription>
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={generalForm.control}
                        name="siteDescription"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("admin.site_description")}</FormLabel>
                            <FormControl>
                              <Textarea
                                rows={3}
                                className="resize-none"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={generalForm.control}
                        name="defaultLanguage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("admin.default_language")}</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a language" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="en">English</SelectItem>
                                <SelectItem value="ar">Arabic</SelectItem>
                                <SelectItem value="fr">French</SelectItem>
                                <SelectItem value="es">Spanish</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="space-y-4 rounded-md border p-4">
                        <h3 className="text-lg font-medium">
                          {t("admin.recipe_submissions")}
                        </h3>

                        <FormField
                          control={generalForm.control}
                          name="enablePublicRecipes"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>{t("admin.enable_public_recipes")}</FormLabel>
                                <FormDescription>
                                  {t("admin.enable_public_recipes_description")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={generalForm.control}
                          name="enableRecipeSubmissions"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>{t("admin.enable_recipe_submissions")}</FormLabel>
                                <FormDescription>
                                  {t("admin.enable_recipe_submissions_description")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={generalForm.control}
                          name="requireApproval"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>{t("admin.require_approval")}</FormLabel>
                                <FormDescription>
                                  {t("admin.require_approval_description")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button
                    form="general-form"
                    type="submit"
                    disabled={saveGeneralSettings.isPending}
                  >
                    {saveGeneralSettings.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {!saveGeneralSettings.isPending && (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    {t("admin.save_changes")}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Email Settings */}
            <TabsContent value="email" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.email_settings")}</CardTitle>
                  <CardDescription>
                    {t("admin.email_settings_description")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...emailForm}>
                    <form
                      id="email-form"
                      onSubmit={emailForm.handleSubmit(onSubmitEmail)}
                      className="space-y-6"
                    >
                      <div className="grid gap-6 md:grid-cols-2">
                        <FormField
                          control={emailForm.control}
                          name="emailFromName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.email_from_name")}</FormLabel>
                              <FormControl>
                                <Input {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={emailForm.control}
                          name="emailFromAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.email_from_address")}</FormLabel>
                              <FormControl>
                                <Input {...field} type="email" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={emailForm.control}
                        name="emailSignature"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t("admin.email_signature")}</FormLabel>
                            <FormControl>
                              <Textarea
                                rows={3}
                                className="resize-none"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="space-y-4 rounded-md border p-4">
                        <h3 className="text-lg font-medium">
                          {t("admin.email_notifications")}
                        </h3>

                        <FormField
                          control={emailForm.control}
                          name="welcomeEmailEnabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>{t("admin.welcome_email")}</FormLabel>
                                <FormDescription>
                                  {t("admin.welcome_email_description")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={emailForm.control}
                          name="notificationEmailsEnabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>{t("admin.notification_emails")}</FormLabel>
                                <FormDescription>
                                  {t("admin.notification_emails_description")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={emailForm.control}
                          name="digestEmailsEnabled"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                              <div className="space-y-0.5">
                                <FormLabel>{t("admin.digest_emails")}</FormLabel>
                                <FormDescription>
                                  {t("admin.digest_emails_description")}
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />

                        {emailForm.watch("digestEmailsEnabled") && (
                          <FormField
                            control={emailForm.control}
                            name="digestFrequency"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>{t("admin.digest_frequency")}</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select frequency" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="daily">{t("admin.daily")}</SelectItem>
                                    <SelectItem value="weekly">{t("admin.weekly")}</SelectItem>
                                    <SelectItem value="monthly">{t("admin.monthly")}</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                      </div>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button
                    form="email-form"
                    type="submit"
                    disabled={saveEmailSettings.isPending}
                  >
                    {saveEmailSettings.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {!saveEmailSettings.isPending && (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    {t("admin.save_changes")}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* API Settings */}
            <TabsContent value="api" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.api_settings")}</CardTitle>
                  <CardDescription>
                    {t("admin.api_settings_description")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...apiForm}>
                    <form
                      id="api-form"
                      onSubmit={apiForm.handleSubmit(onSubmitApi)}
                      className="space-y-6"
                    >
                      <div className="space-y-4 rounded-md border p-4">
                        <h3 className="text-lg font-medium">
                          {t("admin.openai_integration")}
                        </h3>

                        <FormField
                          control={apiForm.control}
                          name="openaiApiKey"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.openai_api_key")}</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormDescription>
                                {t("admin.openai_api_key_description")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="space-y-4 rounded-md border p-4">
                        <h3 className="text-lg font-medium">
                          {t("admin.stripe_integration")}
                        </h3>

                        <FormField
                          control={apiForm.control}
                          name="stripePublicKey"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.stripe_public_key")}</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormDescription>
                                {t("admin.starts_with_pk")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={apiForm.control}
                          name="stripeSecretKey"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.stripe_secret_key")}</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormDescription>
                                {t("admin.starts_with_sk")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={apiForm.control}
                          name="stripeWebhookSecret"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>{t("admin.stripe_webhook_secret")}</FormLabel>
                              <FormControl>
                                <Input type="password" {...field} />
                              </FormControl>
                              <FormDescription>
                                {t("admin.starts_with_whsec")}
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </form>
                  </Form>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button
                    form="api-form"
                    type="submit"
                    disabled={saveApiSettings.isPending}
                  >
                    {saveApiSettings.isPending && (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    )}
                    {!saveApiSettings.isPending && (
                      <Save className="mr-2 h-4 w-4" />
                    )}
                    {t("admin.save_changes")}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Recipe Settings */}
            <TabsContent value="recipes" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.recipe_settings")}</CardTitle>
                  <CardDescription>
                    {t("admin.recipe_settings_description")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4 rounded-md border p-4">
                    <h3 className="text-lg font-medium">
                      {t("admin.ai_features")}
                    </h3>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.auto_tagging")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.auto_tagging_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.recipe.autoTagging}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.ai_descriptions")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.ai_descriptions_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.recipe.enableAIDescriptions}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>
                  </div>

                  <div className="space-y-4 rounded-md border p-4">
                    <h3 className="text-lg font-medium">
                      {t("admin.user_submissions")}
                    </h3>

                    <div className="flex flex-row items-center space-x-4">
                      <div className="w-full max-w-sm">
                        <label className="text-sm font-medium leading-none">
                          {t("admin.max_submissions_per_day")}
                        </label>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.max_submissions_per_day_description")}
                        </p>
                      </div>
                      <Input
                        type="number"
                        min={1}
                        className="w-20"
                        value={settings?.recipe.maximumUserSubmissionsPerDay}
                        onChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="flex flex-row items-center space-x-4">
                      <div className="w-full max-w-sm">
                        <label className="text-sm font-medium leading-none">
                          {t("admin.default_privacy")}
                        </label>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.default_privacy_description")}
                        </p>
                      </div>
                      <Select defaultValue={settings?.recipe.defaultPrivacy}>
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Privacy setting" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="public">{t("admin.public")}</SelectItem>
                          <SelectItem value="followers">{t("admin.followers_only")}</SelectItem>
                          <SelectItem value="private">{t("admin.private")}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4 rounded-md border p-4">
                    <h3 className="text-lg font-medium">
                      {t("admin.engagement_features")}
                    </h3>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.enable_comments")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.enable_comments_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.recipe.enableComments}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.require_login")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.require_login_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.recipe.requireLoginToView}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button
                    onClick={() => {
                      // In a real app, this would save the recipe settings
                      toast({
                        title: t("admin.settings_saved"),
                        description: t("admin.recipe_settings_updated"),
                      });
                    }}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {t("admin.save_changes")}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            {/* Moderation Settings */}
            <TabsContent value="moderation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>{t("admin.moderation_settings")}</CardTitle>
                  <CardDescription>
                    {t("admin.moderation_settings_description")}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4 rounded-md border p-4">
                    <h3 className="text-lg font-medium">
                      {t("admin.automated_moderation")}
                    </h3>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.comment_moderation")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.comment_moderation_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.moderation.autoModerateComments}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.recipe_moderation")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.recipe_moderation_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.moderation.autoModerateRecipes}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.profanity_filter")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.profanity_filter_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.moderation.profanityFilter}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>
                  </div>

                  <div className="space-y-4 rounded-md border p-4">
                    <h3 className="text-lg font-medium">
                      {t("admin.approval_workflow")}
                    </h3>

                    <div className="flex flex-row items-center space-x-4">
                      <div className="w-full max-w-sm">
                        <label className="text-sm font-medium leading-none">
                          {t("admin.approval_level")}
                        </label>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.approval_level_description")}
                        </p>
                      </div>
                      <Select defaultValue={contentApprovalLevels[2].value}>
                        <SelectTrigger className="w-[280px]">
                          <SelectValue placeholder="Select approval level" />
                        </SelectTrigger>
                        <SelectContent>
                          {contentApprovalLevels.map((level) => (
                            <SelectItem key={level.value} value={level.value}>
                              {level.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex flex-row items-center justify-between rounded-md border p-3">
                      <div className="space-y-0.5">
                        <div className="font-medium">{t("admin.admin_notifications")}</div>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.admin_notifications_description")}
                        </p>
                      </div>
                      <Switch
                        checked={settings?.moderation.adminNotificationOnSubmission}
                        onCheckedChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="flex flex-row items-center space-x-4">
                      <div className="w-full max-w-sm">
                        <label className="text-sm font-medium leading-none">
                          {t("admin.max_pending_queue")}
                        </label>
                        <p className="text-muted-foreground text-sm">
                          {t("admin.max_pending_queue_description")}
                        </p>
                      </div>
                      <Input
                        type="number"
                        min={10}
                        className="w-20"
                        value={settings?.moderation.maximumPendingQueue}
                        onChange={() => {
                          // In a real app, this would update the settings
                          toast({
                            title: t("admin.feature_not_implemented"),
                            description: t("admin.feature_coming_soon"),
                          });
                        }}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium leading-none">
                        {t("admin.rejection_reasons")}
                      </label>
                      <p className="text-muted-foreground text-sm">
                        {t("admin.rejection_reasons_description")}
                      </p>
                      <div className="grid gap-2">
                        {settings?.moderation.rejectionReasons.map((reason, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <Input value={reason} readOnly className="flex-1" />
                            <Button
                              variant="outline"
                              size="icon"
                              onClick={() => {
                                // In a real app, this would remove the reason
                                toast({
                                  title: t("admin.feature_not_implemented"),
                                  description: t("admin.feature_coming_soon"),
                                });
                              }}
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="24"
                                height="24"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                              >
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                              </svg>
                            </Button>
                          </div>
                        ))}
                        <div className="flex items-center space-x-2">
                          <Input
                            placeholder={t("admin.new_reason")}
                            className="flex-1"
                          />
                          <Button
                            variant="outline"
                            onClick={() => {
                              // In a real app, this would add a new reason
                              toast({
                                title: t("admin.feature_not_implemented"),
                                description: t("admin.feature_coming_soon"),
                              });
                            }}
                          >
                            {t("admin.add")}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end">
                  <Button
                    onClick={() => {
                      // In a real app, this would save the moderation settings
                      toast({
                        title: t("admin.settings_saved"),
                        description: t("admin.moderation_settings_updated"),
                      });
                    }}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {t("admin.save_changes")}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </AdminLayout>
  );
}