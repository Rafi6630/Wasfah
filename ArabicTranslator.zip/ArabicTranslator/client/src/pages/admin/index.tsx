import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TabsContent, Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2,
  TrendingUp,
  Users,
  BookOpen,
  Tag,
  ChefHat,
  Star,
  BadgePercent,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import AdminLayout from "./admin-layout";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Sector,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

interface AdminStats {
  totalUsers: number;
  newUsers: number;
  totalRecipes: number;
  newRecipes: number;
  activeSubscriptions: number;
  premiumConversionRate: number;
  averageRating: number;
  totalCategories: number;
}

function calculateGrowth(current: number, previous: number): number {
  if (previous === 0) return current > 0 ? 100 : 0;
  return ((current - previous) / previous) * 100;
}

export default function AdminDashboardPage() {
  const { t } = useI18n();
  const [timeRange, setTimeRange] = useState("week"); // week, month, year
  const [statsHistory, setStatsHistory] = useState<AdminStats[]>([]);

  const { data: stats, isLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    refetchInterval: 60000, // Refresh every minute
  });

  // Simulate historical data for charts - in a real app, this would come from the API
  useEffect(() => {
    if (stats) {
      // Generate sample data for the charts based on current stats
      const baseUsers = Math.max(stats.totalUsers - stats.newUsers, 1);
      const baseRecipes = Math.max(stats.totalRecipes - stats.newRecipes, 1);
      
      const periods = timeRange === "week" ? 7 : timeRange === "month" ? 30 : 12;
      const history: AdminStats[] = [];
      
      for (let i = 0; i < periods; i++) {
        // Create a curve where more recent days have higher numbers
        const factor = (i / periods) * 0.8;
        const day: AdminStats = {
          totalUsers: Math.floor(baseUsers * (0.85 + factor * 0.15)),
          newUsers: Math.floor((stats.newUsers / periods) * (0.5 + Math.random() * 1.5)),
          totalRecipes: Math.floor(baseRecipes * (0.9 + factor * 0.1)),
          newRecipes: Math.floor((stats.newRecipes / periods) * (0.5 + Math.random() * 1.5)),
          activeSubscriptions: Math.floor(stats.activeSubscriptions * (0.7 + factor * 0.3)),
          premiumConversionRate: stats.premiumConversionRate * (0.8 + factor * 0.2),
          averageRating: stats.averageRating * (0.95 + Math.random() * 0.1),
          totalCategories: stats.totalCategories,
        };
        history.push(day);
      }
      
      // For the most recent period, use actual data
      if (history.length > 0) {
        history[history.length - 1] = stats;
      }
      
      setStatsHistory(history);
    }
  }, [stats, timeRange]);

  // Prepare data for charts
  const userChartData = statsHistory.map((day, index) => ({
    name: timeRange === "week" ? t(`days.${index}`) : 
          timeRange === "month" ? `Day ${index + 1}` : 
          t(`months.${index}`),
    users: day.totalUsers,
    newUsers: day.newUsers,
  }));

  const recipeChartData = statsHistory.map((day, index) => ({
    name: timeRange === "week" ? t(`days.${index}`) : 
          timeRange === "month" ? `Day ${index + 1}` : 
          t(`months.${index}`),
    recipes: day.totalRecipes,
    newRecipes: day.newRecipes,
  }));
  
  const subscriptionData = [
    { name: t("admin.free_users"), value: stats ? stats.totalUsers - stats.activeSubscriptions : 0 },
    { name: t("admin.premium_users"), value: stats ? stats.activeSubscriptions : 0 },
  ];

  // Calculate growth rates
  const userGrowthPercentage = statsHistory.length > 1 
    ? calculateGrowth(
        statsHistory[statsHistory.length - 1]?.totalUsers || 0, 
        statsHistory[0]?.totalUsers || 0
      )
    : 0;
    
  const recipeGrowthPercentage = statsHistory.length > 1 
    ? calculateGrowth(
        statsHistory[statsHistory.length - 1]?.totalRecipes || 0, 
        statsHistory[0]?.totalRecipes || 0
      )
    : 0;
    
  const subscriptionGrowthPercentage = statsHistory.length > 1 
    ? calculateGrowth(
        statsHistory[statsHistory.length - 1]?.activeSubscriptions || 0, 
        statsHistory[0]?.activeSubscriptions || 0
      )
    : 0;

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="flex h-full items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col justify-between space-y-2 md:flex-row md:items-center md:space-y-0">
          <h2 className="font-playFair text-3xl font-bold tracking-tight">
            {t("admin.dashboard")}
          </h2>
          
          <Tabs defaultValue="week" className="w-[300px]" onValueChange={setTimeRange}>
            <TabsList className="w-full">
              <TabsTrigger value="week">{t("admin.this_week")}</TabsTrigger>
              <TabsTrigger value="month">{t("admin.this_month")}</TabsTrigger>
              <TabsTrigger value="year">{t("admin.this_year")}</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Stats cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.total_users")}
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
              <p className="text-muted-foreground text-xs">
                {userGrowthPercentage > 0 ? (
                  <span className="text-green-500 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3" />
                    +{userGrowthPercentage.toFixed(1)}%
                  </span>
                ) : userGrowthPercentage < 0 ? (
                  <span className="text-red-500 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3 transform rotate-180" />
                    {userGrowthPercentage.toFixed(1)}%
                  </span>
                ) : (
                  <span>0%</span>
                )}
                {" "}
                {t("admin.from", { period: t(`admin.${timeRange}`) })}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.total_recipes")}
              </CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.totalRecipes || 0}</div>
              <p className="text-muted-foreground text-xs">
                {recipeGrowthPercentage > 0 ? (
                  <span className="text-green-500 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3" />
                    +{recipeGrowthPercentage.toFixed(1)}%
                  </span>
                ) : recipeGrowthPercentage < 0 ? (
                  <span className="text-red-500 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3 transform rotate-180" />
                    {recipeGrowthPercentage.toFixed(1)}%
                  </span>
                ) : (
                  <span>0%</span>
                )}
                {" "}
                {t("admin.from", { period: t(`admin.${timeRange}`) })}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.premium_users")}
              </CardTitle>
              <ChefHat className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats?.activeSubscriptions || 0}</div>
              <p className="text-muted-foreground text-xs">
                {subscriptionGrowthPercentage > 0 ? (
                  <span className="text-green-500 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3" />
                    +{subscriptionGrowthPercentage.toFixed(1)}%
                  </span>
                ) : subscriptionGrowthPercentage < 0 ? (
                  <span className="text-red-500 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3 transform rotate-180" />
                    {subscriptionGrowthPercentage.toFixed(1)}%
                  </span>
                ) : (
                  <span>0%</span>
                )}
                {" "}
                {t("admin.from", { period: t(`admin.${timeRange}`) })}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("admin.conversion_rate")}
              </CardTitle>
              <BadgePercent className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {stats?.premiumConversionRate.toFixed(1) || 0}%
              </div>
              <p className="text-muted-foreground text-xs">
                {t("admin.of_total_users")}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>{t("admin.user_growth")}</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={userChartData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="users"
                    name={t("admin.total_users")}
                    stroke="#6a0dad"
                    activeDot={{ r: 8 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="newUsers"
                    name={t("admin.new_users")}
                    stroke="#ffd700"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>{t("admin.recipe_growth")}</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={recipeChartData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar
                    dataKey="recipes"
                    name={t("admin.total_recipes")}
                    fill="#6a0dad"
                  />
                  <Bar
                    dataKey="newRecipes"
                    name={t("admin.new_recipes")}
                    fill="#ffd700"
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Additional stats row */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>{t("admin.subscription_split")}</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={subscriptionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {subscriptionData.map((entry, index) => (
                      <Sector
                        key={`cell-${index}`}
                        fill={index === 0 ? "#4B0082" : "#FFD700"}
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>{t("admin.new_signups")}</CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <div className="flex h-full flex-col items-center justify-center">
                <div className="text-6xl font-bold text-primary">
                  {stats?.newUsers || 0}
                </div>
                <p className="text-muted-foreground mt-2 text-center">
                  {t("admin.new_users_period", { period: t(`admin.${timeRange}`) })}
                </p>
              </div>
            </CardContent>
          </Card>

          <Card className="col-span-1">
            <CardHeader>
              <CardTitle>{t("admin.key_metrics")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="text-muted-foreground text-sm">{t("admin.avg_rating")}</div>
                    <div className="flex items-center">
                      <Star className="mr-2 h-4 w-4 text-yellow-500" />
                      <span className="text-xl font-bold">
                        {stats?.averageRating.toFixed(1) || 0}
                      </span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-muted-foreground text-sm">
                      {t("admin.categories")}
                    </div>
                    <div className="flex items-center">
                      <Tag className="mr-2 h-4 w-4 text-blue-500" />
                      <span className="text-xl font-bold">
                        {stats?.totalCategories || 0}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-muted-foreground text-sm">
                    {t("admin.new_recipes_period", { period: t(`admin.${timeRange}`) })}
                  </div>
                  <div className="flex items-center">
                    <BookOpen className="mr-2 h-4 w-4 text-green-500" />
                    <span className="text-xl font-bold">{stats?.newRecipes || 0}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}