import { useState, ReactNode } from "react";
import { Redirect, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, User, FileText, BarChart3, Settings, LogOut, BarChart4, FileCheck } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";

interface AdminLayoutProps {
  children: ReactNode;
}

export function AdminLayout({ children }: AdminLayoutProps) {
  const { user, isLoading, logoutMutation } = useAuth();
  const { t } = useI18n();
  const [location, navigate] = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  // Check if user is authenticated and is an admin
  if (!user || (user.role !== "ADMIN" && user.role !== "admin")) {
    return <Redirect to="/auth" />;
  }

  const menuItems = [
    {
      icon: <BarChart3 className="mr-2 h-5 w-5" />,
      label: t("admin.dashboard"),
      path: "/admin",
    },
    {
      icon: <User className="mr-2 h-5 w-5" />,
      label: t("admin.users"),
      path: "/admin/users",
    },
    {
      icon: <FileText className="mr-2 h-5 w-5" />,
      label: t("admin.recipes"),
      path: "/admin/recipes",
    },
    {
      icon: <FileCheck className="mr-2 h-5 w-5" />,
      label: t("admin.recipe_approvals"),
      path: "/admin/recipe-approvals",
    },
    {
      icon: <BarChart4 className="mr-2 h-5 w-5" />,
      label: t("admin.analytics"),
      path: "/admin/analytics",
    },
    {
      icon: <Settings className="mr-2 h-5 w-5" />,
      label: t("admin.settings"),
      path: "/admin/settings",
    },
  ];

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <div
        className={cn(
          "bg-muted/30 text-muted-foreground fixed inset-y-0 left-0 z-10 flex w-64 flex-col border-r transition-all duration-300 ease-in-out",
          {
            "-translate-x-full md:translate-x-0": !isSidebarOpen,
          }
        )}
      >
        {/* Admin header */}
        <div className="flex h-16 items-center border-b px-6">
          <div className="flex items-center space-x-2">
            <span className="font-playFair text-xl font-semibold text-primary">
              {t("admin.title")}
            </span>
          </div>
          <button
            onClick={() => setIsSidebarOpen(false)}
            className="text-muted-foreground hover:text-foreground ml-auto md:hidden"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        {/* Admin navigation */}
        <nav className="flex-1 overflow-auto p-4">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.path}>
                <a
                  onClick={(e) => {
                    e.preventDefault();
                    navigate(item.path);
                  }}
                  href={item.path}
                  className={cn(
                    "hover:bg-primary/10 hover:text-primary flex items-center rounded-md px-4 py-2 text-sm transition-colors",
                    {
                      "bg-primary/10 text-primary": location === item.path,
                    }
                  )}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>

        {/* Admin footer */}
        <div className="border-t p-4">
          <div className="flex items-center space-x-3 rounded-md px-3 py-2">
            <div className="h-9 w-9 rounded-full bg-primary/10">
              <div className="flex h-full w-full items-center justify-center text-primary">
                {user.username?.[0]?.toUpperCase() || user.email[0].toUpperCase()}
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium">
                {user.username || user.email.split("@")[0]}
              </span>
              <span className="text-xs text-muted-foreground">{user.email}</span>
            </div>
            <button
              onClick={() => logoutMutation.mutate()}
              className="text-muted-foreground hover:text-primary ml-auto"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile overlay */}
      {!isSidebarOpen && (
        <div
          className="fixed inset-0 z-0 bg-black/50 md:hidden"
          onClick={() => setIsSidebarOpen(true)}
        />
      )}

      {/* Mobile header */}
      <div className="bg-background border-b fixed inset-x-0 top-0 z-10 flex h-16 items-center justify-between px-4 md:hidden">
        <button
          onClick={() => setIsSidebarOpen(true)}
          className="hover:text-foreground text-muted-foreground"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <line x1="3" y1="12" x2="21" y2="12"></line>
            <line x1="3" y1="6" x2="21" y2="6"></line>
            <line x1="3" y1="18" x2="21" y2="18"></line>
          </svg>
        </button>
        <span className="font-playFair text-xl font-semibold text-primary">
          {t("admin.title")}
        </span>
        <div className="w-8"></div> {/* Spacer for centering */}
      </div>

      {/* Main content */}
      <main
        className={cn(
          "flex flex-1 flex-col overflow-hidden transition-all duration-300 ease-in-out",
          {
            "ml-0 md:ml-64": isSidebarOpen,
            "ml-0": !isSidebarOpen,
          }
        )}
      >
        <div className="h-16 md:hidden" />
        <div className="h-full overflow-auto p-4 md:p-8">{children}</div>
      </main>
    </div>
  );
}

export default AdminLayout;