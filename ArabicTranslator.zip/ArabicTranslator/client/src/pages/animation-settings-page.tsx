import React from 'react';
import { Link } from 'wouter';
import { 
  Crown, 
  Settings, 
  ChevronRight, 
  Sparkles, 
  Play, 
  FastForward, 
  Rewind, 
  Eye, 
  EyeOff,
  ArrowLeft,
  BarChart3,
  LayoutGrid
} from 'lucide-react';
import { useAnimation } from '@/lib/animation-context';
import { RoyalFadeIn, RoyalSlideIn } from '@/components/animations/royal-transitions';
import { AnimationDemo } from '@/components/animations/animation-demo';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

export default function AnimationSettingsPage() {
  const { 
    animationsEnabled, 
    setAnimationsEnabled, 
    prefersReducedMotion, 
    setPrefersReducedMotion,
    transitionType,
    setTransitionType,
    animationSpeed,
    setAnimationSpeed
  } = useAnimation();
  
  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <RoyalFadeIn>
        <div className="relative px-4 py-6 bg-royal-purple/5 border-b border-royal-purple/10">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center">
              <Link href="/settings">
                <Button variant="ghost" size="icon" className="mr-2">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-royal-purple font-display flex items-center">
                <Settings className="h-5 w-5 mr-2 text-royal-purple" />
                Animation Settings
              </h1>
            </div>
            <p className="mt-1 text-gray-600 max-w-2xl">
              Customize animation preferences to enhance your royal culinary experience
            </p>
          </div>
        </div>
      </RoyalFadeIn>
      
      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-8">
        <RoyalFadeIn delay={0.1}>
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            <div className="px-5 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="font-bold text-royal-purple flex items-center">
                <Eye className="h-5 w-5 mr-2 text-royal-purple" />
                Animation Visibility
              </h2>
            </div>
            <div className="p-5">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-medium text-gray-900">Enable Animations</h3>
                    <p className="text-sm text-gray-500">
                      Turn on animations for a rich interactive experience
                    </p>
                  </div>
                  <Switch 
                    checked={animationsEnabled} 
                    onCheckedChange={setAnimationsEnabled} 
                    className={cn(
                      animationsEnabled ? "bg-royal-purple" : "bg-gray-200",
                    )}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-medium text-gray-900">Reduce Motion</h3>
                    <p className="text-sm text-gray-500">
                      Minimize animations for improved accessibility and reduced distraction
                    </p>
                  </div>
                  <Switch 
                    checked={prefersReducedMotion} 
                    onCheckedChange={setPrefersReducedMotion}
                    className={cn(
                      prefersReducedMotion ? "bg-royal-purple" : "bg-gray-200",
                    )}
                  />
                </div>
              </div>
            </div>
          </div>
        </RoyalFadeIn>
        
        <RoyalFadeIn delay={0.2}>
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            <div className="px-5 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="font-bold text-royal-purple flex items-center">
                <Sparkles className="h-5 w-5 mr-2 text-royal-purple" />
                Animation Style
              </h2>
            </div>
            <div className="p-5">
              <h3 className="text-base font-medium text-gray-900 mb-3">Transition Type</h3>
              <p className="text-sm text-gray-500 mb-4">
                Select the default transition style for page and content changes
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-5">
                <TransitionButton 
                  isActive={transitionType === 'fade'}
                  onClick={() => setTransitionType('fade')}
                  icon={<Eye className="h-4 w-4" />}
                  label="Fade"
                />
                <TransitionButton 
                  isActive={transitionType === 'slide'} 
                  onClick={() => setTransitionType('slide')}
                  icon={<ChevronRight className="h-4 w-4" />}
                  label="Slide"
                />
                <TransitionButton 
                  isActive={transitionType === 'scale'} 
                  onClick={() => setTransitionType('scale')}
                  icon={<LayoutGrid className="h-4 w-4" />}
                  label="Scale"
                />
                <TransitionButton 
                  isActive={transitionType === 'crown'} 
                  onClick={() => setTransitionType('crown')}
                  icon={<Crown className="h-4 w-4" />}
                  label="Crown"
                />
                <TransitionButton 
                  isActive={transitionType === 'sparkle'} 
                  onClick={() => setTransitionType('sparkle')}
                  icon={<Sparkles className="h-4 w-4" />}
                  label="Sparkle"
                />
              </div>
              
              <Separator className="my-6" />
              
              <h3 className="text-base font-medium text-gray-900 mb-3">Animation Speed</h3>
              <p className="text-sm text-gray-500 mb-4">
                Adjust how quickly animations play throughout the app
              </p>
              
              <RadioGroup
                value={animationSpeed}
                onValueChange={(value) => setAnimationSpeed(value as 'slow' | 'normal' | 'fast')}
                className="flex flex-col space-y-1"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="slow" id="speed-slow" />
                  <Label htmlFor="speed-slow" className="flex items-center">
                    <Rewind className="h-4 w-4 mr-2 text-gray-500" />
                    Slow
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="normal" id="speed-normal" />
                  <Label htmlFor="speed-normal" className="flex items-center">
                    <Play className="h-4 w-4 mr-2 text-gray-500" />
                    Normal
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="fast" id="speed-fast" />
                  <Label htmlFor="speed-fast" className="flex items-center">
                    <FastForward className="h-4 w-4 mr-2 text-gray-500" />
                    Fast
                  </Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        </RoyalFadeIn>
        
        <RoyalFadeIn delay={0.3}>
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            <div className="px-5 py-4 bg-gray-50 border-b border-gray-200">
              <h2 className="font-bold text-royal-purple flex items-center">
                <BarChart3 className="h-5 w-5 mr-2 text-royal-purple" />
                Preview
              </h2>
            </div>
            <div className="p-5">
              <p className="text-sm text-gray-500 mb-4">
                See how your selected animation settings look
              </p>
              
              <div className="space-y-4">
                <AnimationDemo size="md" demoText="Animation Preview" />
                
                <div className="text-center">
                  <Link href="/animation-showcase">
                    <Button variant="outline" className="mt-2">
                      <Sparkles className="h-4 w-4 mr-2" />
                      View Animation Showcase
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </RoyalFadeIn>
        
        <RoyalSlideIn direction="up" distance={20} delay={0.4}>
          <div className="bg-royal-purple/5 rounded-lg p-4 border border-royal-purple/10">
            <div className="flex items-start">
              <div className="mr-3 mt-1">
                <Crown className="h-5 w-5 text-royal-gold" />
              </div>
              <div>
                <h3 className="font-medium text-royal-purple">Animations add royal elegance</h3>
                <p className="mt-1 text-sm text-gray-600">
                  Our royal theme animations are designed to create a feeling of elegance and luxury 
                  while maintaining optimal performance. You can adjust or disable animations at any time.
                </p>
              </div>
            </div>
          </div>
        </RoyalSlideIn>
        
        {/* Back Button */}
        <div className="mt-8 flex justify-center">
          <Link href="/settings">
            <Button variant="outline" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Settings
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

function TransitionButton({ 
  isActive, 
  onClick, 
  icon, 
  label 
}: { 
  isActive: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      className={`flex flex-col items-center justify-center py-3 px-2 rounded-md border transition-all ${
        isActive 
          ? 'bg-royal-purple/10 border-royal-purple text-royal-purple' 
          : 'bg-white border-gray-200 hover:border-gray-300 text-gray-700'
      }`}
      onClick={onClick}
    >
      <div className={`rounded-full p-1.5 mb-1 ${isActive ? 'bg-royal-purple/20' : 'bg-gray-100'}`}>
        {icon}
      </div>
      <span className="text-xs font-medium">
        {label}
      </span>
    </button>
  );
}