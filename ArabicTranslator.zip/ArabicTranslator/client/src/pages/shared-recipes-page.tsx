import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Eye, 
  BookmarkPlus, 
  MessageSquare, 
  Edit,
  Ban,
  ExternalLink,
  Calendar,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { format, formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

// Mock shared recipes data
interface SharedRecipe {
  id: string;
  title: string;
  titleAr: string;
  imageUrl: string;
  publishedDate: Date;
  lastViewed: Date | null;
  stats: {
    views: number;
    saves: number;
    comments: number;
  };
  isPublished: boolean;
}

const mockSharedRecipes: SharedRecipe[] = [
  {
    id: "shared1",
    title: "Homemade Shawarma",
    titleAr: "شاورما منزلية",
    imageUrl: "https://images.unsplash.com/photo-1529006557810-274b9b2fc783",
    publishedDate: new Date(2025, 3, 15), // April 15, 2025
    lastViewed: new Date(2025, 4, 10), // May 10, 2025
    stats: {
      views: 1245,
      saves: 345,
      comments: 29
    },
    isPublished: true
  },
  {
    id: "shared2",
    title: "Lebanese Tabbouleh",
    titleAr: "تبولة لبنانية",
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
    publishedDate: new Date(2025, 3, 10), // April 10, 2025
    lastViewed: new Date(2025, 4, 5), // May 5, 2025
    stats: {
      views: 867,
      saves: 201,
      comments: 15
    },
    isPublished: true
  },
  {
    id: "shared3",
    title: "Chocolate Baklava",
    titleAr: "بقلاوة بالشوكولاتة",
    imageUrl: "https://images.unsplash.com/photo-1519676867240-f03562e64548",
    publishedDate: new Date(2025, 4, 1), // May 1, 2025
    lastViewed: new Date(2025, 4, 11), // May 11, 2025
    stats: {
      views: 415,
      saves: 87,
      comments: 12
    },
    isPublished: true
  },
  {
    id: "shared4",
    title: "Kunafa with Cream",
    titleAr: "كنافة بالقشطة",
    imageUrl: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e",
    publishedDate: new Date(2025, 4, 8), // May 8, 2025
    lastViewed: null, // No views yet
    stats: {
      views: 0,
      saves: 0,
      comments: 0
    },
    isPublished: true
  }
];

export default function SharedRecipesPage() {
  const { t, isRtl, language } = useI18n();
  const [, setLocation] = useLocation();
  const [sharedRecipes, setSharedRecipes] = React.useState<SharedRecipe[]>(mockSharedRecipes);
  const [selectedRecipe, setSelectedRecipe] = React.useState<SharedRecipe | null>(null);
  const [showConfirmDialog, setShowConfirmDialog] = React.useState<boolean>(false);
  
  // Calculate total stats
  const totalStats = React.useMemo(() => {
    return sharedRecipes.reduce((acc, recipe) => {
      return {
        views: acc.views + recipe.stats.views,
        saves: acc.saves + recipe.stats.saves,
        comments: acc.comments + recipe.stats.comments
      };
    }, { views: 0, saves: 0, comments: 0 });
  }, [sharedRecipes]);
  
  const handleGoBack = () => {
    setLocation("/profile");
  };
  
  const handleEditRecipe = (recipeId: string) => {
    setLocation(`/edit-recipe/${recipeId}`);
  };
  
  const handleViewRecipe = (recipeId: string) => {
    setLocation(`/recipe/${recipeId}`);
  };
  
  const handleTogglePublish = (recipe: SharedRecipe) => {
    setSelectedRecipe(recipe);
    setShowConfirmDialog(true);
  };
  
  const confirmTogglePublish = () => {
    if (!selectedRecipe) return;
    
    setSharedRecipes(sharedRecipes.map(recipe => 
      recipe.id === selectedRecipe.id 
        ? { ...recipe, isPublished: !recipe.isPublished } 
        : recipe
    ));
    
    setShowConfirmDialog(false);
    setSelectedRecipe(null);
  };
  
  const formatNumber = (num: number): string => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold">{t("sharedRecipes")}</h1>
        <div className="absolute right-2">
          <LanguageSwitcher />
        </div>
      </div>
      
      {/* Stats Dashboard */}
      <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4">
        <h2 className="font-medium mb-3">{t("overallEngagement")}</h2>
        
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-white/80 p-3 rounded-lg shadow-sm">
            <div className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-blue-500" />
              <div>
                <div className="text-lg font-bold">{formatNumber(totalStats.views)}</div>
                <div className="text-xs text-gray-500">{t("totalViews")}</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white/80 p-3 rounded-lg shadow-sm">
            <div className="flex items-center gap-2">
              <BookmarkPlus className="h-5 w-5 text-green-500" />
              <div>
                <div className="text-lg font-bold">{formatNumber(totalStats.saves)}</div>
                <div className="text-xs text-gray-500">{t("totalSaves")}</div>
              </div>
            </div>
          </div>
          
          <div className="bg-white/80 p-3 rounded-lg shadow-sm">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-purple-500" />
              <div>
                <div className="text-lg font-bold">{formatNumber(totalStats.comments)}</div>
                <div className="text-xs text-gray-500">{t("totalComments")}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* List of Shared Recipes */}
      <div className="p-4">
        <h2 className="font-medium mb-3">{t("yourSharedRecipes")}</h2>
        
        {sharedRecipes.length === 0 ? (
          <div className="text-center py-12">
            <Calendar className="h-16 w-16 mx-auto text-gray-300" />
            <h3 className="mt-4 font-medium text-gray-500">{t("noSharedRecipes")}</h3>
            <p className="text-sm text-gray-400 mt-1">{t("startSharingRecipes")}</p>
            
            <Button 
              className="mt-4"
              onClick={() => setLocation("/create-recipe")}
            >
              {t("createRecipe")}
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {sharedRecipes.map(recipe => (
              <div 
                key={recipe.id}
                className={`border rounded-lg overflow-hidden ${!recipe.isPublished ? 'opacity-50' : ''}`}
              >
                <div className="flex h-24">
                  <div className="w-24 h-24 flex-shrink-0">
                    <img 
                      src={recipe.imageUrl} 
                      alt={isRtl ? recipe.titleAr : recipe.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="flex-1 p-3 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between">
                        <h3 className="font-medium truncate">
                          {isRtl ? recipe.titleAr : recipe.title}
                        </h3>
                        
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <span className="sr-only">{t("openMenu")}</span>
                              <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M3.625 7.5C3.625 8.12132 3.12132 8.625 2.5 8.625C1.87868 8.625 1.375 8.12132 1.375 7.5C1.375 6.87868 1.87868 6.375 2.5 6.375C3.12132 6.375 3.625 6.87868 3.625 7.5ZM8.625 7.5C8.625 8.12132 8.12132 8.625 7.5 8.625C6.87868 8.625 6.375 8.12132 6.375 7.5C6.375 6.87868 6.87868 6.375 7.5 6.375C8.12132 6.375 8.625 6.87868 8.625 7.5ZM13.625 7.5C13.625 8.12132 13.1213 8.625 12.5 8.625C11.8787 8.625 11.375 8.12132 11.375 7.5C11.375 6.87868 11.8787 6.375 12.5 6.375C13.1213 6.375 13.625 6.87868 13.625 7.5Z" fill="currentColor" />
                              </svg>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewRecipe(recipe.id)}>
                              <ExternalLink className="h-4 w-4 mr-2" />
                              {t("viewRecipe")}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditRecipe(recipe.id)}>
                              <Edit className="h-4 w-4 mr-2" />
                              {t("editRecipe")}
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleTogglePublish(recipe)}>
                              {recipe.isPublished ? (
                                <>
                                  <Ban className="h-4 w-4 mr-2 text-red-500" />
                                  <span className="text-red-500">{t("unpublish")}</span>
                                </>
                              ) : (
                                <>
                                  <ExternalLink className="h-4 w-4 mr-2 text-green-500" />
                                  <span className="text-green-500">{t("republish")}</span>
                                </>
                              )}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      
                      <div className="flex items-center gap-2 mt-1 text-xs text-gray-500">
                        <span>
                          {format(recipe.publishedDate, "MMM d, yyyy", {
                            locale: language === 'ar' ? ar : undefined
                          })}
                        </span>
                        
                        {!recipe.isPublished && (
                          <span className="bg-gray-200 text-gray-600 px-1.5 py-0.5 rounded text-[10px]">
                            {t("unpublished")}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center text-xs mt-1">
                      <div className="flex gap-3">
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3 text-gray-500" />
                          <span>{formatNumber(recipe.stats.views)}</span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <BookmarkPlus className="h-3 w-3 text-gray-500" />
                          <span>{formatNumber(recipe.stats.saves)}</span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <MessageSquare className="h-3 w-3 text-gray-500" />
                          <span>{formatNumber(recipe.stats.comments)}</span>
                        </div>
                      </div>
                      
                      <div className="text-gray-500">
                        {recipe.lastViewed 
                          ? t("lastViewed", { 
                              time: formatDistanceToNow(recipe.lastViewed, { 
                                addSuffix: true,
                                locale: language === 'ar' ? ar : undefined
                              })
                            })
                          : t("notViewedYet")
                        }
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {selectedRecipe?.isPublished 
                ? t("confirmUnpublish") 
                : t("confirmRepublish")
              }
            </DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            {selectedRecipe?.isPublished ? (
              <div className="flex items-start gap-2 text-sm">
                <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p>
                    {t("unpublishRecipeWarning", { 
                      title: isRtl ? selectedRecipe.titleAr : selectedRecipe.title 
                    })}
                  </p>
                  <p className="mt-2 text-gray-500">{t("unpublishRecipeNote")}</p>
                </div>
              </div>
            ) : (
              <p className="text-sm">
                {t("republishRecipeConfirmation", { 
                  title: isRtl ? selectedRecipe?.titleAr : selectedRecipe?.title 
                })}
              </p>
            )}
          </div>
          
          <div className="flex justify-between">
            <DialogClose asChild>
              <Button variant="outline">{t("cancel")}</Button>
            </DialogClose>
            
            <Button 
              variant={selectedRecipe?.isPublished ? "destructive" : "default"}
              onClick={confirmTogglePublish}
            >
              {selectedRecipe?.isPublished ? t("unpublish") : t("republish")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}