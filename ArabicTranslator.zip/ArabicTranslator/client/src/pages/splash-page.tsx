import { SplashScreen } from "@/components/splash/splash-screen";

export default function SplashPage() {
  return <SplashScreen />;
}