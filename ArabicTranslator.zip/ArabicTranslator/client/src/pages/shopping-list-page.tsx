import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft,
  Plus,
  Trash2,
  CheckSquare,
  Square,
  Search,
  ShoppingBag,
  Share,
  ChevronDown,
  Edit
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose 
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Types
interface ShoppingListItem {
  id: string;
  name: string;
  nameAr: string;
  category: string;
  categoryAr: string;
  quantity: string;
  unit: string;
  isChecked: boolean;
  recipeId: string | null;
  recipeName: string | null;
  addedAt: Date;
}

interface AddItemFormData {
  name: string;
  quantity: string;
  unit: string;
  category: string;
}

export default function ShoppingListPage() {
  const { t, language, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  
  const initialItems: ShoppingListItem[] = [
    {
      id: "1",
      name: "Chicken breast",
      nameAr: "صدر دجاج",
      category: "Meat & Seafood",
      categoryAr: "لحوم ومأكولات بحرية",
      quantity: "500",
      unit: "g",
      isChecked: false,
      recipeId: "recipe1",
      recipeName: "Chicken Biryani",
      addedAt: new Date()
    },
    {
      id: "2",
      name: "Basmati rice",
      nameAr: "أرز بسمتي",
      category: "Grains",
      categoryAr: "حبوب",
      quantity: "2",
      unit: "cups",
      isChecked: false,
      recipeId: "recipe1",
      recipeName: "Chicken Biryani",
      addedAt: new Date()
    },
    {
      id: "3",
      name: "Yogurt",
      nameAr: "زبادي",
      category: "Dairy",
      categoryAr: "ألبان",
      quantity: "1",
      unit: "cup",
      isChecked: false,
      recipeId: "recipe1",
      recipeName: "Chicken Biryani",
      addedAt: new Date()
    },
    {
      id: "4",
      name: "Onions",
      nameAr: "بصل",
      category: "Produce",
      categoryAr: "خضروات",
      quantity: "2",
      unit: "",
      isChecked: false,
      recipeId: "recipe1",
      recipeName: "Chicken Biryani",
      addedAt: new Date()
    },
    {
      id: "5",
      name: "Tomatoes",
      nameAr: "طماطم",
      category: "Produce",
      categoryAr: "خضروات",
      quantity: "3",
      unit: "",
      isChecked: false,
      recipeId: null,
      recipeName: null,
      addedAt: new Date()
    },
    {
      id: "6",
      name: "Olive oil",
      nameAr: "زيت زيتون",
      category: "Pantry",
      categoryAr: "مؤن",
      quantity: "1",
      unit: "bottle",
      isChecked: true,
      recipeId: null,
      recipeName: null,
      addedAt: new Date()
    }
  ];
  
  const categoryOrder = [
    "Produce", 
    "Meat & Seafood", 
    "Dairy", 
    "Grains", 
    "Pantry", 
    "Spices", 
    "Frozen", 
    "Beverages", 
    "Other"
  ];
  
  // Shopping list state
  const [items, setItems] = React.useState<ShoppingListItem[]>(initialItems);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [newItemOpen, setNewItemOpen] = React.useState(false);
  const [editingItem, setEditingItem] = React.useState<ShoppingListItem | null>(null);
  const [formData, setFormData] = React.useState<AddItemFormData>({
    name: "",
    quantity: "1",
    unit: "",
    category: "Other"
  });
  
  // Function to handle toggling an item's checked status
  const toggleItemChecked = (id: string) => {
    setItems(items.map(item => 
      item.id === id ? { ...item, isChecked: !item.isChecked } : item
    ));
  };
  
  // Function to delete an item
  const deleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
    toast({
      description: t("itemRemoved"),
    });
  };
  
  // Function to add a new item
  const addItem = () => {
    if (!formData.name) return;
    
    const newItem: ShoppingListItem = {
      id: Math.random().toString(36).substring(2, 9),
      name: formData.name,
      nameAr: formData.name, // In a real app, this would be translated
      category: formData.category,
      categoryAr: formData.category, // In a real app, this would be translated
      quantity: formData.quantity,
      unit: formData.unit,
      isChecked: false,
      recipeId: null,
      recipeName: null,
      addedAt: new Date()
    };
    
    setItems([...items, newItem]);
    setFormData({
      name: "",
      quantity: "1",
      unit: "",
      category: "Other"
    });
    setNewItemOpen(false);
    
    toast({
      description: t("itemAdded"),
    });
  };
  
  // Function to update an existing item
  const updateItem = () => {
    if (!editingItem || !formData.name) return;
    
    setItems(items.map(item => 
      item.id === editingItem.id ? {
        ...item,
        name: formData.name,
        nameAr: formData.name, // In a real app, this would be translated
        category: formData.category,
        categoryAr: formData.category, // In a real app, this would be translated
        quantity: formData.quantity,
        unit: formData.unit
      } : item
    ));
    
    setEditingItem(null);
    setFormData({
      name: "",
      quantity: "1",
      unit: "",
      category: "Other"
    });
    
    toast({
      description: t("itemUpdated"),
    });
  };
  
  // Function to start editing an item
  const startEditingItem = (item: ShoppingListItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      quantity: item.quantity,
      unit: item.unit,
      category: item.category
    });
  };
  
  // Function to clear all checked items
  const clearCheckedItems = () => {
    setItems(items.filter(item => !item.isChecked));
    toast({
      description: t("checkedItemsCleared"),
    });
  };
  
  // Function to clear the entire list
  const clearAllItems = () => {
    setItems([]);
    toast({
      description: t("allItemsCleared"),
    });
  };
  
  // Group items by category
  const groupedItems = React.useMemo(() => {
    const filtered = searchQuery 
      ? items.filter(item => 
          item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (item.recipeName && item.recipeName.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      : items;
    
    return filtered.reduce((acc, item) => {
      const category = item.category;
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(item);
      return acc;
    }, {} as Record<string, ShoppingListItem[]>);
  }, [items, searchQuery]);
  
  // Sort categories by predefined order
  const sortedCategories = React.useMemo(() => {
    return Object.keys(groupedItems).sort((a, b) => {
      const indexA = categoryOrder.indexOf(a);
      const indexB = categoryOrder.indexOf(b);
      return (indexA === -1 ? 999 : indexA) - (indexB === -1 ? 999 : indexB);
    });
  }, [groupedItems]);
  
  // Count of items
  const itemCount = items.length;
  const checkedCount = items.filter(item => item.isChecked).length;
  
  // Handle sharing shopping list
  const handleShareList = () => {
    // In a real app, this would generate a shareable link or allow sending the list via messaging
    toast({
      description: t("shoppingListShared"),
    });
  };
  
  const handleGoBack = () => {
    setLocation("/meal-planning");
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white">
        <div className="relative flex items-center justify-center p-4 border-b">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-2"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">{t("shoppingList")}</h1>
          
          <div className="absolute right-2 flex items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={handleShareList}
            >
              <Share className="h-5 w-5" />
            </Button>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => clearCheckedItems()}>
                  {t("clearCheckedItems")}
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive"
                  onClick={() => clearAllItems()}
                >
                  {t("clearEntireList")}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
      
      {/* Search and Action Area */}
      <div className="p-4 border-b">
        <div className="relative mb-4">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={t("searchItems")}
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        
        <div className="flex justify-between items-center">
          <div className="text-sm text-muted-foreground">
            {checkedCount}/{itemCount} {t("itemsChecked")}
          </div>
          
          <Dialog open={newItemOpen} onOpenChange={setNewItemOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-2" />
                {t("addItem")}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("addNewItem")}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <Label htmlFor="item-name">{t("itemName")}</Label>
                  <Input 
                    id="item-name" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder={t("enterItemName")}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="quantity">{t("quantity")}</Label>
                    <Input 
                      id="quantity" 
                      value={formData.quantity}
                      onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                      type="number"
                      min="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">{t("unit")}</Label>
                    <Select 
                      value={formData.unit}
                      onValueChange={(value) => setFormData({...formData, unit: value})}
                    >
                      <SelectTrigger id="unit">
                        <SelectValue placeholder={t("selectUnit")} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">{t("none")}</SelectItem>
                        <SelectItem value="g">{t("grams")}</SelectItem>
                        <SelectItem value="kg">{t("kilograms")}</SelectItem>
                        <SelectItem value="ml">{t("milliliters")}</SelectItem>
                        <SelectItem value="l">{t("liters")}</SelectItem>
                        <SelectItem value="pcs">{t("pieces")}</SelectItem>
                        <SelectItem value="cups">{t("cups")}</SelectItem>
                        <SelectItem value="tbsp">{t("tablespoons")}</SelectItem>
                        <SelectItem value="tsp">{t("teaspoons")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">{t("category")}</Label>
                  <Select 
                    value={formData.category}
                    onValueChange={(value) => setFormData({...formData, category: value})}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder={t("selectCategory")} />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryOrder.map(category => (
                        <SelectItem key={category} value={category}>
                          {t(category.toLowerCase().replace(/ & /g, 'And'))}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setNewItemOpen(false)}>
                  {t("cancel")}
                </Button>
                <Button onClick={addItem}>
                  {t("addItem")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Edit Item Dialog */}
          <Dialog open={!!editingItem} onOpenChange={(open) => !open && setEditingItem(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("editItem")}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="space-y-2">
                  <Label htmlFor="edit-item-name">{t("itemName")}</Label>
                  <Input 
                    id="edit-item-name" 
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder={t("enterItemName")}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-quantity">{t("quantity")}</Label>
                    <Input 
                      id="edit-quantity" 
                      value={formData.quantity}
                      onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                      type="number"
                      min="0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="edit-unit">{t("unit")}</Label>
                    <Select 
                      value={formData.unit}
                      onValueChange={(value) => setFormData({...formData, unit: value})}
                    >
                      <SelectTrigger id="edit-unit">
                        <SelectValue placeholder={t("selectUnit")} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">{t("none")}</SelectItem>
                        <SelectItem value="g">{t("grams")}</SelectItem>
                        <SelectItem value="kg">{t("kilograms")}</SelectItem>
                        <SelectItem value="ml">{t("milliliters")}</SelectItem>
                        <SelectItem value="l">{t("liters")}</SelectItem>
                        <SelectItem value="pcs">{t("pieces")}</SelectItem>
                        <SelectItem value="cups">{t("cups")}</SelectItem>
                        <SelectItem value="tbsp">{t("tablespoons")}</SelectItem>
                        <SelectItem value="tsp">{t("teaspoons")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-category">{t("category")}</Label>
                  <Select 
                    value={formData.category}
                    onValueChange={(value) => setFormData({...formData, category: value})}
                  >
                    <SelectTrigger id="edit-category">
                      <SelectValue placeholder={t("selectCategory")} />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryOrder.map(category => (
                        <SelectItem key={category} value={category}>
                          {t(category.toLowerCase().replace(/ & /g, 'And'))}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditingItem(null)}>
                  {t("cancel")}
                </Button>
                <Button onClick={updateItem}>
                  {t("saveChanges")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Shopping List Items */}
      <div className="divide-y">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12">
            <ShoppingBag className="h-16 w-16 text-muted-foreground/30 mb-4" />
            <p className="text-lg font-medium text-muted-foreground mb-2">
              {t("shoppingListEmpty")}
            </p>
            <p className="text-sm text-muted-foreground/80 text-center max-w-xs mb-6">
              {t("addItemsFromMealPlanning")}
            </p>
            <Button 
              onClick={() => setNewItemOpen(true)}
              size="sm"
            >
              <Plus className="h-4 w-4 mr-2" />
              {t("addFirstItem")}
            </Button>
          </div>
        ) : (
          <Accordion type="multiple" className="w-full" defaultValue={sortedCategories}>
            {sortedCategories.map(category => (
              <AccordionItem key={category} value={category}>
                <AccordionTrigger className="py-2 px-4 hover:no-underline">
                  <div className="flex justify-between items-center w-full">
                    <span>{language === 'ar' ? t(category.toLowerCase().replace(/ & /g, 'And') + 'Ar') : t(category.toLowerCase().replace(/ & /g, 'And'))}</span>
                    <span className="text-sm text-muted-foreground mr-4">
                      {groupedItems[category].filter(item => !item.isChecked).length}/{groupedItems[category].length}
                    </span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="px-2">
                  <div className="space-y-1">
                    {groupedItems[category].map(item => (
                      <div 
                        key={item.id} 
                        className={cn(
                          "flex items-center justify-between p-2 rounded-md transition-colors",
                          item.isChecked ? "bg-muted/30" : "hover:bg-muted/50"
                        )}
                      >
                        <div className="flex items-center">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 mr-1" 
                            onClick={() => toggleItemChecked(item.id)}
                          >
                            {item.isChecked ? 
                              <CheckSquare className="h-5 w-5 text-primary" /> : 
                              <Square className="h-5 w-5" />
                            }
                          </Button>
                          <div className={cn(item.isChecked && "line-through text-muted-foreground")}>
                            <div className="font-medium text-sm">
                              {language === 'ar' ? item.nameAr : item.name}
                              <span className="ml-2 text-xs font-normal text-muted-foreground">
                                {item.quantity} {item.unit && t(item.unit)}
                              </span>
                            </div>
                            {item.recipeName && (
                              <div className="text-xs text-muted-foreground">
                                {t("from")}: {item.recipeName}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8" 
                            onClick={() => startEditingItem(item)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-destructive" 
                            onClick={() => deleteItem(item.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        )}
      </div>
      
      <BottomNavigation />
    </div>
  );
}