import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Globe, 
  Moon, 
  Volume2, 
  Users,
  Mail,
  Shield,
  FileText,
  CreditCard,
  Trash2,
  User,
  Bell,
  Info,
  ChevronRight,
  Paintbrush
} from "lucide-react";
import { ThemePicker } from "@/components/settings/theme-picker";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { useLocation } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/use-auth";

export default function SettingsPage() {
  const { t, language, setLanguage, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { user, updateProfileMutation, logoutMutation } = useAuth();
  
  // Settings state
  const [isDarkMode, setIsDarkMode] = React.useState<boolean>(false);
  const [defaultServings, setDefaultServings] = React.useState<string>("4");
  const [mealReminders, setMealReminders] = React.useState<boolean>(true);
  const [expiryAlerts, setExpiryAlerts] = React.useState<boolean>(true);
  const [timerAlarm, setTimerAlarm] = React.useState<string>("chime");
  const [isPrivateProfile, setIsPrivateProfile] = React.useState<boolean>(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = React.useState<boolean>(false);
  
  const handleGoBack = () => {
    setLocation("/profile");
  };
  
  const handleLanguageChange = (value: string) => {
    setLanguage(value);
    
    // Update user preference in database
    if (user) {
      updateProfileMutation.mutate({
        language: value
      });
    }
  };
  
  const handleDeleteAccount = () => {
    // In a real app, this would send a request to delete the account
    setTimeout(() => {
      setShowDeleteConfirm(false);
      logoutMutation.mutate(undefined, {
        onSuccess: () => {
          setLocation("/auth");
        }
      });
    }, 1500);
  };
  
  // List of setting sections
  const settingSections = [
    {
      id: "theme",
      icon: <Paintbrush className="h-5 w-5" />,
      title: t("theme"),
      component: <ThemePicker />
    },
    {
      id: "language",
      icon: <Globe className="h-5 w-5" />,
      title: t("language"),
      component: (
        <Select 
          value={language} 
          onValueChange={handleLanguageChange}
        >
          <SelectTrigger className="w-[130px]">
            <SelectValue placeholder={t("selectLanguage")} />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="en">
                <div className="flex items-center">
                  <span className="mr-2">🇺🇸</span>
                  English
                </div>
              </SelectItem>
              <SelectItem value="ar">
                <div className="flex items-center">
                  <span className="mr-2">🇸🇦</span>
                  العربية
                </div>
              </SelectItem>
              <SelectItem value="fr">
                <div className="flex items-center">
                  <span className="mr-2">🇫🇷</span>
                  Français
                </div>
              </SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
      )
    },
    {
      id: "appPreferences",
      title: t("appPreferences"),
      items: [
        {
          id: "animations",
          icon: <Paintbrush className="h-5 w-5" />,
          title: t("animations") || "Animations",
          onClick: () => setLocation("/animation-settings"),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />,
          description: t("animationsDescription") || "Customize royal transitions and effects"
        },
        {
          id: "darkMode",
          icon: <Moon className="h-5 w-5" />,
          title: t("darkMode"),
          component: (
            <Switch 
              checked={isDarkMode} 
              onCheckedChange={setIsDarkMode} 
            />
          ),
          description: t("darkModeDescription")
        },
        {
          id: "defaultServings",
          icon: <Users className="h-5 w-5" />,
          title: t("defaultServings"),
          component: (
            <Select 
              value={defaultServings} 
              onValueChange={setDefaultServings}
            >
              <SelectTrigger className="w-[70px]">
                <SelectValue placeholder="4" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="1">1</SelectItem>
                  <SelectItem value="2">2</SelectItem>
                  <SelectItem value="4">4</SelectItem>
                  <SelectItem value="6">6</SelectItem>
                  <SelectItem value="8">8</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          ),
          description: t("defaultServingsDescription")
        }
      ]
    },
    {
      id: "notifications",
      title: t("notifications"),
      items: [
        {
          id: "mealReminders",
          icon: <Bell className="h-5 w-5" />,
          title: t("mealReminders"),
          component: (
            <Switch 
              checked={mealReminders} 
              onCheckedChange={setMealReminders} 
            />
          ),
          description: t("mealRemindersDescription")
        },
        {
          id: "expiryAlerts",
          icon: <Bell className="h-5 w-5" />,
          title: t("expiryAlerts"),
          component: (
            <Switch 
              checked={expiryAlerts} 
              onCheckedChange={setExpiryAlerts} 
            />
          ),
          description: t("expiryAlertsDescription")
        }
      ]
    },
    {
      id: "sounds",
      title: t("sounds"),
      items: [
        {
          id: "timerAlarm",
          icon: <Volume2 className="h-5 w-5" />,
          title: t("timerAlarm"),
          component: (
            <Select 
              value={timerAlarm} 
              onValueChange={setTimerAlarm}
            >
              <SelectTrigger className="w-[130px]">
                <SelectValue placeholder={t("selectSound")} />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="chime">{t("chime")}</SelectItem>
                  <SelectItem value="bell">{t("bell")}</SelectItem>
                  <SelectItem value="alarm">{t("alarm")}</SelectItem>
                  <SelectItem value="none">{t("none")}</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          ),
          description: t("timerAlarmDescription")
        }
      ]
    },
    {
      id: "account",
      title: t("account"),
      items: [
        {
          id: "profile",
          icon: <User className="h-5 w-5" />,
          title: t("profileSettings"),
          onClick: () => setLocation("/edit-profile"),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />
        },
        {
          id: "payment",
          icon: <CreditCard className="h-5 w-5" />,
          title: t("paymentMethods"),
          onClick: () => setLocation("/payment-methods"),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />
        },
        {
          id: "emailSettings",
          icon: <Mail className="h-5 w-5" />,
          title: t("emailSettings"),
          onClick: () => alert(t("emailSettingsFeatureNotImplemented")),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />
        }
      ]
    },
    {
      id: "privacy",
      title: t("privacy"),
      items: [
        {
          id: "privateProfile",
          icon: <Shield className="h-5 w-5" />,
          title: t("privateProfile"),
          component: (
            <Switch 
              checked={isPrivateProfile} 
              onCheckedChange={setIsPrivateProfile} 
            />
          ),
          description: t("privateProfileDescription")
        }
      ]
    },
    {
      id: "legal",
      title: t("legal"),
      items: [
        {
          id: "privacyPolicy",
          icon: <FileText className="h-5 w-5" />,
          title: t("privacyPolicy"),
          onClick: () => setLocation("/privacy-policy"),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />
        },
        {
          id: "termsOfService",
          icon: <FileText className="h-5 w-5" />,
          title: t("termsOfService"),
          onClick: () => setLocation("/terms"),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />
        },
        {
          id: "about",
          icon: <Info className="h-5 w-5" />,
          title: t("about"),
          onClick: () => setLocation("/about"),
          component: <ChevronRight className="h-5 w-5 text-gray-400" />
        }
      ]
    },
    {
      id: "dangerZone",
      title: t("dangerZone"),
      items: [
        {
          id: "deleteAccount",
          icon: <Trash2 className="h-5 w-5 text-red-500" />,
          title: t("deleteAccount"),
          titleClassName: "text-red-500",
          onClick: () => setShowDeleteConfirm(true),
          component: <ChevronRight className="h-5 w-5 text-red-400" />
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold">{t("settings")}</h1>
      </div>
      
      {/* Settings List */}
      <div className="divide-y">
        {settingSections.map(section => (
          <div key={section.id} className="py-4">
            <h2 className="text-sm font-medium text-gray-500 px-4 mb-2">
              {section.title}
            </h2>
            
            {section.component ? (
              <div className="flex items-center justify-between px-4 py-2">
                {section.icon && (
                  <div className="mr-3 text-gray-500">{section.icon}</div>
                )}
                <div className="flex-1">
                  <div className="font-medium">{section.title}</div>
                </div>
                {section.component}
              </div>
            ) : section.items ? (
              <div className="space-y-1">
                {section.items.map(item => (
                  <div 
                    key={item.id} 
                    className={`flex items-center justify-between px-4 py-2 ${
                      item.onClick ? "cursor-pointer hover:bg-gray-50" : ""
                    }`}
                    onClick={item.onClick}
                  >
                    {item.icon && (
                      <div className="mr-3 text-gray-500">{item.icon}</div>
                    )}
                    <div className="flex-1">
                      <div className={`font-medium ${item.titleClassName || ""}`}>
                        {item.title}
                      </div>
                      {item.description && (
                        <p className="text-xs text-gray-500 mt-0.5">{item.description}</p>
                      )}
                    </div>
                    {item.component}
                  </div>
                ))}
              </div>
            ) : null}
          </div>
        ))}
      </div>
      
      {/* App Version */}
      <div className="py-4 px-4 text-center text-xs text-gray-400">
        {t("version")} 2.1.4
      </div>
      
      {/* Delete Account Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-600">{t("deleteAccountConfirmation")}</DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <p className="text-sm">
              {t("deleteAccountWarning")}
            </p>
            <div className="mt-4 p-3 bg-red-50 text-red-700 text-sm rounded-md border border-red-200">
              <p className="font-medium">{t("deleteAccountIrreversible")}</p>
              <ul className="list-disc list-inside mt-2 text-xs">
                <li>{t("deleteAccountItem1")}</li>
                <li>{t("deleteAccountItem2")}</li>
                <li>{t("deleteAccountItem3")}</li>
              </ul>
            </div>
          </div>
          
          <div className="flex justify-between">
            <DialogClose asChild>
              <Button variant="outline">{t("cancel")}</Button>
            </DialogClose>
            
            <Button 
              variant="destructive"
              onClick={handleDeleteAccount}
            >
              {t("confirmDelete")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}