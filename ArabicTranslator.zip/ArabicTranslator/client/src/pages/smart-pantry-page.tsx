import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft,
  Plus,
  Trash2,
  Search,
  Filter,
  ChevronDown,
  Package,
  Calendar,
  AlertCircle,
  Camera,
  Edit,
  ChevronsUpDown,
  FileText,
  Loader2,
  Utensils,
  Mic,
  ScanLine,
  Upload,
  CheckCircle2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useRef, useState } from "react";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose 
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { format, subDays, addDays, differenceInDays, isAfter, isBefore } from "date-fns";
import { ar } from "date-fns/locale";
import { cn } from "@/lib/utils";

// Types
interface PantryItem {
  id: string;
  name: string;
  nameAr: string;
  category: string;
  categoryAr: string;
  quantity: string;
  unit: string;
  expirationDate: Date | null;
  addedDate: Date;
  notes: string;
}

interface AddItemFormData {
  name: string;
  quantity: string;
  unit: string;
  category: string;
  expirationDate: string;
  notes: string;
}

interface IngredientInput {
  id: string;
  name: string;
  quantity: string;
  unit: string;
  fromPantry: boolean;
}

interface IngredientReviewItem extends IngredientInput {
  isOptional: boolean;
}

export default function SmartPantryPage() {
  const { t, language, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Generate sample data
  const today = new Date();
  const initialItems: PantryItem[] = [
    {
      id: "1",
      name: "Rice",
      nameAr: "أرز",
      category: "Grains",
      categoryAr: "حبوب",
      quantity: "2",
      unit: "kg",
      expirationDate: addDays(today, 180),
      addedDate: subDays(today, 30),
      notes: ""
    },
    {
      id: "2",
      name: "Flour",
      nameAr: "دقيق",
      category: "Baking",
      categoryAr: "خبز",
      quantity: "1",
      unit: "kg",
      expirationDate: addDays(today, 90),
      addedDate: subDays(today, 60),
      notes: ""
    },
    {
      id: "3",
      name: "Eggs",
      nameAr: "بيض",
      category: "Dairy",
      categoryAr: "ألبان",
      quantity: "12",
      unit: "pcs",
      expirationDate: addDays(today, 14),
      addedDate: subDays(today, 5),
      notes: ""
    },
    {
      id: "4",
      name: "Chicken breast",
      nameAr: "صدر دجاج",
      category: "Meat & Seafood",
      categoryAr: "لحوم ومأكولات بحرية",
      quantity: "500",
      unit: "g",
      expirationDate: addDays(today, 2),
      addedDate: subDays(today, 3),
      notes: "In freezer"
    },
    {
      id: "5",
      name: "Tomatoes",
      nameAr: "طماطم",
      category: "Produce",
      categoryAr: "خضروات",
      quantity: "6",
      unit: "pcs",
      expirationDate: addDays(today, -1),
      addedDate: subDays(today, 7),
      notes: ""
    },
    {
      id: "6",
      name: "Milk",
      nameAr: "حليب",
      category: "Dairy",
      categoryAr: "ألبان",
      quantity: "1",
      unit: "l",
      expirationDate: addDays(today, 5),
      addedDate: subDays(today, 2),
      notes: ""
    }
  ];
  
  const categoryOrder = [
    "Produce", 
    "Meat & Seafood", 
    "Dairy", 
    "Grains", 
    "Spices", 
    "Baking",
    "Canned Goods",
    "Frozen", 
    "Beverages", 
    "Other"
  ];
  
  // State
  const [items, setItems] = React.useState<PantryItem[]>(initialItems);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [categoryFilter, setCategoryFilter] = React.useState<string | null>(null);
  const [expirationFilter, setExpirationFilter] = React.useState<string | null>(null);
  const [sortType, setSortType] = React.useState<string>("expiringSoon");
  const [newItemOpen, setNewItemOpen] = React.useState(false);
  const [editingItem, setEditingItem] = React.useState<PantryItem | null>(null);
  const [inputMode, setInputMode] = React.useState<string>("pantry");
  const [mainTab, setMainTab] = React.useState<string>("viewPantry");
  const [itemsToFindRecipes, setItemsToFindRecipes] = React.useState<IngredientReviewItem[]>([]);
  const [selectedPantryItems, setSelectedPantryItems] = React.useState<string[]>([]);
  const [additionalIngredient, setAdditionalIngredient] = React.useState("");
  const [additionalQuantity, setAdditionalQuantity] = React.useState("1");
  const [additionalUnit, setAdditionalUnit] = React.useState("unit");
  const [reviewingIngredients, setReviewingIngredients] = React.useState(false);
  const [formData, setFormData] = React.useState<AddItemFormData>({
    name: "",
    quantity: "1",
    unit: "",
    category: "Other",
    expirationDate: "",
    notes: ""
  });
  const [cameraActive, setCameraActive] = React.useState(false);
  const [invoiceScanActive, setInvoiceScanActive] = React.useState(false);
  const [voiceInputActive, setVoiceInputActive] = React.useState(false);
  const cameraRef = useRef<HTMLInputElement>(null);
  const fileUploadRef = useRef<HTMLInputElement>(null);
  
  // Function to handle camera photo capture
  const handleCameraCapture = () => {
    // Open the file input
    if (cameraRef.current) {
      cameraRef.current.click();
    }
  };
  
  // Function to handle camera file selection
  const handleCameraFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, this would process the image, perhaps with OCR
      // For now, we'll just show a success message
      toast({
        title: t("imageProcessed"),
        description: t("itemDetailsExtracted"),
      });
      
      // Reset the file input
      if (cameraRef.current) {
        cameraRef.current.value = "";
      }
    }
  };
  
  // Function to handle invoice scanning
  const handleInvoiceScan = () => {
    setInvoiceScanActive(true);
    
    // Simulate processing an invoice
    setTimeout(() => {
      setInvoiceScanActive(false);
      
      // In a real app, this would extract items from an invoice
      // For now, we'll just show a success message
      toast({
        title: t("invoiceScanned"),
        description: t("itemsExtractedFromInvoice"),
      });
      
      // Add a mock extracted item
      const newItem: PantryItem = {
        id: Math.random().toString(36).substring(2, 9),
        name: "Auto-detected Item",
        nameAr: "عنصر تم اكتشافه تلقائيًا",
        category: "Other",
        categoryAr: "آخر",
        quantity: "1",
        unit: "pcs",
        expirationDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        addedDate: new Date(),
        notes: t("addedViaScan")
      };
      
      setItems([...items, newItem]);
    }, 2000);
  };
  
  // Function to add a new item
  const addItem = () => {
    if (!formData.name) return;
    
    const newItem: PantryItem = {
      id: Math.random().toString(36).substring(2, 9),
      name: formData.name,
      nameAr: formData.name, // In a real app, this would be translated
      category: formData.category,
      categoryAr: formData.category, // In a real app, this would be translated
      quantity: formData.quantity,
      unit: formData.unit,
      expirationDate: formData.expirationDate ? new Date(formData.expirationDate) : null,
      addedDate: new Date(),
      notes: formData.notes
    };
    
    setItems([...items, newItem]);
    setFormData({
      name: "",
      quantity: "1",
      unit: "",
      category: "Other",
      expirationDate: "",
      notes: ""
    });
    setNewItemOpen(false);
    
    toast({
      description: t("itemAdded"),
    });
  };
  
  // Function to update an existing item
  const updateItem = () => {
    if (!editingItem || !formData.name) return;
    
    setItems(items.map(item => 
      item.id === editingItem.id ? {
        ...item,
        name: formData.name,
        nameAr: formData.name, // In a real app, this would be translated
        category: formData.category,
        categoryAr: formData.category, // In a real app, this would be translated
        quantity: formData.quantity,
        unit: formData.unit,
        expirationDate: formData.expirationDate ? new Date(formData.expirationDate) : null,
        notes: formData.notes
      } : item
    ));
    
    setEditingItem(null);
    setFormData({
      name: "",
      quantity: "1",
      unit: "",
      category: "Other",
      expirationDate: "",
      notes: ""
    });
    
    toast({
      description: t("itemUpdated"),
    });
  };
  
  // Function to start editing an item
  const startEditingItem = (item: PantryItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      quantity: item.quantity,
      unit: item.unit,
      category: item.category,
      expirationDate: item.expirationDate ? format(item.expirationDate, 'yyyy-MM-dd') : "",
      notes: item.notes
    });
  };
  
  // Function to delete an item
  const deleteItem = (id: string) => {
    setItems(items.filter(item => item.id !== id));
    toast({
      description: t("itemRemoved"),
    });
  };
  
  // Function to clear all expired items
  const clearExpiredItems = () => {
    const today = new Date();
    setItems(items.filter(item => 
      !item.expirationDate || isAfter(item.expirationDate, today)
    ));
    toast({
      description: t("expiredItemsCleared"),
    });
  };
  
  // Function to add to shopping list
  const addToShoppingList = (item: PantryItem) => {
    // In a real app, this would add the item to the shopping list
    toast({
      description: t("addedToShoppingList"),
    });
  };
  
  // Function to toggle selection of pantry items for recipe search
  const togglePantryItemSelection = (itemId: string) => {
    if (selectedPantryItems.includes(itemId)) {
      setSelectedPantryItems(selectedPantryItems.filter(id => id !== itemId));
    } else {
      setSelectedPantryItems([...selectedPantryItems, itemId]);
    }
  };
  
  // Function to add manual ingredient to the list
  const addManualIngredient = () => {
    if (additionalIngredient.trim()) {
      const newIngredient: IngredientReviewItem = {
        id: Math.random().toString(36).substring(2, 9),
        name: additionalIngredient.trim(),
        quantity: additionalQuantity,
        unit: additionalUnit,
        fromPantry: false,
        isOptional: false
      };
      setItemsToFindRecipes([...itemsToFindRecipes, newIngredient]);
      setAdditionalIngredient("");
      setAdditionalQuantity("1");
      setAdditionalUnit("unit");
    }
  };
  
  // Function to remove ingredient from the list
  const removeIngredient = (id: string) => {
    setItemsToFindRecipes(itemsToFindRecipes.filter(item => item.id !== id));
  };
  
  // Function to toggle ingredient optional status
  const toggleIngredientOptional = (id: string) => {
    setItemsToFindRecipes(
      itemsToFindRecipes.map(item => 
        item.id === id 
          ? { ...item, isOptional: !item.isOptional } 
          : item
      )
    );
  };
  
  // Function to update ingredient quantity
  const updateIngredientQuantity = (id: string, quantity: string) => {
    setItemsToFindRecipes(
      itemsToFindRecipes.map(item => 
        item.id === id 
          ? { ...item, quantity } 
          : item
      )
    );
  };
  
  // Function to update ingredient unit
  const updateIngredientUnit = (id: string, unit: string) => {
    setItemsToFindRecipes(
      itemsToFindRecipes.map(item => 
        item.id === id 
          ? { ...item, unit } 
          : item
      )
    );
  };
  
  // Function to handle voice input
  const handleVoiceInput = () => {
    setVoiceInputActive(true);
    
    // Simulate voice recognition
    setTimeout(() => {
      setVoiceInputActive(false);
      
      // In a real app, this would process voice input
      toast({
        title: t("voiceProcessed"),
        description: t("ingredientsAddedFromVoice"),
      });
      
      // Add a mock recognized ingredient
      const recognizedIngredient: IngredientReviewItem = {
        id: Math.random().toString(36).substring(2, 9),
        name: "Onions",
        quantity: "2",
        unit: "pcs",
        fromPantry: false,
        isOptional: false
      };
      setItemsToFindRecipes([...itemsToFindRecipes, recognizedIngredient]);
    }, 2000);
  };
  
  // Function to handle file upload
  const handleFileUpload = () => {
    if (fileUploadRef.current) {
      fileUploadRef.current.click();
    }
  };
  
  // Function to process file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // In a real app, this would process the file
      toast({
        title: t("fileProcessed"),
        description: t("ingredientsExtractedFromFile"),
      });
      
      // Add mock ingredients from file
      const newIngredients: IngredientReviewItem[] = [
        {
          id: Math.random().toString(36).substring(2, 9),
          name: "Flour",
          quantity: "2",
          unit: "cups",
          fromPantry: false,
          isOptional: false
        },
        {
          id: Math.random().toString(36).substring(2, 9),
          name: "Sugar",
          quantity: "1",
          unit: "cup",
          fromPantry: false,
          isOptional: false
        },
        {
          id: Math.random().toString(36).substring(2, 9),
          name: "Butter",
          quantity: "1/2",
          unit: "cup",
          fromPantry: false,
          isOptional: false
        }
      ];
      setItemsToFindRecipes([...itemsToFindRecipes, ...newIngredients]);
      
      // Reset the file input
      if (fileUploadRef.current) {
        fileUploadRef.current.value = "";
      }
    }
  };
  
  // Function to add selected pantry items to the ingredients list
  const addSelectedPantryItems = () => {
    const selectedPantryItemObjects = items
      .filter(item => selectedPantryItems.includes(item.id));
    
    // Add only items that aren't already in the list
    const existingNames = itemsToFindRecipes.map(item => item.name);
    const newItems = selectedPantryItemObjects.filter(item => 
      !existingNames.includes(item.name)
    );
    
    if (newItems.length > 0) {
      const newIngredients = newItems.map(item => ({
        id: Math.random().toString(36).substring(2, 9),
        name: item.name,
        quantity: item.quantity,
        unit: item.unit,
        fromPantry: true,
        isOptional: false
      }));
      
      setItemsToFindRecipes([...itemsToFindRecipes, ...newIngredients]);
      // Clear selection
      setSelectedPantryItems([]);
      
      toast({
        description: t("ingredientsAddedFromPantry"),
      });
    }
  };
  
  // Function to find recipes with selected ingredients
  const findRecipes = () => {
    if (itemsToFindRecipes.length === 0) {
      toast({
        variant: "destructive",
        description: t("noIngredientsSelected"),
      });
      return;
    }
    
    // Continue if currently in review mode, otherwise show review first
    if (!reviewingIngredients) {
      setReviewingIngredients(true);
      return;
    }
    
    // Extract ingredient names for the search, excluding optional ones that were unchecked
    const ingredientNames = itemsToFindRecipes
      .filter(item => !item.isOptional)
      .map(item => item.name);
    
    // Navigate to search page with selected ingredients
    setLocation(`/search?ingredients=${ingredientNames.join(",")}`);
  };
  
  // Function to cancel reviewing ingredients and go back to editing
  const cancelReviewIngredients = () => {
    setReviewingIngredients(false);
  };
  
  // Filter and sort items
  const filteredItems = React.useMemo(() => {
    // Apply search filter
    let result = items;
    if (searchQuery) {
      result = result.filter(item => 
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    
    // Apply category filter
    if (categoryFilter) {
      result = result.filter(item => item.category === categoryFilter);
    }
    
    // Apply expiration filter
    const today = new Date();
    if (expirationFilter === "expired") {
      result = result.filter(item => 
        item.expirationDate && isBefore(item.expirationDate, today)
      );
    } else if (expirationFilter === "expiringSoon") {
      result = result.filter(item => 
        item.expirationDate && 
        isAfter(item.expirationDate, today) && 
        differenceInDays(item.expirationDate, today) <= 7
      );
    } else if (expirationFilter === "good") {
      result = result.filter(item => 
        item.expirationDate && 
        differenceInDays(item.expirationDate, today) > 7
      );
    }
    
    // Apply sorting
    if (sortType === "expiringSoon") {
      result = [...result].sort((a, b) => {
        if (!a.expirationDate) return 1;
        if (!b.expirationDate) return -1;
        return a.expirationDate.getTime() - b.expirationDate.getTime();
      });
    } else if (sortType === "recentlyAdded") {
      result = [...result].sort((a, b) => 
        b.addedDate.getTime() - a.addedDate.getTime()
      );
    } else if (sortType === "alphabetical") {
      result = [...result].sort((a, b) => 
        a.name.localeCompare(b.name)
      );
    }
    
    return result;
  }, [items, searchQuery, categoryFilter, expirationFilter, sortType]);
  
  // Count expired items
  const expiredCount = React.useMemo(() => {
    const today = new Date();
    return items.filter(item => 
      item.expirationDate && isBefore(item.expirationDate, today)
    ).length;
  }, [items]);
  
  // Count expiring soon items
  const expiringSoonCount = React.useMemo(() => {
    const today = new Date();
    return items.filter(item => 
      item.expirationDate && 
      isAfter(item.expirationDate, today) && 
      differenceInDays(item.expirationDate, today) <= 7
    ).length;
  }, [items]);
  
  const handleGoBack = () => {
    setLocation("/");
  };
  
  // Function to get expiration status class
  const getExpirationStatusClass = (date: Date | null) => {
    if (!date) return "";
    
    const today = new Date();
    const daysUntilExpiration = differenceInDays(date, today);
    
    if (daysUntilExpiration < 0) {
      return "text-red-500 bg-red-50 border-red-200";
    } else if (daysUntilExpiration <= 7) {
      return "text-amber-500 bg-amber-50 border-amber-200";
    } else {
      return "text-green-500 bg-green-50 border-green-200";
    }
  };
  
  // Function to format date
  const formatDate = (date: Date, showRelative = true) => {
    const today = new Date();
    const daysUntilExpiration = differenceInDays(date, today);
    
    if (showRelative) {
      if (daysUntilExpiration < 0) {
        return t("expiredAgo", { days: Math.abs(daysUntilExpiration) });
      } else if (daysUntilExpiration === 0) {
        return t("expiringToday");
      } else {
        return t("expiresIn", { days: daysUntilExpiration });
      }
    } else {
      return format(date, 'PP', { locale: language === 'ar' ? ar : undefined });
    }
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white">
        <div className="relative flex items-center justify-center p-4 border-b">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-2"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">{t("smartPantry")}</h1>
        </div>
      </div>
      
      {/* Main Tabs */}
      <Tabs value={mainTab} onValueChange={setMainTab} className="w-full">
        <div className="sticky top-14 z-10 bg-white border-b">
          <TabsList className="grid grid-cols-2 mb-0 rounded-none">
            <TabsTrigger value="viewPantry">{t("viewPantry")}</TabsTrigger>
            <TabsTrigger value="findRecipes">{t("findRecipesByIngredients")}</TabsTrigger>
          </TabsList>
        </div>
        
        {/* View Pantry Tab */}
        <TabsContent value="viewPantry" className="mt-0 p-0">
          {/* Expiration Alert */}
          {(expiredCount > 0 || expiringSoonCount > 0) && (
            <div className="px-4 py-3 bg-amber-50 border-b border-amber-100">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                <div>
                  <h3 className="font-medium text-amber-800">{t("attentionNeeded")}</h3>
                  {expiredCount > 0 && (
                    <p className="text-sm text-amber-700 mt-0.5">
                      {t("itemsExpired", { count: expiredCount })}
                    </p>
                  )}
                  {expiringSoonCount > 0 && (
                    <p className="text-sm text-amber-700 mt-0.5">
                      {t("itemsExpiringSoon", { count: expiringSoonCount })}
                    </p>
                  )}
                  
                  {expiredCount > 0 && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="mt-1 h-8 bg-white border-amber-200 text-amber-800 hover:bg-amber-100"
                      onClick={clearExpiredItems}
                    >
                      <Trash2 className="h-3.5 w-3.5 mr-1" />
                      {t("clearExpiredItems")}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {/* Pantry Controls */}
          <div className="p-4 space-y-4">
            {/* Search and Filter */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input
                  placeholder={t("searchPantry")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon">
                    <Filter className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <div className="p-2">
                    <h3 className="font-medium text-xs text-gray-500 uppercase">{t("sortBy")}</h3>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    onClick={() => setSortType("expiringSoon")}
                    className={sortType === "expiringSoon" ? "bg-accent" : ""}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    {t("expiringSoon")}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setSortType("recentlyAdded")}
                    className={sortType === "recentlyAdded" ? "bg-accent" : ""}
                  >
                    <Package className="h-4 w-4 mr-2" />
                    {t("recentlyAdded")}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setSortType("alphabetical")}
                    className={sortType === "alphabetical" ? "bg-accent" : ""}
                  >
                    <ChevronsUpDown className="h-4 w-4 mr-2" />
                    {t("alphabetical")}
                  </DropdownMenuItem>
                  
                  <DropdownMenuSeparator />
                  <div className="p-2">
                    <h3 className="font-medium text-xs text-gray-500 uppercase">{t("filterByCategory")}</h3>
                  </div>
                  <DropdownMenuSeparator />
                  
                  <DropdownMenuItem 
                    onClick={() => setCategoryFilter(null)}
                    className={categoryFilter === null ? "bg-accent" : ""}
                  >
                    {t("allCategories")}
                  </DropdownMenuItem>
                  
                  {categoryOrder.map(category => (
                    <DropdownMenuItem 
                      key={category}
                      onClick={() => setCategoryFilter(category)}
                      className={categoryFilter === category ? "bg-accent" : ""}
                    >
                      {category}
                    </DropdownMenuItem>
                  ))}
                  
                  <DropdownMenuSeparator />
                  <div className="p-2">
                    <h3 className="font-medium text-xs text-gray-500 uppercase">{t("filterByExpiration")}</h3>
                  </div>
                  <DropdownMenuSeparator />
                  
                  <DropdownMenuItem 
                    onClick={() => setExpirationFilter(null)}
                    className={expirationFilter === null ? "bg-accent" : ""}
                  >
                    {t("allItems")}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setExpirationFilter("expired")}
                    className={expirationFilter === "expired" ? "bg-accent" : ""}
                  >
                    {t("expired")}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setExpirationFilter("expiringSoon")}
                    className={expirationFilter === "expiringSoon" ? "bg-accent" : ""}
                  >
                    {t("expiringSoon")}
                  </DropdownMenuItem>
                  <DropdownMenuItem 
                    onClick={() => setExpirationFilter("good")}
                    className={expirationFilter === "good" ? "bg-accent" : ""}
                  >
                    {t("notExpiringSoon")}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Dialog open={newItemOpen} onOpenChange={setNewItemOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-1" />
                    {t("addItem")}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{t("addNewItem")}</DialogTitle>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">{t("itemName")}</Label>
                      <Input
                        id="name"
                        placeholder={t("enterItemName")}
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <Label htmlFor="quantity">{t("quantity")}</Label>
                        <Input
                          id="quantity"
                          type="number"
                          min="0"
                          step="0.1"
                          value={formData.quantity}
                          onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="unit">{t("unit")}</Label>
                        <Select 
                          value={formData.unit}
                          onValueChange={(value) => setFormData({ ...formData, unit: value })}
                        >
                          <SelectTrigger id="unit">
                            <SelectValue placeholder={t("selectUnit")} />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="kg">{t("kilogram")}</SelectItem>
                            <SelectItem value="g">{t("gram")}</SelectItem>
                            <SelectItem value="l">{t("liter")}</SelectItem>
                            <SelectItem value="ml">{t("milliliter")}</SelectItem>
                            <SelectItem value="pcs">{t("pieces")}</SelectItem>
                            <SelectItem value="box">{t("box")}</SelectItem>
                            <SelectItem value="can">{t("can")}</SelectItem>
                            <SelectItem value="bottle">{t("bottle")}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="category">{t("category")}</Label>
                      <Select 
                        value={formData.category}
                        onValueChange={(value) => setFormData({ ...formData, category: value })}
                      >
                        <SelectTrigger id="category">
                          <SelectValue placeholder={t("selectCategory")} />
                        </SelectTrigger>
                        <SelectContent>
                          {categoryOrder.map(category => (
                            <SelectItem key={category} value={category}>{category}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="expirationDate">{t("expirationDate")}</Label>
                      <Input
                        id="expirationDate"
                        type="date"
                        value={formData.expirationDate}
                        onChange={(e) => setFormData({ ...formData, expirationDate: e.target.value })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="notes">{t("notes")}</Label>
                      <Input
                        id="notes"
                        placeholder={t("optionalNotes")}
                        value={formData.notes}
                        onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      />
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <DialogClose asChild>
                      <Button variant="outline">{t("cancel")}</Button>
                    </DialogClose>
                    <Button onClick={addItem} disabled={!formData.name}>
                      {t("addItem")}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            
            {/* Item List */}
            {filteredItems.length === 0 ? (
              <div className="text-center py-10">
                <Package className="h-16 w-16 mx-auto text-gray-300" />
                <h3 className="mt-4 font-medium text-gray-500">{t("noPantryItemsFound")}</h3>
                <p className="text-sm text-gray-400 mt-1">{t("addItemsToYourPantry")}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredItems.map(item => (
                  <div
                    key={item.id}
                    className="p-3 border rounded-lg"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">
                          {isRtl ? item.nameAr : item.name}
                        </h3>
                        <div className="text-sm text-gray-500 mt-0.5">
                          {item.quantity} {item.unit} • {isRtl ? item.categoryAr : item.category}
                        </div>
                      </div>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                          >
                            <ChevronDown className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => startEditingItem(item)}>
                            <Edit className="h-4 w-4 mr-2" />
                            {t("edit")}
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => addToShoppingList(item)}>
                            <Package className="h-4 w-4 mr-2" />
                            {t("addToShoppingList")}
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => deleteItem(item.id)} className="text-red-500 hover:text-red-700 hover:bg-red-50 focus:bg-red-50 focus:text-red-700">
                            <Trash2 className="h-4 w-4 mr-2" />
                            {t("delete")}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                    
                    {item.expirationDate && (
                      <div className={cn(
                        "text-xs px-2 py-1 rounded-md border inline-block mt-2",
                        getExpirationStatusClass(item.expirationDate)
                      )}>
                        {formatDate(item.expirationDate)}
                      </div>
                    )}
                    
                    {item.notes && (
                      <div className="text-xs text-gray-500 mt-2">
                        {item.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
          
          {/* Edit Item Dialog */}
          <Dialog open={!!editingItem} onOpenChange={(open) => !open && setEditingItem(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("editItem")}</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">{t("itemName")}</Label>
                  <Input
                    id="edit-name"
                    placeholder={t("enterItemName")}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="edit-quantity">{t("quantity")}</Label>
                    <Input
                      id="edit-quantity"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.quantity}
                      onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-unit">{t("unit")}</Label>
                    <Select 
                      value={formData.unit}
                      onValueChange={(value) => setFormData({ ...formData, unit: value })}
                    >
                      <SelectTrigger id="edit-unit">
                        <SelectValue placeholder={t("selectUnit")} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="kg">{t("kilogram")}</SelectItem>
                        <SelectItem value="g">{t("gram")}</SelectItem>
                        <SelectItem value="l">{t("liter")}</SelectItem>
                        <SelectItem value="ml">{t("milliliter")}</SelectItem>
                        <SelectItem value="pcs">{t("pieces")}</SelectItem>
                        <SelectItem value="box">{t("box")}</SelectItem>
                        <SelectItem value="can">{t("can")}</SelectItem>
                        <SelectItem value="bottle">{t("bottle")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-category">{t("category")}</Label>
                  <Select 
                    value={formData.category}
                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                  >
                    <SelectTrigger id="edit-category">
                      <SelectValue placeholder={t("selectCategory")} />
                    </SelectTrigger>
                    <SelectContent>
                      {categoryOrder.map(category => (
                        <SelectItem key={category} value={category}>{category}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-expirationDate">{t("expirationDate")}</Label>
                  <Input
                    id="edit-expirationDate"
                    type="date"
                    value={formData.expirationDate}
                    onChange={(e) => setFormData({ ...formData, expirationDate: e.target.value })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="edit-notes">{t("notes")}</Label>
                  <Input
                    id="edit-notes"
                    placeholder={t("optionalNotes")}
                    value={formData.notes}
                    onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setEditingItem(null)}>
                  {t("cancel")}
                </Button>
                <Button onClick={updateItem} disabled={!formData.name}>
                  {t("saveChanges")}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </TabsContent>
        
        {/* Find Recipes Tab */}
        <TabsContent value="findRecipes" className="mt-0 p-0">
          <div className="p-4 space-y-6">
            {/* Input Mode Tabs */}
            <Tabs 
              value={inputMode} 
              onValueChange={setInputMode} 
              className="w-full"
            >
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="pantry">{t("fromPantry")}</TabsTrigger>
                <TabsTrigger value="manual">{t("manualEntry")}</TabsTrigger>
              </TabsList>
              
              {/* From Pantry Content */}
              <TabsContent value="pantry" className="mt-4 space-y-4">
                <div className="text-sm text-muted-foreground">
                  {t("selectIngredientsFromPantry")}
                </div>
                
                {/* Pantry Items Selection */}
                <div className="grid grid-cols-1 gap-3 max-h-60 overflow-y-auto">
                  {items.map(item => (
                    <div
                      key={item.id}
                      className={cn(
                        "flex items-center justify-between p-3 border rounded-lg transition-colors",
                        selectedPantryItems.includes(item.id)
                          ? "bg-primary/10 border-primary"
                          : "bg-white hover:bg-gray-50"
                      )}
                      onClick={() => togglePantryItemSelection(item.id)}
                    >
                      <div className="flex items-center">
                        <div className={cn(
                          "w-5 h-5 border rounded-sm flex items-center justify-center mr-3",
                          selectedPantryItems.includes(item.id)
                            ? "bg-primary border-primary text-white"
                            : "border-gray-300"
                        )}>
                          {selectedPantryItems.includes(item.id) && (
                            <CheckCircle2 className="w-4 h-4" />
                          )}
                        </div>
                        <div>
                          <div className="font-medium">{isRtl ? item.nameAr : item.name}</div>
                          <div className="text-xs text-gray-500">
                            {item.quantity} {item.unit}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Button 
                  onClick={addSelectedPantryItems}
                  disabled={selectedPantryItems.length === 0}
                  className="w-full"
                >
                  {t("addSelectedIngredients")}
                </Button>
              </TabsContent>
              
              {/* Manual Entry Content */}
              <TabsContent value="manual" className="mt-4 space-y-4">
                <div className="text-sm text-muted-foreground">
                  {t("addIngredientsManually")}
                </div>
                
                {/* Manual Input */}
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex space-x-2">
                    <div className="flex-1">
                      <Label htmlFor="ingredient-name" className="mb-1.5 block text-sm font-medium">
                        {t("ingredientName")}
                      </Label>
                      <Input
                        id="ingredient-name"
                        value={additionalIngredient}
                        onChange={(e) => {
                          setAdditionalIngredient(e.target.value);
                          // Auto-update ingredients in real-time
                          const currentItem = itemsToFindRecipes.find(item => item.name === "Current Ingredient");
                          if (e.target.value.trim()) {
                            if (currentItem) {
                              // Update existing temporary ingredient
                              setItemsToFindRecipes(
                                itemsToFindRecipes.map(item => 
                                  item.id === currentItem.id 
                                    ? { ...item, name: e.target.value.trim() } 
                                    : item
                                )
                              );
                            } else {
                              // Add new temporary ingredient
                              const newIngredient: IngredientReviewItem = {
                                id: "temp-ingredient",
                                name: "Current Ingredient",
                                quantity: additionalQuantity || "1",
                                unit: additionalUnit || "unit",
                                fromPantry: false,
                                isOptional: false
                              };
                              setItemsToFindRecipes([...itemsToFindRecipes, newIngredient]);
                            }
                          } else if (currentItem) {
                            // Remove temporary ingredient if field is empty
                            setItemsToFindRecipes(
                              itemsToFindRecipes.filter(item => item.id !== currentItem.id)
                            );
                          }
                        }}
                        placeholder={t("enterIngredient")}
                        className="w-full"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            // Finalize the current ingredient
                            const currentItem = itemsToFindRecipes.find(item => item.name === "Current Ingredient");
                            if (currentItem && additionalIngredient.trim()) {
                              // Update temporary ingredient and make it permanent
                              const permanentId = Math.random().toString(36).substring(2, 9);
                              setItemsToFindRecipes(
                                itemsToFindRecipes.map(item => 
                                  item.id === currentItem.id 
                                    ? { ...item, id: permanentId, name: additionalIngredient.trim() } 
                                    : item
                                )
                              );
                              
                              // Clear the inputs for next ingredient
                              setAdditionalIngredient("");
                              setAdditionalQuantity("1");
                            }
                          }
                        }}
                      />
                    </div>
                  </div>
                  
                  <div className="flex space-x-3">
                    <div className="w-1/4">
                      <Label htmlFor="ingredient-quantity" className="mb-1.5 block text-sm font-medium">
                        {t("quantity")}
                      </Label>
                      <Input
                        id="ingredient-quantity"
                        type="text"
                        value={additionalQuantity}
                        onChange={(e) => {
                          setAdditionalQuantity(e.target.value);
                          // Update current ingredient quantity if exists
                          const currentItem = itemsToFindRecipes.find(item => item.name === "Current Ingredient");
                          if (currentItem) {
                            setItemsToFindRecipes(
                              itemsToFindRecipes.map(item => 
                                item.id === currentItem.id 
                                  ? { ...item, quantity: e.target.value } 
                                  : item
                              )
                            );
                          }
                        }}
                        className="w-full"
                      />
                    </div>
                    <div className="w-2/4">
                      <Label htmlFor="ingredient-unit" className="mb-1.5 block text-sm font-medium">
                        {t("unit")}
                      </Label>
                      <Select 
                        value={additionalUnit} 
                        onValueChange={(value) => {
                          setAdditionalUnit(value);
                          // Update current ingredient unit if exists
                          const currentItem = itemsToFindRecipes.find(item => item.name === "Current Ingredient");
                          if (currentItem) {
                            setItemsToFindRecipes(
                              itemsToFindRecipes.map(item => 
                                item.id === currentItem.id 
                                  ? { ...item, unit: value } 
                                  : item
                              )
                            );
                          }
                        }}
                      >
                        <SelectTrigger id="ingredient-unit" className="w-full">
                          <SelectValue placeholder={t("selectUnit")} />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="unit">{t("unit")}</SelectItem>
                          <SelectItem value="g">{t("gram")}</SelectItem>
                          <SelectItem value="kg">{t("kilogram")}</SelectItem>
                          <SelectItem value="ml">{t("milliliter")}</SelectItem>
                          <SelectItem value="l">{t("liter")}</SelectItem>
                          <SelectItem value="tsp">{t("teaspoon")}</SelectItem>
                          <SelectItem value="tbsp">{t("tablespoon")}</SelectItem>
                          <SelectItem value="cup">{t("cup")}</SelectItem>
                          <SelectItem value="pcs">{t("pieces")}</SelectItem>
                          <SelectItem value="bunch">{t("bunch")}</SelectItem>
                          <SelectItem value="pinch">{t("pinch")}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end w-1/4">
                      <div className="w-full h-10 border border-input rounded-md bg-muted/30 flex items-center justify-center text-muted-foreground">
                        <span className="text-sm">{t("autoSaved")}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Alternative Input Methods */}
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant="outline"
                    className="flex flex-col items-center py-3 h-auto"
                    onClick={handleVoiceInput}
                    disabled={voiceInputActive}
                  >
                    {voiceInputActive ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Mic className="h-5 w-5 mb-1" />
                    )}
                    <span className="text-xs">{t("voice")}</span>
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="flex flex-col items-center py-3 h-auto"
                    onClick={handleCameraCapture}
                  >
                    <Camera className="h-5 w-5 mb-1" />
                    <span className="text-xs">{t("camera")}</span>
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      ref={cameraRef}
                      className="hidden"
                      onChange={handleCameraFileChange}
                    />
                  </Button>
                  
                  <Button
                    variant="outline"
                    className="flex flex-col items-center py-3 h-auto"
                    onClick={handleFileUpload}
                  >
                    <Upload className="h-5 w-5 mb-1" />
                    <span className="text-xs">{t("upload")}</span>
                    <input
                      type="file"
                      accept=".jpg,.jpeg,.png,.pdf,.txt"
                      ref={fileUploadRef}
                      className="hidden"
                      onChange={handleFileChange}
                    />
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
            
            {/* Selected Ingredients */}
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <h2 className="font-medium">{t("selectedIngredients")}</h2>
                {itemsToFindRecipes.length > 0 && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-red-500 hover:text-red-700 hover:bg-red-50 h-7 px-2"
                    onClick={() => setItemsToFindRecipes([])}
                  >
                    <Trash2 className="h-3.5 w-3.5 mr-1" />
                    {t("clearAll")}
                  </Button>
                )}
              </div>
              
              {!reviewingIngredients ? (
                <>
                  {itemsToFindRecipes.length === 0 ? (
                    <div className="text-center py-6 text-gray-400">
                      <FileText className="h-12 w-12 mx-auto mb-2 opacity-20" />
                      <p className="text-sm">{t("noIngredientsYet")}</p>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {itemsToFindRecipes.map((ingredient) => (
                        <Badge
                          key={ingredient.id}
                          variant="secondary"
                          className="pl-3 pr-2 py-1.5 bg-gray-100 hover:bg-gray-200 flex items-center gap-1"
                        >
                          <span>{ingredient.name} ({ingredient.quantity} {ingredient.unit})</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-4 w-4 ml-1 hover:bg-gray-300 rounded-full"
                            onClick={() => removeIngredient(ingredient.id)}
                          >
                            <svg className="h-3 w-3" viewBox="0 0 24 24">
                              <path d="M18 6L6 18M6 6l12 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                            </svg>
                          </Button>
                        </Badge>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">{t("reviewIngredients")}</h3>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={cancelReviewIngredients}
                    >
                      <ArrowLeft className="h-4 w-4 mr-1" />
                      {t("back")}
                    </Button>
                  </div>
                  
                  <div className="text-sm text-muted-foreground">
                    {t("adjustIngredientsBeforeSearch")}
                  </div>
                  
                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {itemsToFindRecipes.map((ingredient) => (
                      <div 
                        key={ingredient.id}
                        className={`p-4 border rounded-lg ${ingredient.fromPantry ? 'bg-blue-50 border-blue-200' : 'bg-white'}`}
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <div className="flex items-center">
                              <span className="font-medium mr-2">{ingredient.name}</span>
                              {ingredient.fromPantry && (
                                <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300 text-xs">
                                  {t("fromPantry")}
                                </Badge>
                              )}
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7 hover:bg-gray-100 rounded-full"
                            onClick={() => removeIngredient(ingredient.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                        
                        <div className="grid grid-cols-12 gap-2 items-center">
                          <div className="col-span-3">
                            <Input
                              type="text"
                              value={ingredient.quantity}
                              onChange={(e) => updateIngredientQuantity(ingredient.id, e.target.value)}
                              className="w-full"
                            />
                          </div>
                          <div className="col-span-4">
                            <Select 
                              value={ingredient.unit} 
                              onValueChange={(value) => updateIngredientUnit(ingredient.id, value)}
                            >
                              <SelectTrigger className="w-full">
                                <SelectValue placeholder={t("unit")} />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="unit">{t("unit")}</SelectItem>
                                <SelectItem value="g">{t("gram")}</SelectItem>
                                <SelectItem value="kg">{t("kilogram")}</SelectItem>
                                <SelectItem value="ml">{t("milliliter")}</SelectItem>
                                <SelectItem value="l">{t("liter")}</SelectItem>
                                <SelectItem value="tsp">{t("teaspoon")}</SelectItem>
                                <SelectItem value="tbsp">{t("tablespoon")}</SelectItem>
                                <SelectItem value="cup">{t("cup")}</SelectItem>
                                <SelectItem value="pcs">{t("pieces")}</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="col-span-5 flex items-center">
                            <div className="flex items-center">
                              <Checkbox 
                                id={`optional-${ingredient.id}`}
                                checked={ingredient.isOptional}
                                onCheckedChange={() => toggleIngredientOptional(ingredient.id)}
                                className="mr-2 data-[state=checked]:bg-amber-500"
                              />
                              <Label 
                                htmlFor={`optional-${ingredient.id}`}
                                className="text-sm cursor-pointer"
                              >
                                {t("optional")}
                              </Label>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {!reviewingIngredients && (
                <Button 
                  className="w-full mt-4"
                  disabled={itemsToFindRecipes.length === 0}
                  onClick={findRecipes}
                >
                  {itemsToFindRecipes.length > 0 ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-2" />
                      {t("reviewIngredients")}
                    </>
                  ) : (
                    <>
                      <Utensils className="h-4 w-4 mr-2" />
                      {t("findRecipes")}
                    </>
                  )}
                </Button>
              )}
              
              {reviewingIngredients && (
                <Button 
                  className="w-full mt-4"
                  onClick={findRecipes}
                >
                  <Utensils className="h-4 w-4 mr-2" />
                  {t("findRecipesNow")}
                </Button>
              )}
            </div>
          </div>
        </TabsContent>
      </Tabs>

      <BottomNavigation />
    </div>
  );
}