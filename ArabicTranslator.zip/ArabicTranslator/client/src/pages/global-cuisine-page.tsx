import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { ArrowLeft, Search, Filter, ChevronDown, Globe, Utensils, Coffee, Cake } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { RecipeListItem } from "@/components/recipe/recipe-list-item";
import { RecipeDetail } from "@/components/recipe/recipe-detail";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { getRecipeRecommendations } from "@/lib/openai";
import { useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

// List of cuisines with their flags
const cuisines = [
  { id: "italian", name: "Italian", nameAr: "إيطالي", flag: "🇮🇹" },
  { id: "mexican", name: "Mexican", nameAr: "مكسيكي", flag: "🇲🇽" },
  { id: "japanese", name: "Japanese", nameAr: "ياباني", flag: "🇯🇵" },
  { id: "indian", name: "Indian", nameAr: "هندي", flag: "🇮🇳" },
  { id: "chinese", name: "Chinese", nameAr: "صيني", flag: "🇨🇳" },
  { id: "french", name: "French", nameAr: "فرنسي", flag: "🇫🇷" },
  { id: "thai", name: "Thai", nameAr: "تايلندي", flag: "🇹🇭" },
  { id: "spanish", name: "Spanish", nameAr: "إسباني", flag: "🇪🇸" },
  { id: "greek", name: "Greek", nameAr: "يوناني", flag: "🇬🇷" },
  { id: "lebanese", name: "Lebanese", nameAr: "لبناني", flag: "🇱🇧" },
  { id: "moroccan", name: "Moroccan", nameAr: "مغربي", flag: "🇲🇦" },
  { id: "turkish", name: "Turkish", nameAr: "تركي", flag: "🇹🇷" },
];

const mealTypes = [
  { id: "breakfast", name: "Breakfast", nameAr: "إفطار" },
  { id: "lunch", name: "Lunch", nameAr: "غداء" },
  { id: "dinner", name: "Dinner", nameAr: "عشاء" },
];

const dietaryOptions = [
  { id: "vegan", name: "Vegan", nameAr: "نباتي" },
  { id: "vegetarian", name: "Vegetarian", nameAr: "نباتي" },
  { id: "gluten-free", name: "Gluten-Free", nameAr: "خالي من الغلوتين" },
  { id: "dairy-free", name: "Dairy-Free", nameAr: "خالي من منتجات الألبان" },
];

// Define subcategories for main categories
const categorySubcategories = {
  food: [
    { id: "main-dishes", name: "Main Dishes", nameAr: "الأطباق الرئيسية" },
    { id: "appetizers", name: "Appetizers", nameAr: "المقبلات" },
    { id: "pickles", name: "Pickles", nameAr: "المخللات" },
    { id: "soups", name: "Soups", nameAr: "الحساء" },
    { id: "sauces", name: "Sauces", nameAr: "الصلصات" },
    { id: "others", name: "Others", nameAr: "أخرى" },
  ],
  desserts: [
    { id: "traditional", name: "Traditional", nameAr: "تقليدية" },
    { id: "western", name: "Western", nameAr: "غربية" },
    { id: "pastries", name: "Pastries", nameAr: "معجنات" },
    { id: "ice-cream", name: "Ice Cream", nameAr: "آيس كريم" },
    { id: "others", name: "Others", nameAr: "أخرى" },
  ],
  drinks: [
    { id: "detox", name: "Detox", nameAr: "ديتوكس" },
    { id: "cocktails", name: "Cocktails", nameAr: "كوكتيلات" },
    { id: "alcoholic", name: "Alcoholic", nameAr: "كحولية" },
    { id: "hot-drinks", name: "Hot Drinks", nameAr: "مشروبات ساخنة" },
    { id: "others", name: "Others", nameAr: "أخرى" },
  ]
};

export default function GlobalCuisinePage() {
  const { t, isRtl } = useI18n();
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  const { user } = useAuth();
  
  const [isFiltersExpanded, setIsFiltersExpanded] = React.useState(false);
  const [selectedCuisine, setSelectedCuisine] = React.useState<string>("");
  const [selectedMealType, setSelectedMealType] = React.useState<string>("");
  const [selectedDietaryOptions, setSelectedDietaryOptions] = React.useState<string[]>([]);
  
  // Category navigation
  const [selectedCategory, setSelectedCategory] = React.useState<string>("food");
  const [selectedSubcategory, setSelectedSubcategory] = React.useState<string>("");
  
  // Animation variants for cards
  const cardVariants = {
    initial: { scale: 0.9, opacity: 0 },
    animate: { scale: 1, opacity: 1, transition: { duration: 0.3 } },
    hover: { scale: 1.05, transition: { duration: 0.2 } }
  };
  
  const [isSearching, setIsSearching] = React.useState(false);
  const [searchError, setSearchError] = React.useState<string | null>(null);
  const [searchResults, setSearchResults] = React.useState<any[]>([]);
  const [selectedRecipeId, setSelectedRecipeId] = React.useState<string | null>(null);
  
  const selectedRecipe = searchResults.find(
    (recipe) => recipe.id === selectedRecipeId
  );
  
  // Toggle dietary option selection
  const toggleDietaryOption = (optionId: string) => {
    setSelectedDietaryOptions(prev => 
      prev.includes(optionId) 
        ? prev.filter(id => id !== optionId) 
        : [...prev, optionId]
    );
  };
  
  // Handle searching for recipes
  const findGlobalRecipes = async () => {
    setIsSearching(true);
    setSearchError(null);
    
    try {
      // Prepare search parameters
      const searchParams = {
        cuisinePreferences: selectedCuisine && selectedCuisine !== "any" ? [selectedCuisine] : [],
        dietaryPreferences: selectedDietaryOptions,
        mealType: selectedMealType || undefined,
        ingredients: [] // No ingredients required for global cuisine search
      };
      
      const results = await getRecipeRecommendations(searchParams);
      setSearchResults(results);
    } catch (error) {
      console.error("Search error:", error);
      setSearchError(t("searchError"));
    } finally {
      setIsSearching(false);
    }
  };

  const handleRecipeClick = (id: string) => {
    setSelectedRecipeId(id);
    window.scrollTo(0, 0);
  };

  const handleBackClick = () => {
    setSelectedRecipeId(null);
  };
  
  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setSelectedSubcategory("");
  };
  
  const handleSubcategorySelect = (subcategory: string) => {
    setSelectedSubcategory(subcategory);
    
    // You could trigger a search here if needed
    // For now just update the state
    const searchParams = {
      cuisinePreferences: selectedCuisine ? [selectedCuisine] : [],
      dietaryPreferences: selectedDietaryOptions,
      category: selectedCategory,
      subcategory: subcategory,
      ingredients: [] 
    };
    
    // Optionally automatically trigger search
    // findGlobalRecipes(searchParams);
  };
  
  // If a recipe is selected, show the recipe detail view
  if (selectedRecipeId && selectedRecipe) {
    return <RecipeDetail recipe={selectedRecipe} onBackClick={handleBackClick} />;
  }
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-neutral-50 shadow-xl flex flex-col pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white z-10 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate("/home")}
            className="p-1"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-neutral-800">
            {t("exploreGlobalCuisines")}
          </h1>
          <div className="w-10"></div>
        </div>
      </div>
      
      {/* Cuisine Selection Filter */}
      <div className="p-4 pb-0">
        <p className="text-center text-sm text-gray-600 mb-4">
          {t("discoverRecipesSubtitle")} 🌍
        </p>
        
        <div className="mb-6">
          <label className="block text-sm font-medium mb-1">{t("selectCuisineCountry")}</label>
          <Select 
            value={selectedCuisine} 
            onValueChange={setSelectedCuisine}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder={t("anyCuisine")} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="any">{t("anyCuisine")}</SelectItem>
              {cuisines.map(cuisine => (
                <SelectItem key={cuisine.id} value={cuisine.id}>
                  {cuisine.flag} {isRtl ? cuisine.nameAr : cuisine.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Category Cards */}
      <div className="p-4 pt-0">
        <div className="grid grid-cols-3 gap-3 mb-6">
          {/* Food Category Card */}
          <motion.div
            initial="initial"
            animate="animate"
            whileHover="hover"
            variants={cardVariants}
            className={cn(
              "cursor-pointer rounded-lg overflow-hidden shadow-md text-center", 
              selectedCategory === "food" ? "border-2 border-primary" : ""
            )}
            onClick={() => handleCategorySelect("food")}
          >
            <div className="bg-amber-100 p-4">
              <Utensils className="mx-auto h-10 w-10 text-amber-600" />
              <h3 className="text-sm font-medium mt-2">{t("meal")}</h3>
            </div>
          </motion.div>
          
          {/* Desserts Category Card */}
          <motion.div
            initial="initial"
            animate="animate"
            whileHover="hover"
            variants={cardVariants}
            className={cn(
              "cursor-pointer rounded-lg overflow-hidden shadow-md text-center",
              selectedCategory === "desserts" ? "border-2 border-primary" : ""
            )}
            onClick={() => handleCategorySelect("desserts")}
          >
            <div className="bg-rose-100 p-4">
              <Cake className="mx-auto h-10 w-10 text-rose-600" />
              <h3 className="text-sm font-medium mt-2">{t("dessert")}</h3>
            </div>
          </motion.div>
          
          {/* Drinks Category Card */}
          <motion.div
            initial="initial"
            animate="animate"
            whileHover="hover"
            variants={cardVariants}
            className={cn(
              "cursor-pointer rounded-lg overflow-hidden shadow-md text-center",
              selectedCategory === "drinks" ? "border-2 border-primary" : ""
            )}
            onClick={() => handleCategorySelect("drinks")}
          >
            <div className="bg-blue-100 p-4">
              <Coffee className="mx-auto h-10 w-10 text-blue-600" />
              <h3 className="text-sm font-medium mt-2">{t("drinks")}</h3>
            </div>
          </motion.div>
        </div>
        
        {/* Subcategories for selected category */}
        <Card className="mb-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">
              {selectedCategory === "food" ? t("meal") :
               selectedCategory === "desserts" ? t("dessert") : t("drinks")}
            </CardTitle>
            <CardDescription>
              {t("selectSubcategory")}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2">
              {categorySubcategories[selectedCategory as keyof typeof categorySubcategories].map((subcategory) => (
                <Button
                  key={subcategory.id}
                  variant={selectedSubcategory === subcategory.id ? "default" : "outline"}
                  size="sm"
                  className="justify-start text-sm h-auto py-2"
                  onClick={() => handleSubcategorySelect(subcategory.id)}
                >
                  {isRtl ? subcategory.nameAr : subcategory.name}
                </Button>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full"
              onClick={() => findGlobalRecipes()}
            >
              <Globe className="mr-2 h-4 w-4" />
              {t("findRecipes")}
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      {/* Filters Section */}
      <div className="p-4">
        <Button 
          variant="outline" 
          className="w-full flex items-center justify-between mb-4"
          onClick={() => setIsFiltersExpanded(!isFiltersExpanded)}
        >
          <div className="flex items-center">
            <Filter className="mr-2 h-4 w-4" />
            <span>{t("additionalFilters")}</span>
          </div>
          <span>{isFiltersExpanded ? "▲" : "▼"}</span>
        </Button>
        
        {isFiltersExpanded && (
          <div className="p-4 border rounded-lg bg-white shadow-sm mb-6 space-y-4">
            {/* Meal Type */}
            <div>
              <label className="block text-sm font-medium mb-1">{t("mealType")}</label>
              <div className="flex space-x-2 rtl:space-x-reverse">
                {mealTypes.map(type => (
                  <Button
                    key={type.id}
                    type="button"
                    variant={selectedMealType === type.id ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => setSelectedMealType(prev => prev === type.id ? "" : type.id)}
                  >
                    {isRtl ? type.nameAr : type.name}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Dietary Restrictions */}
            <div>
              <label className="block text-sm font-medium mb-1">{t("dietaryOptions")}</label>
              <div className="grid grid-cols-2 gap-2">
                {dietaryOptions.map(option => (
                  <Button
                    key={option.id}
                    type="button"
                    variant={selectedDietaryOptions.includes(option.id) ? "default" : "outline"}
                    className="justify-start text-sm h-auto py-2"
                    onClick={() => toggleDietaryOption(option.id)}
                  >
                    {selectedDietaryOptions.includes(option.id) && (
                      <span className="mr-1">✓</span>
                    )}
                    {isRtl ? option.nameAr : option.name}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Search button */}
            <Button className="w-full" onClick={findGlobalRecipes}>
              {t("searchCuisines")}
            </Button>
          </div>
        )}
      </div>
      
      <div className="flex-1 p-4">
        {/* Results Section */}
        {(searchResults.length > 0 || isSearching || searchError) && (
          <div className="mt-2">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">{t("recipeResults")}</h2>
            </div>

            {isSearching && (
              <div className="flex flex-col items-center justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                <p className="mt-4 text-gray-600">{t("searching")}</p>
              </div>
            )}

            {searchError && !isSearching && (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-red-500">{searchError}</p>
                <p className="mt-2 text-gray-600">{t("tryAgain")}</p>
              </div>
            )}

            {!isSearching && !searchError && searchResults.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-gray-600">{t("noRecipesFound")}</p>
                <p className="mt-2 text-gray-600">{t("tryDifferentCuisine")}</p>
              </div>
            )}

            {!isSearching && !searchError && searchResults.length > 0 && (
              <div className="space-y-4">
                {searchResults.map((recipe) => (
                  <RecipeListItem
                    key={recipe.id}
                    recipe={recipe}
                    onClick={() => handleRecipeClick(recipe.id)}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      
      <BottomNavigation />
    </div>
  );
}