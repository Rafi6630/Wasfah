import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Plus, 
  Trash2, 
  Camera, 
  Mic, 
  Link, 
  Eye, 
  Upload,
  Globe,
  Lock,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

// Mock cuisine options
const cuisineOptions = [
  "arabic", "lebanese", "egyptian", "moroccan", "turkish", 
  "indian", "italian", "mexican", "american", "chinese", 
  "japanese", "thai", "french", "mediterranean", "other"
];

// Mock meal type options
const mealTypeOptions = [
  "breakfast", "lunch", "dinner", "dessert", "snack", 
  "appetizer", "drink", "sauce", "salad", "soup"
];

// Mock ingredients from user's pantry
const pantryIngredients = [
  "Olive Oil", "Flour", "Rice", "Chicken", "Beef", 
  "Tomatoes", "Onions", "Garlic", "Salt", "Pepper", 
  "Cumin", "Lemon", "Parsley", "Mint"
];

interface RecipeIngredient {
  id: string;
  name: string;
  quantity: string;
  unit: string;
}

interface RecipeStep {
  id: string;
  text: string;
  image?: string;
}

export default function CreateRecipePage() {
  const { t, isRtl, language } = useI18n();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = React.useState<string>("edit");
  const [isSubmitting, setIsSubmitting] = React.useState<boolean>(false);
  
  // Recipe form state
  const [recipeForm, setRecipeForm] = React.useState({
    title: "",
    titleAr: "",
    description: "",
    descriptionAr: "",
    cuisine: "",
    mealType: "",
    prepTime: "",
    cookTime: "",
    servings: "4",
    difficulty: "medium",
    coverImage: "",
  });
  
  // Ingredients state
  const [ingredients, setIngredients] = React.useState<RecipeIngredient[]>([
    { id: "1", name: "", quantity: "", unit: "g" }
  ]);
  
  // Steps state
  const [steps, setSteps] = React.useState<RecipeStep[]>([
    { id: "1", text: "" }
  ]);
  
  // Privacy state
  const [isPublic, setIsPublic] = React.useState<boolean>(true);
  
  const handleGoBack = () => {
    setLocation("/profile");
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setRecipeForm({ ...recipeForm, [name]: value });
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setRecipeForm({ ...recipeForm, [name]: value });
  };
  
  // Ingredient handling
  const addIngredient = () => {
    setIngredients([
      ...ingredients, 
      { 
        id: Date.now().toString(), 
        name: "", 
        quantity: "", 
        unit: "g" 
      }
    ]);
  };
  
  const removeIngredient = (id: string) => {
    if (ingredients.length > 1) {
      setIngredients(ingredients.filter(ing => ing.id !== id));
    }
  };
  
  const updateIngredient = (id: string, field: keyof RecipeIngredient, value: string) => {
    setIngredients(
      ingredients.map(ing => 
        ing.id === id ? { ...ing, [field]: value } : ing
      )
    );
  };
  
  // Step handling
  const addStep = () => {
    setSteps([
      ...steps, 
      { id: Date.now().toString(), text: "" }
    ]);
  };
  
  const removeStep = (id: string) => {
    if (steps.length > 1) {
      setSteps(steps.filter(step => step.id !== id));
    }
  };
  
  const updateStep = (id: string, text: string) => {
    setSteps(
      steps.map(step => 
        step.id === id ? { ...step, text } : step
      )
    );
  };
  
  const addStepImage = (id: string) => {
    // In a real app, this would open a file picker
    alert(t("imageUploadFeatureNotImplemented"));
  };
  
  const recordStepAudio = (id: string) => {
    // In a real app, this would start audio recording
    alert(t("audioRecordingFeatureNotImplemented"));
  };
  
  const handleSubmit = async (isPublishing: boolean) => {
    // Validation
    if (!recipeForm.title.trim()) {
      alert(t("pleaseEnterRecipeTitle"));
      return;
    }
    
    if (ingredients.some(ing => !ing.name.trim() || !ing.quantity.trim())) {
      alert(t("pleaseCompleteAllIngredients"));
      return;
    }
    
    if (steps.some(step => !step.text.trim())) {
      alert(t("pleaseCompleteAllSteps"));
      return;
    }
    
    setIsSubmitting(true);
    
    // In a real app, this would send the recipe data to the server
    setTimeout(() => {
      setIsSubmitting(false);
      if (isPublishing) {
        alert(t("recipePublishedSuccessfully"));
      } else {
        alert(t("recipeSavedSuccessfully"));
      }
      setLocation("/profile");
    }, 1500);
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold">{t("createRecipe")}</h1>
        <div className="absolute right-2">
          <LanguageSwitcher />
        </div>
      </div>
      
      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-center rounded-none border-b bg-transparent">
          <TabsTrigger 
            value="edit" 
            className="flex-1 data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-none border-b-2 data-[state=active]:border-primary border-transparent"
          >
            {t("edit")}
          </TabsTrigger>
          <TabsTrigger 
            value="preview" 
            className="flex-1 data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-none border-b-2 data-[state=active]:border-primary border-transparent"
          >
            {t("preview")}
          </TabsTrigger>
        </TabsList>
        
        {/* Edit Content */}
        <TabsContent value="edit" className="p-4 space-y-6">
          {/* Recipe Cover Image */}
          <div
            className="h-48 bg-gray-100 rounded-lg flex flex-col items-center justify-center cursor-pointer"
            onClick={() => alert(t("imageUploadFeatureNotImplemented"))}
          >
            {recipeForm.coverImage ? (
              <img 
                src={recipeForm.coverImage} 
                alt={recipeForm.title} 
                className="w-full h-full object-cover rounded-lg"
              />
            ) : (
              <>
                <Camera className="h-10 w-10 text-gray-400 mb-2" />
                <p className="text-sm text-gray-500">{t("addCoverImage")}</p>
              </>
            )}
          </div>
          
          {/* Basic Info Section */}
          <div className="space-y-4">
            <h2 className="font-medium text-lg">{t("basicInfo")}</h2>
            
            <div className="space-y-2">
              <Label htmlFor="title">{t("recipeTitle")} ({t("english")})</Label>
              <Input
                id="title"
                name="title"
                placeholder={t("enterRecipeTitle")}
                value={recipeForm.title}
                onChange={handleInputChange}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="titleAr">{t("recipeTitle")} ({t("arabic")})</Label>
              <Input
                id="titleAr"
                name="titleAr"
                placeholder={t("enterRecipeTitleArabic")}
                value={recipeForm.titleAr}
                onChange={handleInputChange}
                dir="rtl"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">{t("description")} ({t("english")})</Label>
              <Textarea
                id="description"
                name="description"
                placeholder={t("enterRecipeDescription")}
                value={recipeForm.description}
                onChange={handleInputChange}
                className="min-h-[80px]"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="descriptionAr">{t("description")} ({t("arabic")})</Label>
              <Textarea
                id="descriptionAr"
                name="descriptionAr"
                placeholder={t("enterRecipeDescriptionArabic")}
                value={recipeForm.descriptionAr}
                onChange={handleInputChange}
                className="min-h-[80px]"
                dir="rtl"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="cuisine">{t("cuisine")}</Label>
                <Select 
                  value={recipeForm.cuisine} 
                  onValueChange={(value) => handleSelectChange("cuisine", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("selectCuisine")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      {cuisineOptions.map(cuisine => (
                        <SelectItem key={cuisine} value={cuisine}>
                          {t(cuisine)}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mealType">{t("mealType")}</Label>
                <Select 
                  value={recipeForm.mealType} 
                  onValueChange={(value) => handleSelectChange("mealType", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t("selectMealType")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      {mealTypeOptions.map(type => (
                        <SelectItem key={type} value={type}>
                          {t(type)}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="prepTime">{t("prepTime")} ({t("min")})</Label>
                <Input
                  id="prepTime"
                  name="prepTime"
                  type="number"
                  placeholder="15"
                  value={recipeForm.prepTime}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="cookTime">{t("cookTime")} ({t("min")})</Label>
                <Input
                  id="cookTime"
                  name="cookTime"
                  type="number"
                  placeholder="30"
                  value={recipeForm.cookTime}
                  onChange={handleInputChange}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="servings">{t("servings")}</Label>
                <Input
                  id="servings"
                  name="servings"
                  type="number"
                  placeholder="4"
                  value={recipeForm.servings}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="difficulty">{t("difficulty")}</Label>
              <Select 
                value={recipeForm.difficulty} 
                onValueChange={(value) => handleSelectChange("difficulty", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t("selectDifficulty")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectGroup>
                    <SelectItem value="easy">{t("easy")}</SelectItem>
                    <SelectItem value="medium">{t("medium")}</SelectItem>
                    <SelectItem value="hard">{t("hard")}</SelectItem>
                  </SelectGroup>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Ingredients Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-medium text-lg">{t("ingredients")}</h2>
              <div className="text-xs text-blue-600">
                {t("suggestFromPantry")}
              </div>
            </div>
            
            <div className="space-y-3">
              {ingredients.map((ingredient, index) => (
                <div key={ingredient.id} className="flex items-end gap-2">
                  <div className="flex-1">
                    <Label htmlFor={`ingredient-${ingredient.id}`} className="sr-only">
                      {t("ingredient")} {index + 1}
                    </Label>
                    <Input
                      id={`ingredient-${ingredient.id}`}
                      placeholder={t("ingredientName")}
                      value={ingredient.name}
                      onChange={(e) => updateIngredient(ingredient.id, "name", e.target.value)}
                      list={`pantry-suggestions-${ingredient.id}`}
                    />
                    <datalist id={`pantry-suggestions-${ingredient.id}`}>
                      {pantryIngredients.map(item => (
                        <option key={item} value={item} />
                      ))}
                    </datalist>
                  </div>
                  
                  <div className="w-20">
                    <Input
                      placeholder={t("amount")}
                      value={ingredient.quantity}
                      onChange={(e) => updateIngredient(ingredient.id, "quantity", e.target.value)}
                    />
                  </div>
                  
                  <div className="w-20">
                    <Select 
                      value={ingredient.unit} 
                      onValueChange={(value) => updateIngredient(ingredient.id, "unit", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          <SelectItem value="g">{t("gram")}</SelectItem>
                          <SelectItem value="kg">{t("kilogram")}</SelectItem>
                          <SelectItem value="ml">{t("milliliter")}</SelectItem>
                          <SelectItem value="l">{t("liter")}</SelectItem>
                          <SelectItem value="tsp">{t("teaspoon")}</SelectItem>
                          <SelectItem value="tbsp">{t("tablespoon")}</SelectItem>
                          <SelectItem value="cup">{t("cup")}</SelectItem>
                          <SelectItem value="piece">{t("piece")}</SelectItem>
                        </SelectGroup>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeIngredient(ingredient.id)}
                    disabled={ingredients.length <= 1}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={addIngredient}
              >
                <Plus className="h-4 w-4 mr-2" />
                {t("addIngredient")}
              </Button>
            </div>
          </div>
          
          {/* Instructions Section */}
          <div className="space-y-4">
            <h2 className="font-medium text-lg">{t("instructions")}</h2>
            
            <div className="space-y-4">
              {steps.map((step, index) => (
                <div key={step.id} className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">
                      {index + 1}
                    </div>
                    <Label htmlFor={`step-${step.id}`} className="sr-only">
                      {t("step")} {index + 1}
                    </Label>
                  </div>
                  
                  <div className="flex gap-2">
                    <Textarea
                      id={`step-${step.id}`}
                      placeholder={t("describeStep")}
                      value={step.text}
                      onChange={(e) => updateStep(step.id, e.target.value)}
                      className="min-h-[80px]"
                    />
                    
                    <div className="flex flex-col gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => addStepImage(step.id)}
                        title={t("addImage")}
                      >
                        <Camera className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => recordStepAudio(step.id)}
                        title={t("recordAudio")}
                      >
                        <Mic className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeStep(step.id)}
                        disabled={steps.length <= 1}
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        title={t("removeStep")}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              
              <Button 
                variant="outline" 
                className="w-full" 
                onClick={addStep}
              >
                <Plus className="h-4 w-4 mr-2" />
                {t("addStep")}
              </Button>
            </div>
          </div>
          
          {/* Privacy Settings */}
          <div className="space-y-4 pt-2">
            <h2 className="font-medium text-lg">{t("privacySettings")}</h2>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {isPublic ? (
                  <Globe className="h-5 w-5 text-green-600" />
                ) : (
                  <Lock className="h-5 w-5 text-gray-600" />
                )}
                <Label htmlFor="public-recipe">
                  {isPublic ? t("publicRecipe") : t("privateRecipe")}
                </Label>
              </div>
              <Switch
                id="public-recipe"
                checked={isPublic}
                onCheckedChange={setIsPublic}
              />
            </div>
            <p className="text-xs text-gray-500">
              {isPublic 
                ? t("publicRecipeDescription") 
                : t("privateRecipeDescription")
              }
            </p>
          </div>
        </TabsContent>
        
        {/* Preview Content */}
        <TabsContent value="preview" className="p-4">
          {recipeForm.title ? (
            <div className="space-y-6">
              {/* Preview Cover Image */}
              <div className="h-48 bg-gray-100 rounded-lg overflow-hidden">
                {recipeForm.coverImage ? (
                  <img 
                    src={recipeForm.coverImage} 
                    alt={recipeForm.title} 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gray-100">
                    <p className="text-gray-400">{t("noImageProvided")}</p>
                  </div>
                )}
              </div>
              
              {/* Recipe Title and Description */}
              <div>
                <h1 className="text-2xl font-bold">{recipeForm.title}</h1>
                
                {recipeForm.description && (
                  <p className="mt-2 text-gray-700">{recipeForm.description}</p>
                )}
                
                {/* Recipe Meta */}
                <div className="flex flex-wrap gap-4 mt-4">
                  {recipeForm.cuisine && (
                    <div className="text-sm">
                      <span className="font-medium">{t("cuisine")}: </span>
                      <span>{t(recipeForm.cuisine)}</span>
                    </div>
                  )}
                  
                  {recipeForm.mealType && (
                    <div className="text-sm">
                      <span className="font-medium">{t("mealType")}: </span>
                      <span>{t(recipeForm.mealType)}</span>
                    </div>
                  )}
                  
                  {recipeForm.prepTime && (
                    <div className="text-sm">
                      <span className="font-medium">{t("prepTime")}: </span>
                      <span>{recipeForm.prepTime} {t("min")}</span>
                    </div>
                  )}
                  
                  {recipeForm.cookTime && (
                    <div className="text-sm">
                      <span className="font-medium">{t("cookTime")}: </span>
                      <span>{recipeForm.cookTime} {t("min")}</span>
                    </div>
                  )}
                  
                  {recipeForm.servings && (
                    <div className="text-sm">
                      <span className="font-medium">{t("servings")}: </span>
                      <span>{recipeForm.servings}</span>
                    </div>
                  )}
                  
                  {recipeForm.difficulty && (
                    <div className="text-sm">
                      <span className="font-medium">{t("difficulty")}: </span>
                      <span>{t(recipeForm.difficulty)}</span>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Ingredients */}
              <div>
                <h2 className="text-xl font-semibold mb-3">{t("ingredients")}</h2>
                
                <ul className="space-y-2 list-disc list-inside">
                  {ingredients.map((ing, index) => (
                    ing.name && (
                      <li key={ing.id} className="text-gray-700">
                        {ing.name} {ing.quantity && `(${ing.quantity} ${t(ing.unit)})`}
                      </li>
                    )
                  ))}
                </ul>
              </div>
              
              {/* Instructions */}
              <div>
                <h2 className="text-xl font-semibold mb-3">{t("instructions")}</h2>
                
                <ol className="space-y-4">
                  {steps.map((step, index) => (
                    step.text && (
                      <li key={step.id} className="flex gap-3">
                        <div className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">
                          {index + 1}
                        </div>
                        <p className="text-gray-700">{step.text}</p>
                      </li>
                    )
                  ))}
                </ol>
              </div>
              
              {/* Recipe author */}
              <div className="flex items-center gap-3 border-t pt-4 mt-6">
                <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden">
                  {user?.avatar_url ? (
                    <img
                      src={user.avatar_url}
                      alt={user.name || ""}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-primary text-white font-bold">
                      {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
                    </div>
                  )}
                </div>
                
                <div>
                  <div className="font-medium">{user?.name || t("you")}</div>
                  <div className="text-xs text-gray-500">{t("recipeCreator")}</div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Eye className="h-16 w-16 mx-auto text-gray-300" />
              <h3 className="mt-4 font-medium text-gray-500">{t("nothingToPreview")}</h3>
              <p className="text-sm text-gray-400 mt-1">{t("addRecipeDetailsFirst")}</p>
              
              <Button 
                variant="outline"
                className="mt-4"
                onClick={() => setActiveTab("edit")}
              >
                {t("switchToEditMode")}
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Bottom action buttons */}
      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto p-4 bg-white border-t flex gap-2">
        <Button
          variant="outline"
          className="flex-1"
          onClick={() => handleSubmit(false)}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <></>
          )}
          {t("saveAsDraft")}
        </Button>
        
        <Button
          className="flex-1"
          onClick={() => handleSubmit(true)}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Upload className="h-4 w-4 mr-2" />
          )}
          {isPublic ? t("publishRecipe") : t("sharePrivately")}
        </Button>
      </div>
    </div>
  );
}