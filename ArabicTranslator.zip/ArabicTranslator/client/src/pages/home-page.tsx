import React, { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Button } from "@/components/ui/button";
import { RecipeCard } from "@/components/recipe/recipe-card";
import { RecipeListItem } from "@/components/recipe/recipe-list-item";
import { RecipeDetail } from "@/components/recipe/recipe-detail";
import { FoodIcons } from "@/components/icons/food-icons";
import { HeroCarousel } from "@/components/home/hero-carousel";
import { DynamicSubcategoryPanel } from "@/components/home/dynamic-subcategory-panel";
import { SeasonalRecipeCarousel } from "@/components/home/seasonal-recipe-carousel";
import { getPopularRecipes, getCategories, getRecipeRecommendations } from "@/lib/openai";
import { useQuery } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Search, Mic, Camera, Filter, CalendarDays, ShoppingBasket, 
  Package, Utensils, Crown, ChefHat, Sparkles 
} from "lucide-react";
import { RoyalCrownIcon, CutleryDivider } from "@/components/icons/crown-icon";
import { IngredientSelector } from "@/components/ingredients/ingredient-selector";

export default function HomePage() {
  const { t, isRtl } = useI18n();
  const [_, setLocation] = useLocation();
  const { user } = useAuth();
  const [selectedRecipeId, setSelectedRecipeId] = React.useState<string | null>(null);
  const [selectedMainCategory, setSelectedMainCategory] = React.useState("food");
  
  // Local cuisine options for global cuisine section
  const localCuisineOptions = [
    { value: "levant", label: "Levant" },
    { value: "italian", label: "Italian" },
    { value: "mexican", label: "Mexican" },
    { value: "chinese", label: "Chinese" },
    { value: "indian", label: "Indian" },
    { value: "japanese", label: "Japanese" },
    { value: "thai", label: "Thai" },
    { value: "turkish", label: "Turkish" },
    { value: "syrian", label: "Syrian" },
    { value: "iraqi", label: "Iraqi" },
    { value: "yemeni", label: "Yemeni" },
    { value: "american", label: "American" },
    { value: "moroccan", label: "Moroccan" },
    { value: "lebanese", label: "Lebanese" },
    { value: "german", label: "German" },
  ];
  
  // Fetch categories
  const { 
    data: categories = [], 
    isLoading: isCategoriesLoading 
  } = useQuery({
    queryKey: ["/api/categories"],
    queryFn: () => getCategories(),
  });
  
  // Fetch AI recommendations
  const { 
    data: recommendations = [],
    isLoading: isRecommendationsLoading 
  } = useQuery({
    queryKey: ["/api/recipes/recommend"],
    queryFn: () => {
      const params = {
        ingredients: Array.isArray(user?.pantry_ingredients) ? user.pantry_ingredients : [],
        dietaryPreferences: Array.isArray(user?.dietary_preferences) ? user.dietary_preferences : undefined,
        cuisinePreferences: Array.isArray(user?.cuisine_preferences) ? user.cuisine_preferences : undefined,
        skillLevel: typeof user?.skill_level === 'string' ? user.skill_level : undefined
      };
      return getRecipeRecommendations(params);
    }
  });
  
  // Fetch popular recipes
  const { 
    data: popularRecipes = [],
    isLoading: isPopularLoading
  } = useQuery({
    queryKey: ["/api/recipes/popular"],
    queryFn: () => getPopularRecipes(),
  });

  const selectedRecipe = popularRecipes?.find(
    (recipe) => recipe.id === selectedRecipeId
  ) || recommendations?.find(
    (recipe) => recipe.id === selectedRecipeId
  );

  const handleRecipeClick = (id: string) => {
    setSelectedRecipeId(id);
    window.scrollTo(0, 0);
  };

  const handleBackClick = () => {
    setSelectedRecipeId(null);
  };

  const [ingredientSelectorOpen, setIngredientSelectorOpen] = useState(false);
  
  const handleSearchClick = () => {
    setIngredientSelectorOpen(true);
  };
  
  const handleIngredientsSelected = (ingredients: any[]) => {
    // Navigate to search with selected ingredients
    if (ingredients.length > 0) {
      // In a real app, you would pass these ingredients to the search page
      // For now, just navigate to the search page
      setLocation("/search?hasIngredients=true");
    }
  };
  
  const handleMainCategorySelect = (categoryId: string) => {
    setSelectedMainCategory(categoryId);
  };
  
  const handleSubcategorySelect = (categoryId: string, subcategoryId: string) => {
    // Navigate to search with category filters
    setLocation(`/search?category=${categoryId}&subcategory=${subcategoryId}`);
  };
  
  const handleVoiceSearch = () => {
    // Mock voice search functionality
    alert("Voice search would be implemented here");
  };
  
  const handleCameraSearch = () => {
    // Mock camera search functionality
    alert("Camera search would be implemented here");
  };
  
  const handleAdvancedFilters = () => {
    setLocation("/search?showFilters=true");
  };
  
  // If a recipe is selected, show the recipe detail view
  if (selectedRecipeId && selectedRecipe) {
    // Convert DB recipe to RecipeRecommendation type for RecipeDetail if needed
    let formattedRecipe;
    
    if ('nameAr' in selectedRecipe) {
      // Already in RecipeRecommendation format
      formattedRecipe = selectedRecipe;
    } else if (selectedRecipe) {
      // Convert DB recipe format to RecipeRecommendation format
      formattedRecipe = {
        id: selectedRecipe.id.toString(),
        name: selectedRecipe.name,
        nameAr: selectedRecipe.name_ar || "",
        cookTime: selectedRecipe.cook_time || 0,
        imageUrl: selectedRecipe.image_url || "",
        descriptionAr: selectedRecipe.description_ar || "",
        description: selectedRecipe.description || "",
        difficulty: selectedRecipe.difficulty || "Medium",
        difficultyAr: selectedRecipe.difficulty || "متوسط",
        servings: selectedRecipe.servings_count?.toString() || "4",
        calories: selectedRecipe.calories || 0,
        dietaryMatchScore: selectedRecipe.matchPercentage || 0,
        ingredients: selectedRecipe.ingredients || [],
        instructions: selectedRecipe.instructions || [],
        cuisine: selectedRecipe.cuisine || "General",
        cuisineAr: selectedRecipe.cuisine_ar || "عام",
        category: selectedRecipe.category || "Main",
        categoryAr: selectedRecipe.category_ar || "رئيسي",
        matchPercentage: selectedRecipe.matchPercentage || 0,
        nutritionFacts: selectedRecipe.nutrition_facts || {
          calories: 0,
          fat: "0g",
          carbs: "0g",
          protein: "0g",
          sodium: "0mg",
          fiber: "0g"
        }
      };
    }
    return <RecipeDetail recipe={formattedRecipe} onBackClick={handleBackClick} />;
  }
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-gradient-to-b from-royal-purple/5 to-white shadow-xl flex flex-col pb-20">
      {/* Language Switcher */}
      <div className="absolute top-3 right-3 z-50">
        <LanguageSwitcher />
      </div>
      
      {/* Header */}
      <div className="px-6 pt-10 pb-6 bg-gradient-to-r from-royal-purple-dark to-royal-purple text-white shadow-md">
        <div className="flex justify-between items-center mb-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <RoyalCrownIcon className="h-6 w-6 text-royal-gold" />
              <h1 className="text-2xl font-bold">
                Recipes Gourmet AI
              </h1>
            </div>
            <h2 className="text-xl">
              {user ? `Welcome, ${user.name || user.email.split('@')[0]}` : "Welcome, Chef"}
            </h2>
            <p className="text-white/80 mt-1 flex items-center gap-1">
              <ChefHat className="h-4 w-4" />
              {t("whatCookToday")}
            </p>
          </div>
          <div className="royal-card-premium p-0.5 rounded-full">
            <div className="w-14 h-14 rounded-full bg-white overflow-hidden">
              <img
                src={user?.avatar_url || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"}
                alt="User Profile"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
        
        {/* Tagline */}
        <div className="mt-3 mb-2 royal-shimmer inline-block py-1 px-3 rounded-full bg-royal-purple-light/30 text-sm">
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-royal-gold" />
            <span>Where AI meets Culinary Excellence</span>
          </span>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 no-scrollbar">
        {/* Hero Carousel */}
        <section className="mb-1">
          <HeroCarousel onCategorySelect={handleMainCategorySelect} />
        </section>
        
        {/* Dynamic Subcategory Panel */}
        <section className="mb-1">
          <DynamicSubcategoryPanel 
            selectedCategory={selectedMainCategory}
            onSelectSubcategory={handleSubcategorySelect}
          />
        </section>
        
        {/* Seasonal Recipe Carousel */}
        <section className="mb-1">
          <SeasonalRecipeCarousel onRecipeSelect={handleRecipeClick} />
        </section>
        
        {/* Search and Filtering */}
        <section className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-lg text-royal-purple-dark mb-3 flex items-center">
            <Search className="h-5 w-5 mr-2 text-royal-gold" />
            {t("searchAndFilter")}
          </h3>
          
          <div className="space-y-3">
            {/* Advanced Filters button */}
            <button
              className="royal-btn-outline w-full flex items-center justify-center group h-11"
              onClick={handleAdvancedFilters}
            >
              <Filter size={16} className="mr-2 text-royal-purple" />
              <span>{t("advancedFilters")}</span>
              <span className="ml-1 text-royal-gold">▼</span>
            </button>
            
            {/* Add Ingredients button */}
            <button
              className="royal-btn-outline w-full flex items-center justify-center h-11 group"
              onClick={handleSearchClick}
            >
              <Search size={16} className="mr-2 text-royal-purple" />
              {t("addIngredients")}
            </button>
            
            {/* Ingredient Selector Component */}
            <IngredientSelector 
              isOpen={ingredientSelectorOpen}
              onClose={() => setIngredientSelectorOpen(false)}
              onIngredientSelect={handleIngredientsSelected}
            />
            
            {/* Main CTA - Find Recipes button */}
            <button
              className="royal-btn-primary w-full py-3 rounded-lg font-semibold text-lg shadow-md transition-all flex items-center justify-center"
              onClick={() => {
                // Direct to recipe results without going through search
                if (recommendations && recommendations.length > 0) {
                  setLocation("/search?results=true");
                } else {
                  // If no recommendations, ask user to add preferences or ingredients
                  setLocation("/preferences");
                }
              }}
            >
              <div className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                <span>{t("findPerfectRecipes")}</span>
              </div>
            </button>
            
            <p className="text-center text-royal-purple-dark text-sm px-4 royal-shimmer py-1 rounded-md">
              <span className="flex items-center gap-1 justify-center">
                <Sparkles className="h-3 w-3 text-royal-gold" />
                {t("personalizedSuggestions")}
                <Sparkles className="h-3 w-3 text-royal-gold" />
              </span>
            </p>
          </div>
        </section>
        
        {/* Quick Access Bar */}
        <section className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-lg text-royal-purple-dark mb-3 flex items-center">
            <Sparkles className="h-5 w-5 mr-2 text-royal-gold" />
            {t("quickAccess")}
          </h3>
          
          <div className="grid grid-cols-3 gap-3">
            <div className="royal-card-premium rounded-lg aspect-square group">
              <button
                className="rounded-lg flex flex-col items-center justify-center p-2 h-full w-full bg-white shadow-sm hover:shadow-md transition-all"
                onClick={() => setLocation("/favorites")}
              >
                <span className="text-2xl mb-1">❤️</span>
                <span className="text-xs font-medium text-royal-purple">{t("myFavorites")}</span>
              </button>
            </div>
            
            <div className="royal-card-premium rounded-lg aspect-square group">
              <button
                className="rounded-lg flex flex-col items-center justify-center p-2 h-full w-full bg-white shadow-sm hover:shadow-md transition-all"
                onClick={() => setLocation("/history")}
              >
                <span className="text-2xl mb-1">🕒</span>
                <span className="text-xs font-medium text-royal-purple">{t("myHistory")}</span>
              </button>
            </div>
            
            <div className="royal-card-premium rounded-lg aspect-square group">
              <button
                className="rounded-lg flex flex-col items-center justify-center p-2 h-full w-full bg-white shadow-sm hover:shadow-md transition-all"
                onClick={() => setLocation("/global-cuisine")}
              >
                <span className="text-2xl mb-1">🌎</span>
                <span className="text-xs font-medium text-royal-purple">{t("globalCuisine")}</span>
              </button>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-3 mt-3">
            <div className="royal-card-premium rounded-lg aspect-square group">
              <button
                className="rounded-lg flex flex-col items-center justify-center p-2 h-full w-full bg-white shadow-sm hover:shadow-md transition-all"
                onClick={() => setLocation("/meal-planning")}
              >
                <span className="text-2xl mb-1">📝</span>
                <span className="text-xs font-medium text-royal-purple">{t("mealPlanning")}</span>
              </button>
            </div>
            
            <div className="royal-card-premium rounded-lg aspect-square group">
              <button
                className="rounded-lg flex flex-col items-center justify-center p-2 h-full w-full bg-white shadow-sm hover:shadow-md transition-all"
                onClick={() => setLocation("/shopping-list")}
              >
                <span className="text-2xl mb-1">🛒</span>
                <span className="text-xs font-medium text-royal-purple">{t("shoppingList")}</span>
              </button>
            </div>
            
            <div className="royal-card-premium rounded-lg aspect-square group">
              <button
                className="rounded-lg flex flex-col items-center justify-center p-2 h-full w-full bg-white shadow-sm hover:shadow-md transition-all"
                onClick={() => setLocation("/smart-pantry")}
              >
                <span className="text-2xl mb-1">🧂</span>
                <span className="text-xs font-medium text-royal-purple">{t("smartPantry")}</span>
              </button>
            </div>
          </div>
        </section>
        
        {/* Create and Share Recipe */}
        <section className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 mb-4">
          <h3 className="font-semibold text-lg text-royal-purple-dark mb-3 flex items-center">
            <ChefHat className="h-5 w-5 mr-2 text-royal-gold" />
            {t("createAndShare")}
          </h3>
          
          <button
            className="royal-btn-secondary w-full py-3 rounded-lg flex items-center justify-center"
            onClick={() => setLocation("/create-recipe")}
          >
            <span className="text-base font-medium">{t("createRecipe")}</span>
          </button>
        </section>
      </div>
      
      <BottomNavigation />
    </div>
  );
}
