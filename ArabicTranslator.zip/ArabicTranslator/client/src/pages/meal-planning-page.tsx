import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Calendar as CalendarIcon, 
  Plus, 
  Trash2, 
  ChevronLeft, 
  ChevronRight,
  Settings,
  MoreVertical,
  Edit,
  Check,
  X,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Popover,
  PopoverContent,
  PopoverTrigger 
} from "@/components/ui/popover";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Badge } from "@/components/ui/badge";
import { format, addDays, startOfWeek, addWeeks, subWeeks, isSameDay } from "date-fns";
import { ar } from "date-fns/locale";
import { useAuth } from "@/hooks/use-auth";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useIsMobile } from "@/hooks/use-mobile";
import { getRecipeById } from "@/lib/openai";
import { cn } from "@/lib/utils";

// Types
interface MealPlanItem {
  id: string;
  recipeId: string | null;
  recipeName: string;
  recipeNameAr: string;
  date: Date;
  mealType: "breakfast" | "lunch" | "dinner" | "snack";
  servings: number;
  notes: string;
  isPlaceholder: boolean;
}

function WeeklyCalendar() {
  const { t, language, isRtl } = useI18n();
  const [currentWeekStart, setCurrentWeekStart] = React.useState<Date>(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [selectedDate, setSelectedDate] = React.useState<Date>(new Date());
  const [mealPlan, setMealPlan] = React.useState<MealPlanItem[]>([]);
  const [addMealDialogOpen, setAddMealDialogOpen] = React.useState(false);
  const [viewingDate, setViewingDate] = React.useState<Date>(new Date());
  const [quickAddText, setQuickAddText] = React.useState("");
  const [isPremium, setIsPremium] = React.useState(false);
  
  const daysOfWeek = React.useMemo(() => {
    return Array(7).fill(0).map((_, i) => addDays(currentWeekStart, i));
  }, [currentWeekStart]);
  
  // Get meals for the selected date
  const mealsForSelectedDate = React.useMemo(() => {
    return mealPlan.filter(meal => isSameDay(new Date(meal.date), selectedDate));
  }, [mealPlan, selectedDate]);
  
  // Function to get the day name 
  const getDayName = (date: Date, short = true) => {
    return format(date, short ? 'EEE' : 'EEEE', { locale: language === 'ar' ? ar : undefined });
  };
  
  // Functions to navigate between weeks
  const goToPreviousWeek = () => {
    setCurrentWeekStart(subWeeks(currentWeekStart, 1));
  };
  
  const goToNextWeek = () => {
    setCurrentWeekStart(addWeeks(currentWeekStart, 1));
  };
  
  const goToCurrentWeek = () => {
    setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }));
    setSelectedDate(new Date());
  };
  
  // Function to add a quick meal
  const handleQuickAddMeal = () => {
    if (!quickAddText.trim()) return;

    const newMeal: MealPlanItem = {
      id: Math.random().toString(36).substring(2, 9),
      recipeId: null,
      recipeName: quickAddText,
      recipeNameAr: quickAddText,
      date: selectedDate,
      mealType: "dinner", // Default
      servings: 2,
      notes: "",
      isPlaceholder: true
    };

    setMealPlan([...mealPlan, newMeal]);
    setQuickAddText("");
  };
  
  // Function to remove a meal from the plan
  const removeMeal = (mealId: string) => {
    setMealPlan(mealPlan.filter(meal => meal.id !== mealId));
  };
  
  // Function to add a new meal (placeholder)
  const addPlaceholderMeal = (type: "breakfast" | "lunch" | "dinner" | "snack", text: string) => {
    const newMeal: MealPlanItem = {
      id: Math.random().toString(36).substring(2, 9),
      recipeId: null,
      recipeName: text || t(type),
      recipeNameAr: text || t(`${type}Ar`),
      date: selectedDate,
      mealType: type,
      servings: 2,
      notes: "",
      isPlaceholder: true
    };

    setMealPlan([...mealPlan, newMeal]);
    setAddMealDialogOpen(false);
  };
  
  // Function to add a recipe meal
  const addRecipeMeal = async (recipeId: string, mealType: "breakfast" | "lunch" | "dinner" | "snack") => {
    try {
      const recipe = await getRecipeById(recipeId);
      
      const newMeal: MealPlanItem = {
        id: Math.random().toString(36).substring(2, 9),
        recipeId: recipe.id,
        recipeName: recipe.name,
        recipeNameAr: recipe.nameAr,
        date: selectedDate,
        mealType,
        servings: 2,
        notes: "",
        isPlaceholder: false
      };

      setMealPlan([...mealPlan, newMeal]);
      setAddMealDialogOpen(false);
    } catch (error) {
      console.error('Failed to add recipe to meal plan:', error);
    }
  };
  
  // Function to generate an AI meal plan
  const generateAiMealPlan = () => {
    if (!isPremium) {
      return;
    }
    
    // This would be an API call to generate a meal plan in a real implementation
    alert(t("aiMealPlanGenerated"));
  };
  
  return (
    <div className="mb-20">
      {/* Calendar Header */}
      <div className="flex justify-between items-center mb-4 px-1">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={goToPreviousWeek}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium">
            {format(currentWeekStart, 'MMM d', { locale: language === 'ar' ? ar : undefined })} - 
            {format(addDays(currentWeekStart, 6), ' MMM d, yyyy', { locale: language === 'ar' ? ar : undefined })}
          </span>
          <Button variant="ghost" size="icon" onClick={goToNextWeek}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={goToCurrentWeek}>
            {t("today")}
          </Button>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant={isPremium ? "default" : "outline"} 
                  size="sm" 
                  className={isPremium ? "" : "border-dashed"}
                  onClick={generateAiMealPlan}
                >
                  {isPremium ? t("generateAiPlan") : t("premiumFeature")}
                </Button>
              </TooltipTrigger>
              {!isPremium && (
                <TooltipContent>
                  <p>{t("upgradeForAiMealPlanning")}</p>
                </TooltipContent>
              )}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
      
      {/* Days of Week */}
      <div className={`grid grid-cols-7 text-center font-medium text-sm mb-2 ${isRtl ? 'rtl' : 'ltr'}`}>
        {daysOfWeek.map((day, index) => (
          <div 
            key={index} 
            className="py-1"
          >
            {getDayName(day)}
          </div>
        ))}
      </div>
      
      {/* Calendar Days */}
      <div className={`grid grid-cols-7 gap-1 mb-6 ${isRtl ? 'rtl' : 'ltr'}`}>
        {daysOfWeek.map((day, index) => {
          const isSelected = isSameDay(day, selectedDate);
          const isToday = isSameDay(day, new Date());
          const dayMeals = mealPlan.filter(meal => isSameDay(new Date(meal.date), day));
          
          return (
            <div 
              key={index} 
              className={cn(
                "min-h-[80px] p-1 border rounded-md relative cursor-pointer transition-colors",
                isSelected ? "bg-primary/10 border-primary" : "hover:bg-muted/50",
                isToday ? "border-primary/50" : ""
              )}
              onClick={() => setSelectedDate(day)}
            >
              <div className="text-right mb-1">
                <span className={cn(
                  "inline-block w-6 h-6 rounded-full text-center text-sm",
                  isToday ? "bg-primary text-primary-foreground" : ""
                )}>
                  {format(day, 'd')}
                </span>
              </div>
              
              <div className="flex flex-col gap-1">
                {dayMeals.length > 0 ? (
                  dayMeals.slice(0, 2).map((meal, i) => (
                    <div key={i} className="text-xs truncate">
                      <span className={cn(
                        "w-2 h-2 inline-block rounded-full mr-1",
                        meal.mealType === "breakfast" ? "bg-green-500" :
                        meal.mealType === "lunch" ? "bg-yellow-500" :
                        meal.mealType === "dinner" ? "bg-red-500" : "bg-blue-500"
                      )}></span>
                      {language === 'ar' ? meal.recipeNameAr : meal.recipeName}
                    </div>
                  ))
                ) : null}
                
                {dayMeals.length > 2 && (
                  <div className="text-xs text-muted-foreground">
                    +{dayMeals.length - 2} {t("more")}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Selected Day Meals List */}
      <div className="bg-card rounded-lg p-4 shadow-sm">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-semibold">
            {format(selectedDate, 'EEEE, MMMM d', { locale: language === 'ar' ? ar : undefined })}
          </h2>
          <Dialog open={addMealDialogOpen} onOpenChange={setAddMealDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm">
                <Plus className="h-4 w-4 mr-1" />
                {t("addMeal")}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t("addMeal")}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>{t("mealType")}</Label>
                  <Select defaultValue="dinner">
                    <SelectTrigger>
                      <SelectValue placeholder={t("selectMealType")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="breakfast">{t("breakfast")}</SelectItem>
                      <SelectItem value="lunch">{t("lunch")}</SelectItem>
                      <SelectItem value="dinner">{t("dinner")}</SelectItem>
                      <SelectItem value="snack">{t("snack")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>{t("mealOption")}</Label>
                  <div className="flex flex-col gap-2">
                    <Button 
                      variant="outline" 
                      className="justify-start"
                      onClick={() => {
                        setAddMealDialogOpen(false);
                        // This would navigate to recipe search in a real app
                        alert(t("searchRecipesForMealPlan"));
                      }}
                    >
                      <span className="mr-2">🔍</span>
                      {t("searchRecipes")}
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start"
                      onClick={() => addPlaceholderMeal("dinner", t("eatingOut"))}
                    >
                      <span className="mr-2">🍽️</span>
                      {t("eatingOut")}
                    </Button>
                    <Button 
                      variant="outline" 
                      className="justify-start"
                      onClick={() => addPlaceholderMeal("dinner", t("leftovers"))}
                    >
                      <span className="mr-2">🍱</span>
                      {t("leftovers")}
                    </Button>
                    <div className="relative">
                      <Input 
                        placeholder={t("customMeal")}
                        value={quickAddText}
                        onChange={(e) => setQuickAddText(e.target.value)}
                        className="pr-16"
                      />
                      <Button 
                        size="sm" 
                        className="absolute right-1 top-1"
                        onClick={handleQuickAddMeal}
                      >
                        {t("add")}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="divide-y">
          {["breakfast", "lunch", "dinner", "snack"].map((mealType) => {
            const meals = mealsForSelectedDate.filter(meal => meal.mealType === mealType);
            
            return (
              <div key={mealType} className="py-3">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium text-sm">{t(mealType)}</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-7 px-2"
                    onClick={() => {
                      setAddMealDialogOpen(true);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    {t("add")}
                  </Button>
                </div>
                
                {meals.length > 0 ? (
                  <div className="space-y-2">
                    {meals.map((meal) => (
                      <div 
                        key={meal.id} 
                        className="flex items-center justify-between bg-background p-2 rounded-md"
                      >
                        <div className="flex items-center">
                          {meal.isPlaceholder ? (
                            <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center mr-3">
                              <Settings className="h-5 w-5 text-muted-foreground" />
                            </div>
                          ) : (
                            <div className="w-10 h-10 rounded-md bg-gradient-to-br from-primary/80 to-primary mr-3"></div>
                          )}
                          <div>
                            <p className="font-medium text-sm">
                              {language === 'ar' ? meal.recipeNameAr : meal.recipeName}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {t("servings")}: {meal.servings}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => alert(t("editMealNotImplemented"))}>
                                <Edit className="h-4 w-4 mr-2" />
                                {t("edit")}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => alert(t("addToShoppingListNotImplemented"))}>
                                <Plus className="h-4 w-4 mr-2" />
                                {t("addToShoppingList")}
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                className="text-destructive focus:text-destructive"
                                onClick={() => removeMeal(meal.id)}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                {t("remove")}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 px-4 bg-muted/30 rounded-md">
                    <p className="text-sm text-muted-foreground">
                      {t("noMealsPlanned")}
                    </p>
                    <Button
                      variant="link"
                      size="sm"
                      onClick={() => {
                        setAddMealDialogOpen(true);
                      }}
                    >
                      {t("addMealNow")}
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default function MealPlanningPage() {
  const { t, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const isMobile = useIsMobile();
  const { user } = useAuth();
  
  const handleGoBack = () => {
    setLocation("/");
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white">
        <div className="relative flex items-center justify-center p-4 border-b">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-2"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">{t("mealPlanning")}</h1>
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute right-2"
            onClick={() => setLocation("/shopping-list")}
          >
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="relative">
                  <CalendarIcon className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 text-xs bg-primary text-white rounded-full w-4 h-4 flex items-center justify-center">3</span>
                </div>
              </TooltipTrigger>
              <TooltipContent>
                {t("viewShoppingList")}
              </TooltipContent>
            </Tooltip>
          </Button>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="p-4 relative">
        <WeeklyCalendar />
        
        {/* Premium Feature Banner */}
        <div className="bg-gradient-to-r from-primary/20 to-primary/10 p-4 rounded-lg mb-6">
          <div className="flex items-start">
            <div className="mr-3 mt-1">
              <AlertCircle className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="font-medium mb-1">{t("upgradeToUnlockAiPlanning")}</h3>
              <p className="text-sm text-muted-foreground mb-2">
                {t("premiumPlanningDescription")}
              </p>
              <Button size="sm" onClick={() => setLocation("/subscription")}>
                {t("upgrade")}
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <BottomNavigation />
    </div>
  );
}