import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Clock, 
  Star, 
  Share2, 
  ChefHat,
  SlidersHorizontal,
  Calendar
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

// Mock cooking history data
interface CookingHistoryItem {
  id: number;
  recipeId: string;
  recipeName: string;
  recipeNameAr: string;
  imageUrl: string;
  cookingDate: Date;
  cookTime: number;
  userRating: number | null;
  timesCooked: number;
}

const mockCookingHistory: CookingHistoryItem[] = [
  {
    id: 1,
    recipeId: "recipe1",
    recipeName: "Chicken Shawarma",
    recipeNameAr: "شاورما الدجاج",
    imageUrl: "https://images.unsplash.com/photo-1529006557810-274b9b2fc783",
    cookingDate: new Date(2025, 4, 10), // May 10, 2025
    cookTime: 45,
    userRating: 4,
    timesCooked: 3
  },
  {
    id: 2,
    recipeId: "recipe2",
    recipeName: "Falafel Wrap",
    recipeNameAr: "لفائف الفلافل",
    imageUrl: "https://images.unsplash.com/photo-1553030942-031e695deec9",
    cookingDate: new Date(2025, 4, 8), // May 8, 2025
    cookTime: 30,
    userRating: 5,
    timesCooked: 2
  },
  {
    id: 3,
    recipeId: "recipe3",
    recipeName: "Hummus with Pita",
    recipeNameAr: "حمص مع خبز بيتا",
    imageUrl: "https://images.unsplash.com/photo-1577906096429-f73c2c312435",
    cookingDate: new Date(2025, 4, 5), // May 5, 2025
    cookTime: 20,
    userRating: 3,
    timesCooked: 1
  },
  {
    id: 4,
    recipeId: "recipe4",
    recipeName: "Tabbouleh Salad",
    recipeNameAr: "سلطة التبولة",
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
    cookingDate: new Date(2025, 4, 1), // May 1, 2025
    cookTime: 25,
    userRating: null,
    timesCooked: 1
  },
  {
    id: 5,
    recipeId: "recipe5",
    recipeName: "Baklava",
    recipeNameAr: "بقلاوة",
    imageUrl: "https://images.unsplash.com/photo-1519676867240-f03562e64548",
    cookingDate: new Date(2025, 3, 28), // April 28, 2025
    cookTime: 60,
    userRating: 5,
    timesCooked: 4
  }
];

type SortOption = "recent" | "mostCooked" | "highestRated";

export default function CookingHistoryPage() {
  const { t, isRtl, language } = useI18n();
  const [, setLocation] = useLocation();
  const [history, setHistory] = React.useState<CookingHistoryItem[]>(mockCookingHistory);
  const [sortOption, setSortOption] = React.useState<SortOption>("recent");
  
  // Total recipes cooked
  const totalRecipesCooked = history.reduce((total, item) => total + item.timesCooked, 0);
  
  const handleGoBack = () => {
    setLocation("/profile");
  };
  
  const handleRecipeClick = (recipeId: string) => {
    setLocation(`/recipe/${recipeId}`);
  };
  
  const handleRateRecipe = (historyId: number, rating: number) => {
    // In a real app, this would update the rating in the database
    setHistory(history.map(item => 
      item.id === historyId ? { ...item, userRating: rating } : item
    ));
  };
  
  const handleShareStats = () => {
    // In a real app, this would open a share dialog
    alert(t("shareFeatureNotImplemented"));
  };
  
  // Sort the history based on the selected option
  const sortedHistory = React.useMemo(() => {
    const sorted = [...history];
    
    switch (sortOption) {
      case "recent":
        return sorted.sort((a, b) => b.cookingDate.getTime() - a.cookingDate.getTime());
      case "mostCooked":
        return sorted.sort((a, b) => b.timesCooked - a.timesCooked);
      case "highestRated":
        return sorted.sort((a, b) => {
          // Handle null ratings (place at the bottom)
          if (a.userRating === null) return 1;
          if (b.userRating === null) return -1;
          return b.userRating - a.userRating;
        });
      default:
        return sorted;
    }
  }, [history, sortOption]);
  
  // Group history by month and year
  const groupedHistory = React.useMemo(() => {
    const groups: Record<string, CookingHistoryItem[]> = {};
    
    sortedHistory.forEach(item => {
      const date = item.cookingDate;
      const key = `${date.getFullYear()}-${date.getMonth()}`;
      
      if (!groups[key]) {
        groups[key] = [];
      }
      
      groups[key].push(item);
    });
    
    return Object.entries(groups).map(([key, items]) => {
      const [year, month] = key.split('-').map(Number);
      return {
        title: format(new Date(year, month, 1), "MMMM yyyy", {
          locale: language === 'ar' ? ar : undefined
        }),
        items
      };
    });
  }, [sortedHistory, language]);

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b bg-gradient-to-r from-royal-purple/5 to-royal-gold/5">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2 text-royal-purple hover:bg-royal-purple/10"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold text-royal-purple tracking-wide">
          <span className="relative">
            {t("cookingHistory")}
            <span className="absolute -bottom-1 left-1/4 right-1/4 h-0.5 bg-royal-gold/40 rounded-full"></span>
          </span>
        </h1>
        <div className="absolute right-2">
          <LanguageSwitcher />
        </div>
      </div>
      
      {/* Stats Widget */}
      <div className="bg-gradient-to-r from-royal-purple/10 to-royal-gold/10 p-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="bg-royal-purple/20 w-12 h-12 rounded-full flex items-center justify-center">
            <ChefHat className="h-6 w-6 text-royal-purple" />
          </div>
          <div>
            <h2 className="font-bold text-xl text-royal-purple">{totalRecipesCooked}</h2>
            <p className="text-sm text-gray-700">{t("totalRecipesCooked")}</p>
          </div>
        </div>
        
        <Button 
          size="sm" 
          variant="outline" 
          className="bg-white border-royal-gold/50 text-royal-purple hover:bg-royal-gold/5"
          onClick={handleShareStats}
        >
          <Share2 className="h-4 w-4 mr-1" />
          {t("shareStats")}
        </Button>
      </div>
      
      {/* Filters */}
      <div className="p-4 bg-gradient-to-r from-white to-royal-purple/5 flex items-center justify-between border-b border-royal-gold/10">
        <div className="flex items-center gap-2">
          <div className="bg-royal-purple/10 p-1.5 rounded-full">
            <SlidersHorizontal className="h-4 w-4 text-royal-purple" />
          </div>
          <span className="text-sm font-medium text-royal-purple">{t("sortBy")}</span>
        </div>
        
        <Select 
          defaultValue={sortOption} 
          onValueChange={(value) => setSortOption(value as SortOption)}
        >
          <SelectTrigger className="w-[130px] border-royal-gold/20 bg-white focus:ring-royal-purple/20">
            <SelectValue placeholder={t("sortBy")} />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="recent" className="focus:bg-royal-purple/10 focus:text-royal-purple">
                {t("recent")}
              </SelectItem>
              <SelectItem value="mostCooked" className="focus:bg-royal-purple/10 focus:text-royal-purple">
                {t("mostCooked")}
              </SelectItem>
              <SelectItem value="highestRated" className="focus:bg-royal-purple/10 focus:text-royal-purple">
                {t("highestRated")}
              </SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
      
      {/* Timeline View */}
      {history.length === 0 ? (
        <div className="text-center py-12 px-4">
          <div className="w-20 h-20 mx-auto bg-royal-purple/10 rounded-full flex items-center justify-center">
            <Calendar className="h-10 w-10 text-royal-purple" />
          </div>
          <h3 className="mt-5 font-semibold text-royal-purple">{t("noCookingHistory")}</h3>
          <p className="text-sm text-gray-600 mt-1 max-w-xs mx-auto">{t("startCookingToSeeHistory")}</p>
          
          <Button 
            className="mt-5 bg-royal-purple hover:bg-royal-purple/90 text-white"
            onClick={() => setLocation("/home")}
          >
            {t("exploreRecipes")}
          </Button>
        </div>
      ) : (
        <div className="divide-y">
          {groupedHistory.map((group, groupIndex) => (
            <div key={groupIndex} className="py-4">
              <h3 className="font-medium px-4 mb-3 flex items-center">
                <span className="inline-block h-0.5 w-4 bg-royal-gold mr-2 rounded-full"></span>
                <span className="text-royal-purple font-semibold">{group.title}</span>
              </h3>
              
              <div className="space-y-3 px-4">
                {group.items.map(item => (
                  <div 
                    key={item.id}
                    className="bg-white rounded-lg border border-royal-gold/20 shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md hover:border-royal-gold/40"
                    onClick={() => handleRecipeClick(item.recipeId)}
                  >
                    <div className="flex h-28">
                      <div className="w-28 h-28 flex-shrink-0 relative">
                        <img 
                          src={item.imageUrl} 
                          alt={isRtl ? item.recipeNameAr : item.recipeName}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-0 right-0 bg-royal-purple/80 text-white text-xs px-2 py-1 rounded-bl-lg flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {format(item.cookingDate, "MMM d", {
                            locale: language === 'ar' ? ar : undefined
                          })}
                        </div>
                      </div>
                      
                      <div className="flex-1 p-3">
                        <h4 className="font-medium truncate text-royal-purple">
                          {isRtl ? item.recipeNameAr : item.recipeName}
                        </h4>
                        
                        <div className="flex items-center gap-4 mt-2 text-xs text-gray-600">
                          <div className="flex items-center bg-gray-100 px-2 py-1 rounded-full">
                            <Clock className="h-3 w-3 mr-1 text-royal-purple" />
                            <span>{item.cookTime} {t("min")}</span>
                          </div>
                          
                          <div className="flex items-center bg-gray-100 px-2 py-1 rounded-full">
                            <ChefHat className="h-3 w-3 mr-1 text-royal-purple" />
                            <span>×{item.timesCooked}</span>
                          </div>
                        </div>
                        
                        <div className="mt-2">
                          {item.userRating ? (
                            <div className="flex items-center">
                              <div className="flex bg-royal-purple/5 px-2 py-1 rounded-full">
                                {[1, 2, 3, 4, 5].map(star => (
                                  <button
                                    key={star}
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleRateRecipe(item.id, star);
                                    }}
                                    className="p-0.5 relative group"
                                  >
                                    <Star 
                                      className={`h-4 w-4 transition-all duration-200 ${
                                        star <= item.userRating! 
                                          ? "text-royal-gold fill-royal-gold" 
                                          : "text-gray-300"
                                      } group-hover:scale-110`}
                                    />
                                  </button>
                                ))}
                              </div>
                            </div>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-6 text-xs border-royal-gold/30 text-royal-purple hover:bg-royal-gold/5"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRateRecipe(item.id, 4);
                              }}
                            >
                              <Star className="h-3 w-3 mr-1 text-royal-gold" />
                              {t("rateRecipe")}
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}