import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Instagram, 
  Twitter, 
  Facebook,
  Youtube,
  Download,
  ExternalLink,
  Heart
} from "lucide-react";
import { FaTiktok } from "react-icons/fa";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";

export default function AboutPage() {
  const { t, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  
  const handleGoBack = () => {
    setLocation("/settings");
  };
  
  const handleCheckForUpdates = () => {
    // In a real app, this would check for updates
    alert(t("alreadyUsingLatestVersion"));
  };
  
  const teamMembers = [
    {
      name: "Sarah Ahmed",
      role: t("founder"),
      avatar: "https://randomuser.me/api/portraits/women/44.jpg"
    },
    {
      name: "Mohammed Khalid",
      role: t("headChef"),
      avatar: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      name: "Layla Ibrahim",
      role: t("nutritionist"),
      avatar: "https://randomuser.me/api/portraits/women/68.jpg"
    }
  ];
  
  const socialLinks = [
    { icon: <Instagram className="h-5 w-5" />, name: "Instagram", url: "https://instagram.com" },
    { icon: <FaTiktok className="h-5 w-5" />, name: "TikTok", url: "https://tiktok.com" },
    { icon: <Youtube className="h-5 w-5" />, name: "YouTube", url: "https://youtube.com" },
    { icon: <Twitter className="h-5 w-5" />, name: "Twitter", url: "https://twitter.com" },
    { icon: <Facebook className="h-5 w-5" />, name: "Facebook", url: "https://facebook.com" }
  ];

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold">{t("about")}</h1>
        <div className="absolute right-2">
          <LanguageSwitcher />
        </div>
      </div>
      
      <div className="p-4 space-y-8">
        {/* App Logo and Name */}
        <div className="text-center">
          <div className="w-24 h-24 bg-gradient-to-r from-primary to-primary/70 rounded-2xl mx-auto flex items-center justify-center shadow-md">
            <span className="text-white text-3xl font-bold">W</span>
          </div>
          <h1 className="text-2xl font-bold mt-3">Wasfah AI</h1>
          <p className="text-gray-500 text-sm mt-1">{t("version")} 2.1.4</p>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-3"
            onClick={handleCheckForUpdates}
          >
            <Download className="h-4 w-4 mr-1" />
            {t("checkForUpdates")}
          </Button>
        </div>
        
        {/* Mission Statement */}
        <div className="bg-gray-50 p-5 rounded-lg">
          <h2 className="text-lg font-semibold mb-2">{t("ourMission")}</h2>
          <p className="text-gray-700">
            {t("missionStatement")}
          </p>
        </div>
        
        {/* Team Section */}
        <div>
          <h2 className="text-lg font-semibold mb-3">{t("meetTheTeam")}</h2>
          
          <div className="grid grid-cols-3 gap-4">
            {teamMembers.map((member, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-full mx-auto overflow-hidden">
                  <img
                    src={member.avatar}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="font-medium text-sm mt-2">{member.name}</h3>
                <p className="text-xs text-gray-500">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
        
        {/* Social Media */}
        <div>
          <h2 className="text-lg font-semibold mb-3">{t("followUs")}</h2>
          
          <div className="flex flex-wrap gap-2">
            {socialLinks.map((link, index) => (
              <Button
                key={index}
                variant="outline"
                className="flex-1"
                onClick={() => window.open(link.url, "_blank")}
              >
                {link.icon}
                <span className="ml-2">{link.name}</span>
              </Button>
            ))}
          </div>
        </div>
        
        {/* App Description */}
        <div>
          <h2 className="text-lg font-semibold mb-2">{t("aboutApp")}</h2>
          <p className="text-sm text-gray-700">
            {t("appDescriptionPart1")}
          </p>
          <p className="text-sm text-gray-700 mt-2">
            {t("appDescriptionPart2")}
          </p>
        </div>
        
        {/* Attributions */}
        <div className="border-t pt-4">
          <h3 className="text-sm font-medium text-gray-500 mb-2">{t("attributions")}</h3>
          <p className="text-xs text-gray-500">
            {t("attributionsText")}
          </p>
          
          <Button
            variant="link"
            size="sm"
            className="text-xs px-0 h-auto"
            onClick={() => setLocation("/attributions")}
          >
            {t("viewAttributions")}
            <ExternalLink className="h-3 w-3 ml-1" />
          </Button>
        </div>
        
        {/* Copyright */}
        <div className="text-center pt-2">
          <p className="text-xs text-gray-400">
            © 2025 Wasfah AI. {t("allRightsReserved")}
          </p>
          <p className="text-xs text-gray-400 mt-2 flex items-center justify-center">
            {t("madeWith")} <Heart className="h-3 w-3 mx-1 text-red-500 fill-red-500" /> {t("inSaudiArabia")}
          </p>
        </div>
      </div>
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}