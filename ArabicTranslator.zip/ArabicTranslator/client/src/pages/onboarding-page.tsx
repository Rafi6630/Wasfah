import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useEffect } from "react";

export default function OnboardingPage() {
  const { t, isRtl } = useI18n();
  const [_, navigate] = useLocation();
  const { user, isLoading } = useAuth();

  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user && !isLoading) {
      navigate("/home");
    }
  }, [user, isLoading, navigate]);

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl relative overflow-hidden">
      {/* Language Switcher */}
      <div className="absolute top-3 right-3 z-50">
        <LanguageSwitcher />
      </div>

      <div className="w-full h-1/2 relative overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1506368249639-73a05d6f6488?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
          alt="Colorful spices and ingredients" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white"></div>
      </div>
      
      <div className="flex flex-col items-center justify-center p-6 -mt-20 relative z-10">
        <img
          src="https://pixabay.com/get/g6bad298f9c718673f57a7295777283542fa46883f46cfb4c4fc9a3510ec22cadebb46a710270404b29ab53dddcb6298cca5e190e7fbc78f6894791368b875c2e_1280.jpg"
          alt="Wasfah Logo"
          className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
        />
        
        <h1 className="mt-6 text-3xl font-bold text-neutral-800">
          {t("appName")}
        </h1>
        
        <p className="mt-3 text-center text-neutral-800 opacity-75">
          {t("tagline")}
        </p>
        
        <Button 
          className={cn(
            "mt-8 bg-primary text-white py-3 px-10 rounded-full font-medium shadow-lg hover:bg-opacity-90 transition w-full",
          )}
          onClick={() => navigate("/auth")}
        >
          {t("startYourCulinaryJourney") || "Start Your Culinary Journey"}
        </Button>
        
        <p className="mt-4 text-sm text-neutral-800 opacity-75">
          {t("alreadyHaveAccount")} <a href="/auth" className="text-primary font-medium">{t("logIn")}</a>
        </p>
        
        {/* Demo button to view the splash screen */}
        <Button 
          variant="outline"
          className="mt-4 border-royal-purple text-royal-purple hover:bg-royal-purple/10" 
          onClick={() => navigate("/splash")}
        >
          {t("viewSplashScreen") || "View Splash Screen"}
        </Button>
      </div>
    </div>
  );
}
