import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { ArrowLeft, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export default function LegalPage() {
  const { t, isRtl } = useI18n();
  const [location, setLocation] = useLocation();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = React.useState<string>(
    location.includes("privacy") ? "privacy" : "terms"
  );
  const [hasAccepted, setHasAccepted] = React.useState<boolean>(!!user);
  
  const handleGoBack = () => {
    setLocation("/settings");
  };
  
  const handleAccept = () => {
    setHasAccepted(true);
    // In a real app, this would update the user's acceptance status
    setTimeout(() => {
      setLocation("/auth");
    }, 1000);
  };
  
  // Privacy Policy content sections
  const privacyPolicySections = [
    {
      title: t("dataCollection"),
      content: t("dataCollectionContent"),
      subsections: [
        {
          title: t("personalInformation"),
          content: t("personalInformationContent")
        },
        {
          title: t("nonPersonalInformation"),
          content: t("nonPersonalInformationContent")
        },
        {
          title: t("cookiesAndTracking"),
          content: t("cookiesAndTrackingContent")
        }
      ]
    },
    {
      title: t("dataUsage"),
      content: t("dataUsageContent"),
      subsections: [
        {
          title: t("serviceProvision"),
          content: t("serviceProvisionContent")
        },
        {
          title: t("personalization"),
          content: t("personalizationContent")
        },
        {
          title: t("analytics"),
          content: t("analyticsContent")
        }
      ]
    },
    {
      title: t("thirdPartySharing"),
      content: t("thirdPartySharingContent"),
      subsections: [
        {
          title: t("serviceProviders"),
          content: t("serviceProvidersContent")
        },
        {
          title: t("legalCompliance"),
          content: t("legalComplianceContent")
        },
        {
          title: t("businessTransfers"),
          content: t("businessTransfersContent")
        }
      ]
    },
    {
      title: t("userRights"),
      content: t("userRightsContent"),
      subsections: [
        {
          title: t("accessAndCorrection"),
          content: t("accessAndCorrectionContent")
        },
        {
          title: t("deletionRights"),
          content: t("deletionRightsContent")
        },
        {
          title: t("dataPortability"),
          content: t("dataPortabilityContent")
        }
      ]
    },
    {
      title: t("dataSecurity"),
      content: t("dataSecurityContent")
    },
    {
      title: t("childrenPrivacy"),
      content: t("childrenPrivacyContent")
    },
    {
      title: t("policyChanges"),
      content: t("policyChangesContent")
    },
    {
      title: t("contactUs"),
      content: t("contactUsContent")
    }
  ];
  
  // Terms of Service content sections
  const termsOfServiceSections = [
    {
      title: t("termsAcceptance"),
      content: t("termsAcceptanceContent")
    },
    {
      title: t("serviceDescription"),
      content: t("serviceDescriptionContent")
    },
    {
      title: t("userAccounts"),
      content: t("userAccountsContent"),
      subsections: [
        {
          title: t("accountCreation"),
          content: t("accountCreationContent")
        },
        {
          title: t("accountSecurity"),
          content: t("accountSecurityContent")
        },
        {
          title: t("accountTermination"),
          content: t("accountTerminationContent")
        }
      ]
    },
    {
      title: t("userContentAndConduct"),
      content: t("userContentAndConductContent"),
      subsections: [
        {
          title: t("userContent"),
          content: t("userContentContent")
        },
        {
          title: t("prohibitedActivities"),
          content: t("prohibitedActivitiesContent")
        },
        {
          title: t("contentRights"),
          content: t("contentRightsContent")
        }
      ]
    },
    {
      title: t("subscriptionsAndPayments"),
      content: t("subscriptionsAndPaymentsContent"),
      subsections: [
        {
          title: t("billingTerms"),
          content: t("billingTermsContent")
        },
        {
          title: t("cancellationPolicy"),
          content: t("cancellationPolicyContent")
        },
        {
          title: t("refundPolicy"),
          content: t("refundPolicyContent")
        }
      ]
    },
    {
      title: t("intellectualProperty"),
      content: t("intellectualPropertyContent")
    },
    {
      title: t("disclaimersAndLimitations"),
      content: t("disclaimersAndLimitationsContent"),
      subsections: [
        {
          title: t("warrantyDisclaimer"),
          content: t("warrantyDisclaimerContent")
        },
        {
          title: t("limitationOfLiability"),
          content: t("limitationOfLiabilityContent")
        },
        {
          title: t("indemnification"),
          content: t("indemnificationContent")
        }
      ]
    },
    {
      title: t("governingLaw"),
      content: t("governingLawContent")
    },
    {
      title: t("termsModifications"),
      content: t("termsModificationsContent")
    }
  ];
  
  // Helper component for rendering a section
  const renderSection = (section: any, index: number) => (
    <div key={index} className="mb-6">
      <h3 className="text-lg font-semibold mb-2">{section.title}</h3>
      <p className="text-sm text-gray-700 mb-3">{section.content}</p>
      
      {section.subsections && (
        <div className="pl-4 border-l-2 border-gray-200 space-y-4 mt-4">
          {section.subsections.map((subsection: any, subIndex: number) => (
            <div key={subIndex}>
              <h4 className="text-md font-medium mb-1">{subsection.title}</h4>
              <p className="text-sm text-gray-700">{subsection.content}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold">{
          activeTab === "privacy" ? t("privacyPolicy") : t("termsOfService")
        }</h1>
        <div className="absolute right-2">
          <LanguageSwitcher />
        </div>
      </div>
      
      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-center rounded-none border-b bg-transparent">
          <TabsTrigger 
            value="privacy" 
            className="flex-1 data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-none border-b-2 data-[state=active]:border-primary border-transparent"
          >
            {t("privacyPolicy")}
          </TabsTrigger>
          <TabsTrigger 
            value="terms" 
            className="flex-1 data-[state=active]:bg-primary/10 data-[state=active]:text-primary rounded-none border-b-2 data-[state=active]:border-primary border-transparent"
          >
            {t("termsOfService")}
          </TabsTrigger>
        </TabsList>
        
        {/* Privacy Policy Content */}
        <TabsContent value="privacy" className="p-4">
          <div className="mb-4">
            <p className="text-sm text-gray-500 italic">
              {t("lastUpdated")}: May 1, 2025
            </p>
          </div>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-700">
              {t("privacyPolicyIntro")}
            </p>
            
            <div className="space-y-6">
              {privacyPolicySections.map(renderSection)}
            </div>
          </div>
        </TabsContent>
        
        {/* Terms of Service Content */}
        <TabsContent value="terms" className="p-4">
          <div className="mb-4">
            <p className="text-sm text-gray-500 italic">
              {t("lastUpdated")}: April 15, 2025
            </p>
          </div>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-700">
              {t("termsOfServiceIntro")}
            </p>
            
            <div className="space-y-6">
              {termsOfServiceSections.map(renderSection)}
            </div>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Accept Button for first-time users */}
      {!hasAccepted && (
        <div className="fixed bottom-20 left-0 right-0 max-w-md mx-auto p-4 bg-white border-t shadow-lg flex justify-center">
          <Button
            className="w-full max-w-xs"
            onClick={handleAccept}
          >
            <Check className="h-4 w-4 mr-2" />
            {t("acceptTermsAndPrivacy")}
          </Button>
        </div>
      )}
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}