import { useState, useEffect } from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation, useRoute } from "wouter";
import { ArrowLeft, Share2, Bookmark } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { IngredientItem } from "@/components/recipe/ingredient-item";
import { InstructionItem } from "@/components/recipe/instruction-item";
import { RecipeCard } from "@/components/recipe/recipe-card";
import { getRecipeById, RecipeRecommendation } from "@/lib/openai";
import { useQuery, useMutation } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ShareRecipeForm } from "@/components/social/share-recipe-form";
import { useToast } from "@/hooks/use-toast";

export default function RecipeDetailPage() {
  const { t, isRtl, language } = useI18n();
  const [_, navigate] = useLocation();
  const [match, params] = useRoute("/recipe/:id");
  const recipeId = params?.id || "";
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [servingCount, setServingCount] = useState(4);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false);
  
  // Fetch recipe details
  const { 
    data: recipe, 
    isLoading,
    isError 
  } = useQuery({
    queryKey: [`/api/recipes/${recipeId}`],
    queryFn: () => getRecipeById(recipeId),
    enabled: !!recipeId,
  });
  
  // Fetch similar recipes
  const { 
    data: similarRecipes = [],
    isLoading: isSimilarLoading 
  } = useQuery({
    queryKey: [`/api/recipes/${recipeId}/similar`],
    queryFn: () => getRecipeById(recipeId).then(() => 
      // This would normally call a separate endpoint, but for demo purposes
      // we're returning mock data formatted similar to our recipe object
      [
        {
          id: "similar1",
          name: "Arabic Mandi",
          nameAr: "المندي العربي",
          rating: 4.7,
          cookTime: 60,
          imageUrl: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=120"
        },
        {
          id: "similar2",
          name: "Chicken Biryani",
          nameAr: "برياني الدجاج",
          rating: 4.5,
          cookTime: 50,
          imageUrl: "https://images.unsplash.com/photo-1563379926898-05f4575a45d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=120"
        },
        {
          id: "similar3",
          name: "Maqluba",
          nameAr: "مقلوبة",
          rating: 4.6,
          cookTime: 70,
          imageUrl: "https://images.unsplash.com/photo-1541518763669-27fef04b14ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=120"
        }
      ] as RecipeRecommendation[]
    ),
    enabled: !!recipeId && !isLoading,
  });
  
  // Toggle favorite mutation with success toast
  const toggleFavoriteMutation = useMutation({
    mutationFn: () => 
      apiRequest(
        "POST", 
        `/api/recipes/${recipeId}/favorite`, 
        { favorite: !isFavorite }
      ),
    onMutate: () => {
      // Optimistic update
      setIsFavorite(!isFavorite);
    },
    onSuccess: () => {
      // Show success message
      toast({
        title: isFavorite ? t("removedFromFavorites") : t("addedToFavorites"),
        duration: 2000,
      });
    },
    onError: () => {
      // Revert on error
      setIsFavorite(isFavorite);
      toast({
        title: t("favoriteError"),
        variant: "destructive",
        duration: 2000,
      });
    }
  });
  
  // Decrease serving count
  const decreaseServings = () => {
    if (servingCount > 1) {
      setServingCount(servingCount - 1);
    }
  };
  
  // Increase serving count
  const increaseServings = () => {
    setServingCount(servingCount + 1);
  };
  
  // Start cooking - would implement cooking mode in full app
  const startCooking = () => {
    alert("Cooking mode is coming soon in the next update!");
  };
  
  // Share the recipe
  const shareRecipe = () => {
    // If native sharing is available and preferred, use it
    if (false && navigator.share) {
      navigator.share({
        title: language === 'ar' ? recipe?.nameAr : recipe?.name,
        text: language === 'ar' ? recipe?.descriptionAr : recipe?.description,
        url: window.location.href
      })
      .catch((error) => console.log('Error sharing', error));
    } else {
      // Otherwise use our custom share dialog with more features
      setIsShareDialogOpen(true);
    }
  };
  
  if (isError) {
    return (
      <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl flex items-center justify-center">
        <div className="text-center p-6">
          <h2 className="text-xl font-bold mb-2">Recipe not found</h2>
          <p className="mb-4">The recipe you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => navigate("/home")}>
            Back to Home
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl flex flex-col">
      <div className="relative">
        {isLoading ? (
          <Skeleton className="w-full h-64" />
        ) : (
          <img 
            src={recipe?.imageUrl} 
            alt={language === 'ar' ? recipe?.nameAr : recipe?.name}
            className="w-full h-64 object-cover"
          />
        )}
        
        <Button 
          variant="outline" 
          size="icon" 
          className="absolute top-10 left-6 bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-md"
          onClick={() => navigate("/home")}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        
        <div className="flex absolute top-10 right-6 space-x-3">
          <Button 
            variant="outline" 
            size="icon" 
            className="bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-md"
            onClick={() => toggleFavoriteMutation.mutate()}
          >
            <Bookmark className={cn("h-5 w-5", isFavorite && "fill-primary text-primary")} />
          </Button>
          <Button 
            variant="outline" 
            size="icon" 
            className="bg-white rounded-full w-10 h-10 flex items-center justify-center shadow-md"
            onClick={shareRecipe}
          >
            <Share2 className="h-5 w-5" />
          </Button>
        </div>
        
        {!isLoading && recipe && (
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
            <div className="flex items-center space-x-2 mb-2">
              <div className="bg-secondary text-white text-xs px-2 py-0.5 rounded-full">
                <span>{t(recipe.difficulty.toLowerCase())}</span>
              </div>
              <div className="bg-white text-neutral-800 text-xs px-2 py-0.5 rounded-full">
                <span>{recipe.cookTime} {t("cookingTime")}</span>
              </div>
              <div className="bg-white text-neutral-800 text-xs px-2 py-0.5 rounded-full">
                <span>{recipe.servings}</span>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-white">
              {language === 'ar' ? recipe.nameAr : recipe.name}
            </h1>
          </div>
        )}
      </div>
      
      {isLoading ? (
        <div className="p-6 space-y-4 flex-1">
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-8 w-3/4" />
          <Skeleton className="h-60 w-full" />
        </div>
      ) : recipe ? (
        <div className="flex-1 overflow-y-auto no-scrollbar">
          <div className="p-6 space-y-6">
            <div className="flex justify-between">
              <div className="flex items-center space-x-2">
                <div className="flex text-accent">
                  <i className="fas fa-star text-sm"></i>
                  <i className="fas fa-star text-sm"></i>
                  <i className="fas fa-star text-sm"></i>
                  <i className="fas fa-star text-sm"></i>
                  <i className="fas fa-star-half-alt text-sm"></i>
                </div>
                <span className="text-sm font-medium">4.8 (256)</span>
              </div>
              <div className="flex items-center space-x-1">
                <i className="fas fa-fire text-accent text-sm"></i>
                <span className="text-sm">
                  {recipe.nutritionFacts.calories} {t("calories")}
                </span>
              </div>
            </div>
            
            <div>
              <h2 className="text-lg font-semibold mb-3">{t("description")}</h2>
              <p className="text-neutral-800 opacity-80">
                {language === 'ar' ? recipe.descriptionAr : recipe.description}
              </p>
            </div>
            
            <div className="space-y-3">
              <h2 className="text-lg font-semibold">{t("ingredients")}</h2>
              
              <div className="flex justify-between items-center">
                <span className="text-sm text-neutral-800">{t("servingSize")}</span>
                
                <div className="flex items-center space-x-4">
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center text-neutral-800"
                    onClick={decreaseServings}
                    disabled={servingCount <= 1}
                  >
                    <i className="fas fa-minus text-xs"></i>
                  </Button>
                  <span className="font-medium">{servingCount}</span>
                  <Button 
                    variant="outline" 
                    size="icon" 
                    className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center text-neutral-800"
                    onClick={increaseServings}
                  >
                    <i className="fas fa-plus text-xs"></i>
                  </Button>
                </div>
              </div>
              
              <div className="bg-neutral-200 rounded-xl p-4 space-y-3">
                {recipe.ingredients.map((ingredient, index) => (
                  <IngredientItem 
                    key={index}
                    name={language === 'ar' ? ingredient.nameAr : ingredient.name}
                    quantity={ingredient.quantity}
                    servingMultiplier={servingCount / parseInt(recipe.servings)}
                  />
                ))}
              </div>
            </div>
            
            <div className="space-y-3">
              <h2 className="text-lg font-semibold">{t("instructions")}</h2>
              
              <div className="space-y-4">
                {recipe.instructions.map((instruction) => (
                  <InstructionItem 
                    key={instruction.step}
                    step={instruction.step}
                    text={language === 'ar' ? instruction.textAr : instruction.text}
                  />
                ))}
              </div>
            </div>
            
            <div className="space-y-3">
              <h2 className="text-lg font-semibold">{t("nutritionFacts")}</h2>
              
              <div className="bg-neutral-200 rounded-xl p-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm">{t("calories")}</span>
                      <span className="text-sm font-medium">{recipe.nutritionFacts.calories}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">{t("fat")}</span>
                      <span className="text-sm font-medium">{recipe.nutritionFacts.fat}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">{t("carbs")}</span>
                      <span className="text-sm font-medium">{recipe.nutritionFacts.carbs}</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm">{t("protein")}</span>
                      <span className="text-sm font-medium">{recipe.nutritionFacts.protein}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">{t("sodium")}</span>
                      <span className="text-sm font-medium">{recipe.nutritionFacts.sodium}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">{t("fiber")}</span>
                      <span className="text-sm font-medium">{recipe.nutritionFacts.fiber}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h2 className="text-lg font-semibold">{t("similarRecipes")}</h2>
              
              <div className={cn(
                "flex overflow-x-auto pb-2 no-scrollbar",
                isRtl ? "space-x-reverse" : "space-x-4"
              )}>
                {isSimilarLoading ? (
                  Array(3).fill(0).map((_, i) => (
                    <div key={i} className="min-w-[140px] max-w-[140px]">
                      <Skeleton className="w-full h-20 rounded-t-xl" />
                      <Skeleton className="w-full h-20 rounded-b-xl mt-0.5" />
                    </div>
                  ))
                ) : (
                  similarRecipes.map((recipe) => (
                    <div 
                      key={recipe.id}
                      className="min-w-[140px] max-w-[140px] bg-white rounded-xl shadow overflow-hidden cursor-pointer"
                      onClick={() => navigate(`/recipe/${recipe.id}`)}
                    >
                      <img 
                        src={recipe.imageUrl} 
                        alt={language === 'ar' ? recipe.nameAr : recipe.name}
                        className="w-full h-20 object-cover"
                      />
                      <div className="p-2">
                        <h3 className="font-medium text-sm">
                          {language === 'ar' ? recipe.nameAr : recipe.name}
                        </h3>
                        <div className="flex items-center justify-between mt-1">
                          <div className="flex items-center">
                            <i className="fas fa-star text-xs text-accent"></i>
                            <span className="text-xs ml-1">{recipe.rating}</span>
                          </div>
                          <span className="text-xs text-gray-500">{recipe.cookTime} {t("cookingTime")}</span>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      ) : null}
      
      <div className="p-6 bg-white shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
        <Button
          className="w-full bg-primary text-white py-6 rounded-lg font-medium shadow hover:bg-opacity-90 transition"
          onClick={startCooking}
          disabled={isLoading}
        >
          {t("startCooking")}
        </Button>
      </div>
      
      {/* Share Recipe Dialog */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent className="max-w-md mx-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t("shareThisRecipe")}</DialogTitle>
          </DialogHeader>
          
          {recipe && (
            <ShareRecipeForm 
              recipe={{
                id: recipe.id,
                title: recipe.name,
                titleAr: recipe.nameAr,
                imageUrl: recipe.imageUrl,
                description: recipe.description || "",
                descriptionAr: recipe.descriptionAr || "",
                ingredients: recipe.ingredients.map(i => i.name),
                cookTime: recipe.cookTime,
                servings: parseInt(recipe.servings) || 4,
                cuisine: recipe.cuisine,
                cuisineAr: recipe.cuisineAr || "",
                category: recipe.category,
                categoryAr: recipe.categoryAr || ""
              }}
              onClose={() => setIsShareDialogOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
