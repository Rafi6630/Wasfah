import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Loader2 } from "lucide-react";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { cn } from "@/lib/utils";
import { FcGoogle } from "react-icons/fc";
import { SiApple } from "react-icons/si";

export default function AuthPage() {
  const { t, isRtl } = useI18n();
  const [location, navigate] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [isLogin, setIsLogin] = React.useState(true);

  // Redirect if user is already logged in
  React.useEffect(() => {
    if (user) {
      navigate("/home");
    }
  }, [user, navigate]);

  // Define schemas for login and register
  const loginSchema = z.object({
    email: z.string().email({ message: "Please enter a valid email address" }),
    password: z.string().min(6, { message: "Password must be at least 6 characters" }),
  });

  const registerSchema = z.object({
    name: z.string().min(2, { message: "Name must be at least 2 characters" }),
    email: z.string().email({ message: "Please enter a valid email address" }),
    password: z.string().min(6, { message: "Password must be at least 6 characters" }),
    confirmPassword: z.string().min(6, { message: "Confirm password must be at least 6 characters" }),
  }).refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

  // Setup form with react-hook-form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  // Form submission handlers
  const onLoginSubmit = (values: z.infer<typeof loginSchema>) => {
    loginMutation.mutate(values, {
      onSuccess: () => {
        navigate("/home");
      }
    });
  };

  const onRegisterSubmit = (values: z.infer<typeof registerSchema>) => {
    registerMutation.mutate(values, {
      onSuccess: () => {
        navigate("/preferences");
      }
    });
  };

  // If still redirecting, show nothing
  if (user) {
    return null;
  }

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden">
      {/* Language Switcher */}
      <div className="absolute top-3 right-3 z-50">
        <LanguageSwitcher />
      </div>

      <div className="flex items-center p-6">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate("/")}
          className="mr-2"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold text-neutral-800">
          {isLogin ? t("signIn") : t("signUp")}
        </h1>
      </div>

      <div className="flex flex-col items-center p-6">
        <div className="w-full max-w-sm">
          {isLogin ? (
            // Login Form
            <>
              <h2 className="text-xl font-semibold mb-4">{t("welcomeBack")}</h2>
              <p className="text-neutral-800 opacity-75 mb-6">{t("loginToAccount")}</p>
              
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                  <FormField
                    control={loginForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("email")}</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="you@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => {
                      const [showPassword, setShowPassword] = React.useState(false);
                      return (
                        <FormItem>
                          <FormLabel>{t("password")}</FormLabel>
                          <div className="relative">
                            <FormControl>
                              <Input 
                                type={showPassword ? "text" : "password"} 
                                placeholder="••••••••" 
                                {...field} 
                              />
                            </FormControl>
                            <button 
                              type="button"
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? 
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" x2="22" y1="2" y2="22"></line></svg> : 
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                              }
                            </button>
                          </div>
                          <div className="flex justify-end mt-2">
                            <a href="#" className="text-sm text-primary">{t("forgotPassword")}</a>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )
                    }}
                  />
                  <Button 
                    type="submit" 
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={loginMutation.isPending}
                  >
                    {loginMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {t("signIn")}
                  </Button>
                </form>
              </Form>
            </>
          ) : (
            // Register Form
            <>
              <h2 className="text-xl font-semibold mb-4">{t("registerNewAccount")}</h2>
              
              <Form {...registerForm}>
                <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                  <FormField
                    control={registerForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("name")}</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={registerForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("email")}</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="you@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={registerForm.control}
                    name="password"
                    render={({ field }) => {
                      const [showPassword, setShowPassword] = React.useState(false);
                      const passwordValue = field.value || "";
                      
                      // Password strength calculation
                      const hasMinLength = passwordValue.length >= 8;
                      const hasNumber = /\d/.test(passwordValue);
                      const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(passwordValue);
                      const hasUpperCase = /[A-Z]/.test(passwordValue);
                      
                      const strength = 
                        (hasMinLength ? 1 : 0) + 
                        (hasNumber ? 1 : 0) + 
                        (hasSpecial ? 1 : 0) + 
                        (hasUpperCase ? 1 : 0);
                      
                      const getStrengthColor = () => {
                        if (passwordValue.length === 0) return "bg-gray-200";
                        if (strength <= 1) return "bg-red-500";
                        if (strength <= 2) return "bg-yellow-500";
                        if (strength <= 3) return "bg-blue-500";
                        return "bg-green-500";
                      };
                      
                      const getStrengthText = () => {
                        if (passwordValue.length === 0) return "";
                        if (strength <= 1) return t("passwordWeak");
                        if (strength <= 2) return t("passwordFair");
                        if (strength <= 3) return t("passwordGood");
                        return t("passwordStrong");
                      };

                      return (
                        <FormItem>
                          <FormLabel>{t("password")}</FormLabel>
                          <div className="relative">
                            <FormControl>
                              <Input 
                                type={showPassword ? "text" : "password"} 
                                placeholder="••••••••" 
                                {...field} 
                              />
                            </FormControl>
                            <button 
                              type="button"
                              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? 
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" x2="22" y1="2" y2="22"></line></svg> : 
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                              }
                            </button>
                          </div>

                          {/* Password strength meter */}
                          {passwordValue.length > 0 && (
                            <div className="mt-2">
                              <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                                <div 
                                  className={`h-full ${getStrengthColor()} transition-all`} 
                                  style={{ width: `${(strength / 4) * 100}%` }}
                                />
                              </div>
                              <p className="text-xs mt-1 text-gray-600">{getStrengthText()}</p>
                            </div>
                          )}

                          <FormMessage />
                        </FormItem>
                      )
                    }}
                  />
                  <FormField
                    control={registerForm.control}
                    name="confirmPassword"
                    render={({ field }) => {
                      const [showPassword, setShowPassword] = React.useState(false);
                      const password = registerForm.watch("password");
                      const confirmValue = field.value || "";
                      const passwordsMatch = password === confirmValue && confirmValue.length > 0;
                      
                      return (
                        <FormItem>
                          <FormLabel>{t("confirmPassword")}</FormLabel>
                          <div className="relative">
                            <FormControl>
                              <Input 
                                type={showPassword ? "text" : "password"} 
                                placeholder="••••••••" 
                                {...field}
                                className={confirmValue.length > 0 ? 
                                  (passwordsMatch ? "border-green-500 focus-visible:ring-green-500" : "border-red-500 focus-visible:ring-red-500") : 
                                  ""
                                }
                              />
                            </FormControl>
                            <div className="absolute right-3 flex items-center h-full">
                              {confirmValue.length > 0 && (
                                <span className="mr-2">
                                  {passwordsMatch ? (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="green" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                      <path d="M20 6L9 17l-5-5"/>
                                    </svg>
                                  ) : (
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="red" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                      <line x1="18" y1="6" x2="6" y2="18"></line>
                                      <line x1="6" y1="6" x2="18" y2="18"></line>
                                    </svg>
                                  )}
                                </span>
                              )}
                              <button 
                                type="button"
                                className="text-gray-500 hover:text-gray-700"
                                onClick={() => setShowPassword(!showPassword)}
                              >
                                {showPassword ? 
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path><line x1="2" x2="22" y1="2" y2="22"></line></svg> : 
                                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                }
                              </button>
                            </div>
                            
                            {/* Password match indicator text */}
                            {confirmValue.length > 0 && (
                              <p className={`text-xs mt-1 ${passwordsMatch ? "text-green-500" : "text-red-500"}`}>
                                {passwordsMatch ? t("passwordsMatch") : t("passwordsDontMatch")}
                              </p>
                            )}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )
                    }}
                  />
                  <Button 
                    type="submit" 
                    className="w-full bg-primary hover:bg-primary/90"
                    disabled={registerMutation.isPending}
                  >
                    {registerMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : null}
                    {t("register")}
                  </Button>
                </form>
              </Form>
            </>
          )}

          {/* Divider */}
          <div className="relative mt-6 mb-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">{t("or")}</span>
            </div>
          </div>

          {/* Social Login Buttons */}
          <div className="flex flex-col space-y-2">
            <Button variant="outline" className="w-full">
              <FcGoogle className="w-5 h-5 mr-2" />
              {t("continueWithGoogle")}
            </Button>
            <Button variant="outline" className="w-full">
              <SiApple className="w-5 h-5 mr-2" />
              {t("continueWithApple")}
            </Button>
          </div>

          {/* Login/Register Switch */}
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              {isLogin ? t("dontHaveAccount") : t("alreadyHaveAccount")}
              <button 
                className="ml-1 text-primary font-medium"
                onClick={() => setIsLogin(!isLogin)}
              >
                {isLogin ? t("signUp") : t("logIn")}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}