import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { ArrowLeft, Plus, Trash2, AlertCircle, CreditCard } from "lucide-react";
import { RoyalCrownIcon } from "@/components/icons/crown-icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { StripePaymentContainer } from "@/components/payment/stripe-payment-container";

// Mock payment card data
const mockPaymentCards = [
  { id: 1, type: "VISA", lastFour: "1234", expiryDate: "12/25" },
  { id: 2, type: "MASTERCARD", lastFour: "5678", expiryDate: "04/26" }
];

export default function PaymentMethodsPage() {
  const { t, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { user, updateSubscriptionMutation } = useAuth();
  const { toast } = useToast();
  const [paymentCards, setPaymentCards] = React.useState(mockPaymentCards);
  // Automatically show the payment dialog when coming from subscription page
  const location = window.location.search;
  const isUpgrading = location.includes('upgrade=premium');
  const billingParam = new URLSearchParams(location).get('billing');
  const billingPeriodParam = billingParam === 'yearly' ? 'yearly' : 'monthly';
  
  const [isAddingCard, setIsAddingCard] = React.useState(isUpgrading);
  const [newCard, setNewCard] = React.useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    billingAddress: ""
  });
  
  // Subscription details
  const [subscriptionDetails, setSubscriptionDetails] = React.useState({
    tier: user?.subscription_tier || 'free',
    price: 5.99,
    billingPeriod: 'monthly',
    nextBillingDate: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000), // 12 days from now
    status: 'active'
  });
  
  // Convert subscription expiry date to days remaining
  const daysRemaining = Math.ceil((subscriptionDetails.nextBillingDate.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
  const subscriptionProgressPercent = (daysRemaining / 30) * 100;
  
  const handleGoBack = () => {
    setLocation("/settings");
  };
  
  const [cardToDelete, setCardToDelete] = React.useState<number | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = React.useState(false);
  
  const handleDeleteCard = (cardId: number) => {
    // Show confirmation dialog
    setCardToDelete(cardId);
    setShowDeleteConfirm(true);
  };
  
  const confirmDeleteCard = () => {
    if (cardToDelete === null) return;
    
    // If this is the last card and user has premium subscription, show warning
    if (paymentCards.length === 1 && subscriptionDetails.tier === 'premium') {
      toast({
        title: t("warning"),
        description: t("lastCardDeletionWarning"),
        variant: "destructive"
      });
    }
    
    // Remove the card
    setPaymentCards(paymentCards.filter(card => card.id !== cardToDelete));
    setShowDeleteConfirm(false);
    setCardToDelete(null);
    
    toast({
      description: t("cardRemoved"),
    });
  };
  
  const handleAddCard = () => {
    // Validate the card details
    if (!newCard.cardNumber || !newCard.expiryDate || !newCard.cvv) {
      toast({
        title: t("validationError"),
        description: t("pleaseCompleteAllFields"),
        variant: "destructive"
      });
      return;
    }
    
    // In a real app, this would integrate with Stripe's API
    // For subscription-based billing, this would use the Stripe API to register a payment method
    // and update the customer's default payment method for recurring billing
    
    // For this demo, we'll simulate success with a mock card
    const newCardObj = {
      id: Math.floor(Math.random() * 1000),
      type: newCard.cardNumber.startsWith("4") ? "VISA" : "MASTERCARD",
      lastFour: newCard.cardNumber.slice(-4),
      expiryDate: newCard.expiryDate
    };
    
    // Simulate API call with short delay
    toast({
      title: t("processing"),
      description: t("validatingCardDetails"),
    });
    
    setTimeout(() => {
      setPaymentCards([...paymentCards, newCardObj]);
      setNewCard({
        cardNumber: "",
        expiryDate: "",
        cvv: "",
        billingAddress: ""
      });
      setIsAddingCard(false);
      
      toast({
        title: t("success"),
        description: t("cardAddedSuccessfully"),
      });
      
      // Update subscription details if this is the first card added
      if (paymentCards.length === 0 && subscriptionDetails.tier === 'free') {
        toast({
          title: t("tryPremium"),
          description: t("upgradeToPremiumNow"),
        });
      }
    }, 1500);
  };
  
  const handleMakeDefault = (cardId: number) => {
    // In a real app, this would update the customer's default payment method in Stripe
    const updatedCards = [...paymentCards];
    // Move the selected card to the front of the array
    const cardIndex = updatedCards.findIndex(card => card.id === cardId);
    if (cardIndex > 0) {
      const [card] = updatedCards.splice(cardIndex, 1);
      updatedCards.unshift(card);
      setPaymentCards(updatedCards);
      
      toast({
        description: t("cardSetAsDefault"),
      });
    }
  };
  
  const handleCardInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewCard({ ...newCard, [name]: value });
  };
  
  const handleRenewSubscription = () => {
    // In a real app, this would use Stripe's API to renew the subscription
    
    // First validate if there's a payment method available
    if (paymentCards.length === 0) {
      toast({
        title: t("paymentMethodRequired"),
        description: t("pleaseAddPaymentMethod"),
        variant: "destructive"
      });
      setIsAddingCard(true);
      return;
    }
    
    // Show processing state
    toast({
      title: t("processingRenewal"),
      description: t("pleaseWait"),
    });
    
    // Simulate API delay
    setTimeout(() => {
      // Update subscription details with new expiry date
      const newExpiryDate = new Date();
      newExpiryDate.setMonth(newExpiryDate.getMonth() + (subscriptionDetails.billingPeriod === 'monthly' ? 1 : 12));
      
      setSubscriptionDetails({
        ...subscriptionDetails,
        nextBillingDate: newExpiryDate
      });
      
      // Show success message
      toast({
        title: t("success"),
        description: t("subscriptionRenewedSuccessfully"),
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center p-4 border-b">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-2"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="font-semibold">{t("paymentMethods")}</h1>
        <div className="absolute right-2">
          <LanguageSwitcher />
        </div>
      </div>
      
      <div className="p-4 space-y-6">
        {/* Subscription Status */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="font-medium mb-2">{t("subscriptionStatus")}</h2>
          
          {subscriptionDetails.tier === "premium" ? (
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="font-medium text-primary">Premium</div>
                  <div className="text-sm text-gray-600">${subscriptionDetails.price}/{subscriptionDetails.billingPeriod === 'monthly' ? t("month") : t("year")}</div>
                </div>
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                  {subscriptionDetails.status === 'active' ? t("active") : t("inactive")}
                </Badge>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center text-sm">
                  <span>{t("nextBillingDate")}</span>
                  <span>{subscriptionDetails.nextBillingDate.toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span>{t("daysRemaining")}</span>
                  <span>{daysRemaining} {t("days")}</span>
                </div>
                <Progress value={subscriptionProgressPercent} className="h-2" />
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <Button 
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation("/subscription")}
                >
                  {t("changePlan")}
                </Button>
                <Button 
                  className="w-full" 
                  size="sm"
                  onClick={handleRenewSubscription}
                >
                  {t("renewSubscription")}
                </Button>
              </div>
            </div>
          ) : (
            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200 flex items-start gap-2">
              <AlertCircle className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-700">{t("freeTier")}</h4>
                <p className="text-sm text-blue-600 mt-1">{t("upgradeToUnlock")}</p>
                <Button 
                  className="mt-2" 
                  size="sm"
                  onClick={() => setLocation("/subscribe")}
                >
                  {t("upgradeToPremium")}
                </Button>
              </div>
            </div>
          )}
        </div>
        
        {/* Saved Cards Section */}
        <div>
          <h2 className="font-medium mb-3">{t("savedCards")}</h2>
          
          {paymentCards.length === 0 ? (
            <div className="text-center py-6 text-gray-500">
              <CreditCard className="h-12 w-12 mx-auto text-gray-400" />
              <p className="mt-2">{t("noSavedCards")}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {paymentCards.map(card => (
                <div 
                  key={card.id}
                  className={`flex items-center justify-between p-3 border rounded-lg ${card.id === paymentCards[0].id ? 'border-primary bg-primary/5' : ''}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-6 rounded flex items-center justify-center text-white text-xs ${card.type === 'VISA' ? 'bg-blue-600' : 'bg-orange-600'}`}>
                      {card.type}
                    </div>
                    <div>
                      <div className="font-medium">•••• {card.lastFour}</div>
                      <div className="text-xs text-gray-500">{t("expires")}: {card.expiryDate}</div>
                      {card.id === paymentCards[0].id && (
                        <Badge variant="outline" className="mt-1 text-xs bg-primary/10 border-primary/20">
                          {t("default")}
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex gap-1">
                    {card.id !== paymentCards[0].id && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        className="text-primary hover:text-primary hover:bg-primary/10"
                        onClick={() => handleMakeDefault(card.id)}
                      >
                        {t("makeDefault")}
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-red-500 hover:text-red-700 hover:bg-red-50"
                      onClick={() => handleDeleteCard(card.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Add Payment Method */}
        <div>
          <Dialog open={isAddingCard} onOpenChange={setIsAddingCard}>
            <DialogTrigger asChild>
              <Button className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                {t("addPaymentMethod")}
              </Button>
            </DialogTrigger>
            
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>
                  {isUpgrading 
                    ? t("completeYourPremiumSubscription") 
                    : t("addNewCard")}
                </DialogTitle>
                <p className="text-sm text-muted-foreground mt-2">
                  {isUpgrading 
                    ? t("paymentRequiredToActivatePremium") 
                    : t("enterYourCardDetailsToSubscribe")}
                </p>
                {isUpgrading && (
                  <div className="mt-2 p-3 bg-royal-gold/10 rounded-lg border border-royal-gold/20">
                    <div className="flex items-start">
                      <div className="mr-2 pt-0.5">
                        <RoyalCrownIcon className="h-4 w-4 text-royal-gold" />
                      </div>
                      <div>
                        <h3 className="text-sm font-medium text-royal-purple-dark">
                          {t("premiumBenefits")}
                        </h3>
                        <p className="text-xs text-royal-purple-dark/80 mt-1">
                          {t("subscriptionPrice", { 
                            price: billingPeriodParam === 'yearly' ? '59.99' : '5.99',
                            period: billingPeriodParam === 'yearly' ? t("year") : t("month")
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </DialogHeader>
              
              {/* Stripe Payment Container - Handles payment intent creation and form display */}
              <StripePaymentContainer 
                tier="premium" 
                billingPeriod={isUpgrading ? billingPeriodParam : (subscriptionDetails.billingPeriod === 'monthly' ? 'monthly' : 'yearly')}
                onSuccess={() => {
                  // Update subscription details in the database
                  updateSubscriptionMutation.mutate({
                    tier: 'premium',
                    billingPeriod: isUpgrading ? billingPeriodParam : subscriptionDetails.billingPeriod
                  });
                  
                  // Update local state
                  setIsAddingCard(false);
                  setSubscriptionDetails({
                    ...subscriptionDetails,
                    tier: 'premium',
                    billingPeriod: isUpgrading ? billingPeriodParam : subscriptionDetails.billingPeriod
                  });
                  
                  // Show success message
                  toast({
                    title: t("subscriptionActivated"),
                    description: t("youAreNowAPremiumMember"),
                  });
                  
                  // Update UI to reflect the payment was successful
                  const newPaymentMethod = {
                    id: Date.now(),
                    type: "VISA",
                    lastFour: "4242", // This would come from the actual Stripe response
                    expiryDate: "12/25", // This would come from the actual Stripe response
                  };
                  setPaymentCards([...paymentCards, newPaymentMethod]);
                  
                  // Redirect back to subscription page after successful payment if coming from there
                  if (isUpgrading) {
                    setTimeout(() => {
                      setLocation("/subscription");
                    }, 1500);
                  }
                }}
                onCancel={() => setIsAddingCard(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
        
        {/* Alternative Payment Methods */}
        <div className="pt-2">
          <h3 className="text-sm text-gray-500 mb-3">{t("otherPaymentOptions")}</h3>
          
          <div className="grid grid-cols-3 gap-2">
            <Button variant="outline" className="flex flex-col items-center py-3 h-auto">
              <span className="text-blue-600 font-bold">Pay</span><span className="text-blue-800 font-bold">Pal</span>
              <span className="text-xs mt-1 text-muted-foreground">{t("expressCheckout") || "Express Checkout"}</span>
            </Button>
            
            <Button variant="outline" className="flex flex-col items-center py-3 h-auto">
              <span className="text-gray-800 font-medium">Google Pay</span>
              <span className="text-xs mt-1 text-muted-foreground">{t("fastAndSecure") || "Fast & Secure"}</span>
            </Button>
            
            <Button variant="outline" className="flex flex-col items-center py-3 h-auto">
              <span className="font-medium">
                <span className="text-gray-800">Apple</span>
                <span className="text-gray-500">Pay</span>
              </span>
              <span className="text-xs mt-1 text-muted-foreground">{t("tapToPay") || "Tap to Pay"}</span>
            </Button>
          </div>
          
          <div className="mt-4 p-3 bg-primary/5 rounded-lg border border-primary/10">
            <div className="flex items-start">
              <div className="bg-primary/10 p-1 rounded-full mr-3 mt-0.5">
                <CreditCard className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h4 className="text-sm font-medium">{t("howPaymentWorks") || "How Payment Works"}</h4>
                <p className="text-xs text-muted-foreground mt-1">
                  {t("paymentExplanation") || "Your payment method will be charged immediately for your first subscription period. Your subscription will automatically renew unless canceled."}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("removeCard")}</AlertDialogTitle>
            <AlertDialogDescription>
              {paymentCards.length === 1 && subscriptionDetails.tier === 'premium'
                ? t("removeLastCardWarning")
                : t("removeCardConfirmation")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteCard}
              className="bg-red-500 hover:bg-red-600"
            >
              {t("remove")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}