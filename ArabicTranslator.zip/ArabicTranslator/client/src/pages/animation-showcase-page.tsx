import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  RoyalFadeIn, 
  RoyalSlideIn, 
  RoyalStaggerChildren, 
  RoyalPresence 
} from '@/components/animations/royal-transitions';
import { RoyalShimmer, ShimmerButton } from '@/components/animations/royal-shimmer';
import { AnimationDemo } from '@/components/animations/animation-demo';
import { useAnimation } from '@/lib/animation-context';
import { 
  Crown, 
  ArrowRight, 
  Sparkles, 
  Play, 
  Pause, 
  RotateCcw, 
  Settings, 
  ChevronRight,
  MoveHorizontal,
  MoveVertical,
  CornerLeftDown,
  Layers
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';
import { Link } from 'wouter';

export default function AnimationShowcasePage() {
  const { 
    animationsEnabled, 
    prefersReducedMotion, 
    transitionType, 
    setTransitionType,
    animationSpeed,
    setAnimationSpeed
  } = useAnimation();
  
  const [demoSection, setDemoSection] = useState<string>('transitions');
  
  return (
    <div className="min-h-screen bg-white pb-20">
      {/* Header */}
      <RoyalFadeIn>
        <div className="relative px-4 py-8 text-center bg-royal-purple/5 overflow-hidden">
          <div className="max-w-5xl mx-auto">
            <div className="absolute inset-0 z-0">
              <div className="absolute inset-0 opacity-[0.03]" 
                   style={{backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%234B0082' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`}}
              />
            </div>
            <div className="relative z-10">
              <h1 className="text-3xl md:text-4xl font-bold text-royal-purple mb-4 font-display flex items-center justify-center">
                <Crown className="h-8 w-8 mr-3 text-royal-gold" />
                Royal Animation Showcase
              </h1>
              <p className="text-lg text-royal-purple/80 max-w-2xl mx-auto">
                Experience our majestic animations that enhance the royal theme throughout the application. Customize animations to match your preferences.
              </p>
            </div>
          </div>
        </div>
      </RoyalFadeIn>
      
      {/* Animation Controls */}
      <div className="max-w-5xl mx-auto px-4 py-6">
        <RoyalSlideIn direction="up" distance={20} delay={0.2}>
          <div className="bg-white border border-gray-200 rounded-lg p-5 mb-8 shadow-sm">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h2 className="text-xl font-bold text-royal-purple mb-1 font-display">Animation Controls</h2>
                <p className="text-sm text-gray-500">Adjust these settings to control animations throughout the app</p>
              </div>
              
              <div className="flex flex-wrap gap-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setTransitionType('fade')}
                  className={cn(transitionType === 'fade' && 'border-royal-purple bg-royal-purple/5')}
                >
                  <Layers className="h-4 w-4 mr-2" />
                  Fade
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setTransitionType('slide')}
                  className={cn(transitionType === 'slide' && 'border-royal-purple bg-royal-purple/5')}
                >
                  <MoveHorizontal className="h-4 w-4 mr-2" />
                  Slide
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setTransitionType('scale')}
                  className={cn(transitionType === 'scale' && 'border-royal-purple bg-royal-purple/5')}
                >
                  <MoveVertical className="h-4 w-4 mr-2" />
                  Scale
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setTransitionType('crown')}
                  className={cn(transitionType === 'crown' && 'border-royal-purple bg-royal-purple/5')}
                >
                  <Crown className="h-4 w-4 mr-2" />
                  Crown
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setTransitionType('sparkle')}
                  className={cn(transitionType === 'sparkle' && 'border-royal-purple bg-royal-purple/5')}
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Sparkle
                </Button>
              </div>
            </div>
            
            <Separator className="my-4" />
            
            <div className="flex flex-col md:flex-row gap-5">
              <div className="w-full md:w-1/2">
                <div className="mb-3">
                  <span className="text-sm font-medium text-gray-700">Animation Speed</span>
                </div>
                <RadioGroup 
                  value={animationSpeed} 
                  onValueChange={(value) => setAnimationSpeed(value as 'slow' | 'normal' | 'fast')}
                  className="flex gap-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="slow" id="speed-slow" />
                    <Label htmlFor="speed-slow">Slow</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="normal" id="speed-normal" />
                    <Label htmlFor="speed-normal">Normal</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="fast" id="speed-fast" />
                    <Label htmlFor="speed-fast">Fast</Label>
                  </div>
                </RadioGroup>
              </div>
              
              <div className="w-full md:w-1/2">
                <div className="mb-3">
                  <span className="text-sm font-medium text-gray-700">Animation Settings</span>
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center">
                    <div className={`relative w-10 h-5 transition-colors duration-200 ease-linear rounded-full ${animationsEnabled ? 'bg-royal-purple' : 'bg-gray-300'}`}>
                      <input
                        type="checkbox"
                        className="absolute w-full h-full cursor-pointer opacity-0"
                        checked={animationsEnabled}
                        onChange={(e) => useAnimation().setAnimationsEnabled(e.target.checked)}
                      />
                      <span className={`absolute left-0.5 top-0.5 bg-white w-4 h-4 rounded-full transition-transform duration-200 ease-in-out ${animationsEnabled ? 'translate-x-5' : ''}`} />
                    </div>
                    <span className="ml-3 text-sm text-gray-700">Enable animations</span>
                  </div>
                  <div className="flex items-center">
                    <div className={`relative w-10 h-5 transition-colors duration-200 ease-linear rounded-full ${prefersReducedMotion ? 'bg-royal-purple' : 'bg-gray-300'}`}>
                      <input
                        type="checkbox"
                        className="absolute w-full h-full cursor-pointer opacity-0"
                        checked={prefersReducedMotion}
                        onChange={(e) => useAnimation().setPrefersReducedMotion(e.target.checked)}
                      />
                      <span className={`absolute left-0.5 top-0.5 bg-white w-4 h-4 rounded-full transition-transform duration-200 ease-in-out ${prefersReducedMotion ? 'translate-x-5' : ''}`} />
                    </div>
                    <span className="ml-3 text-sm text-gray-700">Reduce motion</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </RoyalSlideIn>
        
        {/* Demo Selector */}
        <div className="flex gap-2 mb-6 overflow-x-auto py-2 pb-4">
          <Button 
            variant={demoSection === 'transitions' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setDemoSection('transitions')}
            className="whitespace-nowrap"
          >
            <MoveHorizontal className="h-4 w-4 mr-2" />
            Transitions
          </Button>
          <Button 
            variant={demoSection === 'effects' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setDemoSection('effects')}
            className="whitespace-nowrap"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Effects
          </Button>
          <Button 
            variant={demoSection === 'interactive' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setDemoSection('interactive')}
            className="whitespace-nowrap"
          >
            <Settings className="h-4 w-4 mr-2" />
            Interactive Elements
          </Button>
        </div>
        
        {/* Demo Content */}
        <div className="space-y-8">
          <AnimatePresence mode="wait">
            {demoSection === 'transitions' && (
              <motion.div
                key="transitions"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <TransitionDemo />
              </motion.div>
            )}
            
            {demoSection === 'effects' && (
              <motion.div
                key="effects"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <EffectDemo />
              </motion.div>
            )}
            
            {demoSection === 'interactive' && (
              <motion.div
                key="interactive"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <InteractionDemo />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {/* Back Button */}
        <div className="mt-10 flex justify-center">
          <Link href="/settings">
            <Button variant="outline" className="flex items-center gap-2">
              <RotateCcw className="h-4 w-4" />
              Back to Settings
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}

function TransitionDemo() {
  const items = [
    { title: "Fade Animation", description: "Gentle opacity transitions that subtly bring content into view." },
    { title: "Slide Animation", description: "Content glides smoothly from one position to another." },
    { title: "Scale Animation", description: "Elements gracefully grow or shrink in size." },
    { title: "Staggered Animation", description: "Items animate in sequence, creating a flowing effect." },
  ];
  
  const [showPresence, setShowPresence] = useState(true);
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-royal-purple mb-6 font-display">Royal Transitions</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Fade In */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Layers className="h-4 w-4 mr-2 text-royal-purple" />
              RoyalFadeIn
            </h3>
          </div>
          <div className="p-4 h-56 flex items-center justify-center">
            <RoyalFadeIn className="max-w-xs text-center">
              <div className="bg-royal-purple/5 p-5 rounded-lg border border-royal-purple/20">
                <h4 className="text-lg font-bold text-royal-purple mb-2">Elegant Fade Effect</h4>
                <p className="text-sm text-gray-600">This content gracefully fades into view with a subtle upward movement.</p>
              </div>
            </RoyalFadeIn>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<RoyalFadeIn direction="up" distance={20}>'}
          </div>
        </div>
        
        {/* Slide In */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <MoveHorizontal className="h-4 w-4 mr-2 text-royal-purple" />
              RoyalSlideIn
            </h3>
          </div>
          <div className="p-4 h-56 flex items-center justify-center overflow-hidden">
            <RoyalSlideIn direction="left" distance={100} className="max-w-xs">
              <div className="bg-royal-purple/5 p-5 rounded-lg border border-royal-purple/20">
                <h4 className="text-lg font-bold text-royal-purple mb-2">Majestic Slide Effect</h4>
                <p className="text-sm text-gray-600">Content slides in from the side with a regal motion.</p>
              </div>
            </RoyalSlideIn>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<RoyalSlideIn direction="left" distance={100}>'}
          </div>
        </div>
        
        {/* Stagger Children */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Layers className="h-4 w-4 mr-2 text-royal-purple" />
              RoyalStaggerChildren
            </h3>
          </div>
          <div className="p-4 h-56 flex items-center justify-center">
            <RoyalStaggerChildren
              children={items.map((item, index) => (
                <div key={index} className="bg-royal-purple/5 p-3 mb-2 rounded border border-royal-purple/20">
                  <h4 className="text-sm font-medium text-royal-purple">{item.title}</h4>
                </div>
              ))}
              staggerDelay={0.1}
              direction="up"
              distance={10}
            />
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<RoyalStaggerChildren staggerDelay={0.1}>'}
          </div>
        </div>
        
        {/* Presence */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-royal-purple" />
              RoyalPresence
            </h3>
          </div>
          <div className="p-4 h-56 flex flex-col items-center justify-center gap-4">
            <div className="h-32 w-full flex items-center justify-center overflow-hidden">
              <RoyalPresence show={showPresence} type={transitionType}>
                <div className="bg-royal-purple/5 p-5 rounded-lg border border-royal-purple/20 max-w-xs">
                  <h4 className="text-lg font-bold text-royal-purple mb-2">Dynamic Presence</h4>
                  <p className="text-sm text-gray-600">This element can dynamically appear and disappear.</p>
                </div>
              </RoyalPresence>
            </div>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowPresence(!showPresence)}
              className="mt-4"
            >
              {showPresence ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
              {showPresence ? 'Hide Element' : 'Show Element'}
            </Button>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<RoyalPresence show={state} type="' + transitionType + '">'}
          </div>
        </div>
      </div>
    </div>
  );
}

function EffectDemo() {
  const getRandomStyle = (index: number) => {
    const styles = [
      {
        background: "linear-gradient(45deg, #4b0082 0%, #6a0dad 100%)",
        backgroundSize: "cover",
      },
      {
        position: "relative",
      },
      {
        border: "2px solid #C5A942",
      }
    ];
    return styles[index % styles.length];
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-royal-purple mb-6 font-display">Royal Effects</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Shimmer Component */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-royal-purple" />
              RoyalShimmer
            </h3>
          </div>
          <div className="p-4 h-56 flex items-center justify-center">
            <RoyalShimmer
              className="w-full max-w-xs"
              shimmerWidth={30}
              shimmerOpacity={0.3}
              color="#C5A942"
            >
              <div className="bg-royal-purple p-5 rounded-lg text-white">
                <h4 className="text-lg font-bold mb-2">Golden Shimmer Effect</h4>
                <p className="text-sm opacity-90">A luxurious golden shimmer effect adds a touch of elegance.</p>
              </div>
            </RoyalShimmer>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<RoyalShimmer shimmerWidth={30} shimmerOpacity={0.3}>'}
          </div>
        </div>
        
        {/* Shimmer Button */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Sparkles className="h-4 w-4 mr-2 text-royal-purple" />
              ShimmerButton
            </h3>
          </div>
          <div className="p-4 h-56 flex items-center justify-center">
            <div className="flex flex-col items-center gap-4">
              <ShimmerButton className="w-48">
                Discover Royal Recipes
              </ShimmerButton>
              
              <ShimmerButton className="w-48" disabled>
                Disabled Button
              </ShimmerButton>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<ShimmerButton>Discover Royal Recipes</ShimmerButton>'}
          </div>
        </div>
        
        {/* Direction Control */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <MoveHorizontal className="h-4 w-4 mr-2 text-royal-purple" />
              Shimmer Directions
            </h3>
          </div>
          <div className="p-4 h-56 flex flex-col gap-2 justify-center">
            {['left-to-right', 'right-to-left', 'top-to-bottom', 'diagonal'].map((direction, index) => (
              <RoyalShimmer
                key={direction}
                direction={direction as any}
                shimmerWidth={40}
                shimmerOpacity={0.3}
                delay={index * 0.5}
                className="w-full"
              >
                <div className="bg-royal-purple/10 p-2 rounded text-sm text-royal-purple font-medium">
                  <CornerLeftDown className="h-4 w-4 inline mr-2 opacity-70" />
                  {direction}
                </div>
              </RoyalShimmer>
            ))}
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<RoyalShimmer direction="left-to-right|diagonal|etc">'}
          </div>
        </div>
        
        {/* Animation Demo */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Crown className="h-4 w-4 mr-2 text-royal-purple" />
              Animation Demo
            </h3>
          </div>
          <div className="p-4 h-56 flex items-center justify-center">
            <div className="flex flex-col w-full max-w-xs gap-4">
              <AnimationDemo size="md" demoText="Royal Transitions" />
              <div className="text-xs text-center text-gray-500">
                <p>Click to pause/resume the demo</p>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-4 py-3 border-t border-gray-200 text-xs font-mono text-gray-500">
            {'<AnimationDemo size="md" demoText="Royal Transitions" />'}
          </div>
        </div>
      </div>
    </div>
  );
}

function InteractionDemo() {
  const [activeCard, setActiveCard] = useState<number | null>(null);
  
  const cardData = [
    { title: "Hover Effects", description: "Elegant hover transitions with royal gold accents." },
    { title: "Click Animations", description: "Responsive feedback animations for user interactions." },
    { title: "Focus States", description: "Accessibility-focused highlighting with royal theme." },
    { title: "Navigation Effects", description: "Smooth page transitions between screens." },
  ];
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-royal-purple mb-6 font-display">Interactive Elements</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hover Cards */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm col-span-1 md:col-span-2">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Settings className="h-4 w-4 mr-2 text-royal-purple" />
              Interactive Cards
            </h3>
          </div>
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            {cardData.map((card, index) => (
              <div
                key={index}
                className={`bg-white border rounded-lg p-4 transition-all duration-300 cursor-pointer relative overflow-hidden ${
                  activeCard === index 
                    ? 'border-royal-gold shadow-md' 
                    : 'border-gray-200 hover:border-royal-gold/50 hover:shadow-sm'
                }`}
                onClick={() => setActiveCard(activeCard === index ? null : index)}
              >
                {/* Background shimmer effect */}
                {activeCard === index && (
                  <div className="absolute inset-0 bg-royal-purple/5 z-0"></div>
                )}
                
                {/* Decorative corner elements when active */}
                {activeCard === index && (
                  <>
                    <div className="absolute top-0 left-0 h-8 w-8 pointer-events-none">
                      <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-royal-gold"></div>
                    </div>
                    <div className="absolute top-0 right-0 h-8 w-8 pointer-events-none">
                      <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-royal-gold"></div>
                    </div>
                    <div className="absolute bottom-0 left-0 h-8 w-8 pointer-events-none">
                      <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-royal-gold"></div>
                    </div>
                    <div className="absolute bottom-0 right-0 h-8 w-8 pointer-events-none">
                      <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-royal-gold"></div>
                    </div>
                  </>
                )}
                
                {/* Content */}
                <div className="relative z-10">
                  <h4 className={`font-bold flex items-center ${activeCard === index ? 'text-royal-purple' : 'text-gray-800'}`}>
                    {activeCard === index && <Crown className="h-4 w-4 mr-2 text-royal-gold" />}
                    {card.title}
                  </h4>
                  <p className="text-sm text-gray-600 mt-1">{card.description}</p>
                  
                  {/* Show extra content when active */}
                  {activeCard === index && (
                    <RoyalFadeIn className="mt-3">
                      <div className="text-xs text-royal-purple/80 bg-royal-purple/5 p-2 rounded-sm">
                        Click cards to toggle selection and see the elegant royal animations.
                      </div>
                    </RoyalFadeIn>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Button Showcase */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <Settings className="h-4 w-4 mr-2 text-royal-purple" />
              Button Interactions
            </h3>
          </div>
          <div className="p-6 flex flex-col gap-4 items-center">
            <RoyalShimmer className="w-full max-w-xs">
              <button className="w-full bg-royal-purple hover:bg-royal-purple/90 text-white font-medium py-2 px-4 rounded-md transition-colors duration-200 flex justify-center items-center gap-2">
                <span>Explore Premium Recipes</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </RoyalShimmer>
            
            <button className="w-full max-w-xs border-2 border-royal-gold/70 hover:border-royal-gold text-royal-purple font-medium py-2 px-4 rounded-md transition-all duration-200 hover:shadow-sm group relative overflow-hidden">
              <span className="relative z-10 flex justify-center items-center gap-2">
                <Crown className="h-4 w-4 group-hover:text-royal-gold transition-colors duration-200" />
                <span>Royal Subscription</span>
              </span>
              <div className="absolute inset-0 bg-royal-gold/10 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
            </button>
            
            <button className="w-full max-w-xs bg-white hover:bg-gray-50 text-gray-800 font-medium py-2 px-4 rounded-md border border-gray-300 hover:border-gray-400 transition-all duration-200 flex justify-center items-center gap-2">
              <RotateCcw className="h-4 w-4" />
              <span>Cancel</span>
            </button>
          </div>
        </div>
        
        {/* Link Effects */}
        <div className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-3 bg-gray-50 border-b border-gray-200">
            <h3 className="text-md font-medium flex items-center">
              <ChevronRight className="h-4 w-4 mr-2 text-royal-purple" />
              Link Interactions
            </h3>
          </div>
          <div className="p-6">
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Underline Effect</h4>
                <a href="#" className="text-royal-purple relative group inline-block">
                  <span>View Recipe Details</span>
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-royal-gold group-hover:w-full transition-all duration-300"></span>
                </a>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Icon Shift Effect</h4>
                <a href="#" className="text-royal-purple flex items-center group">
                  <span>Browse Premium Collection</span>
                  <ArrowRight className="h-4 w-4 ml-1 transform group-hover:translate-x-1 transition-transform duration-200" />
                </a>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Highlight Effect</h4>
                <a href="#" className="relative group inline-block">
                  <span className="text-royal-purple relative z-10">Exclusive Royal Dishes</span>
                  <span className="absolute bottom-1 left-0 w-full h-2 bg-royal-gold/20 group-hover:h-5 transition-all duration-200 -z-0"></span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}