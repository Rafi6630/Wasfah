import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { useLocation } from "wouter";
import { ArrowLeft, Search, Filter, AlertCircle, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { RecipeListItem } from "@/components/recipe/recipe-list-item";
import { RecipeDetail } from "@/components/recipe/recipe-detail";
import { AdvancedFilters } from "@/components/search/advanced-filters";
import { IngredientInputForm } from "@/components/search/ingredient-input-form";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { getRecipeRecommendations } from "@/lib/openai";
import { useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RoyalButton } from "@/components/ui/royal-button";

// Common ingredients with images
const commonIngredients = [
  { id: 'garlic', name: 'Garlic', nameAr: 'ثوم', image: 'https://images.unsplash.com/photo-1540148426945-6cf22a6b2383?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100' },
  { id: 'olive_oil', name: 'Olive Oil', nameAr: 'زيت زيتون', image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100' },
  { id: 'lemon', name: 'Lemons', nameAr: 'ليمون', image: 'https://images.unsplash.com/photo-1590502593747-42a996133562?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100' },
  { id: 'parsley', name: 'Parsley', nameAr: 'بقدونس', image: 'https://images.unsplash.com/photo-1611105637889-3afd7295bdbf?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100' },
  { id: 'cinnamon', name: 'Cinnamon', nameAr: 'قرفة', image: 'https://pixabay.com/get/gbe3382a4c47f41390bd82868ab4edf972848f53415717ec673bd4f2f80ca92220f8f984bfc71a45aaf1d6eab827929c0_1280.jpg' },
  { id: 'yogurt', name: 'Yogurt', nameAr: 'زبادي', image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100' },
];

export default function SearchPage() {
  const { t, isRtl } = useI18n();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  const { user, updateProfileMutation } = useAuth();
  
  // Parse URL parameters
  const params = new URLSearchParams(window.location.search);
  const showFilters = params.get('showFilters') === 'true';
  const showResults = params.get('results') === 'true';
  const tabParam = params.get('tab');
  const initialTab = tabParam === 'filters' || showFilters ? 'filters' : 
                     tabParam === 'ingredients' ? 'ingredients' : 'ingredients';
  
  const [activeTab, setActiveTab] = React.useState(initialTab);
  const [selectedIngredients, setSelectedIngredients] = React.useState<any[]>(
    (user?.pantry_ingredients || []).map(name => ({ name }))
  );
  const [isSearching, setIsSearching] = React.useState(false);
  const [searchError, setSearchError] = React.useState<string | null>(null);
  const [searchResults, setSearchResults] = React.useState<any[]>([]);
  const [selectedRecipeId, setSelectedRecipeId] = React.useState<string | null>(null);
  const [appliedFilters, setAppliedFilters] = React.useState<any>({});
  const [sortBy, setSortBy] = React.useState<string>("relevance");
  
  const selectedRecipe = searchResults.find(
    (recipe) => recipe.id === selectedRecipeId
  );
  
  // Automatically search for recipes if coming directly to results
  React.useEffect(() => {
    if (showResults && selectedIngredients.length > 0 && searchResults.length === 0 && !isSearching) {
      findRecipes();
    }
  }, [showResults, selectedIngredients, searchResults.length]);
  
  // Update ingredients
  const updateIngredients = (ingredients: any[]) => {
    setSelectedIngredients(ingredients);
  };
  
  // Handle searching for recipes
  const findRecipes = async () => {
    setIsSearching(true);
    setSearchError(null);
    
    try {
      // Extract ingredient names from the selectedIngredients array
      const ingredientNames = selectedIngredients.map(ing => ing.name);
      
      // Update the user's pantry ingredients
      await updateProfileMutation.mutateAsync({
        pantry_ingredients: ingredientNames
      });
      
      // Then search for recipes
      const searchParams = {
        ingredients: ingredientNames,
        ...appliedFilters
      };
      
      const results = await getRecipeRecommendations(searchParams);
      setSearchResults(results);
    } catch (error) {
      console.error("Search error:", error);
      setSearchError(t("searchError"));
    } finally {
      setIsSearching(false);
    }
  };
  
  const handleApplyFilters = (filters: any) => {
    setAppliedFilters(filters);
    
    // If we already have ingredients, re-search with new filters
    if (selectedIngredients.length > 0) {
      findRecipes();
    }
  };

  const handleRecipeClick = (id: string) => {
    setSelectedRecipeId(id);
    window.scrollTo(0, 0);
  };

  const handleBackClick = () => {
    setSelectedRecipeId(null);
  };
  
  // Handle sorting search results
  const handleSortChange = (value: string) => {
    setSortBy(value);
    sortResults(value);
  };
  
  // Sort search results based on criteria
  const sortResults = (sortCriteria: string) => {
    let sortedResults = [...searchResults];
    
    switch (sortCriteria) {
      case "popular":
        // Sort by rating (highest first)
        sortedResults.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
        
      case "rating":
        // Sort by rating (highest first)
        sortedResults.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
        
      case "newest":
        // Would sort by date in a real app
        // Simulating by id for now
        sortedResults.sort((a, b) => a.id.localeCompare(b.id));
        break;
        
      case "quickest":
        // Sort by cooking time (shortest first)
        sortedResults.sort((a, b) => (a.cookTime || 0) - (b.cookTime || 0));
        break;
        
      case "relevance":
      default:
        // Sort by match percentage (highest first)
        sortedResults.sort((a, b) => (b.matchPercentage || 0) - (a.matchPercentage || 0));
        break;
    }
    
    setSearchResults(sortedResults);
  };
  
  // If a recipe is selected, show the recipe detail view
  if (selectedRecipeId && selectedRecipe) {
    return <RecipeDetail recipe={selectedRecipe} onBackClick={handleBackClick} />;
  }
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-neutral-50 shadow-xl flex flex-col pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white z-10 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setLocation("/home")}
            className="p-1"
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-bold text-royal-purple">
            {t("advancedFilters")}
          </h1>
          <div className="w-10"></div>
        </div>

        {/* Only show tabs when not directly showing results */}
        {!showResults && (
          <>
            <h2 className="text-base font-medium text-neutral-700 mb-4">
              {t("setYourFilters")}
            </h2>

            <div className="flex justify-between gap-2 mb-4">
              <Button
                variant="default"
                className="flex-1"
                onClick={() => setActiveTab("filters")}
              >
                {t("filters")}
              </Button>
            </div>
          </>
        )}
      </div>
      
      {/* Content Section - separate from header */}
      {/* Only show filters section when not directly showing results */}
      {!showResults && (
        <div className="mt-4 px-4 pb-24">
          {/* Filters Card */}
          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-3 text-royal-purple">{t("filtersSection")}</h2>
            <AdvancedFilters onApplyFilters={handleApplyFilters} />
          </div>
          
          {/* OK Button (Fixed at bottom) */}
          <div className="fixed bottom-16 left-0 right-0 p-4 bg-white border-t border-royal-purple/10 z-10">
            <RoyalButton 
              variant="primary"
              isFullWidth={true}
              withGlow={true}
              onClick={() => setLocation('/home')}
            >
              {t("ok")}
            </RoyalButton>
          </div>
        </div>
      )}
      
      <div className="flex-1 p-4">
        
        {/* Results Section */}
        {(searchResults.length > 0 || isSearching || searchError) && (
          <div className="mt-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">{t("searchResults")}</h2>
              
              {!isSearching && searchResults.length > 0 && (
                <div className="flex items-center">
                  <Select
                    value={sortBy}
                    onValueChange={handleSortChange}
                  >
                    <SelectTrigger className="w-[140px] h-8 text-sm">
                      <SelectValue placeholder={t("sortBy")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">{t("relevance")}</SelectItem>
                      <SelectItem value="popular">🔥 {t("mostPopular")}</SelectItem>
                      <SelectItem value="rating">⭐ {t("highestRated")}</SelectItem>
                      <SelectItem value="newest">🆕 {t("latest")}</SelectItem>
                      <SelectItem value="quickest">🕒 {t("quickest")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            {isSearching && (
              <div className="flex flex-col items-center justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
                <p className="mt-4 text-gray-600">{t("searching")}</p>
              </div>
            )}

            {searchError && !isSearching && (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <AlertCircle size={36} className="text-red-500 mb-2" />
                <p className="text-red-500">{searchError}</p>
                <p className="mt-2 text-gray-600">{t("tryAgain")}</p>
              </div>
            )}

            {!isSearching && !searchError && searchResults.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <p className="text-gray-600">{t("noRecipesFound")}</p>
                <p className="mt-2 text-gray-600">{t("tryDifferentIngredients")}</p>
              </div>
            )}

            {!isSearching && !searchError && searchResults.length > 0 && (
              <div className="space-y-4">
                {searchResults.map((recipe) => (
                  <RecipeListItem
                    key={recipe.id}
                    recipe={recipe}
                    onClick={() => handleRecipeClick(recipe.id)}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Removed duplicate OK button */}
      
      <BottomNavigation />
    </div>
  );
}
