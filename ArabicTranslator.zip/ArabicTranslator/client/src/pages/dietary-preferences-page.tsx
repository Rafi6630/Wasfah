import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft,
  Check,
  AlertCircle,
  Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

// Types
interface DietaryPreference {
  id: string;
  name: string;
  nameAr: string;
  description: string; 
  descriptionAr: string;
  icon: string;
}

interface Allergen {
  id: string;
  name: string;
  nameAr: string;
  severity: 'mild' | 'moderate' | 'severe';
  tracesOk: boolean;
  icon: string;
}

interface CuisinePreference {
  id: string;
  name: string;
  nameAr: string;
  icon: string;
  selected: boolean;
}

export default function DietaryPreferencesPage() {
  const { t, language, isRtl } = useI18n();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user, updateProfileMutation } = useAuth();
  
  // Dietary preferences data
  const preferencesData: DietaryPreference[] = [
    { 
      id: "vegetarian", 
      name: t("vegetarian"), 
      nameAr: t("vegetarianAr"),
      description: t("vegetarianDescription"),
      descriptionAr: t("vegetarianDescriptionAr"),
      icon: "🥦" 
    },
    { 
      id: "vegan", 
      name: t("vegan"), 
      nameAr: t("veganAr"),
      description: t("veganDescription"),
      descriptionAr: t("veganDescriptionAr"),
      icon: "🌱" 
    },
    { 
      id: "pescatarian", 
      name: t("pescatarian"), 
      nameAr: t("pescatarianAr"),
      description: t("pescatarianDescription"),
      descriptionAr: t("pescatarianDescriptionAr"),
      icon: "🐟" 
    },
    { 
      id: "keto", 
      name: t("keto"), 
      nameAr: t("ketoAr"),
      description: t("ketoDescription"),
      descriptionAr: t("ketoDescriptionAr"),
      icon: "🥓" 
    },
    { 
      id: "paleo", 
      name: t("paleo"), 
      nameAr: t("paleoAr"),
      description: t("paleoDescription"),
      descriptionAr: t("paleoDescriptionAr"),
      icon: "🥩" 
    },
    { 
      id: "lowCarb", 
      name: t("lowCarb"), 
      nameAr: t("lowCarbAr"),
      description: t("lowCarbDescription"),
      descriptionAr: t("lowCarbDescriptionAr"),
      icon: "🥗" 
    },
    { 
      id: "dairyFree", 
      name: t("dairyFree"), 
      nameAr: t("dairyFreeAr"),
      description: t("dairyFreeDescription"),
      descriptionAr: t("dairyFreeDescriptionAr"),
      icon: "🥛" 
    },
    { 
      id: "glutenFree", 
      name: t("glutenFree"), 
      nameAr: t("glutenFreeAr"),
      description: t("glutenFreeDescription"),
      descriptionAr: t("glutenFreeDescriptionAr"),
      icon: "🌾" 
    },
    { 
      id: "halal", 
      name: t("halal"), 
      nameAr: t("halalAr"),
      description: t("halalDescription"),
      descriptionAr: t("halalDescriptionAr"),
      icon: "🌙" 
    },
    { 
      id: "kosher", 
      name: t("kosher"), 
      nameAr: t("kosherAr"),
      description: t("kosherDescription"),
      descriptionAr: t("kosherDescriptionAr"),
      icon: "✡️" 
    },
    { 
      id: "lowSodium", 
      name: t("lowSodium"), 
      nameAr: t("lowSodiumAr"),
      description: t("lowSodiumDescription"),
      descriptionAr: t("lowSodiumDescriptionAr"),
      icon: "🧂" 
    },
    { 
      id: "lowFat", 
      name: t("lowFat"), 
      nameAr: t("lowFatAr"),
      description: t("lowFatDescription"),
      descriptionAr: t("lowFatDescriptionAr"),
      icon: "💪" 
    }
  ];
  
  // Allergens data
  const allergensData: Allergen[] = [
    { 
      id: "dairy", 
      name: t("dairy"), 
      nameAr: t("dairyAr"), 
      severity: 'moderate',
      tracesOk: false,
      icon: "🧀" 
    },
    { 
      id: "eggs", 
      name: t("eggs"), 
      nameAr: t("eggsAr"), 
      severity: 'mild',
      tracesOk: true,
      icon: "🥚" 
    },
    { 
      id: "peanuts", 
      name: t("peanuts"), 
      nameAr: t("peanutsAr"), 
      severity: 'severe',
      tracesOk: false,
      icon: "🥜" 
    },
    { 
      id: "treeNuts", 
      name: t("treeNuts"), 
      nameAr: t("treeNutsAr"), 
      severity: 'severe',
      tracesOk: false,
      icon: "🌰" 
    },
    { 
      id: "fish", 
      name: t("fish"), 
      nameAr: t("fishAr"), 
      severity: 'moderate',
      tracesOk: false,
      icon: "🐟" 
    },
    { 
      id: "shellfish", 
      name: t("shellfish"), 
      nameAr: t("shellfishAr"), 
      severity: 'moderate',
      tracesOk: false,
      icon: "🦐" 
    },
    { 
      id: "wheat", 
      name: t("wheat"), 
      nameAr: t("wheatAr"), 
      severity: 'mild',
      tracesOk: true,
      icon: "🌾" 
    },
    { 
      id: "soy", 
      name: t("soy"), 
      nameAr: t("soyAr"), 
      severity: 'mild',
      tracesOk: true,
      icon: "🫘" 
    },
    { 
      id: "sesame", 
      name: t("sesame"), 
      nameAr: t("sesameAr"), 
      severity: 'moderate',
      tracesOk: false,
      icon: "🌱" 
    }
  ];
  
  // Cuisine preferences data
  const cuisineData: CuisinePreference[] = [
    { id: "middleEastern", name: t("middleEastern"), nameAr: t("middleEasternAr"), icon: "🫓", selected: true },
    { id: "mediterranean", name: t("mediterranean"), nameAr: t("mediterraneanAr"), icon: "🫒", selected: true },
    { id: "italian", name: t("italian"), nameAr: t("italianAr"), icon: "🍝", selected: false },
    { id: "indian", name: t("indian"), nameAr: t("indianAr"), icon: "🍛", selected: false },
    { id: "chinese", name: t("chinese"), nameAr: t("chineseAr"), icon: "🥡", selected: false },
    { id: "japanese", name: t("japanese"), nameAr: t("japaneseAr"), icon: "🍱", selected: false },
    { id: "mexican", name: t("mexican"), nameAr: t("mexicanAr"), icon: "🌮", selected: false },
    { id: "american", name: t("american"), nameAr: t("americanAr"), icon: "🍔", selected: false },
    { id: "french", name: t("french"), nameAr: t("frenchAr"), icon: "🥐", selected: false },
    { id: "thai", name: t("thai"), nameAr: t("thaiAr"), icon: "🍜", selected: false },
    { id: "greek", name: t("greek"), nameAr: t("greekAr"), icon: "🫔", selected: false },
    { id: "spanish", name: t("spanish"), nameAr: t("spanishAr"), icon: "🥘", selected: false }
  ];
  
  // State
  const [selectedPreferences, setSelectedPreferences] = React.useState<string[]>([]);
  const [selectedAllergens, setSelectedAllergens] = React.useState<Allergen[]>([]);
  const [cuisinePreferences, setCuisinePreferences] = React.useState<CuisinePreference[]>(cuisineData);
  const [strictMode, setStrictMode] = React.useState<boolean>(false);
  const [showAllergenDetails, setShowAllergenDetails] = React.useState<boolean>(false);
  
  // Toggle dietary preference
  const togglePreference = (preferenceId: string) => {
    setSelectedPreferences(prev => {
      if (prev.includes(preferenceId)) {
        return prev.filter(id => id !== preferenceId);
      } else {
        return [...prev, preferenceId];
      }
    });
  };
  
  // Toggle allergen
  const toggleAllergen = (allergen: Allergen) => {
    setSelectedAllergens(prev => {
      if (prev.some(a => a.id === allergen.id)) {
        return prev.filter(a => a.id !== allergen.id);
      } else {
        return [...prev, allergen];
      }
    });
  };
  
  // Toggle cuisine preference
  const toggleCuisine = (cuisineId: string) => {
    setCuisinePreferences(prev => 
      prev.map(cuisine => 
        cuisine.id === cuisineId 
          ? { ...cuisine, selected: !cuisine.selected } 
          : cuisine
      )
    );
  };
  
  // Update allergen severity
  const updateAllergenSeverity = (allergenId: string, severity: 'mild' | 'moderate' | 'severe') => {
    setSelectedAllergens(prev => 
      prev.map(a => 
        a.id === allergenId 
          ? { ...a, severity } 
          : a
      )
    );
  };
  
  // Update allergen traces setting
  const updateAllergenTraces = (allergenId: string, tracesOk: boolean) => {
    setSelectedAllergens(prev => 
      prev.map(a => 
        a.id === allergenId 
          ? { ...a, tracesOk } 
          : a
      )
    );
  };
  
  // Save preferences
  const savePreferences = () => {
    // In a real app, this would call an API to update the user's preferences
    toast({
      title: t("preferencesSaved"),
      description: t("yourPreferencesUpdated"),
    });
    
    if (user) {
      updateProfileMutation.mutate({
        id: user.id,
        dietaryPreferences: selectedPreferences,
        allergens: selectedAllergens.map(a => a.id),
        cuisinePreferences: cuisinePreferences.filter(c => c.selected).map(c => c.id),
        strictMode
      });
    }
  };
  
  // Reset preferences
  const resetPreferences = () => {
    setSelectedPreferences([]);
    setSelectedAllergens([]);
    setCuisinePreferences(cuisineData);
    setStrictMode(false);
    
    toast({
      title: t("preferencesReset"),
      description: t("allPreferencesCleared"),
    });
  };
  
  const handleGoBack = () => {
    setLocation("/profile");
  };
  
  return (
    <div className="min-h-screen max-w-md mx-auto bg-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white">
        <div className="relative flex items-center justify-center p-4 border-b">
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-2"
            onClick={handleGoBack}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="font-semibold">{t("dietaryPreferences")}</h1>
        </div>
      </div>
      
      {/* Main Content */}
      <Tabs defaultValue="preferences" className="p-4">
        <TabsList className="grid grid-cols-3 mb-4">
          <TabsTrigger value="preferences">{t("preferences")}</TabsTrigger>
          <TabsTrigger value="allergens">
            {t("allergens")}
            {selectedAllergens.length > 0 && (
              <Badge className="ml-1 h-5 min-w-5 px-1 bg-red-500">
                {selectedAllergens.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="cuisines">{t("cuisines")}</TabsTrigger>
        </TabsList>
        
        {/* Dietary Preferences Tab */}
        <TabsContent value="preferences" className="mt-0">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-medium">{t("dietaryPreferences")}</h2>
              <p className="text-sm text-muted-foreground mb-4">
                {t("selectDietaryPreferencesDescription")}
              </p>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Info className="h-5 w-5 text-muted-foreground" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-60 text-sm">
                    {t("dietaryPreferencesTooltip")}
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
          
          <div className="grid grid-cols-2 gap-3 mb-6">
            {preferencesData.map((preference) => (
              <div 
                key={preference.id}
                className={cn(
                  "border rounded-lg p-3 cursor-pointer transition-colors",
                  selectedPreferences.includes(preference.id) 
                    ? "bg-primary/10 border-primary" 
                    : "hover:bg-muted"
                )}
                onClick={() => togglePreference(preference.id)}
              >
                <div className="flex items-start">
                  <div className="text-xl mr-2">{preference.icon}</div>
                  <div>
                    <div className="font-medium text-sm mb-0.5">
                      {language === 'ar' ? preference.nameAr : preference.name}
                    </div>
                    <div className="text-xs text-muted-foreground line-clamp-2">
                      {language === 'ar' ? preference.descriptionAr : preference.description}
                    </div>
                  </div>
                  {selectedPreferences.includes(preference.id) && (
                    <div className="ml-auto">
                      <Check className="h-4 w-4 text-primary" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          <div className="flex items-center space-x-3 mb-6">
            <Switch
              id="strict-mode"
              checked={strictMode}
              onCheckedChange={setStrictMode}
            />
            <div>
              <Label 
                htmlFor="strict-mode" 
                className="text-sm font-medium"
              >
                {t("strictMode")}
              </Label>
              <p className="text-xs text-muted-foreground">
                {t("strictModeDescription")}
              </p>
            </div>
          </div>
        </TabsContent>
        
        {/* Allergens Tab */}
        <TabsContent value="allergens" className="mt-0">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="font-medium">{t("allergens")}</h2>
              <p className="text-sm text-muted-foreground mb-4">
                {t("selectAllergensDescription")}
              </p>
            </div>
            <div className="flex">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowAllergenDetails(!showAllergenDetails)}
                className="mr-2"
              >
                {showAllergenDetails ? t("hideDetails") : t("showDetails")}
              </Button>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Info className="h-5 w-5 text-muted-foreground" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="max-w-60 text-sm">
                      {t("allergenTooltip")}
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>
          
          {selectedAllergens.length > 0 && (
            <div className="mb-6 p-3 bg-red-50 border border-red-100 rounded-lg">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-red-500 mr-2 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-red-700">
                    {t("allergensDetected")}
                  </p>
                  <p className="text-xs text-red-600">
                    {t("allergensWillBeExcluded")}
                  </p>
                </div>
              </div>
            </div>
          )}
          
          <div className="space-y-3 mb-6">
            {allergensData.map((allergen) => {
              const isSelected = selectedAllergens.some(a => a.id === allergen.id);
              const selectedItem = selectedAllergens.find(a => a.id === allergen.id);
              
              return (
                <div 
                  key={allergen.id}
                  className={cn(
                    "border rounded-lg p-3 cursor-pointer transition-colors",
                    isSelected
                      ? "bg-red-50 border-red-200" 
                      : "hover:bg-muted"
                  )}
                >
                  <div 
                    className="flex items-start"
                    onClick={() => toggleAllergen(allergen)}
                  >
                    <div className="text-xl mr-2">{allergen.icon}</div>
                    <div>
                      <div className="font-medium text-sm mb-0.5">
                        {language === 'ar' ? allergen.nameAr : allergen.name}
                      </div>
                    </div>
                    {isSelected ? (
                      <div className="ml-auto">
                        <Check className="h-4 w-4 text-red-500" />
                      </div>
                    ) : null}
                  </div>
                  
                  {/* Details section shown when enabled and item is selected */}
                  {isSelected && showAllergenDetails && (
                    <div className="mt-3 pt-3 border-t border-red-100">
                      <div className="space-y-3">
                        <div>
                          <Label className="text-xs font-medium mb-1 block">
                            {t("allergySeverity")}
                          </Label>
                          <div className="flex space-x-2">
                            {(['mild', 'moderate', 'severe'] as const).map((severity) => (
                              <Button
                                key={severity}
                                variant="outline"
                                size="sm"
                                className={cn(
                                  "text-xs px-2 h-8 flex-1",
                                  selectedItem?.severity === severity && [
                                    "border-red-300 bg-red-50",
                                    severity === 'mild' && "text-amber-700",
                                    severity === 'moderate' && "text-orange-700",
                                    severity === 'severe' && "text-red-700",
                                  ]
                                )}
                                onClick={() => updateAllergenSeverity(allergen.id, severity)}
                              >
                                {t(severity)}
                              </Button>
                            ))}
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <Label className="text-xs font-medium mb-0 block">
                              {t("tracesAcceptable")}
                            </Label>
                            <p className="text-xs text-muted-foreground">
                              {t("tracesAcceptableDescription")}
                            </p>
                          </div>
                          <Switch
                            checked={selectedItem?.tracesOk || false}
                            onCheckedChange={(checked) => 
                              updateAllergenTraces(allergen.id, checked)
                            }
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </TabsContent>
        
        {/* Cuisines Tab */}
        <TabsContent value="cuisines" className="mt-0">
          <div className="mb-4">
            <h2 className="font-medium">{t("cuisinePreferences")}</h2>
            <p className="text-sm text-muted-foreground mb-4">
              {t("selectCuisinePreferencesDescription")}
            </p>
          </div>
          
          <div className="grid grid-cols-3 gap-3 mb-6">
            {cuisinePreferences.map((cuisine) => (
              <motion.div 
                key={cuisine.id}
                className={cn(
                  "border rounded-lg p-3 cursor-pointer transition-colors flex flex-col items-center",
                  cuisine.selected
                    ? "bg-primary/10 border-primary" 
                    : "hover:bg-muted"
                )}
                onClick={() => toggleCuisine(cuisine.id)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <div className="text-2xl mb-2">{cuisine.icon}</div>
                <div className="text-xs text-center font-medium">
                  {language === 'ar' ? cuisine.nameAr : cuisine.name}
                </div>
                {cuisine.selected && (
                  <div className="mt-1">
                    <Check className="h-4 w-4 text-primary" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Action Buttons */}
      <div className="sticky bottom-[72px] bg-white border-t p-4 flex justify-between">
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline">
              {t("reset")}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>{t("resetPreferences")}</AlertDialogTitle>
              <AlertDialogDescription>
                {t("resetPreferencesWarning")}
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
              <AlertDialogAction 
                onClick={resetPreferences}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                {t("reset")}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
        
        <Button onClick={savePreferences}>
          {t("savePreferences")}
        </Button>
      </div>
      
      <BottomNavigation />
    </div>
  );
}