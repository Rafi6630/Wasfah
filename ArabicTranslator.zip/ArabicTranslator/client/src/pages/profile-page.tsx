import * as React from "react";
import { useI18n } from "@/lib/i18n";
import { 
  ArrowLeft, 
  Settings, 
  PencilLine, 
  Camera,
  ChefHat,
  Users,
  BookmarkCheck,
  LogOut,
  Heart,
  Plus,
  History,
  Share2,
  CalendarDays,
  ShoppingBasket,
  Crown,
  Sparkles,
  Zap
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BottomNavigation } from "@/components/layout/bottom-navigation";
import { LanguageSwitcher } from "@/components/layout/language-switcher";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { RecipeRecommendation } from "@/lib/openai";
import { RoyalButton } from "@/components/ui/royal-button";
import { RoyalCard, RoyalSectionHeader } from "@/components/ui/royal-card";
import { RoyalCrownIcon, CutleryDivider } from "@/components/icons/crown-icon";
import { cn } from "@/lib/utils";

// Mock recipe data
const mockMyRecipes: RecipeRecommendation[] = [
  {
    id: "my1",
    name: "Homemade Shawarma",
    nameAr: "شاورما منزلية",
    matchPercentage: 98,
    cookTime: 45,
    imageUrl: "https://images.unsplash.com/photo-1529006557810-274b9b2fc783",
    difficulty: "Medium",
    servings: "4",
    calories: 450,
    rating: 4.5,
    ingredients: [],
    instructions: [],
    description: "Delicious homemade shawarma with authentic spices and fresh vegetables.",
    descriptionAr: "شاورما منزلية لذيذة مع التوابل الأصلية والخضروات الطازجة.",
    nutritionFacts: {
      calories: 450,
      fat: "20g",
      carbs: "30g",
      protein: "25g",
      sodium: "600mg",
      fiber: "3g"
    },
    cuisine: "Arabic",
    cuisineAr: "عربي",
    category: "Main",
    categoryAr: "طبق رئيسي"
  },
  {
    id: "my2",
    name: "Lebanese Tabbouleh",
    nameAr: "تبولة لبنانية",
    matchPercentage: 95,
    cookTime: 20,
    imageUrl: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd",
    difficulty: "Easy",
    servings: "6",
    calories: 120,
    rating: 4.8,
    ingredients: [],
    instructions: [],
    description: "Fresh and tangy Lebanese salad with parsley, mint, and bulgur.",
    descriptionAr: "سلطة لبنانية منعشة وحامضة مع البقدونس والنعناع والبرغل.",
    nutritionFacts: {
      calories: 120,
      fat: "7g",
      carbs: "15g",
      protein: "3g",
      sodium: "300mg",
      fiber: "4g"
    },
    cuisine: "Lebanese",
    cuisineAr: "لبناني",
    category: "Salad",
    categoryAr: "سلطة"
  }
];

// Mock saved recipes
const mockSavedRecipes: RecipeRecommendation[] = [
  {
    id: "saved1",
    name: "Homemade Kunafa",
    nameAr: "كنافة منزلية",
    matchPercentage: 85,
    cookTime: 60,
    imageUrl: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e",
    difficulty: "Medium",
    servings: "8",
    calories: 350,
    rating: 4.9,
    ingredients: [],
    instructions: [],
    description: "Sweet and crunchy kunafa with cheese filling and sugar syrup.",
    descriptionAr: "كنافة حلوة ومقرمشة محشوة بالجبن مع شراب السكر.",
    nutritionFacts: {
      calories: 350,
      fat: "15g",
      carbs: "50g",
      protein: "5g",
      sodium: "200mg",
      fiber: "1g"
    },
    cuisine: "Arabic",
    cuisineAr: "عربي",
    category: "Dessert",
    categoryAr: "حلويات"
  },
  {
    id: "saved2",
    name: "Hummus with Tahini",
    nameAr: "حمص بطحينة",
    matchPercentage: 92,
    cookTime: 15,
    imageUrl: "https://images.unsplash.com/photo-1577906096429-f73c2c312435",
    difficulty: "Easy",
    servings: "6",
    calories: 180,
    rating: 4.6,
    ingredients: [],
    instructions: [],
    description: "Creamy hummus with tahini, olive oil, and lemon juice.",
    descriptionAr: "حمص كريمي مع الطحينة وزيت الزيتون وعصير الليمون.",
    nutritionFacts: {
      calories: 180,
      fat: "10g",
      carbs: "20g",
      protein: "8g",
      sodium: "350mg",
      fiber: "5g"
    },
    cuisine: "Arabic",
    cuisineAr: "عربي",
    category: "Appetizer",
    categoryAr: "مقبلات"
  },
  {
    id: "saved3",
    name: "Falafel Wrap",
    nameAr: "لفائف الفلافل",
    matchPercentage: 88,
    cookTime: 30,
    imageUrl: "https://images.unsplash.com/photo-1553030942-031e695deec9",
    difficulty: "Medium",
    servings: "4",
    calories: 320,
    rating: 4.4,
    ingredients: [],
    instructions: [],
    description: "Crispy falafel wrapped in warm pita with tahini sauce and vegetables.",
    descriptionAr: "فلافل مقرمشة ملفوفة في خبز بيتا دافئ مع صلصة الطحينة والخضروات.",
    nutritionFacts: {
      calories: 320,
      fat: "12g",
      carbs: "45g",
      protein: "10g",
      sodium: "500mg",
      fiber: "6g"
    },
    cuisine: "Arabic",
    cuisineAr: "عربي",
    category: "Main",
    categoryAr: "طبق رئيسي"
  }
];

// Mock followers data
interface Follower {
  id: number;
  name: string;
  username: string;
  avatarUrl: string | null;
  isFollowing: boolean;
}

const mockFollowers: Follower[] = [
  {
    id: 1,
    name: "Fatima Ahmad",
    username: "fatima_cooks",
    avatarUrl: "https://randomuser.me/api/portraits/women/65.jpg",
    isFollowing: true
  },
  {
    id: 2,
    name: "Omar Khan",
    username: "chef_omar",
    avatarUrl: "https://randomuser.me/api/portraits/men/42.jpg",
    isFollowing: false
  },
  {
    id: 3,
    name: "Layla Mohammed",
    username: "laylacuisine",
    avatarUrl: "https://randomuser.me/api/portraits/women/33.jpg",
    isFollowing: true
  },
  {
    id: 4,
    name: "Ibrahim Ali",
    username: "ibrahimchef",
    avatarUrl: null,
    isFollowing: false
  }
];

interface RecipeCardProps {
  recipe: RecipeRecommendation;
  onClick: (recipeId: string) => void;
}

const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onClick }) => {
  const { isRtl, t } = useI18n();
  
  return (
    <div
      className="royal-card overflow-hidden cursor-pointer group hover:scale-[1.03] transition-all duration-300"
      onClick={() => onClick(recipe.id)}
    >
      <div className="relative h-36 w-full overflow-hidden">
        <img
          src={recipe.imageUrl}
          alt={isRtl ? recipe.nameAr : recipe.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        
        {/* Recipe difficulty badge */}
        <div className="absolute top-2 left-2 flex items-center bg-white/80 backdrop-blur-sm 
                      px-2 py-1 rounded-full text-xs text-royal-purple border border-royal-gold/20">
          <ChefHat className="h-3 w-3 mr-1 text-royal-purple" />
          <span>{recipe.difficulty}</span>
        </div>
        
        {/* Rating badge */}
        <div className="absolute top-2 right-2 flex items-center bg-white/80 backdrop-blur-sm 
                      px-2 py-1 rounded-full text-xs text-royal-purple border border-royal-gold/20">
          <span className="mr-1">{recipe.rating}</span>
          <svg className="h-3 w-3 text-royal-gold fill-current" viewBox="0 0 24 24">
            <path d="M12 17.27l4.15 2.51c.76.46 1.69-.22 1.49-1.08l-1.1-4.72 3.67-3.18c.67-.58.31-1.68-.57-1.75l-4.83-.41-1.89-4.46c-.34-.81-1.5-.81-1.84 0L9.19 8.63l-4.83.41c-.88.07-1.24 1.17-.57 1.75l3.67 3.18-1.1 4.72c-.2.86.73 1.54 1.49 1.08l4.15-2.5z" />
          </svg>
        </div>
        
        {/* Royal crown overlay on hover */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-royal-purple/10">
          <RoyalCrownIcon className="h-10 w-10 text-royal-gold/80 animate-crown-float" />
        </div>
      </div>
      
      <div className="p-3 bg-white border-t border-royal-gold/10">
        <h3 className="font-medium truncate text-royal-purple-dark">
          {isRtl ? recipe.nameAr : recipe.name}
        </h3>
        
        <div className="flex items-center justify-between mt-2 text-xs text-royal-purple-dark/60">
          <div className="flex items-center gap-1">
            <Crown className="h-3 w-3 text-royal-gold" />
            <span>{recipe.cuisine}</span>
          </div>
          
          <div className="flex items-center">
            <span>{recipe.cookTime} {t("min")}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function ProfilePage() {
  const { t, isRtl } = useI18n();
  const [location, setLocation] = useLocation();
  const { user, logoutMutation, isPremium } = useAuth();
  
  // Check if we have a tab parameter in the URL
  const params = new URLSearchParams(window.location.search);
  const tabParam = params.get('tab');
  const initialTab = tabParam === 'saved' ? 'saved' : 'myRecipes';
  
  const [activeTab, setActiveTab] = React.useState<string>(initialTab);
  const [myRecipes, setMyRecipes] = React.useState<RecipeRecommendation[]>(mockMyRecipes);
  const [savedRecipes, setSavedRecipes] = React.useState<RecipeRecommendation[]>(mockSavedRecipes);
  const [followers, setFollowers] = React.useState<Follower[]>(mockFollowers);
  
  const recipesCount = myRecipes.length;
  const followersCount = followers.length;
  const followingCount = followers.filter(f => f.isFollowing).length;
  
  const handleGoBack = () => {
    setLocation("/home");
  };
  
  const handleSettings = () => {
    setLocation("/settings");
  };
  
  const handleEditProfile = () => {
    setLocation("/edit-profile");
  };
  
  const handleRecipeClick = (recipeId: string) => {
    setLocation(`/recipe/${recipeId}`);
  };
  
  const handleCreateRecipe = () => {
    setLocation("/create-recipe");
  };
  
  const handleCookingHistory = () => {
    setLocation("/cooking-history");
  };
  
  const handleSharedRecipes = () => {
    setLocation("/shared-recipes");
  };
  
  const handleMealPlanning = () => {
    setLocation("/meal-planning");
  };
  
  const handleShoppingList = () => {
    setLocation("/shopping-list");
  };
  
  const handleFollowToggle = (followerId: number) => {
    setFollowers(followers.map(follower => 
      follower.id === followerId 
        ? { ...follower, isFollowing: !follower.isFollowing } 
        : follower
    ));
  };
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        setLocation("/auth");
      }
    });
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-gradient-to-b from-royal-purple/5 to-white shadow-xl overflow-hidden pb-20">
      {/* Header */}
      <div className="relative flex items-center justify-center py-4 px-6 bg-gradient-to-r from-royal-purple-dark to-royal-purple text-white">
        <button 
          className="absolute left-2 p-2 text-white/80 hover:text-white transition-colors"
          onClick={handleGoBack}
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="font-semibold flex items-center gap-2">
          <RoyalCrownIcon className="h-5 w-5 text-royal-gold" />
          <span>{t("profile")}</span>
        </h1>
        <div className="absolute right-2 flex items-center gap-2">
          <LanguageSwitcher />
          <button
            className="p-2 text-white/80 hover:text-white transition-colors"
            onClick={handleSettings}
          >
            <Settings className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      {/* Profile Header */}
      <div className="royal-card-premium mt-6 mx-4">
        <div className="royal-card-premium-inner p-5">
          <div className="flex items-center">
            {/* Profile Image */}
            <div className="relative">
              <div className="w-24 h-24 rounded-full overflow-hidden royal-card-premium p-0.5">
                <div className="bg-white w-full h-full rounded-full overflow-hidden">
                  {user?.avatar_url ? (
                    <img
                      src={user.avatar_url}
                      alt={user.name || ""}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-royal-purple text-white font-bold text-2xl">
                      {user?.name ? user.name.charAt(0).toUpperCase() : "U"}
                    </div>
                  )}
                </div>
              </div>
              
              <div 
                className="absolute bottom-0 right-0 w-8 h-8 flex items-center justify-center bg-royal-gold text-royal-purple-dark rounded-full border-2 border-white cursor-pointer royal-glow"
                onClick={handleEditProfile}
              >
                <Camera className="h-4 w-4" />
              </div>
            </div>
            
            {/* Profile Info */}
            <div className="ml-5 flex-1">
              <h2 className="text-xl font-bold text-royal-purple-dark">
                {user?.name || user?.email}
              </h2>
              <p className="text-sm text-royal-purple-dark/60">
                @{user?.email?.split('@')[0] || user?.email}
              </p>
              
              {/* Subscription Badge */}
              <div className="mt-2">
                {isPremium ? (
                  <div className="inline-flex items-center gap-1.5 bg-royal-gold/10 text-royal-gold border border-royal-gold/20 px-2.5 py-1 rounded-full text-xs">
                    <Crown className="h-3.5 w-3.5" />
                    <span className="font-medium">{t("premiumMember")}</span>
                    <Sparkles className="h-3 w-3 animate-pulse" />
                  </div>
                ) : (
                  <div 
                    className="inline-flex items-center gap-1.5 bg-slate-100 text-slate-600 border border-slate-200 px-2.5 py-1 rounded-full text-xs cursor-pointer hover:bg-slate-200 transition-colors"
                    onClick={() => setLocation("/subscription")}
                  >
                    <Zap className="h-3.5 w-3.5" />
                    <span className="font-medium">{t("upgradeToPremium")}</span>
                  </div>
                )}
              </div>
              
              <div className="flex items-center mt-3 gap-2">
                <RoyalButton 
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  leftIcon={<PencilLine className="h-4 w-4" />}
                  onClick={handleEditProfile}
                >
                  {t("editProfile")}
                </RoyalButton>
                
                <RoyalButton 
                  variant="ghost" 
                  size="sm"
                  className="text-red-500"
                  leftIcon={<LogOut className="h-4 w-4" />}
                  onClick={handleLogout}
                >
                  {t("logout")}
                </RoyalButton>
              </div>
            </div>
          </div>
          
          {/* Divider */}
          <div className="my-5 text-royal-gold/30">
            <CutleryDivider />
          </div>
          
          {/* Stats Bar */}
          <div className="flex items-center justify-around">
            <div className="text-center group">
              <div className="font-bold text-xl text-royal-purple-dark group-hover:text-royal-purple transition-colors">
                {recipesCount}
              </div>
              <div className="text-xs text-royal-purple-dark/60 group-hover:text-royal-purple-dark transition-colors">
                {t("recipes")}
              </div>
            </div>
            
            <div className="text-center relative group">
              <span className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Sparkles className="h-3 w-3 text-royal-gold" />
              </span>
              <div className="font-bold text-xl text-royal-purple-dark group-hover:text-royal-purple transition-colors">
                {followersCount}
              </div>
              <div className="text-xs text-royal-purple-dark/60 group-hover:text-royal-purple-dark transition-colors">
                {t("followers")}
              </div>
            </div>
            
            <div className="text-center group">
              <div className="font-bold text-xl text-royal-purple-dark group-hover:text-royal-purple transition-colors">
                {followingCount}
              </div>
              <div className="text-xs text-royal-purple-dark/60 group-hover:text-royal-purple-dark transition-colors">
                {t("following")}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Additional Profile Actions */}
      <div className="mx-4 mt-4 mb-6">
        <RoyalSectionHeader 
          title={t("quickActions") || "Quick Actions"} 
          subtitle={t("manageYourCulinaryJourney") || "Manage your culinary journey"}
        />
        
        <div className="grid grid-cols-5 gap-2">
          <button 
            className="group flex flex-col items-center justify-center py-4 rounded-md bg-white border border-royal-gold/20 hover:border-royal-gold/50 transition-colors"
            onClick={handleCreateRecipe}
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-royal-purple/5 group-hover:bg-royal-purple/10 transition-colors">
              <Plus className="h-5 w-5 text-royal-purple" />
            </div>
            <span className="text-xs font-medium text-royal-purple-dark mt-2">{t("createRecipe")}</span>
          </button>
          
          <button 
            className="group flex flex-col items-center justify-center py-4 rounded-md bg-white border border-royal-gold/20 hover:border-royal-gold/50 transition-colors"
            onClick={handleSharedRecipes}
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-royal-purple/5 group-hover:bg-royal-purple/10 transition-colors">
              <Share2 className="h-5 w-5 text-royal-purple" />
            </div>
            <span className="text-xs font-medium text-royal-purple-dark mt-2">{t("shared")}</span>
          </button>
          
          <button 
            className="group flex flex-col items-center justify-center py-4 rounded-md bg-white border border-royal-gold/20 hover:border-royal-gold/50 transition-colors"
            onClick={handleCookingHistory}
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-royal-purple/5 group-hover:bg-royal-purple/10 transition-colors">
              <History className="h-5 w-5 text-royal-purple" />
            </div>
            <span className="text-xs font-medium text-royal-purple-dark mt-2">{t("history")}</span>
          </button>
          
          <button 
            className="group flex flex-col items-center justify-center py-4 rounded-md bg-white border border-royal-gold/20 hover:border-royal-gold/50 transition-colors"
            onClick={handleMealPlanning}
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-royal-purple/5 group-hover:bg-royal-purple/10 transition-colors">
              <CalendarDays className="h-5 w-5 text-royal-purple" />
            </div>
            <span className="text-xs font-medium text-royal-purple-dark mt-2">{t("meals")}</span>
          </button>
          
          <button 
            className="group flex flex-col items-center justify-center py-4 rounded-md bg-white border border-royal-gold/20 hover:border-royal-gold/50 transition-colors"
            onClick={handleShoppingList}
          >
            <div className="w-10 h-10 rounded-full flex items-center justify-center bg-royal-purple/5 group-hover:bg-royal-purple/10 transition-colors">
              <ShoppingBasket className="h-5 w-5 text-royal-purple" />
            </div>
            <span className="text-xs font-medium text-royal-purple-dark mt-2">{t("shopping")}</span>
          </button>
        </div>
      </div>
      
      {/* Tabs */}
      <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full px-4">
        <TabsList className="w-full justify-evenly bg-transparent p-0 border-b border-royal-gold/20">
          <TabsTrigger 
            value="myRecipes" 
            className="flex-1 rounded-none border-0 border-b-2 data-[state=active]:border-royal-gold border-transparent
                       text-royal-purple-dark/60 data-[state=active]:text-royal-purple data-[state=active]:bg-transparent 
                       hover:text-royal-purple-dark relative py-3"
          >
            <div className="flex items-center gap-1.5">
              <ChefHat className="h-4 w-4" />
              <span>{t("myRecipes")}</span>
            </div>
            {activeTab === "myRecipes" && (
              <span className="absolute -bottom-0.5 left-1/2 transform -translate-x-1/2">
                <RoyalCrownIcon className="h-3 w-3 text-royal-gold animate-crown-float" />
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger 
            value="saved" 
            className="flex-1 rounded-none border-0 border-b-2 data-[state=active]:border-royal-gold border-transparent
                       text-royal-purple-dark/60 data-[state=active]:text-royal-purple data-[state=active]:bg-transparent 
                       hover:text-royal-purple-dark relative py-3"
          >
            <div className="flex items-center gap-1.5">
              <BookmarkCheck className="h-4 w-4 text-royal-purple" />
              <span>{t("saved")}</span>
            </div>
            {activeTab === "saved" && (
              <span className="absolute -bottom-0.5 left-1/2 transform -translate-x-1/2">
                <RoyalCrownIcon className="h-3 w-3 text-royal-gold animate-crown-float" />
              </span>
            )}
          </TabsTrigger>
          
          <TabsTrigger 
            value="followers" 
            className="flex-1 rounded-none border-0 border-b-2 data-[state=active]:border-royal-gold border-transparent
                       text-royal-purple-dark/60 data-[state=active]:text-royal-purple data-[state=active]:bg-transparent 
                       hover:text-royal-purple-dark relative py-3"
          >
            <div className="flex items-center gap-1.5">
              <Users className="h-4 w-4" />
              <span>{t("followers")}</span>
            </div>
            {activeTab === "followers" && (
              <span className="absolute -bottom-0.5 left-1/2 transform -translate-x-1/2">
                <RoyalCrownIcon className="h-3 w-3 text-royal-gold animate-crown-float" />
              </span>
            )}
          </TabsTrigger>
        </TabsList>
        
        {/* My Recipes Tab */}
        <TabsContent value="myRecipes" className="p-4">
          {myRecipes.length === 0 ? (
            <div className="royal-card-premium p-0.5 rounded-lg">
              <div className="royal-card-premium-inner text-center py-12 px-6 rounded-lg">
                <div className="w-20 h-20 mx-auto bg-royal-purple/5 rounded-full flex items-center justify-center">
                  <ChefHat className="h-10 w-10 text-royal-purple/40" />
                </div>
                <h3 className="mt-6 font-playfair text-xl text-royal-purple-dark">{t("noCreatedRecipes")}</h3>
                <p className="text-sm text-royal-purple-dark/60 mt-2 max-w-xs mx-auto">{t("startCreatingRecipes")}</p>
                
                <RoyalButton 
                  className="mt-6"
                  leftIcon={<Plus className="h-4 w-4" />}
                  onClick={handleCreateRecipe}
                >
                  {t("createRecipe")}
                </RoyalButton>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {myRecipes.map(recipe => (
                <RecipeCard 
                  key={recipe.id} 
                  recipe={recipe} 
                  onClick={handleRecipeClick} 
                />
              ))}
              
              <div 
                className="royal-card flex flex-col items-center justify-center p-6 h-full cursor-pointer group border-2 border-dashed border-royal-gold/20 hover:border-royal-gold/40 bg-royal-purple/5 hover:bg-royal-purple/10 transition-all"
                onClick={handleCreateRecipe}
              >
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center group-hover:royal-glow transition-all">
                  <Plus className="h-8 w-8 text-royal-purple-dark group-hover:text-royal-purple transition-colors" />
                </div>
                <span className="mt-4 font-medium text-royal-purple-dark group-hover:text-royal-purple transition-colors">{t("createNewRecipe")}</span>
              </div>
            </div>
          )}
        </TabsContent>
        
        {/* Saved Tab */}
        <TabsContent value="saved" className="p-4">
          {savedRecipes.length === 0 ? (
            <div className="royal-card-premium p-0.5 rounded-lg">
              <div className="royal-card-premium-inner text-center py-12 px-6 rounded-lg">
                <div className="w-24 h-24 mx-auto bg-royal-purple/10 rounded-full flex items-center justify-center relative">
                  <BookmarkCheck className="h-12 w-12 text-royal-purple" />
                  <div className="absolute -top-1 -right-1 bg-royal-gold/20 w-8 h-8 rounded-full flex items-center justify-center">
                    <Heart className="h-4 w-4 text-royal-gold" />
                  </div>
                </div>
                <h3 className="mt-6 font-playfair text-2xl text-royal-purple-dark">{t("noSavedRecipes")}</h3>
                <p className="text-sm text-royal-purple-dark/70 mt-3 max-w-xs mx-auto">{t("startSavingRecipes")}</p>
                
                <RoyalButton 
                  className="mt-7 px-8"
                  leftIcon={<Heart className="h-4 w-4" />}
                  onClick={() => setLocation("/home")}
                >
                  {t("exploreRecipes")}
                </RoyalButton>
              </div>
            </div>
          ) : (
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <Heart className="h-5 w-5 text-royal-gold mr-2" />
                  <h3 className="font-medium text-lg text-royal-purple">
                    {t("saved")}
                  </h3>
                </div>
                <div className="h-0.5 flex-1 mx-4 bg-gradient-to-r from-royal-gold/30 to-transparent rounded-full"></div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {savedRecipes.map(recipe => (
                  <RecipeCard 
                    key={recipe.id} 
                    recipe={recipe} 
                    onClick={handleRecipeClick} 
                  />
                ))}
              </div>
            </div>
          )}
        </TabsContent>
        
        {/* Followers Tab */}
        <TabsContent value="followers" className="p-4">
          {followers.length === 0 ? (
            <div className="royal-card-premium p-0.5 rounded-lg">
              <div className="royal-card-premium-inner text-center py-12 px-6 rounded-lg">
                <div className="w-20 h-20 mx-auto bg-royal-purple/5 rounded-full flex items-center justify-center">
                  <Users className="h-10 w-10 text-royal-purple/40" />
                </div>
                <h3 className="mt-6 font-playfair text-xl text-royal-purple-dark">{t("noFollowers")}</h3>
                <p className="text-sm text-royal-purple-dark/60 mt-2 max-w-xs mx-auto">{t("shareRecipesToGetFollowers")}</p>
                
                <RoyalButton 
                  className="mt-6"
                  leftIcon={<Share2 className="h-4 w-4" />}
                  onClick={() => setLocation("/shared-recipes")}
                >
                  {t("manageSharedRecipes")}
                </RoyalButton>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {followers.map(follower => (
                <div key={follower.id} className="royal-card p-0 overflow-hidden">
                  <div className="p-3 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 royal-card-premium p-0.5 rounded-full">
                        <div className="w-full h-full rounded-full overflow-hidden">
                          {follower.avatarUrl ? (
                            <img 
                              src={follower.avatarUrl} 
                              alt={follower.name} 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-royal-purple text-white font-bold rounded-full">
                              {follower.name.charAt(0).toUpperCase()}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div>
                        <h3 className="font-medium text-royal-purple-dark flex items-center">
                          {follower.name}
                          {follower.isFollowing && (
                            <span className="ml-1.5">
                              <Crown className="h-3 w-3 text-royal-gold" />
                            </span>
                          )}
                        </h3>
                        <p className="text-xs text-royal-purple-dark/60">@{follower.username}</p>
                      </div>
                    </div>
                    
                    <RoyalButton
                      variant={follower.isFollowing ? "primary" : "outline"}
                      size="sm"
                      onClick={() => handleFollowToggle(follower.id)}
                    >
                      {follower.isFollowing ? (
                        <>
                          <Users className="h-3 w-3 mr-1" />
                          {t("following")}
                        </>
                      ) : (
                        <>
                          <Plus className="h-3 w-3 mr-1" />
                          {t("follow")}
                        </>
                      )}
                    </RoyalButton>
                  </div>
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Bottom Navigation */}
      <BottomNavigation />
    </div>
  );
}