// Script to create an admin user
const { pool } = require('../dist/server/db');
const { scrypt, randomBytes } = require('crypto');
const { promisify } = require('util');

const scryptAsync = promisify(scrypt);

async function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const buf = await scryptAsync(password, salt, 64);
  return `${buf.toString('hex')}.${salt}`;
}

async function createAdminUser() {
  // Admin user details
  const email = 'admin@royalgourmet.ai';
  const password = 'adminpass123'; // In production, this should be more secure
  const hashedPassword = await hashPassword(password);
  
  try {
    // Check if admin user already exists
    const checkResult = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    
    if (checkResult.rows.length > 0) {
      console.log('Admin user already exists');
      
      // Update the user to have admin role
      await pool.query(
        'UPDATE users SET role = $1 WHERE email = $2',
        ['ADMIN', email]
      );
      
      console.log('Updated user to have admin role');
    } else {
      // Create new admin user
      await pool.query(
        `INSERT INTO users (
          email, 
          password, 
          name, 
          username,
          role, 
          status
        ) VALUES ($1, $2, $3, $4, $5, $6)`,
        [
          email,
          hashedPassword,
          'Admin User',
          'admin',
          'ADMIN',
          'ACTIVE'
        ]
      );
      
      console.log('Created new admin user with email:', email);
    }
    
    console.log('Admin credentials:');
    console.log('Email:', email);
    console.log('Password:', password);
    
  } catch (error) {
    console.error('Error creating admin user:', error);
  } finally {
    // Close the database connection
    await pool.end();
  }
}

createAdminUser();