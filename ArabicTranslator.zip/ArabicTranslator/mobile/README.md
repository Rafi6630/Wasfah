# Wasfah AI Mobile App

A React Native mobile application for Wasfah AI, a bilingual (Arabic/English) AI-powered recipe recommendation platform.

## Features

- AI-driven recipe recommendations based on available ingredients, preferences, and dietary restrictions
- Smart Pantry management with expiration tracking and camera integration
- Meal planning and shopping list generation
- Global cuisine exploration with country-specific recipes
- Comprehensive recipe details with nutrition facts and cooking instructions
- User profile management with favorite recipes and cooking history
- Full Arabic language support with RTL interface

## Technology Stack

- React Native (Expo)
- React Navigation for routing
- React Query for data fetching
- React Native Paper for UI components
- OpenAI integration for recipe suggestions
- Camera and image recognition for ingredient scanning
- Multi-language support with i18n
- Secure authentication system

## Getting Started

### Prerequisites

- Node.js (v18+)
- npm or yarn
- Expo CLI

### Installation

1. Clone the repository
2. Install dependencies:
   ```
   cd mobile
   npm install
   ```
3. Start the development server:
   ```
   npm start
   ```
4. Follow the instructions to open the app on your device or emulator

## Environment Variables

The app requires the following environment variables:

- `API_URL`: The URL for the backend API
- `OPENAI_API_KEY`: API key for OpenAI services

## Project Structure

- `/src/screens`: Main application screens
- `/src/components`: Reusable UI components
- `/src/hooks`: Custom React hooks
- `/src/utils`: Utility functions and constants
- `/src/assets`: Static assets like images and icons
- `/src/navigation`: Navigation configuration

## Bilingual Support

The app fully supports both English and Arabic languages, with automatic RTL layout for Arabic. Users can switch languages from the settings screen.