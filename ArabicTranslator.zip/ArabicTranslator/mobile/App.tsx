import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { View, Text } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { I18nProvider } from './src/utils/i18n';
import { AuthProvider } from './src/hooks/useAuth';

// Import Screens
import HomeScreen from './src/screens/HomeScreen';
import SmartPantryScreen from './src/screens/SmartPantryScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import FavoritesScreen from './src/screens/FavoritesScreen';

const Tab = createBottomTabNavigator();
const queryClient = new QueryClient();

// Placeholder for not yet implemented screens
const PlaceholderScreen = ({ route }) => (
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text style={{ fontSize: 20 }}>{route.name} Screen Coming Soon</Text>
  </View>
);

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <I18nProvider>
        <AuthProvider>
          <SafeAreaProvider>
            <NavigationContainer>
              <Tab.Navigator
                screenOptions={({ route }) => ({
                  tabBarIcon: ({ focused, color, size }) => {
                    let iconName;

                    if (route.name === 'Home') {
                      iconName = 'home';
                    } else if (route.name === 'SmartPantry') {
                      iconName = 'package';
                    } else if (route.name === 'Favorites') {
                      iconName = 'heart';
                    } else if (route.name === 'Profile') {
                      iconName = 'user';
                    }

                    return <Feather name={iconName} size={size} color={color} />;
                  },
                  tabBarActiveTintColor: '#10b981',
                  tabBarInactiveTintColor: 'gray',
                  headerShown: false,
                })}
              >
                <Tab.Screen 
                  name="Home" 
                  component={HomeScreen} 
                  options={{ title: 'Home' }} 
                />
                <Tab.Screen 
                  name="SmartPantry" 
                  component={SmartPantryScreen} 
                  options={{ title: 'Smart Pantry' }} 
                />
                <Tab.Screen 
                  name="Favorites" 
                  component={FavoritesScreen} 
                  options={{ title: 'Favorites' }} 
                />
                <Tab.Screen 
                  name="Profile" 
                  component={ProfileScreen} 
                  options={{ title: 'Profile' }} 
                />
              </Tab.Navigator>
            </NavigationContainer>
            <StatusBar style="auto" />
          </SafeAreaProvider>
        </AuthProvider>
      </I18nProvider>
    </QueryClientProvider>
  );
}