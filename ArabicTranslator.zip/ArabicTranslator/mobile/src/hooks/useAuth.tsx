import React, { createContext, ReactNode, useContext, useState, useEffect } from 'react';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { API_URL } from '../utils/constants';

// User type
interface User {
  id: number;
  email: string;
  username: string;
  avatarUrl?: string;
  createdAt?: string;
  updatedAt?: string;
}

// Login data type
interface LoginData {
  email: string;
  password: string;
}

// Register data type
interface RegisterData {
  username: string;
  email: string;
  password: string;
}

// Profile update data type
interface ProfileUpdateData {
  username?: string;
  email?: string;
  avatarUrl?: string;
}

// Auth context type
interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  error: Error | null;
  login: (data: LoginData) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: ProfileUpdateData) => Promise<void>;
}

// Create context
const AuthContext = createContext<AuthContextType | null>(null);

// API request helper
async function apiRequest(method: string, endpoint: string, data?: any) {
  const token = await AsyncStorage.getItem('token');
  
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };
  
  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }
  
  const options: RequestInit = {
    method,
    headers,
    credentials: 'include',
  };
  
  if (data) {
    options.body = JSON.stringify(data);
  }
  
  const response = await fetch(`${API_URL}${endpoint}`, options);
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || 'An error occurred');
  }
  
  try {
    return await response.json();
  } catch (e) {
    return null; // For endpoints that don't return JSON
  }
}

// Auth provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  const [error, setError] = useState<Error | null>(null);
  
  // Get user data
  const { 
    data: user, 
    isLoading,
    refetch: refetchUser 
  } = useQuery({
    queryKey: ['user'],
    queryFn: async () => {
      try {
        return await apiRequest('GET', '/api/user');
      } catch (error) {
        console.error('Error fetching user', error);
        return null;
      }
    },
    initialData: null,
  });
  
  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginData) => {
      return await apiRequest('POST', '/api/login', credentials);
    },
    onSuccess: async (data) => {
      if (data.token) {
        await AsyncStorage.setItem('token', data.token);
      }
      queryClient.setQueryData(['user'], data.user);
      setError(null);
    },
    onError: (error: Error) => {
      setError(error);
      Alert.alert('Login Failed', error.message);
    },
  });
  
  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (userData: RegisterData) => {
      return await apiRequest('POST', '/api/register', userData);
    },
    onSuccess: async (data) => {
      if (data.token) {
        await AsyncStorage.setItem('token', data.token);
      }
      queryClient.setQueryData(['user'], data.user);
      setError(null);
    },
    onError: (error: Error) => {
      setError(error);
      Alert.alert('Registration Failed', error.message);
    },
  });
  
  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest('POST', '/api/logout');
    },
    onSuccess: async () => {
      await AsyncStorage.removeItem('token');
      queryClient.setQueryData(['user'], null);
      setError(null);
    },
    onError: (error: Error) => {
      setError(error);
      Alert.alert('Logout Failed', error.message);
    },
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (profileData: ProfileUpdateData) => {
      return await apiRequest('PATCH', '/api/user', profileData);
    },
    onSuccess: (updatedUser: User) => {
      queryClient.setQueryData(['user'], updatedUser);
      setError(null);
      Alert.alert('Success', 'Profile updated successfully');
    },
    onError: (error: Error) => {
      setError(error);
      Alert.alert('Update Failed', error.message);
    },
  });
  
  // Check for token on load
  useEffect(() => {
    const checkToken = async () => {
      const token = await AsyncStorage.getItem('token');
      if (token && !user) {
        refetchUser();
      }
    };
    
    checkToken();
  }, []);
  
  // Auth context value
  const authContextValue: AuthContextType = {
    user,
    isLoading,
    error,
    login: loginMutation.mutateAsync,
    register: registerMutation.mutateAsync,
    logout: logoutMutation.mutateAsync,
    updateProfile: updateProfileMutation.mutateAsync,
  };
  
  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
}

// Hook to use the auth context
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}