import { DefaultTheme } from 'react-native-paper';
import { COLORS, FONT_SIZES, SPACING, BORDER_RADIUS } from './constants';

export const lightTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: COLORS.primary,
    primaryContainer: COLORS.primaryLight,
    secondary: COLORS.secondary,
    secondaryContainer: COLORS.secondaryLight,
    background: COLORS.background,
    surface: COLORS.white,
    error: COLORS.error,
    onBackground: COLORS.black,
    onSurface: COLORS.black,
    text: COLORS.black,
    disabled: COLORS.gray,
    placeholder: COLORS.gray,
    backdrop: '#00000050',
    notification: COLORS.error,
  },
  roundness: BORDER_RADIUS.md,
  animation: {
    scale: 1.0,
  },
};

export const darkTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    primary: COLORS.primary,
    primaryContainer: COLORS.primaryDark,
    secondary: COLORS.secondary,
    secondaryContainer: COLORS.secondaryDark,
    background: '#121212',
    surface: '#1E1E1E',
    error: COLORS.error,
    onBackground: COLORS.white,
    onSurface: COLORS.white,
    text: COLORS.white,
    disabled: COLORS.grayDark,
    placeholder: COLORS.grayDark,
    backdrop: '#00000080',
    notification: COLORS.error,
  },
  roundness: BORDER_RADIUS.md,
  animation: {
    scale: 1.0,
  },
};

// Common text styles
export const textStyles = {
  heading1: {
    fontSize: FONT_SIZES['3xl'],
    fontWeight: 'bold',
    lineHeight: FONT_SIZES['3xl'] * 1.2,
  },
  heading2: {
    fontSize: FONT_SIZES['2xl'],
    fontWeight: 'bold',
    lineHeight: FONT_SIZES['2xl'] * 1.2,
  },
  heading3: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    lineHeight: FONT_SIZES.xl * 1.2,
  },
  subtitle1: {
    fontSize: FONT_SIZES.lg,
    fontWeight: '500',
    lineHeight: FONT_SIZES.lg * 1.3,
  },
  subtitle2: {
    fontSize: FONT_SIZES.md,
    fontWeight: '500',
    lineHeight: FONT_SIZES.md * 1.3,
  },
  body1: {
    fontSize: FONT_SIZES.md,
    lineHeight: FONT_SIZES.md * 1.5,
  },
  body2: {
    fontSize: FONT_SIZES.sm,
    lineHeight: FONT_SIZES.sm * 1.5,
  },
  caption: {
    fontSize: FONT_SIZES.xs,
    lineHeight: FONT_SIZES.xs * 1.5,
  },
  button: {
    fontSize: FONT_SIZES.md,
    fontWeight: '500',
    textTransform: 'uppercase',
  },
};

// Common layout styles
export const layoutStyles = {
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  contentContainer: {
    padding: SPACING.md,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  spaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.md,
    marginVertical: SPACING.sm,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
};