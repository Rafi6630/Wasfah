import React, { createContext, useContext, useState, ReactNode } from 'react';
import { I18nManager } from 'react-native';

interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

const translations: Translations = {
  en: {
    // General
    appName: 'Wasfah AI',
    home: 'Home',
    profile: 'Profile',
    smartPantry: 'Smart Pantry',
    favorites: 'Favorites',
    settings: 'Settings',
    
    // Auth
    login: 'Login',
    register: 'Register',
    email: 'Email',
    password: 'Password',
    username: 'Username',
    forgotPassword: 'Forgot Password?',
    
    // Home page
    welcomeBack: 'Welcome Back',
    findPerfectRecipes: 'Find Perfect Recipes',
    personalizedSuggestions: 'Get personalized recipes based on your preferences',
    popularRecipes: 'Popular Recipes',
    countries: 'Countries',
    seeAll: 'See All',
    createAndShare: 'Create and Share',
    createRecipe: 'Create Recipe',
    quickAccess: 'Quick Access',
    myFavorites: 'My Favorites',
    advancedFilters: 'Advanced Filters',
    addIngredients: 'Add Ingredients',
    
    // Smart Pantry
    addNewItem: 'Add New Item',
    scanBarcode: 'Scan Barcode',
    comingSoon: 'Coming Soon',
    itemName: 'Item Name',
    enterItemName: 'Enter item name',
    quantity: 'Quantity',
    unit: 'Unit',
    selectUnit: 'Select unit',
    none: 'None',
    grams: 'Grams (g)',
    kilograms: 'Kilograms (kg)',
    milliliters: 'Milliliters (ml)',
    liters: 'Liters (l)',
    pieces: 'Pieces',
    cups: 'Cups',
    tablespoons: 'Tablespoons',
    teaspoons: 'Teaspoons',
    category: 'Category',
    selectCategory: 'Select category',
    expirationDate: 'Expiration Date',
    notes: 'Notes',
    optionalNotes: 'Optional notes',
    cancel: 'Cancel',
    addItem: 'Add Item',
    editItem: 'Edit Item',
    update: 'Update',
    delete: 'Delete',
    confirmDelete: 'Confirm Delete',
    deleteItemConfirm: 'Are you sure you want to delete this item?',
    sortBy: 'Sort By',
    expiringSoon: 'Expiring Soon',
    recentlyAdded: 'Recently Added',
    alphabetical: 'Alphabetical',
    categoryFilter: 'Category Filter',
    allCategories: 'All Categories',
    addToShoppingList: 'Add to Shopping List',
    takePhoto: 'Take Photo',
    scanInvoice: 'Scan Invoice',
    scanning: 'Scanning',
    imageProcessed: 'Image Processed',
    itemDetailsExtracted: 'Item details extracted from image',
    invoiceScanned: 'Invoice Scanned',
    itemsExtractedFromInvoice: 'Items extracted from invoice',
    addedViaScan: 'Added via scan',
    
    // Profile
    followers: 'Followers',
    following: 'Following',
    recipes: 'Recipes',
    editProfile: 'Edit Profile',
    yourRecipes: 'Your Recipes',
    likedRecipes: 'Liked Recipes',
    savedRecipes: 'Saved Recipes',
    cookingHistory: 'Cooking History',
    sharedRecipes: 'Shared Recipes',
    mealPlanning: 'Meal Planning',
    shoppingList: 'Shopping List',
    logOut: 'Log Out',
    
    // Recipe details
    ingredients: 'Ingredients',
    instructions: 'Instructions',
    cookTime: 'Cook Time',
    servings: 'Servings',
    difficulty: 'Difficulty',
    calories: 'Calories',
    nutritionFacts: 'Nutrition Facts',
    relatedRecipes: 'Related Recipes',
    reviews: 'Reviews',
    
    // Meal planning
    mealPlan: 'Meal Plan',
    addMeal: 'Add Meal',
    breakfast: 'Breakfast',
    lunch: 'Lunch',
    dinner: 'Dinner',
    snack: 'Snack',
    generateShoppingList: 'Generate Shopping List',
  },
  ar: {
    // General
    appName: 'وصفة AI',
    home: 'الرئيسية',
    profile: 'الملف الشخصي',
    smartPantry: 'المخزن الذكي',
    favorites: 'المفضلة',
    settings: 'الإعدادات',
    
    // Auth
    login: 'تسجيل الدخول',
    register: 'إنشاء حساب',
    email: 'البريد الإلكتروني',
    password: 'كلمة المرور',
    username: 'اسم المستخدم',
    forgotPassword: 'نسيت كلمة المرور؟',
    
    // Home page
    welcomeBack: 'مرحبًا بعودتك',
    findPerfectRecipes: 'ابحث عن وصفات مثالية',
    personalizedSuggestions: 'احصل على وصفات مخصصة بناءً على تفضيلاتك',
    popularRecipes: 'وصفات شائعة',
    countries: 'البلدان',
    seeAll: 'عرض الكل',
    createAndShare: 'إنشاء ومشاركة',
    createRecipe: 'إنشاء وصفة',
    quickAccess: 'وصول سريع',
    myFavorites: 'المفضلة',
    advancedFilters: 'تصفية متقدم',
    addIngredients: 'إضافة مكونات',
    
    // Smart Pantry
    addNewItem: 'إضافة عنصر جديد',
    scanBarcode: 'مسح الباركود',
    comingSoon: 'قريباً',
    itemName: 'اسم العنصر',
    enterItemName: 'أدخل اسم العنصر',
    quantity: 'الكمية',
    unit: 'الوحدة',
    selectUnit: 'اختر الوحدة',
    none: 'بدون',
    grams: 'جرام (جم)',
    kilograms: 'كيلوجرام (كجم)',
    milliliters: 'ملليلتر (مل)',
    liters: 'لتر (ل)',
    pieces: 'قطع',
    cups: 'أكواب',
    tablespoons: 'ملاعق كبيرة',
    teaspoons: 'ملاعق صغيرة',
    category: 'الفئة',
    selectCategory: 'اختر الفئة',
    expirationDate: 'تاريخ انتهاء الصلاحية',
    notes: 'ملاحظات',
    optionalNotes: 'ملاحظات اختيارية',
    cancel: 'إلغاء',
    addItem: 'إضافة عنصر',
    editItem: 'تعديل العنصر',
    update: 'تحديث',
    delete: 'حذف',
    confirmDelete: 'تأكيد الحذف',
    deleteItemConfirm: 'هل أنت متأكد من رغبتك في حذف هذا العنصر؟',
    sortBy: 'الترتيب حسب',
    expiringSoon: 'ينتهي قريبًا',
    recentlyAdded: 'أضيف مؤخرًا',
    alphabetical: 'أبجدي',
    categoryFilter: 'تصفية حسب الفئة',
    allCategories: 'جميع الفئات',
    addToShoppingList: 'إضافة إلى قائمة التسوق',
    takePhoto: 'التقاط صورة',
    scanInvoice: 'مسح الفاتورة',
    scanning: 'جاري المسح',
    imageProcessed: 'تمت معالجة الصورة',
    itemDetailsExtracted: 'تم استخراج تفاصيل العنصر من الصورة',
    invoiceScanned: 'تم مسح الفاتورة',
    itemsExtractedFromInvoice: 'تم استخراج العناصر من الفاتورة',
    addedViaScan: 'تمت الإضافة عن طريق المسح',
    
    // Profile
    followers: 'المتابعين',
    following: 'يتابع',
    recipes: 'وصفات',
    editProfile: 'تعديل الملف',
    yourRecipes: 'وصفاتك',
    likedRecipes: 'الوصفات المعجبة',
    savedRecipes: 'الوصفات المحفوظة',
    cookingHistory: 'سجل الطبخ',
    sharedRecipes: 'الوصفات المشاركة',
    mealPlanning: 'تخطيط الوجبات',
    shoppingList: 'قائمة التسوق',
    logOut: 'تسجيل الخروج',
    
    // Recipe details
    ingredients: 'المكونات',
    instructions: 'التعليمات',
    cookTime: 'وقت الطهي',
    servings: 'الحصص',
    difficulty: 'الصعوبة',
    calories: 'السعرات الحرارية',
    nutritionFacts: 'الحقائق الغذائية',
    relatedRecipes: 'وصفات ذات صلة',
    reviews: 'التقييمات',
    
    // Meal planning
    mealPlan: 'خطة الوجبات',
    addMeal: 'إضافة وجبة',
    breakfast: 'الإفطار',
    lunch: 'الغداء',
    dinner: 'العشاء',
    snack: 'وجبة خفيفة',
    generateShoppingList: 'إنشاء قائمة التسوق',
  }
};

interface I18nContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
  isRtl: boolean;
}

const I18nContext = createContext<I18nContextType | null>(null);

export function I18nProvider(props: { children: ReactNode }) {
  const [language, setLanguage] = useState('en');
  
  const changeLanguage = (lang: string) => {
    setLanguage(lang);
    const isRtl = lang === 'ar';
    I18nManager.forceRTL(isRtl);
  };
  
  const t = (key: string): string => {
    return translations[language]?.[key] || key;
  };
  
  const contextValue: I18nContextType = {
    language,
    setLanguage: changeLanguage,
    t,
    isRtl: language === 'ar'
  };
  
  return (
    <I18nContext.Provider value={contextValue}>
      {props.children}
    </I18nContext.Provider>
  );
}

export function useI18n(): I18nContextType {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}