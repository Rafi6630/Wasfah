// API URL - replace with your actual API base URL
export const API_URL = 'https://wasfah-api.example.com';

// App theme colors
export const COLORS = {
  primary: '#10b981', // Primary green color
  primaryDark: '#059669',
  primaryLight: '#d1fae5',
  secondary: '#6366f1', // Purple for accents
  secondaryDark: '#4f46e5',
  secondaryLight: '#e0e7ff',
  background: '#f9fafb',
  white: '#ffffff',
  black: '#111827',
  gray: '#9ca3af',
  grayLight: '#e5e7eb',
  grayDark: '#4b5563',
  error: '#ef4444',
  success: '#22c55e',
  warning: '#f59e0b',
  info: '#3b82f6',
};

// Font sizes
export const FONT_SIZES = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  '2xl': 24,
  '3xl': 30,
  '4xl': 36,
};

// Spacing - used for margins, paddings, etc.
export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  '2xl': 48,
  '3xl': 64,
};

// Border radius
export const BORDER_RADIUS = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  '2xl': 24,
  full: 9999,
};

// Animation durations
export const ANIMATION = {
  fast: 200,
  normal: 300,
  slow: 500,
};

// Common patterns
export const REGEX = {
  email: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
  password: /^.{8,}$/, // At least 8 characters
  username: /^[a-zA-Z0-9_]{3,20}$/, // 3-20 alphanumeric chars + underscore
};

// Categorized food ingredients
export const FOOD_CATEGORIES = [
  {
    id: 'meat',
    name: 'Meat',
    nameAr: 'لحوم',
    icon: 'drumstick-bite',
  },
  {
    id: 'vegetables',
    name: 'Vegetables',
    nameAr: 'خضروات',
    icon: 'carrot',
  },
  {
    id: 'fruits',
    name: 'Fruits',
    nameAr: 'فواكه',
    icon: 'apple-alt',
  },
  {
    id: 'grains',
    name: 'Grains & Pasta',
    nameAr: 'حبوب ومعكرونة',
    icon: 'bread-slice',
  },
  {
    id: 'dairy',
    name: 'Dairy',
    nameAr: 'ألبان',
    icon: 'cheese',
  },
  {
    id: 'spices',
    name: 'Spices & Herbs',
    nameAr: 'توابل وأعشاب',
    icon: 'mortar-pestle',
  },
  {
    id: 'oils',
    name: 'Oils & Fats',
    nameAr: 'زيوت ودهون',
    icon: 'oil-can',
  },
  {
    id: 'nuts',
    name: 'Nuts & Seeds',
    nameAr: 'مكسرات وبذور',
    icon: 'seedling',
  },
  {
    id: 'seafood',
    name: 'Seafood',
    nameAr: 'مأكولات بحرية',
    icon: 'fish',
  },
  {
    id: 'sweets',
    name: 'Sweets',
    nameAr: 'حلويات',
    icon: 'cookie',
  },
  {
    id: 'beverages',
    name: 'Beverages',
    nameAr: 'مشروبات',
    icon: 'coffee',
  },
  {
    id: 'other',
    name: 'Other',
    nameAr: 'أخرى',
    icon: 'utensils',
  },
];

// Global cuisine options
export const CUISINE_OPTIONS = [
  { value: 'levant', label: 'Levant', labelAr: 'بلاد الشام' },
  { value: 'italian', label: 'Italian', labelAr: 'إيطالي' },
  { value: 'mexican', label: 'Mexican', labelAr: 'مكسيكي' },
  { value: 'chinese', label: 'Chinese', labelAr: 'صيني' },
  { value: 'indian', label: 'Indian', labelAr: 'هندي' },
  { value: 'japanese', label: 'Japanese', labelAr: 'ياباني' },
  { value: 'thai', label: 'Thai', labelAr: 'تايلاندي' },
  { value: 'turkish', label: 'Turkish', labelAr: 'تركي' },
  { value: 'syrian', label: 'Syrian', labelAr: 'سوري' },
  { value: 'iraqi', label: 'Iraqi', labelAr: 'عراقي' },
  { value: 'yemeni', label: 'Yemeni', labelAr: 'يمني' },
  { value: 'american', label: 'American', labelAr: 'أمريكي' },
  { value: 'moroccan', label: 'Moroccan', labelAr: 'مغربي' },
  { value: 'lebanese', label: 'Lebanese', labelAr: 'لبناني' },
  { value: 'german', label: 'German', labelAr: 'ألماني' },
];