import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  FlatList,
} from 'react-native';
import {
  Button,
  Avatar,
  Card,
  Title,
  Divider,
  ActivityIndicator,
  IconButton,
  Menu,
  Tabs,
  Tab,
} from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { useI18n } from '../utils/i18n';
import { useAuth } from '../hooks/useAuth';
import { COLORS, SPACING } from '../utils/constants';
import { layoutStyles, textStyles } from '../utils/theme';

// Mock data for user recipes
const mockUserRecipes = [
  {
    id: 'user1',
    name: 'Homemade Shawarma',
    nameAr: 'شاورما منزلية',
    cookTime: 45,
    imageUrl: 'https://images.unsplash.com/photo-1529006557810-274b9b2fc783',
    difficulty: 'Medium',
    rating: 4.5,
  },
  {
    id: 'user2',
    name: 'Kunafa with Cream',
    nameAr: 'كنافة بالقشطة',
    cookTime: 60,
    imageUrl: 'https://images.unsplash.com/photo-1562801441-42a1731a52fa',
    difficulty: 'Hard',
    rating: 4.8,
  },
];

// Mock follower data
const mockFollowers = [
  { id: 1, name: 'Ahmed', username: 'ahmed123', avatarUrl: null, isFollowing: true },
  { id: 2, name: 'Sara', username: 'sara_cook', avatarUrl: null, isFollowing: false },
  { id: 3, name: 'Mohammed', username: 'mo_kitchen', avatarUrl: null, isFollowing: true },
];

const ProfileScreen = () => {
  const { t, isRtl, language } = useI18n();
  const { user, logout } = useAuth();
  const navigation = useNavigation();
  const [activeTab, setActiveTab] = useState('myRecipes');
  const [menuVisible, setMenuVisible] = useState(false);
  
  // If not logged in, show login screen
  if (!user) {
    return (
      <View style={styles.authContainer}>
        <Text style={styles.authTitle}>{t('login')}</Text>
        <Button 
          mode="contained" 
          style={styles.authButton}
          onPress={() => navigation.navigate('Auth')}
        >
          {t('login')} / {t('register')}
        </Button>
      </View>
    );
  }
  
  const handleCreateRecipe = () => {
    navigation.navigate('CreateRecipe');
  };
  
  const handleSharedRecipes = () => {
    navigation.navigate('SharedRecipes');
  };
  
  const handleCookingHistory = () => {
    navigation.navigate('CookingHistory');
  };
  
  const handleMealPlanning = () => {
    navigation.navigate('MealPlanning');
  };
  
  const handleShoppingList = () => {
    navigation.navigate('ShoppingList');
  };
  
  const handleEditProfile = () => {
    navigation.navigate('EditProfile');
  };
  
  const handleSettings = () => {
    navigation.navigate('Settings');
  };
  
  const handleLogout = async () => {
    try {
      await logout();
      // Navigation will be handled by auth state change
    } catch (error) {
      console.error('Logout error:', error);
    }
  };
  
  const handleFollowToggle = (followerId) => {
    // Toggle follow status (would make API call in real implementation)
    console.log('Toggle follow for:', followerId);
  };
  
  const handleRecipePress = (recipeId) => {
    navigation.navigate('RecipeDetail', { recipeId });
  };
  
  const renderRecipeItem = ({ item }) => (
    <TouchableOpacity
      style={styles.recipeCard}
      activeOpacity={0.7}
      onPress={() => handleRecipePress(item.id)}
    >
      <Card>
        <Card.Cover source={{ uri: item.imageUrl }} style={styles.recipeImage} />
        <View style={styles.ratingContainer}>
          <Text style={styles.ratingText}>{item.rating}</Text>
          <Feather name="star" size={12} color="#FFD700" />
        </View>
        <Card.Content style={styles.recipeContent}>
          <Title style={styles.recipeTitle}>
            {language === 'ar' ? item.nameAr : item.name}
          </Title>
          <View style={styles.recipeMetadata}>
            <View style={styles.metadataItem}>
              <Feather name="clock" size={14} color={COLORS.gray} />
              <Text style={styles.metadataText}>{item.cookTime} min</Text>
            </View>
            <View style={styles.metadataItem}>
              <Feather name="award" size={14} color={COLORS.gray} />
              <Text style={styles.metadataText}>{item.difficulty}</Text>
            </View>
          </View>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );
  
  const renderFollowerItem = ({ item }) => (
    <View style={styles.followerItem}>
      <View style={styles.followerInfo}>
        <Avatar.Text 
          size={40} 
          label={item.name.charAt(0)} 
          backgroundColor={COLORS.primaryLight}
          color={COLORS.primary}
        />
        <View style={styles.followerName}>
          <Text style={styles.followerNameText}>{item.name}</Text>
          <Text style={styles.followerUsername}>@{item.username}</Text>
        </View>
      </View>
      <Button
        mode={item.isFollowing ? "outlined" : "contained"}
        compact
        onPress={() => handleFollowToggle(item.id)}
        style={item.isFollowing ? styles.unfollowButton : styles.followButton}
      >
        {item.isFollowing ? t('following') : t('follow')}
      </Button>
    </View>
  );
  
  return (
    <ScrollView style={styles.container}>
      {/* Header with back button and settings */}
      <View style={styles.header}>
        <IconButton
          icon="arrow-left"
          iconColor={COLORS.black}
          size={24}
          onPress={() => navigation.goBack()}
          style={[styles.headerButton, isRtl && styles.flipHorizontal]}
        />
        <View style={styles.headerActions}>
          <IconButton
            icon="cog"
            iconColor={COLORS.black}
            size={24}
            onPress={handleSettings}
            style={styles.headerButton}
          />
          <Menu
            visible={menuVisible}
            onDismiss={() => setMenuVisible(false)}
            anchor={
              <IconButton
                icon="dots-vertical"
                iconColor={COLORS.black}
                size={24}
                onPress={() => setMenuVisible(true)}
                style={styles.headerButton}
              />
            }
          >
            <Menu.Item 
              onPress={handleEditProfile} 
              title={t('editProfile')} 
              leadingIcon="pencil"
            />
            <Menu.Item 
              onPress={handleLogout} 
              title={t('logOut')} 
              leadingIcon="logout"
            />
          </Menu>
        </View>
      </View>
      
      {/* Profile Info */}
      <View style={styles.profileContainer}>
        <View style={styles.profileHeader}>
          <Avatar.Image 
            size={80} 
            source={user.avatarUrl ? { uri: user.avatarUrl } : require('../assets/default-avatar.png')} 
          />
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{user.username}</Text>
            <Text style={styles.profileEmail}>{user.email}</Text>
            
            <Button
              mode="outlined"
              compact
              icon="pencil"
              style={styles.editProfileButton}
              onPress={handleEditProfile}
            >
              {t('editProfile')}
            </Button>
          </View>
        </View>
        
        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>120</Text>
            <Text style={styles.statLabel}>{t('recipes')}</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>45</Text>
            <Text style={styles.statLabel}>{t('followers')}</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>65</Text>
            <Text style={styles.statLabel}>{t('following')}</Text>
          </View>
        </View>
      </View>
      
      {/* Profile Actions Grid */}
      <View style={styles.actionsGrid}>
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={handleCreateRecipe}
        >
          <Feather name="plus" size={20} color={COLORS.black} />
          <Text style={styles.actionText}>{t('createRecipe')}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={handleSharedRecipes}
        >
          <Feather name="share-2" size={20} color={COLORS.black} />
          <Text style={styles.actionText}>{t('sharedRecipes')}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={handleCookingHistory}
        >
          <Feather name="clock" size={20} color={COLORS.black} />
          <Text style={styles.actionText}>{t('cookingHistory')}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={handleMealPlanning}
        >
          <Feather name="calendar" size={20} color={COLORS.black} />
          <Text style={styles.actionText}>{t('mealPlanning')}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.actionButton}
          onPress={handleShoppingList}
        >
          <Feather name="shopping-bag" size={20} color={COLORS.black} />
          <Text style={styles.actionText}>{t('shoppingList')}</Text>
        </TouchableOpacity>
      </View>
      
      {/* Content Tabs */}
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'myRecipes' && styles.activeTab]}
          onPress={() => setActiveTab('myRecipes')}
        >
          <Text 
            style={[styles.tabText, activeTab === 'myRecipes' && styles.activeTabText]}
          >
            {t('yourRecipes')}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'favorites' && styles.activeTab]}
          onPress={() => setActiveTab('favorites')}
        >
          <Text 
            style={[styles.tabText, activeTab === 'favorites' && styles.activeTabText]}
          >
            {t('myFavorites')}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'followers' && styles.activeTab]}
          onPress={() => setActiveTab('followers')}
        >
          <Text 
            style={[styles.tabText, activeTab === 'followers' && styles.activeTabText]}
          >
            {t('followers')}
          </Text>
        </TouchableOpacity>
      </View>
      
      {/* Tab Content */}
      <View style={styles.tabContent}>
        {activeTab === 'myRecipes' && (
          <FlatList
            data={mockUserRecipes}
            renderItem={renderRecipeItem}
            keyExtractor={(item) => item.id}
            numColumns={2}
            contentContainerStyle={styles.recipesGrid}
            columnWrapperStyle={styles.recipesRow}
            scrollEnabled={false}
          />
        )}
        
        {activeTab === 'favorites' && (
          <FlatList
            data={mockUserRecipes}
            renderItem={renderRecipeItem}
            keyExtractor={(item) => item.id}
            numColumns={2}
            contentContainerStyle={styles.recipesGrid}
            columnWrapperStyle={styles.recipesRow}
            scrollEnabled={false}
          />
        )}
        
        {activeTab === 'followers' && (
          <FlatList
            data={mockFollowers}
            renderItem={renderFollowerItem}
            keyExtractor={(item) => item.id.toString()}
            scrollEnabled={false}
            ItemSeparatorComponent={() => <Divider style={styles.divider} />}
          />
        )}
      </View>
      
      {/* Spacer for bottom tab navigation */}
      <View style={styles.bottomSpacer} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.sm,
    paddingTop: SPACING.md,
  },
  headerButton: {
    margin: 0,
  },
  flipHorizontal: {
    transform: [{ scaleX: -1 }],
  },
  headerActions: {
    flexDirection: 'row',
  },
  profileContainer: {
    padding: SPACING.md,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileInfo: {
    marginLeft: SPACING.md,
    flex: 1,
  },
  profileName: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.black,
  },
  profileEmail: {
    fontSize: 14,
    color: COLORS.gray,
    marginBottom: SPACING.sm,
  },
  editProfileButton: {
    alignSelf: 'flex-start',
    marginTop: SPACING.xs,
    borderColor: COLORS.primary,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: SPACING.md,
    marginTop: SPACING.md,
    backgroundColor: COLORS.white,
    borderRadius: 8,
    shadowColor: COLORS.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.black,
  },
  statLabel: {
    fontSize: 14,
    color: COLORS.gray,
  },
  statDivider: {
    width: 1,
    height: '70%',
    backgroundColor: COLORS.grayLight,
  },
  actionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: COLORS.grayLight,
    marginTop: SPACING.md,
  },
  actionButton: {
    width: '20%',
    alignItems: 'center',
    padding: SPACING.sm,
    borderRightWidth: 1,
    borderColor: COLORS.grayLight,
  },
  actionText: {
    fontSize: 10,
    marginTop: 4,
    textAlign: 'center',
  },
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderColor: COLORS.grayLight,
    marginTop: SPACING.md,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: SPACING.sm,
  },
  activeTab: {
    borderBottomWidth: 2,
    borderColor: COLORS.primary,
  },
  tabText: {
    color: COLORS.gray,
    fontWeight: '500',
  },
  activeTabText: {
    color: COLORS.primary,
    fontWeight: 'bold',
  },
  tabContent: {
    padding: SPACING.md,
  },
  recipesGrid: {
    paddingBottom: SPACING.md,
  },
  recipesRow: {
    justifyContent: 'space-between',
    marginBottom: SPACING.md,
  },
  recipeCard: {
    width: '48%',
    marginBottom: SPACING.md,
  },
  recipeImage: {
    height: 120,
  },
  ratingContainer: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 12,
    marginRight: 2,
  },
  recipeContent: {
    padding: 8,
  },
  recipeTitle: {
    fontSize: 14,
    marginBottom: 4,
  },
  recipeMetadata: {
    flexDirection: 'row',
    marginTop: 2,
  },
  metadataItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: SPACING.sm,
  },
  metadataText: {
    fontSize: 12,
    color: COLORS.gray,
    marginLeft: 4,
  },
  followerItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: SPACING.sm,
  },
  followerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  followerName: {
    marginLeft: SPACING.sm,
  },
  followerNameText: {
    fontWeight: '500',
    fontSize: 16,
  },
  followerUsername: {
    color: COLORS.gray,
    fontSize: 14,
  },
  followButton: {
    height: 36,
  },
  unfollowButton: {
    height: 36,
    borderColor: COLORS.primary,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.grayLight,
  },
  bottomSpacer: {
    height: 60,
  },
  authContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xl,
  },
  authTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: SPACING.lg,
    textAlign: 'center',
  },
  authButton: {
    width: '100%',
  },
});

export default ProfileScreen;