import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  ScrollView,
} from 'react-native';
import {
  Button,
  Card,
  Title,
  Searchbar,
  Chip,
  IconButton,
  ActivityIndicator,
  Divider,
} from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { useI18n } from '../utils/i18n';
import { useAuth } from '../hooks/useAuth';
import { COLORS, SPACING } from '../utils/constants';
import { layoutStyles, textStyles } from '../utils/theme';

// Mock favorite recipes data
const mockFavoriteRecipes = [
  {
    id: 'fav1',
    name: 'Kabsa Rice with Chicken',
    nameAr: 'كبسة أرز بالدجاج',
    cookTime: 60,
    imageUrl: 'https://images.unsplash.com/photo-1631292784640-2b24d224ee5c',
    difficulty: 'Medium',
    cuisine: 'Saudi',
    rating: 4.8,
    categories: ['Main Dish', 'Rice', 'Meat'],
  },
  {
    id: 'fav2',
    name: 'Hummus with Tahini',
    nameAr: 'حمص بالطحينة',
    cookTime: 20,
    imageUrl: 'https://images.unsplash.com/photo-1640984756059-7303641db7bc',
    difficulty: 'Easy',
    cuisine: 'Levant',
    rating: 4.5,
    categories: ['Appetizer', 'Vegetarian'],
  },
  {
    id: 'fav3',
    name: 'Tabbouleh Salad',
    nameAr: 'سلطة تبولة',
    cookTime: 25,
    imageUrl: 'https://images.unsplash.com/photo-1637949385762-4c2c0bc9f42b',
    difficulty: 'Easy',
    cuisine: 'Lebanese',
    rating: 4.7,
    categories: ['Salad', 'Vegetarian', 'Healthy'],
  },
  {
    id: 'fav4',
    name: 'Baklava',
    nameAr: 'بقلاوة',
    cookTime: 90,
    imageUrl: 'https://images.unsplash.com/photo-1585540083814-590ba6ab3a8e',
    difficulty: 'Hard',
    cuisine: 'Turkish',
    rating: 4.9,
    categories: ['Dessert', 'Sweet'],
  },
];

const FavoritesScreen = () => {
  const { t, isRtl, language } = useI18n();
  const { user } = useAuth();
  const navigation = useNavigation();
  const [searchQuery, setSearchQuery] = React.useState('');
  const [selectedCategories, setSelectedCategories] = React.useState<string[]>([]);
  
  // Filter favorites based on search and category filters
  const filteredFavorites = mockFavoriteRecipes.filter(recipe => {
    const nameMatches = (language === 'ar' ? recipe.nameAr : recipe.name)
      .toLowerCase()
      .includes(searchQuery.toLowerCase());
    
    const categoryMatches = selectedCategories.length === 0 || 
      recipe.categories.some(category => selectedCategories.includes(category));
    
    return nameMatches && categoryMatches;
  });
  
  // Get all categories from recipes
  const allCategories = Array.from(
    new Set(mockFavoriteRecipes.flatMap(recipe => recipe.categories))
  ).sort();
  
  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };
  
  const clearFilters = () => {
    setSelectedCategories([]);
    setSearchQuery('');
  };
  
  const handleRecipePress = (recipeId: string) => {
    navigation.navigate('RecipeDetail', { recipeId });
  };
  
  const handleRemoveFavorite = (recipeId: string) => {
    // In a real app, this would call an API to remove the recipe from favorites
    // For now, we'll just show an alert
    alert(`${t('removedFromFavorites')}: ${recipeId}`);
  };
  
  const renderRecipeItem = ({ item }) => {
    const recipeTitle = language === 'ar' ? item.nameAr : item.name;
    
    return (
      <Card style={styles.recipeCard} mode="outlined">
        <TouchableOpacity
          activeOpacity={0.9}
          onPress={() => handleRecipePress(item.id)}
        >
          <Card.Cover source={{ uri: item.imageUrl }} style={styles.cardImage} />
          
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingText}>{item.rating}</Text>
            <Feather name="star" size={12} color="#FFD700" />
          </View>
          
          <IconButton
            icon="heart"
            iconColor={COLORS.error}
            size={20}
            style={styles.favoriteButton}
            onPress={() => handleRemoveFavorite(item.id)}
          />
          
          <Card.Content style={styles.cardContent}>
            <Title style={styles.cardTitle}>{recipeTitle}</Title>
            
            <View style={styles.cardMeta}>
              <View style={styles.metaItem}>
                <Feather name="clock" size={14} color={COLORS.gray} />
                <Text style={styles.metaText}>{item.cookTime} min</Text>
              </View>
              
              <View style={styles.metaItem}>
                <Feather name="award" size={14} color={COLORS.gray} />
                <Text style={styles.metaText}>{item.difficulty}</Text>
              </View>
            </View>
            
            <View style={styles.cardCategories}>
              {item.categories.slice(0, 2).map((category, index) => (
                <Chip
                  key={index}
                  style={styles.categoryChip}
                  textStyle={styles.categoryChipText}
                  onPress={() => toggleCategory(category)}
                >
                  {category}
                </Chip>
              ))}
              {item.categories.length > 2 && (
                <Text style={styles.moreCategories}>+{item.categories.length - 2}</Text>
              )}
            </View>
          </Card.Content>
        </TouchableOpacity>
      </Card>
    );
  };
  
  // Login check
  if (!user) {
    return (
      <View style={styles.authContainer}>
        <Text style={styles.authTitle}>{t('loginToViewFavorites')}</Text>
        <Button 
          mode="contained" 
          style={styles.authButton}
          onPress={() => navigation.navigate('Auth')}
        >
          {t('login')} / {t('register')}
        </Button>
      </View>
    );
  }
  
  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t('favorites')}</Text>
      </View>
      
      {/* Search */}
      <View style={styles.searchContainer}>
        <Searchbar
          placeholder={t('searchFavorites')}
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchbar}
          iconColor={COLORS.gray}
        />
      </View>
      
      {/* Category filters */}
      <View style={styles.filtersContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.filtersScrollContent}
        >
          {allCategories.map((category) => (
            <Chip
              key={category}
              selected={selectedCategories.includes(category)}
              onPress={() => toggleCategory(category)}
              style={styles.filterChip}
              showSelectedOverlay
            >
              {category}
            </Chip>
          ))}
        </ScrollView>
        
        {(searchQuery || selectedCategories.length > 0) && (
          <Button 
            onPress={clearFilters}
            compact
            mode="text"
            style={styles.clearButton}
          >
            {t('clearFilters')}
          </Button>
        )}
      </View>
      
      {/* Recipe List */}
      <FlatList
        data={filteredFavorites}
        renderItem={renderRecipeItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.recipesList}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Feather name="heart" size={64} color={COLORS.grayLight} />
            <Text style={styles.emptyTitle}>
              {searchQuery || selectedCategories.length > 0
                ? t('noMatchingFavorites')
                : t('noFavorites')}
            </Text>
            <Text style={styles.emptyText}>
              {searchQuery || selectedCategories.length > 0
                ? t('tryAdjustingFilters')
                : t('exploreAndSaveFavorites')}
            </Text>
            <Button
              mode="contained"
              style={styles.exploreButton}
              onPress={() => navigation.navigate('Home')}
            >
              {t('exploreRecipes')}
            </Button>
          </View>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingHorizontal: SPACING.md,
    paddingTop: SPACING.xl,
    paddingBottom: SPACING.sm,
    backgroundColor: COLORS.white,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.black,
  },
  searchContainer: {
    padding: SPACING.md,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.grayLight,
  },
  searchbar: {
    elevation: 0,
    backgroundColor: COLORS.grayLight,
  },
  filtersContainer: {
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.grayLight,
    paddingBottom: SPACING.sm,
  },
  filtersScrollContent: {
    paddingHorizontal: SPACING.md,
  },
  filterChip: {
    marginRight: SPACING.xs,
    marginBottom: SPACING.xs,
  },
  clearButton: {
    alignSelf: 'flex-end',
    marginRight: SPACING.md,
    marginTop: SPACING.xs,
  },
  recipesList: {
    padding: SPACING.md,
    paddingBottom: 80, // For bottom nav
  },
  recipeCard: {
    marginBottom: SPACING.md,
    overflow: 'hidden',
  },
  cardImage: {
    height: 160,
  },
  ratingContainer: {
    position: 'absolute',
    top: 8,
    left: 8,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 12,
    marginRight: 2,
  },
  favoriteButton: {
    position: 'absolute',
    top: 0,
    right: 0,
    backgroundColor: 'rgba(255,255,255,0.8)',
    borderRadius: 20,
    margin: 4,
  },
  cardContent: {
    padding: SPACING.sm,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  cardMeta: {
    flexDirection: 'row',
    marginVertical: 4,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: SPACING.md,
  },
  metaText: {
    fontSize: 12,
    color: COLORS.gray,
    marginLeft: 4,
  },
  cardCategories: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 4,
    alignItems: 'center',
  },
  categoryChip: {
    marginRight: 4,
    marginBottom: 4,
    height: 24,
  },
  categoryChipText: {
    fontSize: 10,
  },
  moreCategories: {
    fontSize: 10,
    color: COLORS.gray,
  },
  emptyContainer: {
    padding: SPACING.xl,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: SPACING.md,
    marginBottom: SPACING.xs,
    textAlign: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: COLORS.gray,
    textAlign: 'center',
    marginBottom: SPACING.lg,
  },
  exploreButton: {
    marginTop: SPACING.md,
  },
  authContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: SPACING.xl,
  },
  authTitle: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: SPACING.lg,
  },
  authButton: {
    marginTop: SPACING.md,
  },
});

export default FavoritesScreen;