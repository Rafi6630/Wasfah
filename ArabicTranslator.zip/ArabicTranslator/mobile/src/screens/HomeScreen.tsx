import React, { useState } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  StyleSheet, 
  TouchableOpacity, 
  Image,
  FlatList,
} from 'react-native';
import { 
  Button, 
  Searchbar, 
  Card, 
  Title, 
  Paragraph,
  Chip,
  Divider,
} from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { Feather } from '@expo/vector-icons';
import { useQuery } from '@tanstack/react-query';
import { useI18n } from '../utils/i18n';
import { useAuth } from '../hooks/useAuth';
import { COLORS, SPACING, CUISINE_OPTIONS } from '../utils/constants';
import { layoutStyles, textStyles } from '../utils/theme';

// Mock functions - replace with actual API calls
const getPopularRecipes = async () => {
  // Simulating API call
  return [
    {
      id: 'recipe1',
      name: 'Kabsa Rice with Chicken',
      nameAr: 'كبسة أرز بالدجاج',
      cookTime: 60,
      imageUrl: 'https://images.unsplash.com/photo-1631292784640-2b24d224ee5c',
      difficulty: 'Medium',
      cuisine: 'Saudi',
      rating: 4.8,
    },
    {
      id: 'recipe2',
      name: 'Hummus with Tahini',
      nameAr: 'حمص بالطحينة',
      cookTime: 20,
      imageUrl: 'https://images.unsplash.com/photo-1640984756059-7303641db7bc',
      difficulty: 'Easy',
      cuisine: 'Levant',
      rating: 4.5,
    },
    {
      id: 'recipe3',
      name: 'Falafel Wrap',
      nameAr: 'لفائف الفلافل',
      cookTime: 30,
      imageUrl: 'https://images.unsplash.com/photo-1550507992-eb63ffee0847',
      difficulty: 'Easy',
      cuisine: 'Levant',
      rating: 4.7,
    },
  ];
};

const getRecommendedRecipes = async () => {
  // Simulating API call with similar data
  return await getPopularRecipes(); // Reusing same mock data for now
};

const HomeScreen = () => {
  const { t, isRtl, language } = useI18n();
  const { user } = useAuth();
  const navigation = useNavigation();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Fetch popular recipes
  const { 
    data: popularRecipes = [], 
    isLoading: isLoadingPopular 
  } = useQuery({
    queryKey: ['popularRecipes'],
    queryFn: getPopularRecipes,
  });
  
  // Fetch recommended recipes
  const { 
    data: recommendedRecipes = [], 
    isLoading: isLoadingRecommended 
  } = useQuery({
    queryKey: ['recommendedRecipes'],
    queryFn: getRecommendedRecipes,
  });
  
  const onSearchQueryChange = (query: string) => {
    setSearchQuery(query);
  };
  
  const handleSearchSubmit = () => {
    // Navigate to search results
    navigation.navigate('Search', { query: searchQuery });
  };
  
  const handleRecipePress = (recipeId: string) => {
    // Navigate to recipe detail
    navigation.navigate('RecipeDetail', { recipeId });
  };
  
  const handleCreateRecipe = () => {
    // Navigate to create recipe
    navigation.navigate('CreateRecipe');
  };
  
  const goToAdvancedFilters = () => {
    // Navigate to advanced filters
    navigation.navigate('Search', { showFilters: true });
  };
  
  const goToCategories = () => {
    // Navigate to categories screen
    navigation.navigate('Categories');
  };
  
  // Recipe card component
  const RecipeCard = ({ recipe }) => (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={() => handleRecipePress(recipe.id)}
      style={styles.recipeCard}
    >
      <Card style={styles.card}>
        <Card.Cover source={{ uri: recipe.imageUrl }} style={styles.cardImage} />
        <View style={styles.ratingContainer}>
          <Text style={styles.ratingText}>{recipe.rating}</Text>
          <Feather name="star" size={12} color="#FFD700" />
        </View>
        <Card.Content style={styles.cardContent}>
          <Title style={styles.cardTitle}>
            {language === 'ar' ? recipe.nameAr : recipe.name}
          </Title>
          <View style={styles.cardMeta}>
            <View style={styles.metaItem}>
              <Feather name="clock" size={14} color={COLORS.gray} />
              <Text style={styles.metaText}>{recipe.cookTime} min</Text>
            </View>
            <View style={styles.metaItem}>
              <Feather name="award" size={14} color={COLORS.gray} />
              <Text style={styles.metaText}>{recipe.difficulty}</Text>
            </View>
          </View>
        </Card.Content>
      </Card>
    </TouchableOpacity>
  );
  
  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      showsVerticalScrollIndicator={false}
    >
      {/* Greeting */}
      <View style={styles.greeting}>
        <Text style={styles.greetingText}>
          {t('welcomeBack')}{user ? `, ${user.username}` : ''}
        </Text>
      </View>
      
      {/* Advanced Filters Section */}
      <View style={styles.filtersSection}>
        <Button
          mode="outlined"
          icon="filter"
          onPress={goToAdvancedFilters}
          style={styles.advancedFilterButton}
        >
          {t('advancedFilters')}
        </Button>
        
        {/* Add Ingredients button (moved from search bar) */}
        <Button
          mode="outlined"
          icon="magnify"
          onPress={() => navigation.navigate('Search')}
          style={styles.addIngredientsButton}
        >
          {t('addIngredients')}
        </Button>
      </View>
      
      {/* Large CTA Button for Find Recipes */}
      <TouchableOpacity
        style={styles.findRecipesButton}
        activeOpacity={0.8}
        onPress={() => navigation.navigate('Search', { results: true })}
      >
        <Feather name="search" size={20} color="#FFF" style={styles.buttonIcon} />
        <Text style={styles.findRecipesText}>{t('findPerfectRecipes')} 🍳</Text>
      </TouchableOpacity>
      <Text style={styles.suggestionSubtext}>
        {t('personalizedSuggestions')}
      </Text>
      
      {/* Create and Share Recipe */}
      <View style={styles.createSection}>
        <Text style={styles.sectionTitle}>{t('createAndShare')}</Text>
        <Button
          mode="contained"
          onPress={handleCreateRecipe}
          style={styles.createButton}
          labelStyle={styles.createButtonLabel}
        >
          {t('createRecipe')}
        </Button>
      </View>
      
      {/* Countries Section */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t('countries')}</Text>
          <TouchableOpacity onPress={goToCategories}>
            <Text style={styles.seeAll}>{t('seeAll')}</Text>
          </TouchableOpacity>
        </View>
        
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.cuisinesScrollView}
          contentContainerStyle={styles.cuisinesContainer}
        >
          {CUISINE_OPTIONS.slice(0, 8).map((cuisine) => (
            <TouchableOpacity
              key={cuisine.value}
              style={styles.cuisineItem}
              onPress={() => navigation.navigate('Search', { cuisine: cuisine.value })}
            >
              <View style={styles.cuisineImageContainer}>
                {/* Placeholder for cuisine images */}
                <View style={styles.cuisinePlaceholder}>
                  <Text style={styles.cuisineEmoji}>🌍</Text>
                </View>
              </View>
              <Text style={styles.cuisineText}>
                {language === 'ar' ? cuisine.labelAr : cuisine.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      
      {/* Popular Recipes */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{t('popularRecipes')}</Text>
          <TouchableOpacity onPress={() => navigation.navigate('PopularRecipes')}>
            <Text style={styles.seeAll}>{t('seeAll')}</Text>
          </TouchableOpacity>
        </View>
        
        {isLoadingPopular ? (
          <View style={styles.loadingContainer}>
            <Text>Loading...</Text>
          </View>
        ) : (
          <FlatList
            data={popularRecipes}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => <RecipeCard recipe={item} />}
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.recipeList}
            contentContainerStyle={styles.recipeListContent}
          />
        )}
      </View>
      
      {/* Quick Access Buttons */}
      <View style={styles.quickAccessSection}>
        <Text style={styles.sectionTitle}>{t('quickAccess')}</Text>
        <View style={styles.quickAccessGrid}>
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('Favorites')}
          >
            <Text style={styles.quickAccessEmoji}>❤️</Text>
            <Text style={styles.quickAccessText}>{t('myFavorites')}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('SmartPantry')}
          >
            <Text style={styles.quickAccessEmoji}>🥫</Text>
            <Text style={styles.quickAccessText}>{t('smartPantry')}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.quickAccessButton}
            onPress={() => navigation.navigate('ShoppingList')}
          >
            <Text style={styles.quickAccessEmoji}>🛒</Text>
            <Text style={styles.quickAccessText}>{t('shoppingList')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  contentContainer: {
    padding: SPACING.md,
    paddingBottom: SPACING['2xl'], // Extra padding at bottom for scrolling
  },
  greeting: {
    marginBottom: SPACING.md,
  },
  greetingText: {
    ...textStyles.heading2,
    color: COLORS.black,
  },
  filtersSection: {
    marginBottom: SPACING.md,
  },
  advancedFilterButton: {
    marginBottom: SPACING.sm,
    borderColor: COLORS.primary,
  },
  addIngredientsButton: {
    borderColor: COLORS.primary,
  },
  findRecipesButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 8,
    padding: SPACING.lg,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: SPACING.md,
  },
  buttonIcon: {
    marginRight: SPACING.sm,
  },
  findRecipesText: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  suggestionSubtext: {
    textAlign: 'center',
    color: COLORS.grayDark,
    fontSize: 14,
    marginBottom: SPACING.lg,
  },
  createSection: {
    backgroundColor: COLORS.white,
    borderRadius: 8,
    padding: SPACING.md,
    marginBottom: SPACING.lg,
  },
  createButton: {
    marginTop: SPACING.sm,
    backgroundColor: COLORS.secondary,
  },
  createButtonLabel: {
    fontSize: 16,
    paddingVertical: 2,
  },
  section: {
    marginBottom: SPACING.lg,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.sm,
  },
  sectionTitle: {
    ...textStyles.heading3,
    color: COLORS.black,
  },
  seeAll: {
    color: COLORS.primary,
    ...textStyles.subtitle2,
  },
  cuisinesScrollView: {
    flexGrow: 0,
  },
  cuisinesContainer: {
    paddingVertical: SPACING.sm,
  },
  cuisineItem: {
    alignItems: 'center',
    marginRight: SPACING.md,
    width: 80,
  },
  cuisineImageContainer: {
    marginBottom: SPACING.xs,
  },
  cuisinePlaceholder: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: COLORS.primaryLight,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cuisineEmoji: {
    fontSize: 24,
  },
  cuisineText: {
    fontSize: 12,
    textAlign: 'center',
    color: COLORS.black,
  },
  loadingContainer: {
    padding: SPACING.md,
    alignItems: 'center',
  },
  recipeList: {
    flexGrow: 0,
  },
  recipeListContent: {
    paddingVertical: SPACING.sm,
  },
  recipeCard: {
    width: 220,
    marginRight: SPACING.md,
  },
  card: {
    overflow: 'hidden',
  },
  cardImage: {
    height: 120,
  },
  ratingContainer: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0,0,0,0.7)',
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  ratingText: {
    color: COLORS.white,
    fontSize: 12,
    marginRight: 2,
  },
  cardContent: {
    padding: SPACING.sm,
  },
  cardTitle: {
    fontSize: 16,
    marginBottom: 4,
  },
  cardMeta: {
    flexDirection: 'row',
    marginTop: 2,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: SPACING.md,
  },
  metaText: {
    fontSize: 12,
    color: COLORS.gray,
    marginLeft: 4,
  },
  quickAccessSection: {
    backgroundColor: COLORS.white,
    borderRadius: 8,
    padding: SPACING.md,
    marginBottom: SPACING.lg,
  },
  quickAccessGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: SPACING.sm,
  },
  quickAccessButton: {
    alignItems: 'center',
    flex: 1,
    padding: SPACING.md,
    borderWidth: 1,
    borderColor: COLORS.grayLight,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  quickAccessEmoji: {
    fontSize: 24,
    marginBottom: SPACING.xs,
  },
  quickAccessText: {
    fontSize: 12,
    textAlign: 'center',
  },
});

export default HomeScreen;