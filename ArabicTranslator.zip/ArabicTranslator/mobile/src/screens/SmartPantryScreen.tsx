import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Alert,
  Platform,
} from 'react-native';
import {
  Button,
  Searchbar,
  Card,
  Title,
  Paragraph,
  IconButton,
  Menu,
  Divider,
  Dialog,
  Portal,
  TextInput,
  List,
  FAB,
  ActivityIndicator,
  Chip,
} from 'react-native-paper';
import { useNavigation } from '@react-navigation/native';
import { Camera } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import { Feather } from '@expo/vector-icons';
import { useI18n } from '../utils/i18n';
import { useAuth } from '../hooks/useAuth';
import { COLORS, SPACING, FOOD_CATEGORIES } from '../utils/constants';
import { layoutStyles, textStyles } from '../utils/theme';

// Mock data for pantry items
const initialItems = [
  {
    id: '1',
    name: 'Tomatoes',
    nameAr: 'طماطم',
    category: 'Vegetables',
    categoryAr: 'خضروات',
    quantity: '5',
    unit: 'pcs',
    expirationDate: new Date(new Date().setDate(new Date().getDate() + 7)),
    addedDate: new Date(),
    notes: 'For pasta sauce',
  },
  {
    id: '2',
    name: 'Chicken Breast',
    nameAr: 'صدور دجاج',
    category: 'Meat',
    categoryAr: 'لحوم',
    quantity: '500',
    unit: 'g',
    expirationDate: new Date(new Date().setDate(new Date().getDate() + 2)),
    addedDate: new Date(),
    notes: '',
  },
  {
    id: '3',
    name: 'Rice',
    nameAr: 'أرز',
    category: 'Grains',
    categoryAr: 'حبوب',
    quantity: '2',
    unit: 'kg',
    expirationDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
    addedDate: new Date(),
    notes: 'Basmati',
  },
  {
    id: '4',
    name: 'Milk',
    nameAr: 'حليب',
    category: 'Dairy',
    categoryAr: 'ألبان',
    quantity: '1',
    unit: 'l',
    expirationDate: new Date(new Date().setDate(new Date().getDate() + 3)),
    addedDate: new Date(new Date().setDate(new Date().getDate() - 2)),
    notes: '',
  },
  {
    id: '5',
    name: 'Olive Oil',
    nameAr: 'زيت زيتون',
    category: 'Oils',
    categoryAr: 'زيوت',
    quantity: '750',
    unit: 'ml',
    expirationDate: new Date(new Date().setMonth(new Date().getMonth() + 12)),
    addedDate: new Date(new Date().setDate(new Date().getDate() - 30)),
    notes: 'Extra virgin',
  },
];

// Interface for form data
interface AddItemFormData {
  name: string;
  quantity: string;
  unit: string;
  category: string;
  expirationDate: string;
  notes: string;
}

// Interface for pantry item
interface PantryItem {
  id: string;
  name: string;
  nameAr: string;
  category: string;
  categoryAr: string;
  quantity: string;
  unit: string;
  expirationDate: Date | null;
  addedDate: Date;
  notes: string;
}

const SmartPantryScreen = () => {
  const { t, isRtl, language } = useI18n();
  const { user } = useAuth();
  const navigation = useNavigation();
  const cameraRef = useRef(null);
  
  // State
  const [items, setItems] = useState<PantryItem[]>(initialItems);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [expirationFilter, setExpirationFilter] = useState<string | null>(null);
  const [sortType, setSortType] = useState<string>('expiringSoon');
  const [addDialogVisible, setAddDialogVisible] = useState(false);
  const [editDialogVisible, setEditDialogVisible] = useState(false);
  const [confirmDeleteVisible, setConfirmDeleteVisible] = useState(false);
  const [filterMenuVisible, setFilterMenuVisible] = useState(false);
  const [sortMenuVisible, setSortMenuVisible] = useState(false);
  const [itemMenuVisible, setItemMenuVisible] = useState<string | null>(null);
  const [formData, setFormData] = useState<AddItemFormData>({
    name: '',
    quantity: '1',
    unit: '',
    category: 'Other',
    expirationDate: '',
    notes: '',
  });
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [cameraPermission, setCameraPermission] = useState<boolean | null>(null);
  const [cameraVisible, setCameraVisible] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  
  // Handler for adding a new item
  const addItem = () => {
    if (!formData.name) {
      Alert.alert(t('error'), t('pleaseEnterItemName'));
      return;
    }
    
    const newItem: PantryItem = {
      id: Math.random().toString(36).substring(2, 9),
      name: formData.name,
      nameAr: formData.name, // In a real app, this would be translated
      category: formData.category,
      categoryAr: formData.category, // In a real app, this would be translated
      quantity: formData.quantity,
      unit: formData.unit,
      expirationDate: formData.expirationDate ? new Date(formData.expirationDate) : null,
      addedDate: new Date(),
      notes: formData.notes,
    };
    
    setItems([...items, newItem]);
    setFormData({
      name: '',
      quantity: '1',
      unit: '',
      category: 'Other',
      expirationDate: '',
      notes: '',
    });
    setAddDialogVisible(false);
  };
  
  // Handler for updating an item
  const updateItem = () => {
    if (!selectedItemId || !formData.name) return;
    
    const updatedItems = items.map(item => {
      if (item.id === selectedItemId) {
        return {
          ...item,
          name: formData.name,
          nameAr: formData.name, // In a real app, this would be translated
          category: formData.category,
          categoryAr: formData.category, // In a real app, this would be translated
          quantity: formData.quantity,
          unit: formData.unit,
          expirationDate: formData.expirationDate ? new Date(formData.expirationDate) : null,
          notes: formData.notes,
        };
      }
      return item;
    });
    
    setItems(updatedItems);
    setEditDialogVisible(false);
    setSelectedItemId(null);
  };
  
  // Handler for deleting an item
  const deleteItem = () => {
    if (!selectedItemId) return;
    
    const updatedItems = items.filter(item => item.id !== selectedItemId);
    setItems(updatedItems);
    setConfirmDeleteVisible(false);
    setSelectedItemId(null);
  };
  
  // Handler for starting to edit an item
  const startEditingItem = (item: PantryItem) => {
    setSelectedItemId(item.id);
    setFormData({
      name: item.name,
      quantity: item.quantity,
      unit: item.unit,
      category: item.category,
      expirationDate: item.expirationDate ? item.expirationDate.toISOString().split('T')[0] : '',
      notes: item.notes,
    });
    setEditDialogVisible(true);
    setItemMenuVisible(null);
  };
  
  // Handler for adding item to shopping list
  const addToShoppingList = (item: PantryItem) => {
    // This would typically make an API call to add the item to the shopping list
    Alert.alert(t('success'), `${item.name} ${t('addedToShoppingList')}`);
    setItemMenuVisible(null);
  };
  
  // Filter items based on search query and selected filters
  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !categoryFilter || item.category === categoryFilter;
    
    let matchesExpiration = true;
    if (expirationFilter === 'soon') {
      const today = new Date();
      const inTwoWeeks = new Date();
      inTwoWeeks.setDate(today.getDate() + 14);
      matchesExpiration = item.expirationDate !== null && 
                          item.expirationDate > today && 
                          item.expirationDate < inTwoWeeks;
    } else if (expirationFilter === 'expired') {
      const today = new Date();
      matchesExpiration = item.expirationDate !== null && item.expirationDate < today;
    }
    
    return matchesSearch && matchesCategory && matchesExpiration;
  });
  
  // Sort items based on sort type
  const sortedItems = [...filteredItems].sort((a, b) => {
    if (sortType === 'expiringSoon') {
      if (!a.expirationDate) return 1;
      if (!b.expirationDate) return -1;
      return a.expirationDate.getTime() - b.expirationDate.getTime();
    } else if (sortType === 'recentlyAdded') {
      return b.addedDate.getTime() - a.addedDate.getTime();
    } else if (sortType === 'alphabetical') {
      return a.name.localeCompare(b.name);
    }
    return 0;
  });
  
  // Format date for display
  const formatDate = (date: Date | null) => {
    if (!date) return t('noExpirationDate');
    return date.toLocaleDateString();
  };
  
  // Calculate days until expiration
  const getDaysUntilExpiration = (date: Date | null) => {
    if (!date) return null;
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const expiryDate = new Date(date);
    expiryDate.setHours(0, 0, 0, 0);
    
    const diffTime = expiryDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };
  
  // Get expiration status text and color
  const getExpirationStatus = (date: Date | null) => {
    if (!date) return { text: t('noExpiration'), color: COLORS.gray };
    
    const days = getDaysUntilExpiration(date);
    
    if (days === null) return { text: t('noExpiration'), color: COLORS.gray };
    
    if (days < 0) return { text: t('expired'), color: COLORS.error };
    if (days === 0) return { text: t('expiringToday'), color: COLORS.warning };
    if (days <= 2) return { text: `${t('expiresSoon')}: ${days} ${t('days')}`, color: COLORS.warning };
    if (days <= 7) return { text: `${days} ${t('days')}`, color: COLORS.info };
    
    return { text: formatDate(date), color: COLORS.gray };
  };
  
  // Request camera permissions
  const requestCameraPermission = async () => {
    const { status } = await Camera.requestCameraPermissionsAsync();
    setCameraPermission(status === 'granted');
    
    if (status === 'granted') {
      setCameraVisible(true);
    } else {
      Alert.alert(
        t('cameraPermissionRequired'),
        t('pleaseGrantCameraPermission'),
        [{ text: t('ok') }]
      );
    }
  };
  
  // Take a photo
  const takePhoto = async () => {
    if (cameraRef.current) {
      try {
        const photo = await cameraRef.current.takePictureAsync();
        setCameraVisible(false);
        
        // In a real app, we would process the photo here to extract product info
        // For now, just simulate successful processing
        setTimeout(() => {
          Alert.alert(
            t('photoProcessed'),
            t('itemInfoExtracted'),
            [
              {
                text: t('addToInventory'),
                onPress: () => {
                  // Simulate adding a detected item
                  const newItem: PantryItem = {
                    id: Math.random().toString(36).substring(2, 9),
                    name: 'Detected Product',
                    nameAr: 'منتج مكتشف',
                    category: 'Other',
                    categoryAr: 'أخرى',
                    quantity: '1',
                    unit: 'pcs',
                    expirationDate: new Date(new Date().setDate(new Date().getDate() + 30)),
                    addedDate: new Date(),
                    notes: t('detectedViaCamera'),
                  };
                  
                  setItems([...items, newItem]);
                }
              },
              {
                text: t('cancel'),
                style: 'cancel',
              }
            ]
          );
        }, 2000);
      } catch (error) {
        console.error('Error taking photo:', error);
        Alert.alert(t('error'), t('failedToTakePhoto'));
      }
    }
  };
  
  // Pick an image from the gallery
  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 1,
      });
      
      if (!result.canceled) {
        // In a real app, we would process the image here to extract product info
        // For now, just simulate successful processing
        setTimeout(() => {
          Alert.alert(
            t('imageProcessed'),
            t('itemInfoExtracted'),
            [
              {
                text: t('addToInventory'),
                onPress: () => {
                  // Simulate adding a detected item
                  const newItem: PantryItem = {
                    id: Math.random().toString(36).substring(2, 9),
                    name: 'Gallery Product',
                    nameAr: 'منتج من المعرض',
                    category: 'Other',
                    categoryAr: 'أخرى',
                    quantity: '1',
                    unit: 'pcs',
                    expirationDate: new Date(new Date().setDate(new Date().getDate() + 30)),
                    addedDate: new Date(),
                    notes: t('detectedViaGallery'),
                  };
                  
                  setItems([...items, newItem]);
                }
              },
              {
                text: t('cancel'),
                style: 'cancel',
              }
            ]
          );
        }, 2000);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert(t('error'), t('failedToPickImage'));
    }
  };
  
  // Scan invoice
  const scanInvoice = () => {
    setIsScanning(true);
    
    // Simulate invoice scanning process
    setTimeout(() => {
      setIsScanning(false);
      
      Alert.alert(
        t('invoiceScanned'),
        t('itemsDetectedInInvoice'),
        [
          {
            text: t('addAllToInventory'),
            onPress: () => {
              // Simulate adding multiple detected items
              const newItems: PantryItem[] = [
                {
                  id: Math.random().toString(36).substring(2, 9),
                  name: 'Bread',
                  nameAr: 'خبز',
                  category: 'Grains',
                  categoryAr: 'حبوب',
                  quantity: '1',
                  unit: 'pcs',
                  expirationDate: new Date(new Date().setDate(new Date().getDate() + 5)),
                  addedDate: new Date(),
                  notes: t('fromInvoice'),
                },
                {
                  id: Math.random().toString(36).substring(2, 9),
                  name: 'Eggs',
                  nameAr: 'بيض',
                  category: 'Dairy',
                  categoryAr: 'ألبان',
                  quantity: '12',
                  unit: 'pcs',
                  expirationDate: new Date(new Date().setDate(new Date().getDate() + 14)),
                  addedDate: new Date(),
                  notes: t('fromInvoice'),
                },
                {
                  id: Math.random().toString(36).substring(2, 9),
                  name: 'Apples',
                  nameAr: 'تفاح',
                  category: 'Fruits',
                  categoryAr: 'فواكه',
                  quantity: '1',
                  unit: 'kg',
                  expirationDate: new Date(new Date().setDate(new Date().getDate() + 10)),
                  addedDate: new Date(),
                  notes: t('fromInvoice'),
                }
              ];
              
              setItems([...items, ...newItems]);
            }
          },
          {
            text: t('cancel'),
            style: 'cancel',
          }
        ]
      );
    }, 3000);
  };
  
  const renderItem = ({ item }: { item: PantryItem }) => {
    const expirationStatus = getExpirationStatus(item.expirationDate);
    
    return (
      <Card style={styles.itemCard} mode="outlined">
        <Card.Content>
          <View style={styles.itemHeader}>
            <View>
              <Title style={styles.itemTitle}>
                {language === 'ar' ? item.nameAr : item.name}
              </Title>
              <Chip 
                style={[
                  styles.categoryChip, 
                  { backgroundColor: COLORS.primaryLight }
                ]}
                textStyle={{ color: COLORS.primary, fontSize: 12 }}
              >
                {language === 'ar' ? item.categoryAr : item.category}
              </Chip>
            </View>
            
            <Menu
              visible={itemMenuVisible === item.id}
              onDismiss={() => setItemMenuVisible(null)}
              anchor={
                <IconButton
                  icon="dots-vertical"
                  size={20}
                  onPress={() => setItemMenuVisible(item.id)}
                />
              }
            >
              <Menu.Item
                leadingIcon="pencil"
                onPress={() => startEditingItem(item)}
                title={t('edit')}
              />
              <Menu.Item
                leadingIcon="cart-plus"
                onPress={() => addToShoppingList(item)}
                title={t('addToShoppingList')}
              />
              <Menu.Item
                leadingIcon="trash-can"
                onPress={() => {
                  setSelectedItemId(item.id);
                  setItemMenuVisible(null);
                  setConfirmDeleteVisible(true);
                }}
                title={t('delete')}
                titleStyle={{ color: COLORS.error }}
              />
            </Menu>
          </View>
          
          <View style={styles.itemDetails}>
            <View style={styles.itemDetail}>
              <Feather name="package" size={14} color={COLORS.gray} />
              <Text style={styles.itemDetailText}>
                {item.quantity} {item.unit}
              </Text>
            </View>
            
            <View style={styles.itemDetail}>
              <Feather name="calendar" size={14} color={expirationStatus.color} />
              <Text style={[styles.itemDetailText, { color: expirationStatus.color }]}>
                {expirationStatus.text}
              </Text>
            </View>
          </View>
          
          {item.notes ? (
            <Text style={styles.itemNotes}>{item.notes}</Text>
          ) : null}
        </Card.Content>
      </Card>
    );
  };
  
  return (
    <View style={styles.container}>
      {/* Camera View */}
      {cameraVisible && cameraPermission && (
        <View style={styles.cameraContainer}>
          <Camera
            style={styles.camera}
            ref={cameraRef}
            type={Camera.Constants.Type.back}
          >
            <View style={styles.cameraOverlay}>
              <View style={styles.cameraControls}>
                <IconButton
                  icon="close"
                  iconColor={COLORS.white}
                  size={30}
                  onPress={() => setCameraVisible(false)}
                  style={styles.cameraButton}
                />
                <IconButton
                  icon="camera"
                  iconColor={COLORS.white}
                  size={40}
                  onPress={takePhoto}
                  style={[styles.cameraButton, styles.cameraShutterButton]}
                />
                <View style={{ width: 40 }} />
              </View>
            </View>
          </Camera>
        </View>
      )}
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t('smartPantry')}</Text>
        
        <View style={styles.headerActions}>
          <IconButton
            icon="camera"
            size={24}
            onPress={requestCameraPermission}
          />
          <IconButton
            icon="image"
            size={24}
            onPress={pickImage}
          />
          <IconButton
            icon="file-document"
            size={24}
            onPress={scanInvoice}
            disabled={isScanning}
          />
        </View>
      </View>
      
      {/* Search and Filter Section */}
      <View style={styles.searchFilterContainer}>
        <Searchbar
          placeholder={t('searchItems')}
          onChangeText={setSearchQuery}
          value={searchQuery}
          style={styles.searchbar}
          icon="magnify"
          clearIcon="close"
        />
        
        <View style={styles.filterActions}>
          <Menu
            visible={sortMenuVisible}
            onDismiss={() => setSortMenuVisible(false)}
            anchor={
              <Button
                mode="outlined"
                icon="sort"
                onPress={() => setSortMenuVisible(true)}
                style={styles.filterButton}
                compact
              >
                {t('sortBy')}
              </Button>
            }
          >
            <Menu.Item
              leadingIcon={sortType === 'expiringSoon' ? 'check' : undefined}
              onPress={() => {
                setSortType('expiringSoon');
                setSortMenuVisible(false);
              }}
              title={t('expiringSoon')}
              titleStyle={
                sortType === 'expiringSoon' ? { color: COLORS.primary } : undefined
              }
            />
            <Menu.Item
              leadingIcon={sortType === 'recentlyAdded' ? 'check' : undefined}
              onPress={() => {
                setSortType('recentlyAdded');
                setSortMenuVisible(false);
              }}
              title={t('recentlyAdded')}
              titleStyle={
                sortType === 'recentlyAdded' ? { color: COLORS.primary } : undefined
              }
            />
            <Menu.Item
              leadingIcon={sortType === 'alphabetical' ? 'check' : undefined}
              onPress={() => {
                setSortType('alphabetical');
                setSortMenuVisible(false);
              }}
              title={t('alphabetical')}
              titleStyle={
                sortType === 'alphabetical' ? { color: COLORS.primary } : undefined
              }
            />
          </Menu>
          
          <Menu
            visible={filterMenuVisible}
            onDismiss={() => setFilterMenuVisible(false)}
            anchor={
              <Button
                mode="outlined"
                icon="filter"
                onPress={() => setFilterMenuVisible(true)}
                style={styles.filterButton}
                compact
              >
                {t('filter')}
              </Button>
            }
          >
            <View style={styles.filterMenuContent}>
              <Text style={styles.filterMenuTitle}>{t('categoryFilter')}</Text>
              <Menu.Item
                leadingIcon={!categoryFilter ? 'check' : undefined}
                onPress={() => {
                  setCategoryFilter(null);
                }}
                title={t('allCategories')}
                titleStyle={
                  !categoryFilter ? { color: COLORS.primary } : undefined
                }
              />
              <Divider />
              {FOOD_CATEGORIES.map((category) => (
                <Menu.Item
                  key={category.id}
                  leadingIcon={categoryFilter === category.name ? 'check' : undefined}
                  onPress={() => {
                    setCategoryFilter(category.name);
                  }}
                  title={language === 'ar' ? category.nameAr : category.name}
                  titleStyle={
                    categoryFilter === category.name
                      ? { color: COLORS.primary }
                      : undefined
                  }
                />
              ))}
              
              <Divider />
              <Text style={styles.filterMenuTitle}>{t('expirationFilter')}</Text>
              <Menu.Item
                leadingIcon={!expirationFilter ? 'check' : undefined}
                onPress={() => {
                  setExpirationFilter(null);
                  setFilterMenuVisible(false);
                }}
                title={t('all')}
                titleStyle={
                  !expirationFilter ? { color: COLORS.primary } : undefined
                }
              />
              <Menu.Item
                leadingIcon={expirationFilter === 'soon' ? 'check' : undefined}
                onPress={() => {
                  setExpirationFilter('soon');
                  setFilterMenuVisible(false);
                }}
                title={t('expiringSoon')}
                titleStyle={
                  expirationFilter === 'soon' ? { color: COLORS.primary } : undefined
                }
              />
              <Menu.Item
                leadingIcon={expirationFilter === 'expired' ? 'check' : undefined}
                onPress={() => {
                  setExpirationFilter('expired');
                  setFilterMenuVisible(false);
                }}
                title={t('expired')}
                titleStyle={
                  expirationFilter === 'expired' ? { color: COLORS.primary } : undefined
                }
              />
            </View>
          </Menu>
        </View>
        
        {/* Active Filters Display */}
        {(categoryFilter || expirationFilter) && (
          <View style={styles.activeFilters}>
            {categoryFilter && (
              <Chip
                mode="outlined"
                icon="close"
                onPress={() => setCategoryFilter(null)}
                style={styles.filterChip}
              >
                {language === 'ar' 
                  ? FOOD_CATEGORIES.find(c => c.name === categoryFilter)?.nameAr || categoryFilter
                  : categoryFilter
                }
              </Chip>
            )}
            {expirationFilter === 'soon' && (
              <Chip
                mode="outlined"
                icon="close"
                onPress={() => setExpirationFilter(null)}
                style={styles.filterChip}
              >
                {t('expiringSoon')}
              </Chip>
            )}
            {expirationFilter === 'expired' && (
              <Chip
                mode="outlined"
                icon="close"
                onPress={() => setExpirationFilter(null)}
                style={styles.filterChip}
              >
                {t('expired')}
              </Chip>
            )}
          </View>
        )}
      </View>
      
      {/* Items List */}
      {isScanning ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>{t('scanningInvoice')}</Text>
        </View>
      ) : (
        <FlatList
          data={sortedItems}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                {searchQuery 
                  ? t('noItemsMatchSearch') 
                  : categoryFilter 
                    ? t('noItemsInCategory')
                    : t('noPantryItems')}
              </Text>
              <Button 
                mode="contained" 
                onPress={() => setAddDialogVisible(true)}
                style={styles.emptyButton}
              >
                {t('addFirstItem')}
              </Button>
            </View>
          }
        />
      )}
      
      {/* FAB */}
      <FAB
        style={styles.fab}
        icon="plus"
        onPress={() => setAddDialogVisible(true)}
      />
      
      {/* Add Item Dialog */}
      <Portal>
        <Dialog
          visible={addDialogVisible}
          onDismiss={() => setAddDialogVisible(false)}
          style={styles.dialog}
        >
          <Dialog.Title>{t('addNewItem')}</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label={t('itemName')}
              value={formData.name}
              onChangeText={(text) => setFormData({ ...formData, name: text })}
              style={styles.input}
            />
            
            <View style={styles.formRow}>
              <TextInput
                label={t('quantity')}
                value={formData.quantity}
                onChangeText={(text) => setFormData({ ...formData, quantity: text })}
                keyboardType="numeric"
                style={[styles.input, styles.halfInput]}
              />
              
              <View style={[styles.halfInput, { marginLeft: 8 }]}>
                <TextInput
                  label={t('unit')}
                  value={formData.unit}
                  onChangeText={(text) => setFormData({ ...formData, unit: text })}
                  style={styles.input}
                />
              </View>
            </View>
            
            <View style={styles.selectContainer}>
              <Text style={styles.selectLabel}>{t('category')}</Text>
              <Menu
                visible={!!formData.category && formData.category === 'SELECTING'}
                onDismiss={() => setFormData({ ...formData, category: formData.category === 'SELECTING' ? 'Other' : formData.category })}
                anchor={
                  <TouchableOpacity
                    style={styles.selectButton}
                    onPress={() => setFormData({ ...formData, category: 'SELECTING' })}
                  >
                    <Text>
                      {formData.category !== 'SELECTING' ? formData.category : t('selectCategory')}
                    </Text>
                    <Feather name="chevron-down" size={16} />
                  </TouchableOpacity>
                }
              >
                {FOOD_CATEGORIES.map((category) => (
                  <Menu.Item
                    key={category.id}
                    onPress={() => setFormData({ ...formData, category: category.name })}
                    title={language === 'ar' ? category.nameAr : category.name}
                  />
                ))}
              </Menu>
            </View>
            
            <View style={styles.datePickerContainer}>
              <Text style={styles.selectLabel}>{t('expirationDate')}</Text>
              <TextInput
                value={formData.expirationDate}
                onChangeText={(text) => setFormData({ ...formData, expirationDate: text })}
                placeholder="YYYY-MM-DD"
                keyboardType="numeric"
                style={styles.input}
              />
            </View>
            
            <TextInput
              label={t('notes')}
              value={formData.notes}
              onChangeText={(text) => setFormData({ ...formData, notes: text })}
              multiline
              numberOfLines={2}
              style={[styles.input, styles.notesInput]}
            />
            
            <View style={styles.cameraOptions}>
              <Button
                mode="outlined"
                icon="camera"
                onPress={requestCameraPermission}
                style={styles.cameraOption}
              >
                {t('takePhoto')}
              </Button>
              
              <Button
                mode="outlined"
                icon="file-document"
                onPress={scanInvoice}
                style={styles.cameraOption}
                loading={isScanning}
              >
                {isScanning ? t('scanning') : t('scanInvoice')}
              </Button>
            </View>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setAddDialogVisible(false)}>{t('cancel')}</Button>
            <Button onPress={addItem}>{t('add')}</Button>
          </Dialog.Actions>
        </Dialog>
        
        {/* Edit Item Dialog */}
        <Dialog
          visible={editDialogVisible}
          onDismiss={() => setEditDialogVisible(false)}
          style={styles.dialog}
        >
          <Dialog.Title>{t('editItem')}</Dialog.Title>
          <Dialog.Content>
            <TextInput
              label={t('itemName')}
              value={formData.name}
              onChangeText={(text) => setFormData({ ...formData, name: text })}
              style={styles.input}
            />
            
            <View style={styles.formRow}>
              <TextInput
                label={t('quantity')}
                value={formData.quantity}
                onChangeText={(text) => setFormData({ ...formData, quantity: text })}
                keyboardType="numeric"
                style={[styles.input, styles.halfInput]}
              />
              
              <View style={[styles.halfInput, { marginLeft: 8 }]}>
                <TextInput
                  label={t('unit')}
                  value={formData.unit}
                  onChangeText={(text) => setFormData({ ...formData, unit: text })}
                  style={styles.input}
                />
              </View>
            </View>
            
            <View style={styles.selectContainer}>
              <Text style={styles.selectLabel}>{t('category')}</Text>
              <Menu
                visible={!!formData.category && formData.category === 'SELECTING'}
                onDismiss={() => setFormData({ ...formData, category: formData.category === 'SELECTING' ? 'Other' : formData.category })}
                anchor={
                  <TouchableOpacity
                    style={styles.selectButton}
                    onPress={() => setFormData({ ...formData, category: 'SELECTING' })}
                  >
                    <Text>
                      {formData.category !== 'SELECTING' ? formData.category : t('selectCategory')}
                    </Text>
                    <Feather name="chevron-down" size={16} />
                  </TouchableOpacity>
                }
              >
                {FOOD_CATEGORIES.map((category) => (
                  <Menu.Item
                    key={category.id}
                    onPress={() => setFormData({ ...formData, category: category.name })}
                    title={language === 'ar' ? category.nameAr : category.name}
                  />
                ))}
              </Menu>
            </View>
            
            <View style={styles.datePickerContainer}>
              <Text style={styles.selectLabel}>{t('expirationDate')}</Text>
              <TextInput
                value={formData.expirationDate}
                onChangeText={(text) => setFormData({ ...formData, expirationDate: text })}
                placeholder="YYYY-MM-DD"
                keyboardType="numeric"
                style={styles.input}
              />
            </View>
            
            <TextInput
              label={t('notes')}
              value={formData.notes}
              onChangeText={(text) => setFormData({ ...formData, notes: text })}
              multiline
              numberOfLines={2}
              style={[styles.input, styles.notesInput]}
            />
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setEditDialogVisible(false)}>{t('cancel')}</Button>
            <Button onPress={updateItem}>{t('update')}</Button>
          </Dialog.Actions>
        </Dialog>
        
        {/* Delete Confirmation Dialog */}
        <Dialog
          visible={confirmDeleteVisible}
          onDismiss={() => setConfirmDeleteVisible(false)}
        >
          <Dialog.Title>{t('confirmDelete')}</Dialog.Title>
          <Dialog.Content>
            <Text>{t('deleteItemConfirm')}</Text>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => setConfirmDeleteVisible(false)}>{t('cancel')}</Button>
            <Button onPress={deleteItem} textColor={COLORS.error}>{t('delete')}</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingTop: SPACING.lg,
    paddingBottom: SPACING.sm,
    backgroundColor: COLORS.white,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.black,
  },
  headerActions: {
    flexDirection: 'row',
  },
  searchFilterContainer: {
    padding: SPACING.md,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.grayLight,
  },
  searchbar: {
    marginBottom: SPACING.sm,
    elevation: 0,
    backgroundColor: COLORS.grayLight,
  },
  filterActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  filterButton: {
    flex: 1,
    marginHorizontal: 4,
  },
  activeFilters: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: SPACING.sm,
  },
  filterChip: {
    marginRight: SPACING.xs,
    marginBottom: SPACING.xs,
  },
  filterMenuContent: {
    padding: SPACING.sm,
    width: 250,
  },
  filterMenuTitle: {
    fontWeight: 'bold',
    marginVertical: SPACING.xs,
  },
  listContainer: {
    padding: SPACING.md,
    paddingBottom: 80, // Space for FAB
  },
  itemCard: {
    marginBottom: SPACING.sm,
    backgroundColor: COLORS.white,
  },
  itemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  categoryChip: {
    alignSelf: 'flex-start',
    marginTop: 4,
    height: 24,
  },
  itemDetails: {
    flexDirection: 'row',
    marginTop: SPACING.xs,
    flexWrap: 'wrap',
  },
  itemDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: SPACING.md,
    marginBottom: 4,
  },
  itemDetailText: {
    fontSize: 14,
    color: COLORS.gray,
    marginLeft: 4,
  },
  itemNotes: {
    fontSize: 14,
    color: COLORS.grayDark,
    marginTop: SPACING.xs,
    fontStyle: 'italic',
  },
  fab: {
    position: 'absolute',
    right: SPACING.md,
    bottom: SPACING.xl,
    backgroundColor: COLORS.primary,
  },
  dialog: {
    maxHeight: '80%',
  },
  input: {
    marginBottom: SPACING.sm,
  },
  formRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  halfInput: {
    flex: 1,
  },
  selectContainer: {
    marginBottom: SPACING.sm,
  },
  selectLabel: {
    fontSize: 12,
    color: COLORS.gray,
    marginBottom: 4,
  },
  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
    borderWidth: 1,
    borderColor: COLORS.gray,
    borderRadius: 4,
  },
  datePickerContainer: {
    marginBottom: SPACING.sm,
  },
  notesInput: {
    height: 80,
  },
  cameraOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: SPACING.xs,
  },
  cameraOption: {
    flex: 1,
    marginHorizontal: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: SPACING.xl,
  },
  emptyText: {
    fontSize: 16,
    color: COLORS.gray,
    textAlign: 'center',
    marginBottom: SPACING.md,
  },
  emptyButton: {
    marginTop: SPACING.md,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: SPACING.md,
    color: COLORS.gray,
  },
  cameraContainer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 100,
  },
  camera: {
    flex: 1,
  },
  cameraOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'flex-end',
  },
  cameraControls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.xl,
    paddingHorizontal: SPACING.md,
  },
  cameraButton: {
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  cameraShutterButton: {
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderWidth: 2,
    borderColor: COLORS.white,
  },
});

export default SmartPantryScreen;